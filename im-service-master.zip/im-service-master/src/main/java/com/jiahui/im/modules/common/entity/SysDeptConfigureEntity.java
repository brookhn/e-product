package com.jiahui.im.modules.common.entity;

import lombok.Data;

import java.util.Date;

/**
 * 科室客服-科室配置表
 */
@Data
public class SysDeptConfigureEntity {

    private Long id;

    /**
     * 科室ID
     */
    private Long deptId;

    /**
     * 科室名称
     */
    private String deptName;

    /**
     * 科室头像
     */
    private String headUrl;

    /**
     * 是否消息置顶 0 否 1是
     */
    private Integer isMsgTop;

    /**
     * 消息置顶时间
     */
    private Integer msgTopMinute;

    /**
     * 是否自动退出 0 否 1是
     */
    private Integer isAutoExit;

    /**
     * 自动退出时间
     */
    private Integer autoExitMinute;

    /**
     * 自动退出消息
     */
    private String autoExitMsg;

    /**
     * 退出接待是否自动推送 0 否 1是
     */
    private Integer isAutoPush;

    /**
     * 退出接待消息
     */
    private String autoPushMsg;

    /**
     * 工作开始时间（小时）
     */
    private Integer workingStartTime;

    /**
     * 工作结束时间（小时）
     */
    private Integer workingEndTime;

    /**
     * 非工作时间是否自动回复 0-否 1-是
     */
    private Integer isNonworkingReply;

    /**
     * 非工作时间自动回复消息
     */
    private String nonworkingReplyMsg;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date updateTime;
}