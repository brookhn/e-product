package com.jiahui.im.util;

import com.jiahui.im.common.CodeMsg;
import com.jiahui.im.common.exception.BizException;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.Key;
import java.security.Security;

/**
 * @Desc 加密工具类
 * @Author linfei
 * @Date 2019/11/27 10:53
 **/
public class EncryptUtil {

    private static boolean initialized = false;

    /**
     * 请求参数加密
     *
     * @param key  加密KEY
     * @param iv   偏移量
     * @param data 加密数据
     * @return
     */
    public static byte[] cbcEncrypt(byte[] key, byte[] iv, byte[] data) {
        initialize();
        try {
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS7Padding");
            Key keySpec = new SecretKeySpec(key, "AES");
            IvParameterSpec ips = new IvParameterSpec(iv);
            cipher.init(Cipher.ENCRYPT_MODE, keySpec, ips);
            return cipher.doFinal(data);
        } catch (Exception e) {
            throw new BizException(CodeMsg.CBC_ENCRYPT_EXCEPTION);
        }
    }

    /**
     * 请求参数解码
     * @param data  加密数据
     * @param key   加密KEY
     * @param iv    偏移量
     * @return
     */
    public static String desEncrypt(byte[] data, byte[] key, byte[] iv) {
        initialize();
        try {
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS7Padding");
            Key keySpec = new SecretKeySpec(key, "AES");
            IvParameterSpec ips = new IvParameterSpec(iv);
            cipher.init(Cipher.DECRYPT_MODE, keySpec, ips);
            byte[] encrypted = cipher.doFinal(data);
            return new String(encrypted);
        } catch (Exception e) {
            throw new BizException(CodeMsg.DES_ENCRYPT_EXCEPTION);
        }
    }

    /**
     * java自带的是PKCS5Padding填充，不支持PKCS7Padding填充
     * 通过BouncyCastle组件来让java里面支持PKCS7Padding填充
     */
    private static void initialize() {
        if (initialized) {
            return;
        }
        Security.addProvider(new BouncyCastleProvider());
        initialized = true;
    }

    /**
     * 返回十六进制字符串
     *
     * @param arr
     * @return
     */
    public static String hex(byte[] arr) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < arr.length; ++i) {
            sb.append(Integer.toHexString((arr[i] & 0xFF) | 0x100).substring(1, 3));
        }
        return sb.toString();
    }
}
