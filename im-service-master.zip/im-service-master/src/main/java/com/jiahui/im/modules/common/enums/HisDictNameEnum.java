package com.jiahui.im.modules.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * HIS业务操作编码
 * @author Tommy
 * @date 2021/6/8
 */
@Getter
@AllArgsConstructor
public enum HisDictNameEnum {
	
	EPISODELIST("patientEpisodeDetail", "查询就诊记录列表"),
	
	PATIENT_INFO("patientInfo", "查询就诊人信息"),
	
	PATIENTCLINICREPORT("patientClinicReport", "查询时间段内的用户的就诊报告"),
	
	QUERYBILLDETAIL("queryBillDetail", "查询账单明细"),
	
	PATIENTAPPTLIST("patientApptDetail", "查询病人预约记录"),
	
	PREFERLANGUAGE("preferLanguage","查询语言"),
	
	IDTYPE("idType","查询证件类型"),
	
	COUNTRY("country","查询国籍"),
	
    SITE("site", "查询站点信息"),
    
    DEPT("dept", "查询科室信息"),
    
    DOCTOR("doctor", "查询医生信息"),
    ;

    /**
     * 业务操作编码
     */
    private final String code;

    /**
     * 业务操作编码描述
     */
    private final String desc;
    
}
