package com.jiahui.im.modules.ws.converter;

import com.jiahui.im.modules.ws.dto.kafka.notice.DisconnectReminderDto;
import com.jiahui.im.modules.ws.dto.kafka.notice.EndReceptDto;
import com.jiahui.im.modules.ws.dto.kafka.notice.RankingDto;
import com.jiahui.im.modules.ws.dto.kafka.notice.ReceivedDto;
import com.jiahui.im.modules.ws.dto.kafka.notice.UserEndRankDto;
import com.jiahui.im.modules.ws.vo.notice.DisconnectReminderOut;
import com.jiahui.im.modules.ws.vo.notice.EndReceptOut;
import com.jiahui.im.modules.ws.vo.notice.RankingOut;
import com.jiahui.im.modules.ws.vo.notice.ReceivedOut;
import com.jiahui.im.modules.ws.vo.notice.UserEndRankOut;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @author Tommy
 * @date 2022/1/21
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface NoticeConverter {

    NoticeConverter INSTANCE = Mappers.getMapper(NoticeConverter.class);

    ReceivedOut receivedDto2Out(ReceivedDto dto);

    RankingOut rankingDto2Out(RankingDto dto);

    EndReceptOut pushEvaluateDto2Out(EndReceptDto dto);

    DisconnectReminderOut disconnectReminderDto2Out(DisconnectReminderDto dto);

    UserEndRankOut userEndRankDto2Out(UserEndRankDto dto);
}