package com.jiahui.im.modules.ws.enums;

import com.google.common.collect.Maps;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Map;

/**
 * 服务端操作指令枚举
 * @author Tommy
 * @date 2021/8/2
 */
@Getter
@AllArgsConstructor
public enum ServerActionEnum {

    CHAT("chat", "聊天"),
    NOTICE("notice", "通知"),
    ;

    /**
     * 指令类型
     */
    private final String action;

    /**
     * 指令描述
     */
    private final String desc;

    public static final Map<String, ServerActionEnum> map = Maps.newHashMap();

    static {
        for (ServerActionEnum e : ServerActionEnum.values()) {
            map.put(e.getAction(), e);
        }
    }

    public static ServerActionEnum fromAction(String action) {
        return map.get(action);
    }
}
