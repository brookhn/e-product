package com.jiahui.im.config.properties;

import cn.hutool.core.codec.Base64Encoder;
import com.google.common.collect.Maps;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;
import java.util.Map;

/**
 * @author Tommy
 * @date 2021/6/10
 */
@Data
@Configuration
@ConfigurationProperties(prefix = "his")
public class HisProperties {

    /**
     * 认证信息
     */
    private Auth auth;

    /**
     * HIS主数据相关
     */
    private String dictUrl;

    /**
     * 患者相关
     */
    private String patientUrl;

    /**
     * 预约相关
     */
    private String apptUrl;

    @Data
    public static class Auth {

        /**
         * 用户名
         */
        private String userName;

        /**
         * 密码
         */
        private String password;

        /**
         * 认证header
         */
        private Map<String, String> headerMap = Maps.newHashMap();
    }

    @PostConstruct
    private void init() {
        String token = "Basic " + Base64Encoder.encode(auth.getUserName() + ":" + auth.getPassword());
        auth.headerMap.put("Authorization", token);
    }
}
