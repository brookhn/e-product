package com.jiahui.im.modules.ws.dto.kafka.kefu;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 科室客服-待接待人数变更
 * @author Tommy
 * @date 2021/8/11
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DeptUnreceptNumDto {

	/**
	 * 通知类型
	 */
	private Integer noticeType;

    /**
     * 科室ID
	 */
	private Long deptId;

	/**
	 * 待接待人数
	 */
	private Integer unreceptNum;
}
