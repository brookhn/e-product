package com.jiahui.im.modules.common.mapper;

import com.jiahui.im.modules.common.entity.CcUserUnboundEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface CcUserUnboundMapper {
    int deleteByPrimaryKey(Long id);

    int insert(CcUserUnboundEntity record);

    int insertSelective(CcUserUnboundEntity record);

    CcUserUnboundEntity selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(CcUserUnboundEntity record);

    int updateByPrimaryKey(CcUserUnboundEntity record);

    /**
     * 根据唯一索引查询
     * @param userId
     * @return
     */
    CcUserUnboundEntity selectByUk(@Param("userId") Long userId);

    /**
     * 查询未绑定用户量
     * @return
     */
    int count();

    /**
     * 获取用户排名
     * @param userId
     * @return
     */
    int getRanking(Long userId);

    /**
     * 根据唯一索引删除
     * @param userId
     * @return
     */
    int deleteByUk(Long userId);

    /**
     * 查询下限id后面的排名信息
     * @param lowerId
     * @return
     */
    List<CcUserUnboundEntity> selectRankByLowerId(Long lowerId);
}