package com.jiahui.im.common;

import com.github.pagehelper.PageInfo;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Collections;
import java.util.List;

/**
 * 返回分页类
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class PageOut<T> {

    /**
     * 页码
     */
    private int pageNo;

    /**
     * 每页显示的数据条数
     */
    private int pageSize;

    /**
     * 总数据条数
     */
    private int totalCount;

    /**
     * 当前页数据
     */
    private List<T> rows = Collections.emptyList();

    public PageOut(int totalCount) {
        this.totalCount = totalCount;
    }

    public PageOut(Long totalCount) {
        this.totalCount = Long.valueOf(totalCount).intValue();
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    public void setTotalCount(Long totalCount) {
        this.totalCount = Long.valueOf(totalCount).intValue();
    }

    public PageOut(int pageNo, int pageSize) {
        this.pageNo = pageNo;
        this.pageSize = pageSize;
    }

    public PageOut(PageInfo<T> pageInfo) {
        this.pageNo = pageInfo.getPageNum();
        this.pageSize = pageInfo.getPageSize();
        this.totalCount = Long.valueOf(pageInfo.getTotal()).intValue();
    }
}
