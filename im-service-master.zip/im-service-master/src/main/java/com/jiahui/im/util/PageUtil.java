package com.jiahui.im.util;

import java.util.ArrayList;
import java.util.List;

import com.github.pagehelper.PageInfo;

public class PageUtil {

    /**
     * 手动分页类
     * @param datas
     * @param pageSize
     * @param pageNum
     * @param <T>
     * @return
     */
    public static <T> PageInfo<T> getPageInfo(List<T> datas,int pageSize,int pageNum){
        List<T> pageList = getPageList(datas, pageSize, pageNum);
        PageInfo<T> pageInfo = new PageInfo<>(pageList);
        pageInfo.setTotal(datas.size());
        pageInfo.setPageNum(pageNum);
        pageInfo.setPageSize(pageSize);
        return pageInfo;
    }
    public static <T> List<T> getPageList(List<T> datas,int pageSize,int pageNum){
        int startNum = (pageNum-1)* pageSize+1 ;                     //起始截取数据位置
        if(startNum > datas.size()){
            return null;
        }
        List<T> res = new ArrayList<>();
        int rum = datas.size() - startNum;
        if(rum < 0){
            return null;
        }
        if(rum == 0){                                               //说明正好是最后一个了
            int index = datas.size() -1;
            res.add(datas.get(index));
            return res;
        }
        if(rum / pageSize >= 1){                                    //剩下的数据还够1页，返回整页的数据
            for(int i=startNum;i<startNum + pageSize;i++){          //截取从startNum开始的数据
                res.add(datas.get(i-1));
            }
            return res;
        }else if((rum / pageSize == 0) && rum > 0){                 //不够一页，直接返回剩下数据
            for(int j = startNum ;j<=datas.size();j++){
                res.add(datas.get(j-1));
            }
            return res;
        }else{
            return null;
        }
    }



}
