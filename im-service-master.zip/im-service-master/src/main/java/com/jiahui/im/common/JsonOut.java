package com.jiahui.im.common;

import com.jiahui.im.common.exception.BizException;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.ToString;

import java.util.Collections;
import java.util.Optional;

/**
 * 返回Json类
 */
@ApiModel(description = "响应对象")
@ToString
public class JsonOut<T> {
    @ApiModelProperty(value = "业务码", example = "200", required = true)
    private int code;
    @ApiModelProperty(value = "业务码描述", example = "成功", required = true)
    private String msg;
    @ApiModelProperty(value = "业务数据", example = "{}", required = true)
    private T data;

    public JsonOut() {
    }

    public JsonOut(CodeMsg codeMsg) {
        this.code = codeMsg.code();
        this.msg = codeMsg.msg();
    }

    public JsonOut(CodeMsg codeMsg, T data) {
        this.code = codeMsg.code();
        this.msg = codeMsg.msg();
        this.data = data;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public T getData() {
        return Optional.ofNullable(data).orElse((T) Collections.emptyMap());
    }

    public void setData(T data) {
        this.data = data;
    }

    public JsonOut(int status, String message) {
        this.code = status;
        this.msg = message;
    }

    public JsonOut(int status, String message, T data) {
        this.code = status;
        this.msg = message;
        this.data = data;
    }

    public static JsonOut ok() {
        return new JsonOut(CodeMsg.CODE_200);
    }

    public static <T> JsonOut<T> ok(T data) {
        return new JsonOut(CodeMsg.CODE_200, data);
    }

    public static JsonOut error(CodeMsg codeMsg) {
        return new JsonOut(codeMsg.getCode(), codeMsg.getMsg());
    }
    
    public static JsonOut error(int code,String msg) {
        return new JsonOut(code, msg);
    }

    public static JsonOut error(BizException e) {
        return new JsonOut(e.getCode(), e.getMsg(), e.getData());
    }
}
