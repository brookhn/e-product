package com.jiahui.im.modules.api.service;

import com.jiahui.im.modules.api.vo.login.LoginIn;
import com.jiahui.im.modules.api.vo.login.LoginOut;
import com.jiahui.im.modules.common.enums.KefuTypeEnum;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author Tommy
 * @date 2022/05/30
 */
@Service
@Log4j2
public class LoginService {

    @Autowired
    private DeptLoginService deptLoginService;

    @Autowired
    private CcLoginService ccLoginService;

    /**
     * 用户登录
     * @param loginIn
     * @return
     */
    public LoginOut login(LoginIn loginIn) {
        if (KefuTypeEnum.DEPT.getType().equals(loginIn.getKefuType())) {
            return deptLoginService.login(loginIn);
        }
        return ccLoginService.login(loginIn);
    }
}
