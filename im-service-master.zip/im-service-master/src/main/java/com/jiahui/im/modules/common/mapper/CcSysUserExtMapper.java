package com.jiahui.im.modules.common.mapper;

import com.jiahui.im.modules.common.dto.chat.CcReceptNumDto;
import com.jiahui.im.modules.common.entity.CcSysUserExtEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface CcSysUserExtMapper {
    int deleteByPrimaryKey(Long id);

    int insert(CcSysUserExtEntity record);

    int insertSelective(CcSysUserExtEntity record);

    CcSysUserExtEntity selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(CcSysUserExtEntity record);

    int updateByPrimaryKey(CcSysUserExtEntity record);

    /**
     * 查询可分配的客服（在线&接待量在上限以内），需要满足以下条件
     * - 部门：Call Center部门
     * - 分组：JIH-Call Center-中文、JIH-Call Center-EN
     * - 角色：JIH-PA CC-客服坐席
     * @param receptLimit 接待上限
     * @param eventTypeList
     * @return
     */
    List<CcReceptNumDto> selectAllocatable(@Param("receptLimit") Integer receptLimit, @Param("eventTypeList") List<Integer> eventTypeList);

    /**
     * 更新客服接待中数量
     * @param kefuId
     * @return
     */
    int incrReceivingNum(@Param("kefuId") Long kefuId, @Param("receptLimit") Integer receptLimit);

    /**
     * 更新客服接待中数量（自减）
     * @param kefuId
     * @return
     */
    int decrReceivingNum(@Param("kefuId") Long kefuId);
}