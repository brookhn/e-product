package com.jiahui.im.helper;

import cn.hutool.core.map.MapUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jiahui.im.common.CodeMsg;
import com.jiahui.im.common.exception.BizException;
import com.jiahui.im.config.properties.BigFrontProperties;
import com.jiahui.im.config.properties.HisProperties;
import com.jiahui.im.constant.GlobalVar;
import com.jiahui.im.modules.common.dto.bigfront.BigFrontRespDto;
import com.jiahui.im.modules.common.dto.his.HisRespDto;
import com.jiahui.im.util.EncryptUtil;
import com.jiahui.im.util.JsonUtils;
import org.apache.commons.codec.binary.Base64;
import org.apache.logging.log4j.ThreadContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.Collections;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

/**
 * rest工具类
 * @author Tommy
 * @date 2021/6/11
 */
@Component
public class RestHelper {

    private static Logger log = LoggerFactory.getLogger(RestHelper.class);

    private static final long MAX_REQUEST_WAIT_TIME = 4000L;

    private static RestTemplate restTemplate;

    private static ObjectMapper objectMapper;

    private static BigFrontProperties bigFrontProperties;

    private static HisProperties hisProperties;

    @Autowired
    private void setRestTemplate(RestTemplate restTemplate) {
        RestHelper.restTemplate = restTemplate;
    }

    @Autowired
    private void setObjectMapper(ObjectMapper objectMapper) {
        RestHelper.objectMapper = objectMapper;
    }

    @Autowired
    private void setBigFrontProperties(BigFrontProperties bigFrontProperties) {
        RestHelper.bigFrontProperties = bigFrontProperties;
    }

    @Autowired
    public void setHisProperties(HisProperties hisProperties) {
        RestHelper.hisProperties = hisProperties;
    }

    /**
     * post请求携带表单数据
     * @param url
     * @param paramMap
     * @param headerMap
     * @param typeReference
     * @param <T>
     * @return
     */
    public static <T> T doFormPost(String url, MultiValueMap<String, Object> paramMap, Map<String, String> headerMap, ParameterizedTypeReference<T> typeReference) {
        try {
            //设置请求头
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
            headers.add(GlobalVar.USER_ID, ThreadContext.get(GlobalVar.USER_ID));
            headers.add(GlobalVar.SRC, ThreadContext.get(GlobalVar.SRC));
            if (MapUtil.isNotEmpty(headerMap)) {
                headerMap.forEach((k, v) -> headers.add(k, v));
            }

            long beginTime = System.currentTimeMillis();
            paramMap = Optional.ofNullable(paramMap).orElse(new LinkedMultiValueMap<>());
            HttpEntity<MultiValueMap> httpEntity = new HttpEntity<>(paramMap, headers);
            ResponseEntity<T> rss = restTemplate.exchange(url, HttpMethod.POST, httpEntity, typeReference);
            long spendtime = System.currentTimeMillis() - beginTime;
            String payload = JSON.toJSONString(paramMap);
            String result = String.format("RestHelper.doFormPost::request:%s,cost:%dms,payload:%s,reponse:%s", url, spendtime, payload, rss.getBody());
            if (spendtime > MAX_REQUEST_WAIT_TIME) {
                log.warn(result);
            } else {
                log.info(result);
            }
            if (rss.getStatusCode().equals(HttpStatus.OK)) {
                return rss.getBody();
            } else {
                log.error("RestHelper.doFormPost::failed to request:{},param:{},httpstatus:{},repsBody:{}", url, payload, rss.getStatusCode(), rss.getBody());
                throw new BizException(CodeMsg.NETWORK_EXCEPTION);
            }
        } catch (HttpStatusCodeException e) {
            // 4xx和5xx的错误打印状态码
            log.error("RestHelper.doFormPost::failed to request:{},param:{},httpstatus:{},repsBody:{}", url, paramMap, e.getStatusCode().value(), e.getResponseBodyAsString(), e);
            throw new BizException(CodeMsg.NETWORK_EXCEPTION);
        } catch (Exception e) {
            log.error("RestHelper.doFormPost::failed to request:{},param:{}", url, paramMap, e);
            throw new BizException(CodeMsg.NETWORK_EXCEPTION);
        }
    }

    /**
     * post请求携带表单数据
     * 大前端加密接口
     * @param url
     * @param paramObj
     * @param typeReference
     * @param <T>
     * @return
     */
    public static <T> T doFormPostWithEncrypt(String url, Object paramObj, TypeReference<T> typeReference) {
        String payload = (paramObj instanceof String) ? (String) paramObj : JSON.toJSONString(paramObj);
        // 参数加密
        byte[] bytes = EncryptUtil.cbcEncrypt(bigFrontProperties.getEncryptKey().getBytes(), bigFrontProperties.getEncryptIv().getBytes(), payload.getBytes());
        String data = Base64.encodeBase64String(bytes);
        MultiValueMap<String, Object> paramMap = new LinkedMultiValueMap<>();
        paramMap.add("params", data);
        // 发起请求
        Map<String, String> headerMap = bigFrontProperties.getAuthMap();
        BigFrontRespDto<String> resDto = RestHelper.doFormPost(url, paramMap, headerMap, new ParameterizedTypeReference<BigFrontRespDto<String>>() {});
        if (!Objects.equals(0, resDto.getCode())) {
            throw new BizException(CodeMsg.BIG_FRONT_EXCEPTION.getCode(), resDto.getMsg());
        }
        // 解密返回数据
        String secretData = resDto.getData();
        if (StrUtil.isBlank(secretData)) {
            return null;
        }
        byte[] decodeBytes = Base64.decodeBase64(secretData.getBytes());
        String desData = EncryptUtil.desEncrypt(decodeBytes, bigFrontProperties.getEncryptKey().getBytes(), bigFrontProperties.getEncryptIv().getBytes());
        try {
            // 反序列化
            return objectMapper.readValue(desData, typeReference);
        } catch (IOException e) {
            log.error("parse json error", e);
        }
        return null;
    }

    /**
     * post请求
     * @param url
     * @param payload
     * @param headerMap
     * @return
     */
    public static String doPost(String url, String payload, Map<String, String> headerMap) {
        try {
            //设置请求头
            HttpHeaders headers = new HttpHeaders();
            MediaType type = MediaType.parseMediaType(MediaType.APPLICATION_JSON_UTF8_VALUE);
            headers.setContentType(type);
            headers.add("Accept", MediaType.APPLICATION_JSON_UTF8_VALUE);
            headers.add(GlobalVar.USER_ID, ThreadContext.get(GlobalVar.USER_ID) );
            headers.add(GlobalVar.SRC, ThreadContext.get(GlobalVar.SRC));
            if (MapUtil.isNotEmpty(headerMap)) {
                headerMap.forEach((k, v) -> headers.add(k, v));
            }

            long beginTime = System.currentTimeMillis();
            HttpEntity<String> formEntity = new HttpEntity<>(payload, headers);
            ResponseEntity<String> rss = restTemplate.exchange(url, HttpMethod.POST, formEntity, String.class);
            long spendtime = System.currentTimeMillis() - beginTime;
            String result = String.format("RestHelper.doPost::request:%s,cost:%dms,payload:%s,reponse:%s", url, spendtime, payload, rss.getBody());
            if (spendtime > MAX_REQUEST_WAIT_TIME) {
                log.warn(result);
            } else {
                log.info(result);
            }
            if (rss.getStatusCode().equals(HttpStatus.OK)) {
                return rss.getBody();
            } else {
                log.error("RestHelper.doPost::failed to request:{},param:{},httpstatus:{},repsBody:{}", url, payload, rss.getStatusCode(), rss.getBody());
                throw new BizException(CodeMsg.NETWORK_EXCEPTION);
            }
        } catch (HttpStatusCodeException e) {
            // 4xx和5xx的错误打印状态码
            log.error("RestHelper.doPost::failed to request:{},param:{},httpstatus:{},repsBody:{}", url, payload, e.getStatusCode().value(), e.getResponseBodyAsString(), e);
            throw new BizException(CodeMsg.NETWORK_EXCEPTION);
        } catch (Exception e) {
            log.error("RestHelper.doPost::failed to request:{},param:{}", url, payload, e);
            throw new BizException(CodeMsg.NETWORK_EXCEPTION);
        }
    }

    /**
     * 适用出/入参遵循Java api数据结构规范的接口
     * @param url
     * @param payload
     * @param headerMap
     * @param typeReference
     * @param <T>
     * @return
     */
    public static <T> T doPost(String url, String payload, Map<String, String> headerMap, TypeReference<T> typeReference) {
        String body = doPost(url, payload, headerMap);
        try {
            return objectMapper.readValue(body, typeReference);
        } catch (IOException e) {
            log.error("parse json error", e);
        }
        return null;
    }

    public static <T> T doPost(String url, String payload, Map<String, String> headerMap, Class<T> clazz) {
        String body = doPost(url, payload, headerMap);
        try {
            return objectMapper.readValue(body, clazz);
        } catch (IOException e) {
            log.error("parse json error", e);
        }
        return null;
    }

    public static String doPost(String url, Object paramObject, Map<String, String> headerMap){
        String payload = JsonUtils.toJsonString(paramObject);
        return doPost(url, payload, headerMap);
    }

    public static <T> T doPost(String url, Object paramObject, Map<String, String> headerMap, TypeReference<T> typeReference) {
        String payload = JsonUtils.toJsonString(paramObject);
        return doPost(url, payload, headerMap, typeReference);
    }

    public static <T> T doPost(String url, Object paramObject, Map<String, String> headerMap, Class<T> clazz) {
        String payload = JsonUtils.toJsonString(paramObject);
        return doPost(url, payload, headerMap, clazz);
    }

    /**
     * get请求
     * @param url
     * @param params
     * @return
     */
    public static String doGet(String url, Map<String, Object> params) {
        try {
            //设置请求头
            HttpHeaders headers = new HttpHeaders();
            headers.add("Accept", MediaType.APPLICATION_JSON_UTF8_VALUE);
            headers.add(GlobalVar.USER_ID,ThreadContext.get(GlobalVar.USER_ID) );
            headers.add(GlobalVar.SRC,ThreadContext.get(GlobalVar.SRC) );

            long startTime = System.currentTimeMillis();
            HttpEntity headerEntity = new HttpEntity(headers);
            ResponseEntity<String> rss = restTemplate.exchange(url, HttpMethod.GET, headerEntity, String.class, params);
            long spendtime = System.currentTimeMillis() - startTime;
            String result = String.format("RestHelper.doGet::request:%s,cost:%dms,params:%s,reponse:%s", url, spendtime, params, rss.getBody());
            if (spendtime > MAX_REQUEST_WAIT_TIME) {
                log.warn(result);
            } else {
                log.info(result);
            }
            if (rss.getStatusCode().equals(HttpStatus.OK)) {
                return rss.getBody();
            } else {
                log.error("RestHelper.doGet::failed to request:{},params:{},httpstatus:{},repsBody:{}", url, params, rss.getStatusCode(), rss.getBody());
                throw new BizException(CodeMsg.NETWORK_EXCEPTION);
            }
        }catch (HttpStatusCodeException e) {
            // 4xx和5xx的错误打印状态码
            log.error("RestHelper.doGet::failed to request:{},params:{},httpstatus:{},repsBody:{}", url, params, e.getStatusCode().value(), e.getResponseBodyAsString(), e);
            throw new BizException(CodeMsg.NETWORK_EXCEPTION);
        } catch (Exception e) {
            log.error("RestHelper.doGet::failed to request:{},params:{}", url, params, e);
            throw new BizException(CodeMsg.NETWORK_EXCEPTION);
        }
    }

    public static <T> T doGet(String url, Map<String, Object> params, TypeReference<T> typeReference) {
        String body = doGet(url, params);
        try {
            return objectMapper.readValue(body, typeReference);
        } catch (IOException e) {
            log.error("parse json error", e);
        }
        return null;
    }

    /**
     * get请求
     * - 返回泛型结果
     * @param url
     * @param params
     * @param payload
     * @param headerMap
     * @return
     */
    public static <T> T doGet(String url, Map<String, Object> params, String payload, Map<String, String> headerMap, ParameterizedTypeReference<T> typeReference) {
        try {
            //设置请求头
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.add(GlobalVar.USER_ID,ThreadContext.get(GlobalVar.USER_ID) );
            headers.add(GlobalVar.SRC,ThreadContext.get(GlobalVar.SRC));
            if (MapUtil.isNotEmpty(headerMap)) {
                headerMap.forEach((k, v) -> headers.add(k, v));
            }

            long startTime = System.currentTimeMillis();
            //处理非空字段
            params = Optional.ofNullable(params).orElse(Collections.emptyMap());
            payload = Optional.ofNullable(payload).orElse("");
            //发起请求
            HttpEntity<String> httpEntity = new HttpEntity<>(payload, headers);
            ResponseEntity<T> rss = restTemplate.exchange(url, HttpMethod.GET, httpEntity, typeReference, params);
            long spendtime = System.currentTimeMillis() - startTime;
            String result = String.format("RestHelper.doGet::request:%s,cost:%dms,params:%s,payload:%s,reponse:%s", url, spendtime, params, payload, rss.getBody());
            if (spendtime > MAX_REQUEST_WAIT_TIME) {
                log.warn(result);
            } else {
                log.info(result);
            }
            if (rss.getStatusCode().equals(HttpStatus.OK)) {
                return rss.getBody();
            } else {
                log.error("RestHelper.doGet::failed to request:{},params:{},payload:{},httpstatus:{},repsBody:{}", url, params, payload, rss.getStatusCode(), rss.getBody());
                throw new BizException(CodeMsg.NETWORK_EXCEPTION);
            }
        }catch (HttpStatusCodeException e) {
            // 4xx和5xx的错误打印状态码
            log.error("RestHelper.doGet::failed to request:{},params:{},payload:{},httpstatus:{},repsBody:{}", url, params, payload, e.getStatusCode().value(), e.getResponseBodyAsString(), e);
            throw new BizException(CodeMsg.NETWORK_EXCEPTION);
        } catch (Exception e) {
            log.error("RestHelper.doGet::failed to request:{},params:{},payload:{}", url, params, payload, e);
            throw new BizException(CodeMsg.NETWORK_EXCEPTION);
        }
    }

    /**
     * get请求
     * - 大前端认证
     * @param url
     * @param typeReference
     * @param <T>
     * @return
     */
    public static <T> T doGetWithAuthForBigFront(String url, ParameterizedTypeReference<BigFrontRespDto<T>> typeReference) {
        Map<String, String> headerMap = bigFrontProperties.getAuthMap();
        BigFrontRespDto<T> respDto = doGet(url, null, null, headerMap, typeReference);
        if (!respDto.isSuccess()) {
            throw new BizException(CodeMsg.BIG_FRONT_EXCEPTION.getCode(), respDto.getMsg());
        }
        return respDto.getData();
    }

    /**
     * post请求
     * - HIS认证
     * @param url
     * @param typeReference
     * @param <T>
     * @return
     */
    public static <T> T doPostWithAuthForHis(String url, Object paramObject, TypeReference<HisRespDto<T>> typeReference) {
        String payload = JsonUtils.toJsonString(paramObject);
        Map<String, String> headerMap = hisProperties.getAuth().getHeaderMap();
        HisRespDto<T> respDto = doPost(url, payload, headerMap, typeReference);
        if (Objects.isNull(respDto)) {
            throw new BizException(CodeMsg.HIS_EXCEPTION);
        }
        if (!respDto.isSuccess()) {
            throw new BizException(CodeMsg.HIS_EXCEPTION.getCode(), respDto.getMsg());
        }
        return respDto.getData();
    }
}
