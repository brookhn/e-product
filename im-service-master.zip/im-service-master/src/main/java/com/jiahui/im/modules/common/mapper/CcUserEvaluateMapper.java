package com.jiahui.im.modules.common.mapper;

import com.jiahui.im.modules.common.entity.CcUserEvaluateEntity;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CcUserEvaluateMapper {
    int deleteByPrimaryKey(Long id);

    int insert(CcUserEvaluateEntity record);

    int insertSelective(CcUserEvaluateEntity record);

    CcUserEvaluateEntity selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(CcUserEvaluateEntity record);

    int updateByPrimaryKey(CcUserEvaluateEntity record);
}