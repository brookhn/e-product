package com.jiahui.im.modules.ws.tio;

import com.jiahui.im.helper.MyJwt;
import com.jiahui.im.modules.common.enums.KefuTypeEnum;
import com.jiahui.im.modules.ws.constant.ImConst;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.tio.core.ChannelContext;
import org.tio.core.intf.Packet;
import org.tio.websocket.common.WsSessionContext;
import org.tio.websocket.server.WsServerAioListener;

import java.util.Objects;

@Log4j2
@Component
public class ImWsServerAioListener extends WsServerAioListener {

	@Autowired
	private DeptImWsServerAioListener deptImWsServerAioListener;

	@Autowired
	private CcImWsServerAioListener ccImWsServerAioListener;

	/**
	 * 连接建立之后
	 * @param channelContext
	 * @param isConnected
	 * @param isReconnect
	 * @throws Exception
	 */
	@Override
	public void onAfterConnected(ChannelContext channelContext, boolean isConnected, boolean isReconnect) throws Exception {
		super.onAfterConnected(channelContext, isConnected, isReconnect);

//		log.info("[{}]onAfterConnected==={},isConnected:{},isReconnect:{}", Thread.currentThread().getName(), channelContext, isConnected, isReconnect);
	}

	/**
	 * 服务端->客户端发消息之后
	 * @param channelContext
	 * @param packet
	 * @param isSentSuccess
	 * @throws Exception
	 */
	@Override
	public void onAfterSent(ChannelContext channelContext, Packet packet, boolean isSentSuccess) throws Exception {
		super.onAfterSent(channelContext, packet, isSentSuccess);

		// 校验jwt（握手失败没有jwt）
		MyJwt myJwt = (MyJwt) channelContext.get(ImConst.JWT_INFO);
		if (Objects.isNull(myJwt)) {
			return;
		}
		// 维护连接信息
		if (KefuTypeEnum.DEPT.getType().equals(myJwt.getKefuType())) {
			deptImWsServerAioListener.onAfterSent(channelContext, packet, isSentSuccess);
			return;
		}
		ccImWsServerAioListener.onAfterSent(channelContext, packet, isSentSuccess);
	}

	/**
	 * 客户端/服务端关闭连接之前
	 * @param channelContext
	 * @param throwable
	 * @param remark
	 * @param isRemove
	 * @throws Exception
	 */
	@Override
	public void onBeforeClose(ChannelContext channelContext, Throwable throwable, String remark, boolean isRemove) throws Exception {
		super.onBeforeClose(channelContext, throwable, remark, isRemove);

		WsSessionContext wsSessionContext = (WsSessionContext) channelContext.get();
		if (Objects.isNull(wsSessionContext) || !wsSessionContext.isHandshaked()) {
			return;
		}

		// 校验jwt（握手失败没有jwt）
		MyJwt myJwt = (MyJwt) channelContext.get(ImConst.JWT_INFO);
		if (Objects.isNull(myJwt)) {
			return;
		}
		if (KefuTypeEnum.DEPT.getType().equals(myJwt.getKefuType())) {
			deptImWsServerAioListener.onBeforeClose(channelContext, throwable, remark, isRemove);
			return;
		}
		ccImWsServerAioListener.onBeforeClose(channelContext, throwable, remark, isRemove);
	}

	/**
	 * 接收到客户端消息&解码之后
	 * @param channelContext
	 * @param packet
	 * @param packetSize
	 * @throws Exception
	 */
	@Override
	public void onAfterDecoded(ChannelContext channelContext, Packet packet, int packetSize) throws Exception {
		super.onAfterDecoded(channelContext, packet, packetSize);

//		WsPacket wp = (WsPacket) packet;
//		log.info("[{}]onAfterDecoded==={},wsOpcode:{},text:{}", Thread.currentThread().getName(), channelContext, wp.getWsOpcode(), wp.getWsBodyText());
	}

	/**
	 * 接收到客户端消息之后
	 * @param channelContext
	 * @param receivedBytes
	 * @throws Exception
	 */
	@Override
	public void onAfterReceivedBytes(ChannelContext channelContext, int receivedBytes) throws Exception {
		super.onAfterReceivedBytes(channelContext, receivedBytes);

		// 校验jwt（握手失败没有jwt）
		MyJwt myJwt = (MyJwt) channelContext.get(ImConst.JWT_INFO);
		if (Objects.isNull(myJwt)) {
			return;
		}
		// 维护连接信息
		if (KefuTypeEnum.DEPT.getType().equals(myJwt.getKefuType())) {
			deptImWsServerAioListener.onAfterReceivedBytes(channelContext, receivedBytes);
			return;
		}
		ccImWsServerAioListener.onAfterReceivedBytes(channelContext, receivedBytes);
	}

	/**
	 * 接收到客户端消息&处理之后
	 * @param channelContext
	 * @param packet
	 * @param cost
	 * @throws Exception
	 */
	@Override
	public void onAfterHandled(ChannelContext channelContext, Packet packet, long cost) throws Exception {
		super.onAfterHandled(channelContext, packet, cost);

		/*WsPacket wp = (WsPacket) packet;
		log.info("[{}]onAfterHandled==={},wsOpcode:{},text:{}", Thread.currentThread().getName(), channelContext, wp.getWsOpcode(), wp.getWsBodyText());
		if (Opcode.PING.equals(wp.getWsOpcode())) {
			WsResponse wsResponse = new WsResponse();
			wsResponse.setWsOpcode(Opcode.PONG);
			Tio.send(channelContext, wsResponse);
		}*/
	}

}
