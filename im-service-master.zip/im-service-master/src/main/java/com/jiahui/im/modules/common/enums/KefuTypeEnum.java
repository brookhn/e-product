package com.jiahui.im.modules.common.enums;

import com.google.common.collect.Maps;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Map;

/**
 * 客服类型
 * @author Tommy
 * @date 2021/6/8
 */
@Getter
@AllArgsConstructor
public enum KefuTypeEnum {

    DEPT(1, "科室客服"),
    CC(2, "CC客服"),
    ;

    /**
     * 类型
     */
    private final Integer type;

    /**
     * 描述
     */
    private final String desc;

    public static final Map<Integer, KefuTypeEnum> map = Maps.newHashMap();

    static {
        for (KefuTypeEnum e : KefuTypeEnum.values()) {
            map.put(e.getType(), e);
        }
    }

    public static KefuTypeEnum fromType(Integer type) {
        return map.get(type);
    }
}
