package com.jiahui.im.modules.ws.vo.action;

import lombok.Data;

/**
 * @author Tommy
 * @date 2021/8/2
 */
@Data
public class ChatActionIn {

    /**
     * 请求标识
     */
    private String requestId;

    /**
     * 消息类型 1-文本 2-图片 3-语音 4-视频 5-word 6-PDF 7-文件
     */
    private Integer msgType;

    /**
     * 消息内容
     */
    private String content;
}
