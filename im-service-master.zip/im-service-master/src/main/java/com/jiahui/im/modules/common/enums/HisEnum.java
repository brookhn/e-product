package com.jiahui.im.modules.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 
 * @author gavin.gong
 *
 */
@Getter
@AllArgsConstructor
public enum HisEnum {
	
	RESP_OK("1","请求成功");
	
	 /**
     * 业务操作编码
     */
    private final String code;

    /**
     * 业务操作编码描述
     */
    private final String desc;
}
