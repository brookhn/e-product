package com.jiahui.im.modules.common.mapper;

import com.jiahui.im.modules.common.dto.chat.CcUserExtDto;
import com.jiahui.im.modules.common.entity.CcUserExtEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface CcUserExtMapper {
    int insertSelective(CcUserExtEntity record);

    /**
     * 查询用户扩展信息
     * @param userId
     * @return
     */
    CcUserExtDto selectByUserId(@Param("userId") Long userId);

    /**
     * 根据用户id更新用户已读状态
     * @param userId
     * @return
     */
    int markUserReadByUserId(@Param("userId") Long userId);

    /**
     * 根据账号id更新用户已读状态
     * @param accountId
     * @return
     */
    int markUserReadByAccountId(@Param("accountId") Long accountId);

    /**
     * 根据账号id查询
     * @param accountId
     * @return
     */
    CcUserExtEntity selectByAccountId(@Param("accountId") Long accountId);

    /**
     * 查询首次咨询标记
     * @param userId
     * @return
     */
    Integer selectFirstQuestionFlag(@Param("userId") Long userId);

    /**
     * 更新首次咨询标记
     * @param userId
     * @return
     */
    int updateFirstQuestionFlag(@Param("userId") Long userId, @Param("channelType") Integer channelType);
}