package com.jiahui.im.modules.common.enums;

import com.google.common.collect.Maps;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Map;

/**
 * 科室客服-客服通知类型
 * @author Tommy
 * @date 2021/6/8
 */
@Getter
@AllArgsConstructor
public enum DeptKefuNoticeEnum {

    APPLY_RECEPT(1, "申请接待"),
    REFUSE_RECEPT(2, "拒绝接待"),
    RECEIVED(3, "接待成功"),
    UNBIND(4, "解绑成功"),

    UNRECEPT_NUM(31, "待接待人数变更"),
    TODAY_RECEPT_NUM(32, "今日接待人数变更"),
    ;

    /**
     * 类型
     */
    private final Integer type;

    /**
     * 描述
     */
    private final String desc;

    public static final Map<Integer, DeptKefuNoticeEnum> map = Maps.newHashMap();

    static {
        for (DeptKefuNoticeEnum e : DeptKefuNoticeEnum.values()) {
            map.put(e.getType(), e);
        }
    }

    public static DeptKefuNoticeEnum fromType(Integer type) {
        return map.get(type);
    }
}
