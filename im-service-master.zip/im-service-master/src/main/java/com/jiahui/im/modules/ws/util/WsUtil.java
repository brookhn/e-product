package com.jiahui.im.modules.ws.util;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.jiahui.im.common.CodeMsg;
import com.jiahui.im.common.exception.BizException;
import com.jiahui.im.constant.Constant;
import com.jiahui.im.helper.MyJwt;
import com.jiahui.im.helper.RedisHelper;
import com.jiahui.im.modules.common.enums.KefuTypeEnum;
import com.jiahui.im.modules.ws.constant.ImConst;
import com.jiahui.im.modules.ws.enums.ServerActionEnum;
import com.jiahui.im.modules.ws.tio.ImWebsocketStarter;
import com.jiahui.im.modules.ws.vo.WsResponseOut;
import org.tio.core.ChannelContext;
import org.tio.core.Tio;
import org.tio.utils.lock.ReadLockHandler;
import org.tio.utils.lock.SetWithLock;
import org.tio.websocket.common.WsPacket;
import org.tio.websocket.common.WsResponse;

import java.util.Objects;
import java.util.Set;
import java.util.concurrent.TimeUnit;

/**
 * ws工具类
 * @author Tommy
 * @date 2022/05/31
 */
public class WsUtil {

    /**
     * 科室客服-发送给用户在某科室的连接
     * @param serverActionEnum
     * @param data
     * @param userId
     * @param deptId
     * @param <T>
     */
    public static <T> void sendToUserForDept(ServerActionEnum serverActionEnum, T data, String userId, Long deptId) {
        SetWithLock<ChannelContext> userSetWithLock = Tio.getByUserid(ImWebsocketStarter.getServerGroupContext(), userId);
        if (Objects.isNull(userSetWithLock)) {
            return;
        }
        userSetWithLock.handle((ReadLockHandler<Set<ChannelContext>>) set -> set.parallelStream()
                // 过滤掉其他科室的连接
                .filter(channelContext -> {
                    MyJwt myJwt = (MyJwt) channelContext.get(ImConst.JWT_INFO);
                    return KefuTypeEnum.DEPT.getType().equals(myJwt.getKefuType()) && Objects.equals(myJwt.getDeptId(), deptId);
                })
                .forEach(channelContext -> {
                    WsResponseOut<T> wsResponseOut = WsResponseOut.ok(serverActionEnum.getAction(), data);
                    WsResponse wsResponse = WsResponse.fromText(JSON.toJSONString(wsResponseOut), WsPacket.CHARSET_NAME);
                    Tio.send(channelContext, wsResponse);
                }));
    }

    /**
     * CC客服-发送给用户
     * @param serverActionEnum
     * @param data
     * @param userId
     * @param <T>
     */
    public static <T> void sendToUserForCc(ServerActionEnum serverActionEnum, T data, String userId) {
        SetWithLock<ChannelContext> userSetWithLock = Tio.getByUserid(ImWebsocketStarter.getServerGroupContext(), userId);
        if (Objects.isNull(userSetWithLock)) {
            return;
        }
        userSetWithLock.handle((ReadLockHandler<Set<ChannelContext>>) set -> set.parallelStream()
                .filter(channelContext -> {
                    MyJwt myJwt = (MyJwt) channelContext.get(ImConst.JWT_INFO);
                    return KefuTypeEnum.CC.getType().equals(myJwt.getKefuType());
                })
                .forEach(channelContext -> {
                    WsResponseOut<T> wsResponseOut = WsResponseOut.ok(serverActionEnum.getAction(), data);
                    WsResponse wsResponse = WsResponse.fromText(JSON.toJSONString(wsResponseOut), WsPacket.CHARSET_NAME);
                    Tio.send(channelContext, wsResponse);
                }));
    }

    /**
     * 发送消息
     * @param channelContext
     * @param wsResponseOut
     */
    public static void send(ChannelContext channelContext, WsResponseOut wsResponseOut) {
        WsResponse wsResponse = WsResponse.fromText(JSON.toJSONString(wsResponseOut), WsPacket.CHARSET_NAME);
        Tio.send(channelContext, wsResponse);
    }

    /**
     * 发送消息
     * @param channelContext
     * @param serverActionEnum
     * @param data
     * @param <T>
     */
    public static <T> void send(ChannelContext channelContext, ServerActionEnum serverActionEnum, T data) {
        WsResponseOut<T> wsResponseOut = WsResponseOut.ok(serverActionEnum.getAction(), data);
        WsResponse wsResponse = WsResponse.fromText(JSON.toJSONString(wsResponseOut), WsPacket.CHARSET_NAME);
        Tio.send(channelContext, wsResponse);
    }

    /**
     * 发送异常消息
     * @param channelContext
     * @param e
     */
    public static void sendError(ChannelContext channelContext, BizException e) {
        WsResponseOut wsResponseOut = WsResponseOut.error(e);
        WsResponse wsResponse = WsResponse.fromText(JSON.toJSONString(wsResponseOut), WsPacket.CHARSET_NAME);
        Tio.send(channelContext, wsResponse);
    }

    /**
     * 发送异常消息
     * @param channelContext
     * @param codeMsg
     */
    public static void sendError(ChannelContext channelContext, CodeMsg codeMsg) {
        WsResponseOut wsResponseOut = WsResponseOut.error(codeMsg);
        WsResponse wsResponse = WsResponse.fromText(JSON.toJSONString(wsResponseOut), WsPacket.CHARSET_NAME);
        Tio.send(channelContext, wsResponse);
    }


    /**
     * 缓存用户连接
     * @param channelContext
     * @param myJwt
     */
    public static void cacheUserChannelId(ChannelContext channelContext, MyJwt myJwt) {
        long nowMillis = DateUtil.current();
        KefuTypeEnum kefuTypeEnum = KefuTypeEnum.fromType(myJwt.getKefuType());
        switch (kefuTypeEnum) {
            case CC://CC客服
                // 用户在CC客服的连接
                String ccChannelIdZsetkey = StrUtil.format(Constant.CC_USER_CHANNEL_ID_ZSET, myJwt.getAccountId());
                RedisHelper.zAdd(ccChannelIdZsetkey, channelContext.getId(), nowMillis);
                RedisHelper.expire(ccChannelIdZsetkey, myJwt.getTtls(), TimeUnit.SECONDS);
                break;
            case DEPT://科室客服
                // 用户在某科室的连接
                String deptChannelIdZsetkey = StrUtil.format(Constant.DEPT_USER_CHANNEL_ID_ZSET, myJwt.getAccountId(), myJwt.getDeptId());
                RedisHelper.zAdd(deptChannelIdZsetkey, channelContext.getId(), nowMillis);
                RedisHelper.expire(deptChannelIdZsetkey, myJwt.getTtls(), TimeUnit.SECONDS);
                // 用户在全部科室的连接
                String deptAllChannelIdZsetkey = StrUtil.format(Constant.DEPT_USER_ALL_CHANNEL_ID_ZSET, myJwt.getAccountId());
                RedisHelper.zAdd(deptAllChannelIdZsetkey, channelContext.getId(), nowMillis);
                RedisHelper.expire(deptAllChannelIdZsetkey, myJwt.getTtls(), TimeUnit.SECONDS);
                break;
        }
        // 用户在某渠道的所有连接（包含CC客服和科室客服）
        String channelChannelIdZsetkey = StrUtil.format(Constant.KEFU_USER_CHANNEL_CHANNEL_ID_ZSET, myJwt.getAccountId(), myJwt.getChannelType());
        RedisHelper.zAdd(channelChannelIdZsetkey, channelContext.getId(), nowMillis);
        RedisHelper.expire(channelChannelIdZsetkey, myJwt.getTtls(), TimeUnit.SECONDS);
        // 用户咨询客服的所有连接（包含CC客服和科室客服）
        String allChannelIdZsetkey = StrUtil.format(Constant.KEFU_USER_CHANNEL_ID_ZSET, myJwt.getAccountId());
        RedisHelper.zAdd(allChannelIdZsetkey, channelContext.getId(), nowMillis);
        RedisHelper.expire(allChannelIdZsetkey, myJwt.getTtls(), TimeUnit.SECONDS);
    }

    /**
     * 删除用户连接
     * @param channelContext
     * @param myJwt
     */
    public static void delUserChannelId(ChannelContext channelContext, MyJwt myJwt) {
        KefuTypeEnum kefuTypeEnum = KefuTypeEnum.fromType(myJwt.getKefuType());
        switch (kefuTypeEnum) {
            case CC://CC客服
                // 用户在CC客服的连接
                String ccChannelIdZsetkey = StrUtil.format(Constant.CC_USER_CHANNEL_ID_ZSET, myJwt.getAccountId());
                RedisHelper.zRemove(ccChannelIdZsetkey, channelContext.getId());
                break;
            case DEPT://科室客服
                // 用户在某科室的连接
                String deptChannelIdZsetkey = StrUtil.format(Constant.DEPT_USER_CHANNEL_ID_ZSET, myJwt.getAccountId(), myJwt.getDeptId());
                RedisHelper.zRemove(deptChannelIdZsetkey, channelContext.getId());
                // 用户在全部科室的连接
                String deptAllChannelIdZsetkey = StrUtil.format(Constant.DEPT_USER_ALL_CHANNEL_ID_ZSET, myJwt.getAccountId());
                RedisHelper.zRemove(deptAllChannelIdZsetkey, channelContext.getId());
                break;
        }
        // 用户在某渠道的所有连接（包含CC客服和科室客服）
        String channelChannelIdZsetkey = StrUtil.format(Constant.KEFU_USER_CHANNEL_CHANNEL_ID_ZSET, myJwt.getAccountId(), myJwt.getChannelType());
        RedisHelper.zRemove(channelChannelIdZsetkey, channelContext.getId());
        // 用户咨询客服的所有连接（包含CC客服和科室客服）
        String allChannelIdZsetkey = StrUtil.format(Constant.KEFU_USER_CHANNEL_ID_ZSET, myJwt.getAccountId());
        RedisHelper.zRemove(allChannelIdZsetkey, channelContext.getId());
    }
}
