package com.jiahui.im.modules.common.dto.his.patient;

import lombok.Data;

@Data
public class EpisodeListReqDto {
	
	private String patientId;
	
	private String startTime;
	
	private String endTime;

}
