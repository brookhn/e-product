package com.jiahui.im.modules.ws.dto.kafka;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CcChatRecordDto {

	/**
	 * 主键
	 */
	private String id;

	/**
	 * 发送者ID
	 */
	private Long fromId;

	/**
	 * 发送者类型 1-用户 2-客服 3-系统
	 */
	private Integer fromType;

	/**
	 * 接收者ID
	 */
	private Long toId;

	/**
	 * 接收者类型 1-用户 2-客服 3-系统
	 */
	private Integer toType;

	/**
	 * 文件名
	 */
	private String fileName;

	/**
	 * 文件大小（byte）
	 */
	private Long fileSize;

	/**
	 * 消息类型 1-文本 2-图片 3-语音 4-视频 5-word 6-PDF 7-文件
	 */
	private Integer msgType;

	/**
	 * 消息内容
	 */
	private String content;

	/**
	 * 部门ID
	 */
	private Long deptId;

	/**
	 * 渠道类型 1-APP 2-公众号 3-小程序 4-企业微信
	 */
	private Integer channelType;

	/**
	 * 系统版本
	 */
	private String systemVersion;

	/**
	 * 设备型号
	 */
	private String deviceModel;

	/**
	 * app版本
	 */
	private String appVersion;

	/**
	 * 请求标识
	 */
	private String requestId;

	/**
	 * 会话ID
	 */
	private String conversationId;

	/**
	 * 消息发送时间 毫秒级时间戳
	 */
	private Long sendTime;

	/******************************以上字段为mongo中已有字段，以下字段为补充字段******************************/

	/**
	 * 发送者名称
	 */
	private String fromName;

	/**
	 * 发送者头像
	 */
	private String fromHeadUrl;

	/**
	 * 发送者国籍（仅发送者为用户时有值）
	 */
	private String fromNationality;

	/**
	 * 接待类型 0-未知 1-待接待 2-接待中
	 */
	private Integer receptType;

	/**
	 * 渠道名称 1-APP 2-公众号 3-小程序 4-企业微信
	 */
	private String channel;

	/**
	 * 排队人数（有值表示在排队）
	 */
	private Integer ranking;

	/**
	 * OSS对象名称
	 */
	private String objectName;

	/**
	 * kafka发送时间 毫秒级时间戳
	 */
	private Long kafkaSendTime;
}
