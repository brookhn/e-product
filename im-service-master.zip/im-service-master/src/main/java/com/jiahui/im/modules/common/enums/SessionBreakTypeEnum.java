package com.jiahui.im.modules.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 连接断开方式
 * @author Tommy
 * @date 2022/6/22
 */
@Getter
@AllArgsConstructor
public enum SessionBreakTypeEnum {
	
	NO(0,"未断开"),
    AUTOMATIC(1,"自动断开"),
	SYSTEM(2,"系统断开");

	 /**
     * 方式
     */
    private final Integer type;

    /**
     * 描述
     */
    private final String desc;
}
