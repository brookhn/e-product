package com.jiahui.im.filter;

import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 请求过滤器
 * - RequestFilter优先级要在WebTraceFilter之后
 * - WebTraceFilter默认order为-1
 * - 由于需要在拦截器里面读取请求参数，所以需要该过滤器放在所有过滤器后面，保证RequestWrapper为最后一次包装类
 * @author Tommy
 * @date 2022/6/29
 */
public class RequestFilter extends OncePerRequestFilter {

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
		// 包装请求（解决POST请求中的BODY参数不能重复读取多次的问题）
		RequestWrapper requestWrapper = new RequestWrapper(request);
		filterChain.doFilter(requestWrapper, response);
	}
}
