package com.jiahui.im.modules.ws.event;

import cn.hutool.core.convert.Convert;
import cn.hutool.core.date.DateField;
import cn.hutool.core.date.DateTime;
import com.alibaba.fastjson.JSON;
import com.jiahui.im.modules.common.enums.UserNoticeEnum;
import com.jiahui.im.modules.ws.converter.NoticeConverter;
import com.jiahui.im.modules.ws.dto.kafka.notice.DisconnectReminderDto;
import com.jiahui.im.modules.ws.dto.kafka.notice.EndReceptDto;
import com.jiahui.im.modules.ws.dto.kafka.notice.NoticeDto;
import com.jiahui.im.modules.ws.dto.kafka.notice.RankingDto;
import com.jiahui.im.modules.ws.dto.kafka.notice.ReceivedDto;
import com.jiahui.im.modules.ws.dto.kafka.notice.UserEndRankDto;
import com.jiahui.im.modules.ws.enums.ServerActionEnum;
import com.jiahui.im.modules.ws.util.WsUtil;
import com.jiahui.im.modules.ws.vo.notice.DisconnectReminderOut;
import com.jiahui.im.modules.ws.vo.notice.EndReceptOut;
import com.jiahui.im.modules.ws.vo.notice.RankingOut;
import com.jiahui.im.modules.ws.vo.notice.ReceivedOut;
import com.jiahui.im.modules.ws.vo.notice.UserEndRankOut;
import lombok.extern.log4j.Log4j2;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.context.annotation.DependsOn;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;

/**
 * CC客服-用户通知消息监听
 */
@Log4j2
@Component
@DependsOn("imWebsocketStarter")
public class CcUserNoticeMsgConsumer {

    @KafkaListener(topics = "#{'${kafka.topic.CC_IM_USER_NOTICE_MSG}'}", containerFactory = "imListenerContainerFactory")
    public void consume(List<ConsumerRecord<String, String>> records, Acknowledgment acknowledgment) {
        try {
            long expTime = DateTime.now().offset(DateField.MINUTE, -5).getTime();
            records.forEach(record -> {
                NoticeDto noticeDto = JSON.parseObject(record.value(), NoticeDto.class);
                if (noticeDto.getKafkaSendTime() < expTime) {
                    // 丢弃过期消息
                    return;
                }
                UserNoticeEnum userNoticeEnum = UserNoticeEnum.fromType(noticeDto.getNoticeType());
                if (Objects.isNull(userNoticeEnum)) {
                    return;
                }
                switch (userNoticeEnum) {
                    case RECEIVED://接待成功
                        handleReceived(noticeDto);
                        break;
                    case RANKING://排名变更
                        handleRanking(noticeDto);
                        break;
                    case END_RECEPT://结束接待
                        handleEndRecept(noticeDto);
                        break;
                    case USER_END_RANK://用户结束排队
                        handleUserEndRank(noticeDto);
                        break;
                    default:
                        break;
                }
            });
        } catch (Exception e) {
            log.error("消费异常", e);
        } finally {
            // 手动提交offset
            acknowledgment.acknowledge();
        }
    }

    /**
     * 【接待成功】
     * @param noticeDto
     */
    private void handleReceived(NoticeDto noticeDto) {
        ReceivedDto receivedDto = Convert.convert(ReceivedDto.class, noticeDto.getData());
        ReceivedOut receivedOut = NoticeConverter.INSTANCE.receivedDto2Out(receivedDto);
        // 发送给指定用户
        WsUtil.sendToUserForCc(ServerActionEnum.NOTICE, receivedOut, receivedOut.getUserId().toString());
    }

    /**
     * 【排名变更】
     * @param noticeDto
     */
    private void handleRanking(NoticeDto noticeDto) {
        RankingDto rankingDto = Convert.convert(RankingDto.class, noticeDto.getData());
        RankingOut rankingOut = NoticeConverter.INSTANCE.rankingDto2Out(rankingDto);
        // 发送给指定用户
        WsUtil.sendToUserForCc(ServerActionEnum.NOTICE, rankingOut, rankingOut.getUserId().toString());
    }

    /**
     * 【结束接待】
     * @param noticeDto
     */
    private void handleEndRecept(NoticeDto noticeDto) {
        EndReceptDto endReceptDto = Convert.convert(EndReceptDto.class, noticeDto.getData());
        EndReceptOut endReceptOut = NoticeConverter.INSTANCE.pushEvaluateDto2Out(endReceptDto);
        // 发送给指定用户
        WsUtil.sendToUserForCc(ServerActionEnum.NOTICE, endReceptOut, endReceptOut.getUserId().toString());
    }

    /**
     * 【用户结束排队】
     * @param noticeDto
     */
    private void handleUserEndRank(NoticeDto noticeDto) {
        UserEndRankDto userEndRankDto = Convert.convert(UserEndRankDto.class, noticeDto.getData());
        UserEndRankOut userEndRankOut = NoticeConverter.INSTANCE.userEndRankDto2Out(userEndRankDto);
        // 发送给指定用户
        WsUtil.sendToUserForCc(ServerActionEnum.NOTICE, userEndRankOut, userEndRankOut.getUserId().toString());
    }
}
