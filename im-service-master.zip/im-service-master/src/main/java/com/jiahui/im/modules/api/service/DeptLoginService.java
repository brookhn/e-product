package com.jiahui.im.modules.api.service;

import cn.hutool.core.date.DateField;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.lang.Assert;
import cn.hutool.core.util.StrUtil;
import cn.hutool.extra.spring.SpringUtil;
import com.jiahui.im.common.CodeMsg;
import com.jiahui.im.common.exception.BizException;
import com.jiahui.im.config.properties.JwtProperties;
import com.jiahui.im.config.properties.SysProperties;
import com.jiahui.im.constant.Constant;
import com.jiahui.im.helper.JwtHelper;
import com.jiahui.im.helper.MyJwt;
import com.jiahui.im.modules.api.vo.login.LoginIn;
import com.jiahui.im.modules.api.vo.login.LoginOut;
import com.jiahui.im.modules.common.dto.bigfront.DeptInfoDto;
import com.jiahui.im.modules.common.dto.bigfront.UserInfoDto;
import com.jiahui.im.modules.common.dto.his.patient.PatientDto;
import com.jiahui.im.modules.common.entity.UserEntity;
import com.jiahui.im.modules.common.entity.UserExtEntity;
import com.jiahui.im.modules.common.enums.ChannelTypeEnum;
import com.jiahui.im.modules.common.enums.KefuTypeEnum;
import com.jiahui.im.modules.common.enums.MAPatientAuthRelationEnum;
import com.jiahui.im.modules.common.enums.MATerminalDictEnum;
import com.jiahui.im.modules.common.mapper.UserExtMapper;
import com.jiahui.im.modules.common.mapper.UserMapper;
import com.jiahui.im.modules.common.service.BigFrontService;
import com.jiahui.im.modules.common.service.CacheService;
import com.jiahui.im.modules.common.service.PatientService;
import com.jiahui.im.util.UserUtil;
import lombok.extern.log4j.Log4j2;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletResponse;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

/**
 * 科室客服-登录
 * @author Tommy
 * @date 2022/5/30
 */
@Service
@Log4j2
public class DeptLoginService {

	@Autowired
	private HttpServletResponse response;

	@Autowired
	private JwtProperties jwtProperties;

	@Autowired
	private UserMapper userMapper;

	@Autowired
	private UserExtMapper userExtMapper;

	@Autowired
	private CacheService cacheService;

	@Autowired
	private BigFrontService bigFrontService;

	@Autowired
	private PatientService patientService;

	@Autowired
	private RedissonClient redissonClient;

	public LoginOut login(LoginIn loginIn) {
		// 校验渠道
		Assert.notNull(ChannelTypeEnum.fromValidType(loginIn.getChannelType()), () -> new BizException(CodeMsg.ILLEGAL_CHANNEL));
		// 查询科室
		Assert.notNull(loginIn.getDeptId(), () -> new BizException(CodeMsg.ILLEGAL_DEPT));
		DeptInfoDto deptInfoDto = cacheService.findGroupById(loginIn.getDeptId());
		Assert.isTrue(Objects.nonNull(deptInfoDto) && Objects.nonNull(deptInfoDto.getId()), () -> new BizException(CodeMsg.ILLEGAL_DEPT));
		// 查询数据库
		UserEntity userEntity = userMapper.selectByAccountId(loginIn.getAccountId());
		Assert.isFalse(Objects.nonNull(userEntity) && Constant.FALSE.equals(userEntity.getStatus()), () -> new BizException(CodeMsg.CANCEL_USER));
		// 判断是否需要更新用户信息（不在数据库中|更新时间超过指定时间间隔）
		boolean updateFlag = Objects.isNull(userEntity) || DateUtil.date().offset(DateField.MINUTE, -SysProperties.updateUserInfoTime).isAfterOrEquals(userEntity.getUpdateTime());
		UserEntity tempUserEntity = null;
		if (updateFlag) {
			// 查询用户信息
			UserInfoDto userInfoDto = bigFrontService.getUserDetailInfo(loginIn.getAccountId());
			Assert.notNull(userInfoDto, () -> new BizException(CodeMsg.ILLEGAL_USER));
			Optional<PatientDto> patientDtoOptional = userInfoDto.getPatientRelationList().stream()
					.filter(e -> MAPatientAuthRelationEnum.SELF.getRelation().equals(e.getAuthRelation()))
					.findFirst().map(e -> patientService.getPatientFromHis(e));
			// 组装数据
			tempUserEntity = UserEntity.builder()
					// 账号信息
					.userName(StrUtil.blankToDefault(userInfoDto.getNickName(), userInfoDto.getPhone()))
					.accountId(userInfoDto.getId())
					.mobile(userInfoDto.getPhone())
					.terminalCode(userInfoDto.getTerminal())
					.terminal(MATerminalDictEnum.findByCode(userInfoDto.getTerminal()).getDesc())
					.registerTime(userInfoDto.getCreateTime())
					.bindCount(userInfoDto.getPatientRelationList().size())
					.headUrl(userInfoDto.getAvatar())
					.build();
			if (patientDtoOptional.isPresent()) {
				// 患者信息
				PatientDto patientDto = patientDtoOptional.get();
				tempUserEntity.setGender(patientDto.getGender());
				tempUserEntity.setMrn(patientDto.getMrn());
				tempUserEntity.setPatientName(patientDto.getName());
				tempUserEntity.setNationalityCode(patientDto.getNationalityCode());
				tempUserEntity.setNationality(patientDto.getNationality());
				tempUserEntity.setBirthday(patientDto.getBirthDate());
			}
		}
		// 新增/更新用户信息
		DeptLoginService deptLoginService = SpringUtil.getBean(DeptLoginService.class);
		UserEntity currentUserEntity = deptLoginService.upsertUserInfo(loginIn, userEntity, updateFlag, tempUserEntity);
		// 生成jwt
		MyJwt myJwt = new MyJwt();
		myJwt.setUserId(currentUserEntity.getId());
		myJwt.setAccountId(loginIn.getAccountId());
		myJwt.setUserName(UserUtil.getShowName(currentUserEntity));
		myJwt.setHeadUrl(UserUtil.getShowHeadUrl(currentUserEntity.getHeadUrl()));
		myJwt.setChannelType(loginIn.getChannelType());
		myJwt.setDeptId(loginIn.getDeptId());
		myJwt.setKefuType(KefuTypeEnum.DEPT.getType());
		String token = JwtHelper.createMyJwt(myJwt);
		// 设置响应头
		response.setHeader(jwtProperties.getHeader(), token);
		return new LoginOut(myJwt.getUserName(), myJwt.getHeadUrl());
	}

	/**
	 * 新增/更新用户信息
	 * - 这里不用加事务，没有意义
	 * - 分布式锁保证user表的accountId不重复
	 * - 唯一索引保证user_ext表数据不重复
	 * @param loginIn
	 * @param userEntity
	 * @param updateFlag
	 * @param tempUserEntity
	 * @return
	 */
//	@Transactional(value = "kefuImTransactionManager", rollbackFor = Exception.class)
	public UserEntity upsertUserInfo(LoginIn loginIn, UserEntity userEntity, boolean updateFlag, UserEntity tempUserEntity) {
		// 新增/更新用户信息
		if (Objects.isNull(userEntity)) {
			RLock lock = redissonClient.getLock(StrUtil.format(Constant.DEPT_USER_ACCOUNT_LOCK, loginIn.getAccountId()));
			try {
				// 尝试加锁，最多等待3秒，上锁以后5秒自动解锁
				if (lock.tryLock(3, 5, TimeUnit.SECONDS)) {
					try {
						// 再查一次
						UserEntity dbUserEntity = userMapper.selectByAccountId(loginIn.getAccountId());
						if (Objects.isNull(dbUserEntity)) {
							userMapper.insertSelective(tempUserEntity);
						} else {
							// 并发情况
							tempUserEntity.setId(dbUserEntity.getId());
						}
					} catch (Exception e) {
						throw new BizException(CodeMsg.FREQUENT_OPERATION);
					} finally {
						if (lock.isLocked() && lock.isHeldByCurrentThread()) {
							lock.unlock();
						}
					}
				} else {
					throw new BizException(CodeMsg.FREQUENT_OPERATION);
				}
			} catch (InterruptedException e) {
				// 保留中断发生的证据，以便调用栈中更高层的代码能知道中断，并对中断作出响应
				Thread.currentThread().interrupt();
				throw new BizException(CodeMsg.FREQUENT_OPERATION);
			}
		} else if (updateFlag) {
			tempUserEntity.setId(userEntity.getId());
			userMapper.updateByPrimaryKeySelective(tempUserEntity);
		}
		// 维护用户扩展信息（每个科室都有一条数据）
		UserEntity currentUserEntity = updateFlag ? tempUserEntity : userEntity;
		Integer isExist = userExtMapper.isExist(currentUserEntity.getId(), loginIn.getDeptId());
		if (Objects.isNull(isExist)) {
			UserExtEntity userExtEntity = UserExtEntity.builder().userId(currentUserEntity.getId()).deptId(loginIn.getDeptId()).build();
			userExtMapper.insertSelective(userExtEntity);
		}
		return currentUserEntity;
	}
}
