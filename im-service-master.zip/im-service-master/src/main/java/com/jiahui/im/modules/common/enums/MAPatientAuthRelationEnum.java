package com.jiahui.im.modules.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;

/**
 * 病例授权关系枚举
 *
 * @author qi.ding
 * @version 1.0.0
 * @date 2020-09-27
 */
@Getter
@AllArgsConstructor
public enum MAPatientAuthRelationEnum {

    UNKNOWN(0, "待补充", "To be added"),
    SELF(1, "本人", "Self"),
    CHILD(2, "子女", "Child"),
    SPOUSE(3, "配偶", "Spouse"),
    OTHER(4, "其他", "Other"),
    PARENT(5, "父母", "parent"),
    RELATIVES(6, "亲属", "Relatives"),
    FRIEND(7, "朋友", "friend");

    /**
     * 关系
     */
    private Integer relation;
    /**
     * 关系名称(中文)
     */
    private String nameCn;
    /**
     * 关系名称(英文)
     */
    private String nameEn;

    /**
     * 通过关系查找
     *
     * @param relation 关系
     * @return 病例授权关系枚举
     */
    public static MAPatientAuthRelationEnum findByRelation(Integer relation) {
        if (Objects.isNull(relation)) {
            return MAPatientAuthRelationEnum.UNKNOWN;
        }
        for (MAPatientAuthRelationEnum item : MAPatientAuthRelationEnum.values()) {
            if (item.getRelation().equals(relation)) {
                return item;
            }
        }
        return MAPatientAuthRelationEnum.UNKNOWN;
    }

}