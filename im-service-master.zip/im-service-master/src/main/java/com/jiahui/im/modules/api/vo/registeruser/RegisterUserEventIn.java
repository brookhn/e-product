package com.jiahui.im.modules.api.vo.registeruser;

import com.alibaba.fastjson.JSONObject;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.NotNull;

/**
 * 注册用户事件
 * @author Tommy
 * @date 2022/2/23
 */
@ApiModel
@Data
public class RegisterUserEventIn {

    @ApiModelProperty(value = "事件类型 1-注销 2-变更手机号")
    @NotNull
    @Range(min = 1, max = 2)
    private Integer eventType;

    @ApiModelProperty(value = "事件内容")
    @NotNull
    private JSONObject data;
}