package com.jiahui.im.modules.ws.util;

import cn.hutool.core.date.DateTime;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONValidator;
import com.jiahui.im.common.CodeMsg;
import com.jiahui.im.common.exception.BizException;
import com.jiahui.im.modules.common.enums.MsgTypeEnum;
import com.jiahui.im.modules.ws.enums.ClientActionEnum;
import com.jiahui.im.modules.ws.vo.WsRequestIn;
import com.jiahui.im.modules.ws.vo.action.ChatActionIn;
import org.tio.websocket.common.Opcode;

import java.util.Objects;

/**
 * ws入参校验
 * @author Tommy
 * @date 2021/8/2
 */
public class WsInputChecker {

    private static final WsInputChecker CHECKER = new WsInputChecker();

    private WsInputChecker() {
    }

    public static WsInputChecker checker() {
        return CHECKER;
    }

    /**
     * 心跳ping检查
     * @param text
     */
    public boolean checkPing(String text) {
        if (Opcode.PING.name().equalsIgnoreCase(text)) {
            return true;
        }
        return false;
    }

    /**
     * 心跳pong检查
     * @param text
     */
    public boolean checkPong(String text) {
        if (Opcode.PONG.name().equalsIgnoreCase(text)) {
            return true;
        }
        return false;
    }

    /**
     * 校验是否是json格式
     * @param text
     * @return
     */
    public WsInputChecker checkJson(String text) {
        boolean flag = JSONValidator.from(text).validate();
        if (!flag) {
            throw new BizException(CodeMsg.INVALID_JSON);
        }
        return CHECKER;
    }

    /**
     * 校验jwt是否过期
     * @param exp 过期时间
     * @return
     */
    public WsInputChecker checkJwtExp(Long exp) {
        long nowSec = DateTime.now().getTime() / 1000L;
        if (nowSec > exp) {
            throw new BizException(CodeMsg.UNAUTHORIZED);
        }
        return CHECKER;
    }

    /**
     * 转换数据
     * @param text
     */
    public WsRequestIn transform(String text) {
        try {
            return JSON.parseObject(text, WsRequestIn.class);
        } catch (Exception e) {
            throw new BizException(CodeMsg.INVALID_JSON);
        }
    }

    /**
     * 校验指令
     * @param wsRequestIn
     * @return
     */
    public WsInputChecker checkAction(WsRequestIn wsRequestIn) {
        ClientActionEnum clientActionEnum = ClientActionEnum.fromAction(wsRequestIn.getAction());
        if (Objects.isNull(clientActionEnum)) {
            throw new BizException(CodeMsg.INVALID_ACTION);
        }
        return CHECKER;
    }

    /**
     * 校验聊天入参
     * @param chatActionIn
     * @return
     */
    public WsInputChecker checkParams(ChatActionIn chatActionIn) {
        if (StrUtil.isBlank(chatActionIn.getRequestId())) {
            throw new BizException(CodeMsg.PARAMS_ERROR.code(), "请求标识不能为空");
        }
        MsgTypeEnum msgTypeEnum = MsgTypeEnum.fromType(chatActionIn.getMsgType());
        if (Objects.isNull(msgTypeEnum)) {
            throw new BizException(CodeMsg.PARAMS_ERROR.code(), "暂不支持这种消息类型");
        }
        if (StrUtil.isBlank(chatActionIn.getContent())) {
            throw new BizException(CodeMsg.PARAMS_ERROR.code(), "消息内容不能为空");
        }
        return CHECKER;
    }
}
