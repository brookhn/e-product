package com.jiahui.im.modules.common.mapper;

import com.jiahui.im.modules.common.entity.DeptUserConnectRecordEntity;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface DeptUserConnectRecordMapper {

    int insertSelective(DeptUserConnectRecordEntity record);

    /**
     * 根据唯一索引更新
     * @param record
     * @return
     */
    int updateByUk(DeptUserConnectRecordEntity record);
}