package com.jiahui.im.modules.ws.enums;

import com.google.common.collect.Maps;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Map;

/**
 * 客户端操作指令枚举
 * @author Tommy
 * @date 2021/8/2
 */
@Getter
@AllArgsConstructor
public enum ClientActionEnum {

    CHAT("chat", "聊天"),
    ;

    /**
     * 指令类型
     */
    private final String action;

    /**
     * 指令描述
     */
    private final String desc;

    public static final Map<String, ClientActionEnum> map = Maps.newHashMap();

    static {
        for (ClientActionEnum e : ClientActionEnum.values()) {
            map.put(e.getAction(), e);
        }
    }

    public static ClientActionEnum fromAction(String action) {
        return map.get(action);
    }
}
