package com.jiahui.im.modules.common.mapper;

import com.jiahui.im.modules.common.entity.CcUserDialogEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Set;

@Mapper
public interface CcUserDialogMapper {
    int insertSelective(CcUserDialogEntity record);

    /**
     * 查询已结束未评价的会话（60分钟内已结束未评价的会话）
     * @param conversationIdSet
     * @return
     */
    List<CcUserDialogEntity> selectNoEvaluate(@Param("conversationIdSet") Set<String> conversationIdSet);

    /**
     * 根据唯一索引查询
     * @param conversationId
     * @return
     */
    CcUserDialogEntity selectByUk(String conversationId);

    /**
     * 更新评价id
     * @param conversationId
     * @param evaluateId
     * @return
     */
    int updateEvaluateId(@Param("conversationId") String conversationId, @Param("evaluateId") Long evaluateId);

    /**
     * 根据唯一索引更新
     * @param record
     * @return
     */
    int updateByUk(CcUserDialogEntity record);
}