package com.jiahui.im.modules.api.controller;

import com.jiahui.im.common.JsonOut;
import com.jiahui.im.modules.api.service.HomeService;
import com.jiahui.im.modules.api.vo.home.ChatRecordListIn;
import com.jiahui.im.modules.api.vo.home.ChatRecordListOut;
import com.jiahui.im.modules.api.vo.home.CheckRequestIdIn;
import com.jiahui.im.modules.api.vo.home.CheckRequestIdOut;
import com.jiahui.im.modules.api.vo.home.EvaluateIn;
import com.jiahui.im.modules.api.vo.home.NewestChatRecordListIn;
import com.jiahui.im.modules.api.vo.home.NewestChatRecordListOut;
import com.jiahui.im.modules.api.vo.home.RankInfoOut;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Tommy
 * @date 2021/8/17
 */
@Api(tags = "主页相关接口")
@RestController
@RequestMapping("/home")
public class HomeController {

    @Autowired
    private HomeService homeService;

    @ApiOperation(value = "聊天记录列表", notes = "分页接口")
    @PostMapping("/chat-record-list")
    public JsonOut<ChatRecordListOut> chatRecordList(@RequestBody @Validated ChatRecordListIn chatRecordListIn) {
        return JsonOut.ok(homeService.chatRecordList(chatRecordListIn));
    }

    @ApiOperation(value = "最新聊天记录列表")
    @PostMapping("/newest-chat-record-list")
    public JsonOut<NewestChatRecordListOut> newestChatRecordList(@RequestBody @Validated NewestChatRecordListIn newestChatRecordListIn) {
        return JsonOut.ok(homeService.newestChatRecordList(newestChatRecordListIn));
    }

    @ApiOperation(value = "排队信息")
    @PostMapping("/rank-info")
    public JsonOut<RankInfoOut> rankInfo() {
        return JsonOut.ok(homeService.rankInfo());
    }

    @ApiOperation(value = "检查消息是否发送成功")
    @PostMapping("/check-request-id")
    public JsonOut<CheckRequestIdOut> checkRequestId(@RequestBody @Validated CheckRequestIdIn checkRequestIdIn) {
        return JsonOut.ok(homeService.checkRequestId(checkRequestIdIn));
    }

    @ApiOperation(value = "评价")
    @PostMapping("/evaluate")
    public JsonOut evaluate(@RequestBody @Validated EvaluateIn evaluateIn) {
        homeService.evaluate(evaluateIn);
        return JsonOut.ok();
    }

    @ApiOperation(value = "结束排队")
    @PostMapping("/end-rank")
    public JsonOut endRank() {
        homeService.endRank();
        return JsonOut.ok();
    }
}
