package com.jiahui.im.modules.common.dto.bigfront;

import lombok.Data;

@Data
public class DeptInfoDto {
	/**
	 * 科室id
	 */
	private Long id;

	/**
	 * 科室中文名称
	 */
	private String departmentNameCn;

	/**
	 * 科室英文名称
	 */
	private String departmentNameEn;
}
