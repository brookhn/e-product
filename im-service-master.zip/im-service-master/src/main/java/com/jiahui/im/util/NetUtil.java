package com.jiahui.im.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

public class NetUtil {
    //10.0.0.0/8：10.0.0.0～10.255.255.255
    //172.16.0.0/12：172.16.0.0～172.31.255.255
    //192.168.0.0/16：192.168.0.0～192.168.255.255
    public static boolean isInnerIp(String ip)
    {
//        String reg = "^(10|172|192)\\.([0-1][0-9]{0,2}|[2][0-5]{0,2}|[3-9][0-9]{0,1})\\.([0-1][0-9]{0,2}|[2][0-5]{0,2}|[3-9][0-9]{0,1})\\.([0-1][0-9]{0,2}|[2][0-5]{0,2}|[3-9][0-9]{0,1})";
        String reg = "^(10|172|192)\\.([0-1][0-9]{0,2}|[2][0-5]{0,2}|[3-9][0-9]{0,1})\\.([0-1][0-9]{0,2}|[2][0-9]{0,2}|[3-9][0-9]{0,1})\\.([0-1][0-9]{0,2}|[2][0-5]{0,2}|[3-9][0-9]{0,1})$";
        Pattern p = Pattern.compile(reg);
        Matcher matcher = p.matcher(ip);
        return matcher.find();
    }
    /**
     * 获取客户端IP地址
     *
     * @param request HttpServletRquest
     * @return String
     */
    public static String getClientIpAddr(HttpServletRequest request) {
//        String clientIp = request.getHeader("clientIp");
//        if (clientIp != null && clientIp.length() > 1) return clientIp;
//        String ip = request.getHeader("x-forwarded-for");
        String ip = request.getHeader("X-Forwarded-For");
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
            //防止 hang
//            if (ip.equals("127.0.0.1")) {
//                //根据网卡取本机配置的IP
//                InetAddress inet = null;
//                try {
//                    inet = InetAddress.getLocalHost();
//                } catch (UnknownHostException e) {
//                    e.printStackTrace();
//                }
//                ip = inet != null ? inet.getHostAddress() : null;
//            }
        }
        // 对于通过多个代理的情况，第一个IP为客户端真实IP,多个IP按照','分割
        if (ip != null && ip.length() > 15) {
            if (ip.indexOf(",") > 0) {
                ip = ip.substring(0, ip.indexOf(","));
            }
        }
        return ip;
    }

    public static Integer getServerPort(HttpServletRequest request) {
        return request.getLocalPort();
    }
    
    public static int justUrlStatus(String url, String innerTopLevelDomain,String serviceName)
    {
        String reg3="^http(s){0,1}://"+serviceName;
//        String reg3="^(http(s){0,1}://"+serviceName+")|^("+serviceName+")";
        //域名 svName
        if(Pattern.compile(reg3).matcher(url).find()){
            return 3;
        }
//        String reg1="^http(s){0,1}://([\\.\\da-zA-Z_-]+\\.)"+innerTopLevelDomain;
        String reg1="^http(s){0,1}://([\\.\\da-zA-Z_-]+\\.)"+innerTopLevelDomain;
        String reg2="^http(s){0,1}://(127\\.0\\.0\\.1)|(localhost)|(10\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3})|(172\\.((1[6-9])|(2\\d)|(3[01]))\\.\\d{1,3}\\.\\d{1,3})|(192\\.168\\.\\d{1,3}\\.\\d{1,3})|(100\\.((6[4-9])|([7-9]\\d)|1[01]\\d|12[0-7])\\.\\d{1,3}\\.\\d{1,3})";
        //特定域名判断
        if(Pattern.compile(reg1).matcher(url).find()){
            return 1;
        }
        //域名断为ip地址判断
        if(Pattern.compile(reg2).matcher(url).find()){
            return 2;
        }
//        String reg=reg1+"|"+reg2;
//        Pattern p = Pattern.compile(reg1);
//        Matcher matcher = p.matcher(url);
//        return matcher.find();
//        return (Pattern.compile(reg1).matcher(url).find()|Pattern.compile(reg2).matcher(url).find());
//        return (Pattern.compile(reg).matcher(url).find());
        return 0;
    }



}
