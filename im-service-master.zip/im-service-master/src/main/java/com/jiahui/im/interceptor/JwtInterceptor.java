package com.jiahui.im.interceptor;

import cn.hutool.core.date.DateUtil;
import com.jiahui.im.common.CodeMsg;
import com.jiahui.im.common.exception.UnauthorizedException;
import com.jiahui.im.config.properties.JwtProperties;
import com.jiahui.im.constant.GlobalVar;
import com.jiahui.im.context.UserThreadContext;
import com.jiahui.im.helper.MyJwt;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Objects;

/**
 * jwt拦截器
 * @author Tommy
 * @date 2021/6/11
 */
@Log4j2
@Component
public class JwtInterceptor implements HandlerInterceptor {

    @Autowired
    private JwtProperties jwtProperties;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        if(!handler.getClass().isAssignableFrom(HandlerMethod.class)){
            return true;
        }
        // 验证jwt（jwt已在Log4j2Filter中解析）
        MyJwt myJwt = UserThreadContext.getUserVisitor().getMyJwt();
        if (Objects.isNull(myJwt) || myJwt.getStatus() != 0) {
            throw new UnauthorizedException(CodeMsg.UNAUTHORIZED);
        }
        // 响应头设置jwtToken
        String jwtToken = UserThreadContext.getUserVisitor().getJwtToken();
        response.setHeader(jwtProperties.getHeader(), jwtToken);
        response.setHeader(GlobalVar.TIMESTAMP, String.valueOf(DateUtil.current()));
        return true;
    }
}
