package com.jiahui.im.modules.api.vo.oss;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@ApiModel
@Data
public class STSTokenOut {
	@ApiModelProperty(value = "临时访问密钥ID")
	private String accessKeyId = "";

	@ApiModelProperty(value = "临时访问密钥Secret")
	private String accessKeySecret = "";

	@ApiModelProperty(value = "安全令牌")
	private String securityToken = "";

	@ApiModelProperty(value = "临时访问凭证有效时间 UTC格式")
	private String expiration = "";

	@ApiModelProperty(value = "Bucket所在地域对应的Endpoint")
	private String endPoint = "";

	@ApiModelProperty(value = "Bucket名称")
	private String bucketName = "";
}
