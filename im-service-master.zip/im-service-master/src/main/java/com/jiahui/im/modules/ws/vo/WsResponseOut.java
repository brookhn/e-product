package com.jiahui.im.modules.ws.vo;

import com.jiahui.im.common.CodeMsg;
import com.jiahui.im.common.exception.BizException;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Collections;
import java.util.Optional;

/**
 * ws响应对象
 * @author Tommy
 * @date 2021/8/2
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WsResponseOut<T> {
    /**
     * 操作指令
     */
    private String action;

    /**
     * 业务码
     */
    private int code;

    /**
     * 业务码描述
     */
    private String msg;

    /**
     * 业务数据
     */
    private T data;


    public T getData() {
        return Optional.ofNullable(data).orElse((T) Collections.emptyMap());
    }

    public WsResponseOut(int code, String message) {
        this.code = code;
        this.msg = message;
    }

    public WsResponseOut(CodeMsg codeMsg) {
        this.code = codeMsg.code();
        this.msg = codeMsg.msg();
    }

    public WsResponseOut(String action, CodeMsg codeMsg) {
        this.action = action;
        this.code = codeMsg.code();
        this.msg = codeMsg.msg();
    }

    public WsResponseOut(String action, CodeMsg codeMsg, T data) {
        this.action = action;
        this.code = codeMsg.code();
        this.msg = codeMsg.msg();
        this.data = data;
    }

    public static WsResponseOut ok(String action) {
        return new WsResponseOut(action, CodeMsg.CODE_200);
    }

    public static <T> WsResponseOut<T> ok(String action, T data) {
        return new WsResponseOut(action, CodeMsg.CODE_200, data);
    }

    public static WsResponseOut error(CodeMsg codeMsg) {
        return new WsResponseOut(codeMsg);
    }

    public static WsResponseOut error(int code, String msg) {
        return new WsResponseOut(code, msg);
    }

    public static WsResponseOut error(BizException e) {
        return new WsResponseOut(e.getCode(), e.getMsg());
    }
}
