package com.jiahui.im.modules.ws.tio;

import com.jiahui.im.modules.ws.config.ImWsServerConfig;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.tio.server.ServerTioConfig;
import org.tio.websocket.server.WsServerStarter;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.io.IOException;
import java.util.Optional;

@Log4j2
@Component
public class ImWebsocketStarter {

    @Autowired
    private ImWsServerConfig imWsServerConfig;

    @Autowired
    private ImWsMsgHandler imWsMsgHandler;

    @Autowired
    private ImWsServerAioListener imWsServerAioListener;

    private static ServerTioConfig serverGroupContext;

    private static WsServerStarter wsServerStarter;

    public static ServerTioConfig getServerGroupContext() {
        return serverGroupContext;
    }

    @PostConstruct
    public void init() {
        try {
            log.info("ImWebsocketStarter.init::开始启动");
            wsServerStarter = new WsServerStarter(imWsServerConfig.getWsPort(), imWsMsgHandler);
            serverGroupContext = wsServerStarter.getServerTioConfig();
            serverGroupContext.setName(imWsServerConfig.getProtocolName());
            serverGroupContext.setServerAioListener(imWsServerAioListener);
            serverGroupContext.debug = Optional.ofNullable(imWsServerConfig.getDebug()).orElse(Boolean.FALSE);
            //设置心跳超时时间
            serverGroupContext.setHeartbeatTimeout(imWsServerConfig.getHeartbeatTimeout());
            wsServerStarter.start();
            log.info("ImWebsocketStarter.init::启动成功");
        } catch (IOException e) {
            log.error("ImWebsocketStarter.init::启动失败", e);
            System.exit(-1);
        }
    }

    @PreDestroy
    public void destroy() {
        log.info("ImWebsocketStarter.destroy::关闭tio服务");
        boolean isStop = wsServerStarter.getTioServer().stop();
        log.info("ImWebsocketStarter.destroy::tio服务已关闭，关闭状态：{}", isStop);
    }
}