package com.jiahui.im.interceptor;

import cn.hutool.core.io.IoUtil;
import cn.hutool.core.util.NumberUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONValidator;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.jiahui.im.common.CodeMsg;
import com.jiahui.im.common.exception.BizException;
import com.jiahui.im.util.SignUtil;
import lombok.extern.log4j.Log4j2;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 签名拦截器
 * @author Tommy
 * @date 2021/6/11
 */
@Log4j2
@Component
public class SignAuthInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        if(!handler.getClass().isAssignableFrom(HandlerMethod.class)){
            return true;
        }
        // 非post请求，放行
        if (!HttpMethod.POST.name().equalsIgnoreCase(request.getMethod())) {
            return true;
        }
        try {
            // 读取请求体body
            String body = IoUtil.read(request.getReader());
            String sortedBody = body;
            boolean isJsonStr = JSONValidator.from(body).validate();
            if (isJsonStr) {
                // 对请求体内json进行字典排序，保证和调用方一致
                sortedBody = JSON.toJSONString(JSON.parse(body), SerializerFeature.MapSortField);
            }
            /**
             * 校验请求头
             * - timestamp：毫秒级时间戳
             * - nonce：随机字符串
             * - sign：签名
             */
            String timestamp = request.getHeader("timestamp");
            if (!NumberUtil.isNumber(timestamp)) {
                throw new BizException(CodeMsg.SIGN_PARAMS_EXCEPTION);
            }
            String nonce = request.getHeader("nonce");
            if (StrUtil.isBlank(nonce) || nonce.length() < 32) {
                throw new BizException(CodeMsg.SIGN_PARAMS_EXCEPTION);
            }
            String sign = request.getHeader("sign");
            if (StrUtil.isBlank(sign)) {
                throw new BizException(CodeMsg.SIGN_PARAMS_EXCEPTION);
            }
            // 生成签名
            String serverSign = SignUtil.generateSign(timestamp, nonce, sortedBody);
            // 对比签名
            if (!sign.equals(serverSign)) {
                throw new BizException(CodeMsg.SIGN_EXCEPTION);
            }
        } catch (BizException e1) {
            throw e1;
        } catch (Exception e2) {
            throw new BizException(CodeMsg.SIGN_EXCEPTION);
        }
        return true;
    }
}
