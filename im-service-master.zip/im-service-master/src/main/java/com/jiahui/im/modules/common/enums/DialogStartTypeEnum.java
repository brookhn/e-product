package com.jiahui.im.modules.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

@Getter
@AllArgsConstructor
public enum DialogStartTypeEnum {

    USER(1, "用户发起"),
    KEFU(2, "客服发起"),
    ;

    /**
     * 会话开始方式
     */
    private final Integer type;

    /**
     * 描述
     */
    private final String desc;

    public static final Map<Integer, DialogStartTypeEnum> map = Arrays.stream(DialogStartTypeEnum.values()).collect(Collectors.toMap(DialogStartTypeEnum::getType, e -> e));

    public static DialogStartTypeEnum fromType(Integer type) {
        return map.get(type);
    }
}
