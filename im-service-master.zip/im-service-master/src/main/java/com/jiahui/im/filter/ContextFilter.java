package com.jiahui.im.filter;

import com.jiahui.im.config.properties.JwtProperties;
import com.jiahui.im.context.UserThreadContext;
import com.jiahui.im.context.UserVisitor;
import com.jiahui.im.util.NetUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 上下文过滤器
 * - ContextFilter优先级要在Log4j2Filter之前
 * @author Tommy
 * @date 2021/6/16
 */
@Component
public class ContextFilter extends OncePerRequestFilter {

    @Autowired
    private JwtProperties jwtProperties;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        try {
            UserThreadContext.requestStart();
            // 获取请求头信息
            UserVisitor visitor = getRequestHeader(request);
            String clientIp = NetUtil.getClientIpAddr(request);
            visitor.setClientIp(clientIp);
            // 设置上下文
            UserThreadContext.setUserVisitor(visitor);
            filterChain.doFilter(request, response);
        } finally {
            UserThreadContext.requestEnd();
        }
    }

    /**
     * 获取请求头信息
     * @param request
     * @return
     */
    public UserVisitor getRequestHeader(HttpServletRequest request) {
        String jwtToken = request.getHeader(jwtProperties.getHeader());
        UserVisitor visitor = new UserVisitor();
        visitor.setJwtToken(jwtToken);
        return visitor;
    }
}
