package com.jiahui.im.modules.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

@Getter
@AllArgsConstructor
public enum DialogEndTypeEnum {

    USER_END_QUEUE(10, "用户结束排队"),

    KEFU_END(20, "客服结束会话"),
    OVERTIME(22, "超时结束会话"),
    ;

    /**
     * 会话结束方式
     */
    private final Integer type;

    /**
     * 描述
     */
    private final String desc;

    public static final Map<Integer, DialogEndTypeEnum> map = Arrays.stream(DialogEndTypeEnum.values()).collect(Collectors.toMap(DialogEndTypeEnum::getType, e -> e));

    public static DialogEndTypeEnum fromType(Integer type) {
        return map.get(type);
    }
}
