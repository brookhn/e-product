package com.jiahui.im.modules.api.vo.oss;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class DirectIn {

    @ApiModelProperty(value = "上传到OSS文件的前缀", required = true)
    @NotBlank
    private String dir;
}
