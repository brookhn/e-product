package com.jiahui.im.modules.common.service;

import cn.hutool.core.util.StrUtil;
import com.jiahui.im.modules.common.dto.bigfront.UserInfoDto;
import com.jiahui.im.modules.common.dto.his.dict.DictRespDto;
import com.jiahui.im.modules.common.dto.his.patient.PatientDto;
import com.jiahui.im.modules.common.dto.his.patient.PatientRespDto;
import com.jiahui.im.modules.common.enums.HisDictNameEnum;
import com.jiahui.im.modules.common.enums.MAPatientAuthRelationEnum;
import com.jiahui.im.modules.common.service.CacheService;
import com.jiahui.im.modules.common.service.HisService;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.Objects;
import java.util.Optional;

/**
 * @author Tommy
 * @date 2022/01/14
 */
@Log4j2
@Service
public class PatientService {

    @Autowired
    private HisService hisService;

    @Autowired
    private CacheService cacheService;

    /**
     * 根据mrn获取就诊人信息
     * @param relation
     * @return
     */
    public PatientDto getPatientFromHis(UserInfoDto.Relation relation) {
        // 查询就诊人信息
        PatientRespDto patientRespDto = hisService.patientInfo(relation.getPatientCode());
        if (Objects.isNull(patientRespDto)) {
            return null;
        }
        // 查询国籍
        Map<String, DictRespDto> countryMap = cacheService.getDictCache(HisDictNameEnum.COUNTRY.getCode());
        DictRespDto country = countryMap.get(patientRespDto.getCounCode());
        PatientDto patientDto = PatientDto.builder()
                .birthDate(patientRespDto.getBirthDate())
                .certificatesNum(patientRespDto.getPostId())
                .certificatesType(patientRespDto.getPostType())
                .email(patientRespDto.getEmail())
                .languageCode(patientRespDto.getMainLanguage())
                .mobile(patientRespDto.getTel())
                .mrn(patientRespDto.getPatientId())
                .name(patientRespDto.getFullName())
                .nationality(Optional.ofNullable(country).map(DictRespDto::getDictValue).orElse(StrUtil.EMPTY))
                .nationalityCode(patientRespDto.getCounCode())
                .gender(patientRespDto.getGender())
                .homeAddress(patientRespDto.getHomeAddress())
                .relations(relation.getAuthRelation())
                .relationName(MAPatientAuthRelationEnum.findByRelation(relation.getAuthRelation()).getNameCn())
                .build();
        return patientDto;
    }
}
