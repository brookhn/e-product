package com.jiahui.im.modules.api.vo.home;

import cn.hutool.core.util.StrUtil;
import com.jiahui.im.config.properties.SysProperties;
import com.jiahui.im.modules.common.enums.MsgTypeEnum;
import com.jiahui.im.modules.common.enums.UserTypeEnum;
import com.jiahui.im.modules.common.mongo.CcChatRecord;
import com.jiahui.im.modules.common.mongo.ChatRecord;
import com.jiahui.im.util.KefuUtil;
import com.jiahui.im.util.UserUtil;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.net.URL;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

/**
 * @author Tommy
 * @date 2021/8/10
 */
@ApiModel
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ChatRecordListOut {

    @ApiModelProperty(value = "记录列表")
    private List<Record> recordList = Collections.emptyList();

    @ApiModelProperty(value = "总数据量")
    private int totalCount;

    @ApiModel("ChatRecordListOutRecord")
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Record {
        @ApiModelProperty(value = "主键")
        private String id;

        @ApiModelProperty(value = "发送者id")
        private Long fromId;

        @ApiModelProperty(value = "发送者类型 1-用户 2-客服 3-系统")
        private Integer fromType;

        @ApiModelProperty(value = "发送者头像")
        private String fromHeadUrl;

        @ApiModelProperty(value = "接收者id")
        private Long toId;

        @ApiModelProperty(value = "接收者类型 1-用户 2-客服 3-系统")
        private Integer toType;

        @ApiModelProperty(value = "文件名")
        private String fileName;

        @ApiModelProperty(value = "文件大小（byte）")
        private Long fileSize;

        @ApiModelProperty(value = "消息类型 1-文本 2-图片 3-语音 4-视频 5-word 6-PDF 7-文件")
        private Integer msgType;

        @ApiModelProperty(value = "消息内容")
        private String content;

        @ApiModelProperty(value = "OSS对象名称")
        private String objectName;

        @ApiModelProperty(value = "请求标识")
        private String requestId;

        @ApiModelProperty(value = "发送时间 毫秒级时间戳")
        private Long sendTime;

        @ApiModelProperty(value = "会话id（CC客服）")
        private String conversationId;

        @ApiModelProperty(value = "展示未评价的推评 0-不展示 1-展示（CC客服）")
        private Integer showNoEvaluate;

        public Record(ChatRecord chatRecord, String userHeadUrl, Map<String, URL> ossURLMap) {
            this.id = chatRecord.getId();
            this.fromId = chatRecord.getFromId();
            this.fromType = chatRecord.getFromType();
            if (UserTypeEnum.USER.getType().equals(this.fromType)) {
                this.fromHeadUrl = UserUtil.getShowHeadUrl(userHeadUrl);
            } else if (UserTypeEnum.KEFU.getType().equals(this.fromType)) {
                this.fromHeadUrl = KefuUtil.getShowDeptHeadUrl(chatRecord.getDeptId());
            } else {
                this.fromHeadUrl = SysProperties.deptDefaultKefuHeadUrl;
            }
            this.toId = chatRecord.getToId();
            this.toType = chatRecord.getToType();
            this.fileName = chatRecord.getFileName();
            this.fileSize = chatRecord.getFileSize();
            this.msgType = chatRecord.getMsgType();
            // 处理OSS私有bucket文件链接
            Boolean isOssResource = Optional.ofNullable(MsgTypeEnum.fromType(chatRecord.getMsgType())).map(MsgTypeEnum::isOssResource).orElse(false);
            this.content = isOssResource ? Optional.ofNullable(ossURLMap.get(chatRecord.getContent())).map(URL::toString)
                    .orElse(StrUtil.EMPTY) : chatRecord.getContent();
            this.objectName = isOssResource ? chatRecord.getContent() : StrUtil.EMPTY;
            this.requestId = chatRecord.getRequestId();
            this.sendTime = chatRecord.getCreateTime().getTime();
        }

        public Record(CcChatRecord ccChatRecord, String userHeadUrl, Map<String, URL> ossURLMap, Set<String> endMsgIdSet) {
            this.id = ccChatRecord.getId();
            this.fromId = ccChatRecord.getFromId();
            this.fromType = ccChatRecord.getFromType();
            if (UserTypeEnum.USER.getType().equals(this.fromType)) {
                this.fromHeadUrl = UserUtil.getShowHeadUrl(userHeadUrl);
            } else {
                this.fromHeadUrl = SysProperties.ccDefaultKefuHeadUrl;
            }
            this.toId = ccChatRecord.getToId();
            this.toType = ccChatRecord.getToType();
            this.fileName = ccChatRecord.getFileName();
            this.fileSize = ccChatRecord.getFileSize();
            this.msgType = ccChatRecord.getMsgType();
            // 处理OSS私有bucket文件链接
            Boolean isOssResource = Optional.ofNullable(MsgTypeEnum.fromType(ccChatRecord.getMsgType())).map(MsgTypeEnum::isOssResource).orElse(false);
            this.content = isOssResource ? Optional.ofNullable(ossURLMap.get(ccChatRecord.getContent())).map(URL::toString).orElse(StrUtil.EMPTY) : ccChatRecord.getContent();
            this.objectName = isOssResource ? ccChatRecord.getContent() : StrUtil.EMPTY;
            this.requestId = ccChatRecord.getRequestId();
            this.conversationId = ccChatRecord.getConversationId();
            this.sendTime = ccChatRecord.getCreateTime().getTime();
            this.showNoEvaluate = endMsgIdSet.contains(this.id) ? 1 : 0;
        }
    }
}
