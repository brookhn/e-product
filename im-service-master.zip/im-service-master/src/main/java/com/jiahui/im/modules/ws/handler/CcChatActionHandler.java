package com.jiahui.im.modules.ws.handler;

import cn.hutool.core.convert.Convert;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.IdUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.jiahui.im.common.CodeMsg;
import com.jiahui.im.common.exception.BizException;
import com.jiahui.im.constant.Constant;
import com.jiahui.im.constant.KafkaConstant;
import com.jiahui.im.helper.MyJwt;
import com.jiahui.im.helper.RedisHelper;
import com.jiahui.im.modules.api.service.OssService;
import com.jiahui.im.modules.common.entity.CcUserBindingEntity;
import com.jiahui.im.modules.common.entity.CcUserDialogEntity;
import com.jiahui.im.modules.common.entity.CcUserEntity;
import com.jiahui.im.modules.common.entity.CcUserUnboundEntity;
import com.jiahui.im.modules.common.enums.CcKefuNoticeEnum;
import com.jiahui.im.modules.common.enums.ChannelTypeEnum;
import com.jiahui.im.modules.common.enums.DialogStartTypeEnum;
import com.jiahui.im.modules.common.enums.KefuTypeEnum;
import com.jiahui.im.modules.common.enums.MsgTypeEnum;
import com.jiahui.im.modules.common.enums.ReceptTypeEnum;
import com.jiahui.im.modules.common.enums.UserTypeEnum;
import com.jiahui.im.modules.common.mapper.CcUserBindingMapper;
import com.jiahui.im.modules.common.mapper.CcUserDialogMapper;
import com.jiahui.im.modules.common.mapper.CcUserExtMapper;
import com.jiahui.im.modules.common.mapper.CcUserUnboundMapper;
import com.jiahui.im.modules.common.mongo.CcChatRecord;
import com.jiahui.im.modules.common.mongo.CcChatRecordDao;
import com.jiahui.im.modules.common.service.CcAllocateService;
import com.jiahui.im.modules.ws.constant.ImConst;
import com.jiahui.im.modules.ws.converter.CcChatConverter;
import com.jiahui.im.modules.ws.dto.kafka.CcChatRecordDto;
import com.jiahui.im.modules.ws.dto.kafka.SyncCcChatRecordDto;
import com.jiahui.im.modules.ws.dto.kafka.kefu.CcRankNumDto;
import com.jiahui.im.modules.ws.dto.kafka.notice.NoticeDto;
import com.jiahui.im.modules.ws.enums.ClientActionEnum;
import com.jiahui.im.modules.ws.util.WsInputChecker;
import com.jiahui.im.modules.ws.util.WsUtil;
import com.jiahui.im.modules.ws.vo.WsRequestIn;
import com.jiahui.im.modules.ws.vo.action.ChatActionIn;
import com.jiahui.im.util.UserUtil;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;
import org.tio.core.ChannelContext;

import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

/**
 * CC客服-聊天指令处理器
 * @author Tommy
 * @date 2021/08/03
 */
@Log4j2
@Component
public class CcChatActionHandler implements IActionHandler {

    @Autowired
    private KafkaTemplate<String, String> kafkaImTemplate;

    @Autowired
    private CcChatRecordDao ccChatRecordDao;

    @Autowired
    private CcUserExtMapper ccUserExtMapper;

    @Autowired
    private CcUserBindingMapper ccUserBindingMapper;

    @Autowired
    private CcUserUnboundMapper ccUserUnboundMapper;

    @Autowired
    private CcUserDialogMapper ccUserDialogMapper;

    @Autowired
    private OssService ossService;

    @Autowired
    private CcAllocateService ccAllocateService;

    @Override
    public String getAction() {
        return ClientActionEnum.CHAT.getAction();
    }

    @Override
    public Integer getKefuType() {
        return KefuTypeEnum.CC.getType();
    }

    @Override
    public void handle(ChannelContext channelContext, WsRequestIn wsRequestIn) {
        MyJwt myJwt = (MyJwt) channelContext.get(ImConst.JWT_INFO);
        CcUserEntity ccUserEntity = (CcUserEntity) channelContext.get(ImConst.USER_INFO);
        // 类型转换
        ChatActionIn chatActionIn = Convert.convert(ChatActionIn.class, wsRequestIn.getParams());
        // 校验入参
        try {
            WsInputChecker.checker().checkParams(chatActionIn);
        } catch (BizException e) {
            // 响应错误信息
            WsUtil.sendError(channelContext, e);
            return;
        }

        /* ---------------- 查询绑定关系 ---------------- */
        DateTime now = DateTime.now();
        String conversationId;
        ReceptTypeEnum receptTypeEnum;
        Long bindRecordId = null;
        boolean isNewConversation = false;//是否新会话
        CcUserBindingEntity ccUserBindingEntity = ccUserBindingMapper.selectByUk(ccUserEntity.getId());
        if (Objects.nonNull(ccUserBindingEntity)) {//已绑定
            receptTypeEnum = ReceptTypeEnum.RECEIVING;
            conversationId = ccUserBindingEntity.getConversationId();
            bindRecordId = ccUserBindingEntity.getBindRecordId();
        } else {//未绑定
            receptTypeEnum = ReceptTypeEnum.WAITING;
            CcUserUnboundEntity ccUserUnboundEntity = ccUserUnboundMapper.selectByUk(ccUserEntity.getId());
            if (Objects.isNull(ccUserUnboundEntity)) {//不在排队
                conversationId = IdUtil.fastSimpleUUID();
                isNewConversation = true;
            } else {//在排队
                conversationId = ccUserUnboundEntity.getConversationId();
            }
        }

        /* ---------------- 消息入库 ---------------- */
        CcChatRecord ccChatRecord = CcChatRecord.builder()
                .userId(ccUserEntity.getId())
                .fromId(ccUserEntity.getId())
                .fromType(UserTypeEnum.USER.getType())
                .toId(0L)
                .toType(UserTypeEnum.KEFU.getType())
                .fileName(StrUtil.EMPTY)
                .fileSize(0L)
                .msgType(chatActionIn.getMsgType())
                .content(chatActionIn.getContent())
                .deptId(0L)
                .channelType(myJwt.getChannelType())
                .systemVersion(myJwt.getSystemVersion())
                .deviceModel(myJwt.getDeviceModel())
                .appVersion(myJwt.getAppVersion())
                .requestId(chatActionIn.getRequestId())
                .conversationId(conversationId)
                .createTime(now)
                .updateTime(now)
                .build();
        try {
            ccChatRecordDao.save(ccChatRecord);
        } catch (DuplicateKeyException e1) {
            // 消息幂等性校验
            WsUtil.sendError(channelContext, CodeMsg.DUPLICATE_REQUEST_ID);
            return;
        } catch (Exception e2) {
            log.error("聊天消息写入MongoDB异常", e2);
            WsUtil.sendError(channelContext, CodeMsg.SYSTEM_EXCEPTION);
            return;
        }

        /* ---------------- 新会话逻辑 ---------------- */
        Integer ranking = null;
        if (isNewConversation) {
            CcUserUnboundEntity tempCcUserUnboundEntity = CcUserUnboundEntity.builder()
                    .conversationId(conversationId)
                    .userId(ccUserEntity.getId())
                    .channelType(myJwt.getChannelType())
                    .systemVersion(myJwt.getSystemVersion())
                    .deviceModel(myJwt.getDeviceModel())
                    .appVersion(myJwt.getAppVersion())
                    .userQuestionTime(now)
                    .build();
            // 是否需要排队
            int rankCount = ccUserUnboundMapper.count();
            Pair<Boolean, Long> allocatePair = Pair.of(false, null);
            if (rankCount == 0) {
                // 前面没人排队，尝试分配新用户
                allocatePair = ccAllocateService.allocateNewUser(tempCcUserUnboundEntity, chatActionIn);
            }
            if (allocatePair.getLeft()) {//分配成功，已经发送接待成功通知
                receptTypeEnum = ReceptTypeEnum.RECEIVING;
                bindRecordId = allocatePair.getRight();
            } else {//分配失败|需要排队，走排队逻辑
                // 维护未绑定表和会话表
                CcUserDialogEntity tempCcUserDialogEntity = CcUserDialogEntity.builder()
                        .conversationId(conversationId)
                        .userId(ccUserEntity.getId())
                        .channelType(myJwt.getChannelType())
                        .systemVersion(myJwt.getSystemVersion())
                        .deviceModel(myJwt.getDeviceModel())
                        .appVersion(myJwt.getAppVersion())
                        .isRecept(Constant.FALSE)
                        .startType(DialogStartTypeEnum.USER.getType())
                        .startTime(now)
                        .isRank(Constant.TRUE)
                        .build();
                try {
                    ccUserUnboundMapper.insertSelective(tempCcUserUnboundEntity);
                    ccUserDialogMapper.insertSelective(tempCcUserDialogEntity);
                } catch (DuplicateKeyException e) {
                    // do nothing
                }
                // 将排队信息放在消息体中一起发给用户
                ranking = rankCount + 1;
                /* ----------------发送kafka，通知客服【排队人数变更】---------------- */
                int rankNum = ccUserUnboundMapper.count();
                CcRankNumDto ccRankNumDto = new CcRankNumDto(CcKefuNoticeEnum.RANK_NUM.getType(), rankNum);
                NoticeDto<CcRankNumDto> rankNumNoticeDto = new NoticeDto<>(ccRankNumDto.getNoticeType(), ccRankNumDto);
                kafkaImTemplate.send(KafkaConstant.TOPIC_CC_IM_KEFU_NOTICE_MSG, JSON.toJSONString(rankNumNoticeDto));
            }
        }

        // 发送kafka，异步消费写入MySQL
        SyncCcChatRecordDto syncCcChatRecordDto = CcChatConverter.INSTANCE.chatRecord2SyncDto(ccChatRecord);
        syncCcChatRecordDto.setBindRecordId(bindRecordId);
        syncCcChatRecordDto.setAccountId(ccUserEntity.getAccountId());
        syncCcChatRecordDto.setKafkaSendTime(DateUtil.current());
        kafkaImTemplate.send(KafkaConstant.TOPIC_CC_IM_CHAT_RECORD, syncCcChatRecordDto.getUserId().toString(), JSON.toJSONString(syncCcChatRecordDto));
        // 标记用户消息为未读
        RedisHelper.setBit(StrUtil.format(Constant.CC_USER_MSG_IS_READ), ccUserEntity.getId(), Boolean.FALSE);
        // 维护用户首次咨询标记
        boolean userFirstQuestionFlag = (boolean) channelContext.get(ImConst.CC_USER_FIRST_QUESTION_FLAG);
        if (!userFirstQuestionFlag) {
            ccUserExtMapper.updateFirstQuestionFlag(ccUserEntity.getId(), myJwt.getChannelType());
            // 设置用户首次咨询标记
            channelContext.set(ImConst.CC_USER_FIRST_QUESTION_FLAG, true);
        }

        /* ---------------- 发送kafka【聊天消息】 ---------------- */
        CcChatRecordDto ccChatRecordDto = CcChatConverter.INSTANCE.chatRecord2Dto(ccChatRecord);
        ccChatRecordDto.setFromName(UserUtil.getShowName(ccUserEntity));
        ccChatRecordDto.setFromHeadUrl(UserUtil.getShowHeadUrl(ccUserEntity.getHeadUrl()));
        ccChatRecordDto.setFromNationality(ccUserEntity.getNationality());
        ccChatRecordDto.setReceptType(receptTypeEnum.getType());
        ccChatRecordDto.setChannel(ChannelTypeEnum.fromType(myJwt.getChannelType()).getDesc());
        ccChatRecordDto.setRanking(ranking);
        // 处理OSS资源
        Boolean isOssResource = Optional.ofNullable(MsgTypeEnum.fromType(ccChatRecord.getMsgType())).map(MsgTypeEnum::isOssResource).orElse(Boolean.FALSE);
        ccChatRecordDto.setObjectName(isOssResource ? ccChatRecord.getContent() : StrUtil.EMPTY);
        if (isOssResource) {
            // 获取OSS私有bucket文件链接
            String ossUrl = ossService.ossPresignedUrl(ccChatRecord.getContent(), ccChatRecord.getMsgType()).toString();
            ccChatRecordDto.setContent(ossUrl);
        }
        ccChatRecordDto.setKafkaSendTime(DateUtil.current());
        kafkaImTemplate.send(KafkaConstant.TOPIC_CC_IM_USER_MSG, JSON.toJSONString(ccChatRecordDto));
    }
}
