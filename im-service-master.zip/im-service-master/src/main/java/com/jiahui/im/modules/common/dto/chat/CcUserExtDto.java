package com.jiahui.im.modules.common.dto.chat;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * @author Tommy
 * @date 2022/1/19
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CcUserExtDto {
    /* ----------------cc_user表字段---------------- */
    /**
     * 账号id
     */
    private Long accountId;

    /**
     * 电话
     */
    private String phone;

    /**
     * 姓名
     */
    private String userName;

    /**
     * 绑定本人性别 M-男 F-女
     */
    private String gender;

    /**
     * 头像
     */
    private String headUrl;

    /**
     * 注册来源编码
     */
    private String terminalCode;

    /**
     * 注册来源
     */
    private String terminal;

    /**
     * 绑定本人mrn
     */
    private String mrn;

    /**
     * 绑定本人姓名
     */
    private String patientName;

    /**
     * 绑定本人生日
     */
    private Date birthday;

    /**
     * 绑定本人国籍编码
     */
    private String nationalityCode;

    /**
     * 绑定本人国籍
     */
    private String nationality;

    /**
     * 绑定家庭成员数量
     */
    private Integer bindCount;

    /* ----------------cc_user_ext表字段---------------- */
    /**
     * 用户id
     */
    private Long userId;

    /**
     * 用户最后一条消息时间
     */
    private Date lastSendTime;

    /**
     * 用户最后一条消息文件名
     */
    private String lastFileName;

    /**
     * 用户最后一条消息文件大小（byte）
     */
    private Long lastFileSize;

    /**
     * 用户最后一条消息类型 1-文本 2-图片 3-语音 4-视频 5-word 6-PDF 7-文件
     */
    private Integer lastMsgType;

    /**
     * 用户最后一条消息内容
     */
    private String lastContent;

    /**
     * 用户最后一条消息渠道类型 1-APP 2-公众号 3-小程序 4-企业微信
     */
    private Integer lastChannelType;
}
