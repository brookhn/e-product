package com.jiahui.im.modules.common.dto.bigfront;

import lombok.Data;

@Data
public class GetUserInfoReqDto {
	/**
	 * 页码
	 */
	private Integer current;

	/**
	 * 每页数据量
	 */
	private Integer size;

	/**
	 * 手机号
	 */
	private String phone;

	/**
	 * 注册来源
	 */
	private String terminal;
}
