package com.jiahui.im.constant;

import com.jiahui.im.config.properties.SysProperties;

/**
 * 常量
 */
public class Constant {

    /**
     * redis key
     */
    /** -------------------CC客服--------------------- */
    public static final String CC_PREFIX = "cc-im-".concat(SysProperties.profile).concat(":");
    // 用户消息已读状态
    public static final String CC_USER_MSG_IS_READ = CC_PREFIX.concat("user-msg:is-read");
    // 请求标识
//    public static final String CC_USER_REQUEST_ID = CC_PREFIX.concat("user:{}:request-id:{}");
    // 用户ws连接id有序集合（可以查看连接建立时间）
    public static final String CC_USER_CHANNEL_ID_ZSET = CC_PREFIX.concat("user:{}:channel-id-zset");
    // 用户锁
    public static final String CC_USER_ACCOUNT_LOCK = CC_PREFIX.concat("user:account-id:{}:lock");

    /** -------------------科室客服--------------------- */
    public static final String DEPT_PREFIX = "dept-im-".concat(SysProperties.profile).concat(":");
    // 用户消息已读状态
    public static final String DEPT_USER_MSG_IS_READ = DEPT_PREFIX.concat("dept:{}:user-msg:is-read");
    // 请求标识
//    public static final String DEPT_USER_REQUEST_ID = DEPT_PREFIX.concat("user:{}:request-id:{}");
    // 用户某科室ws连接id有序集合（可以查看连接建立时间）
    public static final String DEPT_USER_CHANNEL_ID_ZSET = DEPT_PREFIX.concat("user:{}:dept:{}:channel-id-zset");
    // 用户全部ws连接id有序集合（可以查看连接建立时间）
    public static final String DEPT_USER_ALL_CHANNEL_ID_ZSET = DEPT_PREFIX.concat("user:{}:channel-id-zset");
    // 用户锁
    public static final String DEPT_USER_ACCOUNT_LOCK = DEPT_PREFIX.concat("user:account-id:{}:lock");

    /** -------------------全部客服--------------------- */
    public static final String KEFU_PREFIX = "kefu-im-".concat(SysProperties.profile).concat(":");
    // 用户在某渠道的ws连接id有序集合（可以查看连接建立时间）【包含CC客服和科室客服】
    public static final String KEFU_USER_CHANNEL_CHANNEL_ID_ZSET = KEFU_PREFIX.concat("user:{}:channel:{}:channel-id-zset");
    // 用户全部ws连接id有序集合（可以查看连接建立时间）【包含CC客服和科室客服】
    public static final String KEFU_USER_CHANNEL_ID_ZSET = KEFU_PREFIX.concat("user:{}:channel-id-zset");



    /**
     * kafka topic
     */
    /** -------------------CC客服--------------------- */
//    public static final String TOPIC_CC_IM_USER_MSG = "CC-IM-USER-MSG";//用户消息
//    public static final String TOPIC_CC_IM_KEFU_MSG = "CC-IM-KEFU-MSG";//客服消息
//    public static final String TOPIC_CC_IM_USER_NOTICE_MSG = "CC-IM-USER-NOTICE-MSG";//用户通知消息
//    public static final String TOPIC_CC_IM_KEFU_NOTICE_MSG = "CC-IM-KEFU-NOTICE-MSG";//客服通知消息
//    public static final String TOPIC_CC_IM_CHAT_RECORD = "CC-IM-CHAT-RECORD";//聊天记录
//    public static final String TOPIC_CC_IM_USER_ALLOCATE = "CC-IM-USER-ALLOCATE";//用户排队分配

    /** -------------------科室客服--------------------- */
//    public static final String TOPIC_DEPT_IM_USER_MSG = "DEPT-IM-USER-MSG";//用户消息
//    public static final String TOPIC_DEPT_IM_KEFU_MSG = "DEPT-IM-KEFU-MSG";//客服消息
//    public static final String TOPIC_DEPT_IM_NOTICE_MSG = "DEPT-IM-NOTICE-MSG";//通知消息
//    public static final String TOPIC_DEPT_IM_CHAT_RECORD = "DEPT-IM-CHAT-RECORD";//聊天记录



    /**
     * 系统默认值
     */
    public static final String DEFAULT_KEFU_NAME = "系统客服";//默认客服名称
    public static final String DEFAULT_USER_NAME = "游客";//默认用户名称
//    public static final Integer CC_DEFAULT_RECEPT_LIMIT = 5;//CC客服-默认接待上限

    /**
     * oss相关
     */
    public static final String OSS_VIDEO_STYLE = "video/snapshot,t_1000,f_jpg,m_fast,ar_auto";//视频截帧

    /**
     * 真假 0-假 1-真
     */
    public static final Integer FALSE = 0;
    public static final Integer TRUE = 1;
}
