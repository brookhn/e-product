package com.jiahui.im.modules.common.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * 科室客服-用户连接记录表
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DeptUserConnectRecordEntity {
    /**
     * 主键
     */
    private Long id;

    /**
     * 会话id
     */
    private String sessionId;

    /**
     * 用户id
     */
    private Long userId;

    /**
     * 账号id
     */
    private Long accountId;

    /**
     * 科室id
     */
    private Long deptId;

    /**
     * 渠道类型 1-APP 2-公众号 3-小程序 4-企业微信
     */
    private Integer channelType;

    /**
     * 连接建立时间
     */
    private Date connectTime;

    /**
     * 连接活跃时间
     */
    private Date activeTime;

    /**
     * 连接断开时间
     */
    private Date breakTime;

    /**
     * 连接断开方式 0-未断开 1-自动断开 2-系统断开
     */
    private Integer breakType;

    /**
     * 备注
     */
    private String remark;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;
}