package com.jiahui.im.modules.common.dto.chat;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Tommy
 * @date 2022/1/19
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CcReceptNumDto {
    /**
     * 客服id
     */
    private Long kefuId;

    /**
     * 用户名
     */
    private String userName;

    /**
     * 姓名
     */
    private String fullName;

    /**
     * 头像
     */
    private String headUrl;

    /**
     * 客服所在部门id
     */
    private Long deptId;

    /**
     * 接待中数量
     */
    private Integer receivingNum;

    /**
     * 今日接待量
     */
    private Integer receptNum;
}
