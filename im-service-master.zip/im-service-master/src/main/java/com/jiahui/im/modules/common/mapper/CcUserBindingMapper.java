package com.jiahui.im.modules.common.mapper;

import com.jiahui.im.modules.common.entity.CcUserBindingEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface CcUserBindingMapper {
    int insertSelective(CcUserBindingEntity record);

    /**
     * 根据唯一索引查询
     * @param userId
     * @return
     */
    CcUserBindingEntity selectByUk(@Param("userId") Long userId);
}