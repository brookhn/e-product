package com.jiahui.im.modules.common.mapper;

import com.jiahui.im.modules.common.entity.CcUserBindRecordEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface CcUserBindRecordMapper {
    int insertSelective(CcUserBindRecordEntity record);

    /**
     * 查询客服今日接待人数
     * @param kefuId
     * @param eventTypeList
     * @return
     */
    int todayReceptNumByKefuId(@Param("kefuId") Long kefuId, @Param("eventTypeList") List<Integer> eventTypeList);
}