package com.jiahui.im.modules.api.vo.home;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Tommy
 * @date 2021/8/10
 */
@ApiModel
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CheckRequestIdOut {
    @ApiModelProperty(value = "请求标识")
    private String requestId;

    @ApiModelProperty(value = "聊天记录ID", notes = "发送成功时返回")
    private String recordId;

    public CheckRequestIdOut(String requestId) {
        this.requestId = requestId;
    }
}
