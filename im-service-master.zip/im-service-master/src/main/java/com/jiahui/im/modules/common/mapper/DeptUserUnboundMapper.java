package com.jiahui.im.modules.common.mapper;

import com.jiahui.im.modules.common.entity.DeptUserUnboundEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface DeptUserUnboundMapper {
    int insertSelective(DeptUserUnboundEntity record);

    /**
     * 根据唯一索引查询
     * @param userId
     * @param deptId
     * @return
     */
    DeptUserUnboundEntity selectByUk(@Param("userId") Long userId, @Param("deptId") Long deptId);

    /**
     * 根据科室查询待接待人数
     * @param deptId
     * @return
     */
    int countByDeptId(@Param("deptId") Long deptId);
}