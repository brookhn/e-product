package com.jiahui.im.modules.api.vo.login;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.NotNull;

@ApiModel
@Data
public class LoginIn {
	@ApiModelProperty(value = "用户ID", required = true)
    @NotNull
    @Range(min = 1)
    private Long accountId;

    @ApiModelProperty(value = "渠道类型 1-APP 3-小程序", required = true)
    @NotNull
    private Integer channelType;

    @ApiModelProperty(value = "科室ID（科室客服必传）")
    private Long deptId;

    @ApiModelProperty(value = "系统版本（CC客服）")
    private String systemVersion = "";

    @ApiModelProperty(value = "设备型号（CC客服）")
    private String deviceModel = "";

    @ApiModelProperty(value = "app版本（CC客服）")
    private String appVersion = "";

    @ApiModelProperty(value = "客服类型 1-科室客服 2-CC客服", required = true)
    @Range(min = 1, max = 2)
    @NotNull
    private Integer kefuType;
}