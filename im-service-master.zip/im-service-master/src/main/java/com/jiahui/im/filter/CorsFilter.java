package com.jiahui.im.filter;

import cn.hutool.core.util.StrUtil;
import com.jiahui.im.config.properties.JwtProperties;
import com.jiahui.im.constant.GlobalVar;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 跨域过滤器
 * @author Tommy
 * @date 2021/6/16
 */
@Component
public class CorsFilter extends OncePerRequestFilter {

    @Autowired
    private JwtProperties jwtProperties;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        // 解决跨域问题
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "OPTIONS, GET, POST, DELETE, PUT");
        response.setHeader("Access-Control-Allow-Headers", "X-Requested-With,Accept,Content-Type,lang,token,terminal,version," + jwtProperties.getHeader());
        response.setHeader("Access-Control-Allow-Credentials", "true");
        response.setHeader("Access-Control-Expose-Headers", StrUtil.join(",", jwtProperties.getHeader(), GlobalVar.TIMESTAMP));
        response.setHeader("Access-Control-Max-Age", "3600");
        if (request.getMethod().equals("OPTIONS")) {
            return;
        }
        filterChain.doFilter(request, response);
    }
}
