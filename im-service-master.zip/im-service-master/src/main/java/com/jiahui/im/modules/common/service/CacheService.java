package com.jiahui.im.modules.common.service;

import com.jiahui.im.modules.common.dto.bigfront.DeptInfoDto;
import com.jiahui.im.modules.common.dto.his.dict.DictRespDto;
import com.jiahui.im.modules.common.entity.SysDeptConfigureEntity;
import com.jiahui.im.modules.common.mapper.SysDeptConfigureMapper;
import com.jiahui.im.modules.common.service.BigFrontService;
import com.jiahui.im.modules.common.service.HisService;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

@Log4j2
@Service
public class CacheService {

	@Autowired
	private BigFrontService bigFrontService;

	@Autowired
	private HisService hisService;

	@Autowired
	private SysDeptConfigureMapper sysDeptConfigureMapper;

	/**
	 * 查询字典
	 * @param dictName
	 * @return
	 */
	@Cacheable(cacheNames = "dictCache", key = "#dictName", unless = "#result.size() == 0")
	public Map<String, DictRespDto> getDictCache(String dictName) {
		List<DictRespDto> dictList = hisService.dictList(dictName);
		Map<String, DictRespDto> dictMap = dictList.stream().collect(Collectors.toMap(DictRespDto::getDictCode, e -> e, (e1, e2) -> e2));
		return dictMap;
	}

	/**
	 * 获取科室头像
	 * @param deptId
	 * @return
	 */
	@Cacheable(cacheNames = "deptHeadUrlCache", key = "#deptId", unless = "#result == null")
	public String getDeptHeadUrl(Long deptId) {
		SysDeptConfigureEntity sysDeptConfigureEntity = sysDeptConfigureMapper.selectByDeptId(deptId);
		return Objects.isNull(sysDeptConfigureEntity) ? null : sysDeptConfigureEntity.getHeadUrl();
	}

	/**
	 * 根据ID获取一级科室数据
	 * @param deptId
	 * @return
	 */
	@Cacheable(cacheNames = "deptInfoCache", key = "#deptId", unless = "#result == null || #result.getId() == null")
	public DeptInfoDto findGroupById(Long deptId) {
		return bigFrontService.findGroupById(deptId);
	}

	/**
	 * 根据ID获取一级科室数据
	 * @return
	 */
	@Cacheable(cacheNames = "allDeptInfoCache", unless = "#result.size() == 0")
	public List<DeptInfoDto> getAllDepartmentInfo() {
		return bigFrontService.getAllDepartmentInfo();
	}

}
