package com.jiahui.im.modules.common.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * 科室客服-用户未绑定表
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DeptUserUnboundEntity {
    /**
     * 主键
     */
    private Long id;

    /**
     * 关联用户id
     */
    private Long userId;

    /**
     * 科室id
     */
    private Long deptId;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

    private Date userQuestionTime;
}