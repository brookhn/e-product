package com.jiahui.im.modules.api.vo.oss;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class OssPresignedUrlIn {
	
	@ApiModelProperty(value = "oss文件名", name = "objectName",  required = true)
	private String objectName;

	@ApiModelProperty(value = "消息类型 1-文本 2-图片 3-语音 4-视频 5-word 6-PDF 7-文件", name = "msgType",  required = true)
	private Integer msgType;
}
