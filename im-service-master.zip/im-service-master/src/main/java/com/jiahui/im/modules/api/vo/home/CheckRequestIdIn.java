package com.jiahui.im.modules.api.vo.home;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author Tommy
 * @date 2021/8/10
 */
@ApiModel
@Data
public class CheckRequestIdIn {
    @ApiModelProperty(value = "请求标识")
    private String requestId;
}

