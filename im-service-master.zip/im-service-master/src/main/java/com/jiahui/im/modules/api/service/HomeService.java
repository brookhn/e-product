package com.jiahui.im.modules.api.service;

import cn.hutool.core.util.StrUtil;
import com.jiahui.im.context.UserThreadContext;
import com.jiahui.im.helper.MyJwt;
import com.jiahui.im.modules.api.vo.home.ChatRecordListIn;
import com.jiahui.im.modules.api.vo.home.ChatRecordListOut;
import com.jiahui.im.modules.api.vo.home.CheckRequestIdIn;
import com.jiahui.im.modules.api.vo.home.CheckRequestIdOut;
import com.jiahui.im.modules.api.vo.home.EvaluateIn;
import com.jiahui.im.modules.api.vo.home.NewestChatRecordListIn;
import com.jiahui.im.modules.api.vo.home.NewestChatRecordListOut;
import com.jiahui.im.modules.api.vo.home.RankInfoOut;
import com.jiahui.im.modules.common.enums.KefuTypeEnum;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author Tommy
 * @date 2022/5/30
 */
@Service
@Log4j2
public class HomeService {

    @Autowired
    private DeptHomeService deptHomeService;

    @Autowired
    private CcHomeService ccHomeService;

    /**
     * 聊天记录列表
     * @param chatRecordListIn
     * @return
     */
    public ChatRecordListOut chatRecordList(ChatRecordListIn chatRecordListIn) {
        MyJwt myJwt = UserThreadContext.getUserVisitor().getMyJwt();
        if (KefuTypeEnum.DEPT.getType().equals(myJwt.getKefuType())) {
            return deptHomeService.chatRecordList(chatRecordListIn);
        }
        return ccHomeService.chatRecordList(chatRecordListIn);
    }

    /**
     * 最新聊天记录列表
     * @param newestChatRecordListIn
     * @return
     */
    public NewestChatRecordListOut newestChatRecordList(NewestChatRecordListIn newestChatRecordListIn) {
        if (StrUtil.isBlank(newestChatRecordListIn.getRecordId())) {
            return new NewestChatRecordListOut();
        }
        MyJwt myJwt = UserThreadContext.getUserVisitor().getMyJwt();
        if (KefuTypeEnum.DEPT.getType().equals(myJwt.getKefuType())) {
            return deptHomeService.newestChatRecordList(newestChatRecordListIn);
        }
        return ccHomeService.newestChatRecordList(newestChatRecordListIn);
    }

    /**
     * 排队信息
     */
    public RankInfoOut rankInfo() {
        MyJwt myJwt = UserThreadContext.getUserVisitor().getMyJwt();
        if (KefuTypeEnum.DEPT.getType().equals(myJwt.getKefuType())) {
            return new RankInfoOut();
        }
        return ccHomeService.rankInfo();
    }

    /**
     * 检查消息是否发送成功
     * @param checkRequestIdIn
     * @return
     */
    public CheckRequestIdOut checkRequestId(CheckRequestIdIn checkRequestIdIn) {
        MyJwt myJwt = UserThreadContext.getUserVisitor().getMyJwt();
        if (KefuTypeEnum.DEPT.getType().equals(myJwt.getKefuType())) {
            return deptHomeService.checkRequestId(checkRequestIdIn);
        }
        return ccHomeService.checkRequestId(checkRequestIdIn);
    }

    /**
     * 评价
     * @param evaluateIn
     */
    public void evaluate(EvaluateIn evaluateIn) {
        MyJwt myJwt = UserThreadContext.getUserVisitor().getMyJwt();
        if (KefuTypeEnum.DEPT.getType().equals(myJwt.getKefuType())) {
            return;
        }
        ccHomeService.evaluate(evaluateIn);
    }

    /**
     * 结束排队
     */
    public void endRank() {
        MyJwt myJwt = UserThreadContext.getUserVisitor().getMyJwt();
        if (KefuTypeEnum.DEPT.getType().equals(myJwt.getKefuType())) {
            return;
        }
        ccHomeService.endRank();
    }
}
