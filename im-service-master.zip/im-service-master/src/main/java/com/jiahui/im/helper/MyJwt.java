package com.jiahui.im.helper;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.io.Serializable;

/**
 * @author Tommy
 * @date 2021/6/9
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class MyJwt implements Serializable {

    private static final long serialVersionUID = 861305544313746294L;

    /**
     * 签发者
     */
    private String iss;

    /**
     * 主题
     */
//    private String sub;

    /**
     * 接收JWT的一方
     */
//    private String aud;

    /**
     *  JWT的唯一身份标识
     *  PS：主要用来作为一次性token，从而回避重放攻击
     */
    private String jti;

    /**
     * JWT的过期时间，秒级时间戳
     */
    private long exp;

    /**
     * 过期秒数
     * PS：可使用该字段配合exp字段实现续期功能
     */
    private int ttls;

    /********************生成jwt入参 start********************/
    /**
     * 用户id
     */
    private Long userId;

    /**
     * 账号id
     */
    private Long accountId;

    /**
     * 用户名称
     */
    private String userName;

    /**
     * 用户头像
     */
    private String headUrl;

    /**
     * 渠道类型 1-APP 2-公众号 3-小程序 4-企业微信
     */
    private Integer channelType;

    /**
     * 科室ID（科室客服）
     */
    private Long deptId;

    /**
     * 系统版本（CC客服）
     */
    private String systemVersion;

    /**
     * 设备型号（CC客服）
     */
    private String deviceModel;

    /**
     * app版本（CC客服）
     */
    private String appVersion;

    /**
     * 客服类型 1-科室客服 2-CC客服
     */
    private Integer kefuType;

    /********************生成jwt入参 end********************/

    /**
     * 状态 0正常 -1非法 -2已过期 -3jwt密钥非法 -4未知异常
     */
    @JsonIgnore
    private int status;

    /**
     * 状态描述
     */
    @JsonIgnore
    private String statusMsg;
}

