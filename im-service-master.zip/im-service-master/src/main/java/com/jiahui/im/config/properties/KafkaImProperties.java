package com.jiahui.im.config.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * @author Tommy
 * @date 2021/07/16
 */
@Data
@Configuration
@ConfigurationProperties(prefix = "kafka.im")
public class KafkaImProperties {

    private String bootstrapServers;
    private String clientId;
    private Producer producer;
    private Consumer consumer;

    @Data
    public static class Producer {
        private Integer retries;
        private Integer batchSize;
        private Long lingerMs;
        private Long bufferMemory;
    }

    @Data
    public static class Consumer {
        private Boolean enableAutoCommit;
        private Integer maxPollRecords;
        private Integer heartBeatInterval;
        private Integer sessionTimeout;
        private String autoOffsetReset;
        private Integer concurrency;
    }
}
