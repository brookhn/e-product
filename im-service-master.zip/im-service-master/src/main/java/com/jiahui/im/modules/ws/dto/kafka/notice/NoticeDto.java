package com.jiahui.im.modules.ws.dto.kafka.notice;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class NoticeDto<T> {

	/**
	 * 通知类型 {@link com.jiahui.im.modules.common.enums.UserNoticeEnum}
	 */
	private Integer noticeType;

	/**
	 * 消息体
	 */
	private T data;

	/**
	 * kafka发送时间 毫秒级时间戳
	 */
	private Long kafkaSendTime;

	public NoticeDto(Integer noticeType, T data) {
		this.noticeType = noticeType;
		this.data = data;
		this.kafkaSendTime = System.currentTimeMillis();
	}
}
