package com.jiahui.im.modules.common.mongo;

import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.jiahui.im.common.PageOut;
import com.jiahui.im.modules.common.enums.UserTypeEnum;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;

/**
 * 科室客服
 * @author Tommy
 * @date 2022/5/31
 */
@Component
public class ChatRecordDao {

    @Autowired
    private MongoTemplate mongoTemplate;
 
    /**
     * 保存聊天记录
     * @param chatRecord
     */
    public void save(ChatRecord chatRecord) {
        mongoTemplate.save(chatRecord);
    }

    /**
     * 分页查询聊天记录
     * @param userId
     * @param deptId
     * @param recordId
     * @param pageSize
     * @return
     */
    public PageOut<ChatRecord> pageByUserId(Long userId, Long deptId, String recordId, int pageSize) {
        PageOut<ChatRecord> pageOut = new PageOut();
        Query query = new Query();
        query.addCriteria(Criteria.where(ChatRecord.Field.deptId.getName()).is(deptId));
        Criteria criteria = new Criteria();
        criteria.orOperator(
                // 发送者是用户
                Criteria.where(ChatRecord.Field.fromId.getName()).is(userId)
                        .andOperator(Criteria.where(ChatRecord.Field.fromType.getName()).is(UserTypeEnum.USER.getType())),
                // 接收者是用户&发送者是客服
                Criteria.where(ChatRecord.Field.toId.getName()).is(userId)
                        .andOperator(Criteria.where(ChatRecord.Field.toType.getName()).is(UserTypeEnum.USER.getType()),
                                Criteria.where(ChatRecord.Field.fromType.getName()).is(UserTypeEnum.KEFU.getType()))
        );
        query.addCriteria(criteria);
        if (StrUtil.isNotBlank(recordId)) {
            query.addCriteria(Criteria.where(ChatRecord.Field.id.getName()).lt(new ObjectId(recordId)));
        }
        // 只能查看最近6个月的记录
        DateTime endTime = DateUtil.offsetMonth(new Date(), -6);
        query.addCriteria(Criteria.where(ChatRecord.Field.createTime.getName()).gt(endTime));
        // 查询总数据量
        long count = mongoTemplate.count(query, ChatRecord.class);
        pageOut.setTotalCount(count);
        if (count == 0) {
            return pageOut;
        }
        // 查询单页数据
        query.with(Sort.by(Sort.Order.desc(ChatRecord.Field.id.getName())));
        query.limit(pageSize);
        List<ChatRecord> chatRecordList = mongoTemplate.find(query, ChatRecord.class);
        pageOut.setRows(chatRecordList);
        return pageOut;
    }

    /**
     * 查询最新聊天记录
     * @param userId
     * @param deptId
     * @param recordId
     * @return
     */
    public List<ChatRecord> newestByUserId(Long userId, Long deptId, String recordId) {
        Query query = new Query();
        query.addCriteria(Criteria.where(ChatRecord.Field.deptId.getName()).is(deptId));
        Criteria criteria = new Criteria();
        criteria.orOperator(
                // 发送者是用户
                Criteria.where(ChatRecord.Field.fromId.getName()).is(userId)
                        .andOperator(Criteria.where(ChatRecord.Field.fromType.getName()).is(UserTypeEnum.USER.getType())),
                // 接收者是用户&发送者是客服
                Criteria.where(ChatRecord.Field.toId.getName()).is(userId)
                        .andOperator(Criteria.where(ChatRecord.Field.toType.getName()).is(UserTypeEnum.USER.getType()),
                                Criteria.where(ChatRecord.Field.fromType.getName()).is(UserTypeEnum.KEFU.getType()))
        );
        query.addCriteria(criteria);
        if (StrUtil.isNotBlank(recordId)) {
            query.addCriteria(Criteria.where(ChatRecord.Field.id.getName()).gt(new ObjectId(recordId)));
        }
        query.with(Sort.by(Sort.Order.asc(ChatRecord.Field.id.getName())));
        List<ChatRecord> chatRecordList = mongoTemplate.find(query, ChatRecord.class);
        return chatRecordList;
    }

    /**
     * 根据requestId查询
     * @param userId
     * @param deptId
     * @param requestId
     * @return
     */
    public ChatRecord queryByRequestId(Long userId, Long deptId, String requestId) {
        Query query = new Query();
        query.addCriteria(Criteria.where(ChatRecord.Field.deptId.getName()).is(deptId));
        query.addCriteria(Criteria.where(ChatRecord.Field.fromId.getName()).is(userId)
                .andOperator(Criteria.where(ChatRecord.Field.fromType.getName()).is(UserTypeEnum.USER.getType())));
        query.addCriteria(Criteria.where(ChatRecord.Field.requestId.getName()).is(requestId));
        return mongoTemplate.findOne(query, ChatRecord.class);
    }
}
