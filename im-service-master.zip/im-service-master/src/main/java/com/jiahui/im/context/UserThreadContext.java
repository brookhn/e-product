package com.jiahui.im.context;

import java.util.HashMap;
import java.util.Map;

/**
 * 用户线程上下文
 * @author Tommy
 * @date 2021/6/16
 */
public class UserThreadContext {

    private static final ThreadLocal<Map<String, Object>> CTX_HOLDER = new ThreadLocal<>();

    public static final String REQUEST_HEADER_KEY = "requestHeader";

    public static <T> T getAttribute(String key){
        Map<String, Object> ctx = CTX_HOLDER.get();
        return (T) ctx.get(key);
    }

    public static void setAttribute(String key, Object value){
        Map<String, Object> ctx = CTX_HOLDER.get();
        ctx.put(key, value);
    }

    public static void requestStart(){
        CTX_HOLDER.set(new HashMap<>());
    }

    public static void requestEnd(){
        CTX_HOLDER.remove();
    }

    public static UserVisitor getUserVisitor(){
        return getAttribute(REQUEST_HEADER_KEY);
    }

    public static void setUserVisitor(UserVisitor visitor){
        setAttribute(REQUEST_HEADER_KEY, visitor);
    }
 }