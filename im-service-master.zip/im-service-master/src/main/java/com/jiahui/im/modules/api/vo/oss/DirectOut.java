package com.jiahui.im.modules.api.vo.oss;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class DirectOut {
    @ApiModelProperty(value = "访问密钥ID")
    private String accessKeyId = "";

    @ApiModelProperty(value = "policy")
    private String encodedPolicy = "";

    @ApiModelProperty(value = "signature")
    private String postSignature = "";

    @ApiModelProperty(value = "Bucket所在地域对应的Endpoint")
    private String endPoint = "";

    @ApiModelProperty(value = "Bucket名称")
    private String bucketName = "";

    @ApiModelProperty(value = "过期时间 毫秒级时间戳")
    private Long expiresTime;
}
