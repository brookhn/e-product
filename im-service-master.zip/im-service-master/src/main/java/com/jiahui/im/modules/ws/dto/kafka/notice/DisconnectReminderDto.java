package com.jiahui.im.modules.ws.dto.kafka.notice;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 会话断开提醒
 * @author Tommy
 * @date 2021/8/11
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DisconnectReminderDto {

	/**
	 * 通知类型 {@link com.jiahui.im.modules.common.enums.UserNoticeEnum}
	 */
	private Integer noticeType;

    /**
     * 用户ID
	 */
	private Long userId;
}
