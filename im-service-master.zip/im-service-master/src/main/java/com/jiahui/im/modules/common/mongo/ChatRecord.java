package com.jiahui.im.modules.common.mongo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

/**
 * 科室客服-聊天记录表
 * @author Tommy
 * @date 2022/5/31
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document("chat_record")
public class ChatRecord {

	/**
	 * 主键
	 * PS：使用id进行条件查询时，必须用ObjectId包装
	 */
	private String id;

	/**
	 * 用户ID
	 */
	private Long userId;

	/**
	 * 发送者ID
	 */
	private Long fromId;

	/**
	 * 发送者类型 1-用户 2-客服 3-系统
	 */
	private Integer fromType;

	/**
	 * 接收者ID
	 */
	private Long toId;

	/**
	 * 接收者类型 1-用户 2-客服 3-系统
	 */
	private Integer toType;

	/**
	 * 文件名
	 */
	@Builder.Default
	private String fileName = "";

	/**
	 * 文件大小（byte）
	 */
	@Builder.Default
	private Long fileSize = 0L;

	/**
	 * 消息类型 1-文本 2-图片 3-语音 4-视频 5-word 6-PDF 7-文件
	 */
	private Integer msgType;

	/**
	 * 消息内容
	 */
	private String content;

	/**
	 * 用于APP消息推送的消息内容（content去除html标签）
	 */
	@Builder.Default
	private String pushContent = "";

	/**
	 * 科室ID
	 */
	private Long deptId;

	/**
	 * 渠道类型 1-APP 2-公众号 3-小程序 4-企业微信
	 */
	private Integer channelType;

	/**
	 * 请求标识
	 */
	private String requestId;

	/**
	 * 创建时间
	 */
	private Date createTime;

	/**
	 * 更新时间
	 */
	private Date updateTime;

	@Getter
	@AllArgsConstructor
	public enum Field {
		id("id", "主键"),
		fromId("fromId", "发送者ID"),
		fromType("fromType", "发送者类型 1-用户 2-客服 3-系统"),
		toId("toId", "接收者ID"),
		toType("toType", "接收者类型 1-用户 2-客服 3-系统"),
		msgType("msgType", "消息类型 1-文本 2-图片 3-语音 4-视频 5-word 6-PDF 7-文件"),
		content("content", "消息内容"),
		deptId("deptId", "科室ID"),
		channelType("channelType", "渠道类型 1-APP 2-公众号 3-小程序 4-企业微信"),
		requestId("requestId", "请求标识"),
		createTime("createTime", "创建时间"),
		updateTime("updateTime", "更新时间"),
		;

		/**
		 * 字段名称
		 */
		private final String name;

		/**
		 * 字段描述
		 */
		private final String desc;
	}
}
