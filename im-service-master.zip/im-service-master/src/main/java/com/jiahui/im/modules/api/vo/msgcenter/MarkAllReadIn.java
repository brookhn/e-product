package com.jiahui.im.modules.api.vo.msgcenter;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.List;

/**
 * @author Tommy
 * @date 2022/5/19
 */
@ApiModel
@Data
public class MarkAllReadIn {
    @ApiModelProperty(value = "账号id")
    @NotNull
    @Range(min = 1L)
    private Long accountId;

    @ApiModelProperty(value = "科室id集合", notes = "集合上限1000")
    @Size(min = 1, max = 1000)
    private List<Long> deptIdList;
}
