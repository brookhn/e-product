package com.jiahui.im.modules.common.dto.his;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Tommy
 * @date 2021/06/08
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class HisReqDto<T> {
    /**
     * 业务操作编码
     */
    private String dictName;

    /**
     * 参数
     */
    private T params;

    public HisReqDto(String dictName) {
        this.dictName = dictName;
    }
}
