package com.jiahui.im.modules.ws.vo.action;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 用户消息
 * @author Tommy
 * @date 2021/8/2
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ChatMsgOut {

    /**
     * 主键
     */
    private String id;

    /**
     * 发送者ID
     */
    private Long fromId;

    /**
     * 发送者类型 1-用户 2-客服 3-系统
     */
    private Integer fromType;

    /**
     * 发送者名称
     */
    private String fromName;

    /**
     * 发送者头像
     */
    private String fromHeadUrl;

    /**
     * 接收者ID
     */
    private Long toId;

    /**
     * 接收者类型 1-用户 2-客服 3-系统
     */
    private Integer toType;

    /**
     * 文件名
     */
    private String fileName;

    /**
     * 文件大小（byte）
     */
    private Long fileSize;

    /**
     * 消息类型 1-文本 2-图片 3-语音 4-视频 5-word 6-PDF 7-文件
     */
    private Integer msgType;

    /**
     * 消息内容
     */
    private String content;

    /**
     * OSS对象名称
     */
    private String objectName;

    /**
     * 请求标识
     */
    private String requestId;

    /**
     * 会话ID（CC客服）
     */
    private String conversationId;

    /**
     * 排队人数（有值表示在排队）（CC客服）
     */
    private Integer ranking;

    /**
     * 消息发送时间 毫秒级时间戳
     */
    private Long sendTime;
}
