package com.jiahui.im.modules.ws.tio;

import cn.hutool.core.lang.Assert;
import cn.hutool.core.thread.ThreadUtil;
import com.jiahui.im.common.CodeMsg;
import com.jiahui.im.common.exception.BizException;
import com.jiahui.im.constant.Constant;
import com.jiahui.im.helper.MyJwt;
import com.jiahui.im.modules.common.entity.DeptUserConnectRecordEntity;
import com.jiahui.im.modules.common.entity.UserEntity;
import com.jiahui.im.modules.common.mapper.DeptUserConnectRecordMapper;
import com.jiahui.im.modules.common.mapper.UserExtMapper;
import com.jiahui.im.modules.common.mapper.UserMapper;
import com.jiahui.im.modules.ws.constant.ImConst;
import com.jiahui.im.modules.ws.util.WsUtil;
import com.jiahui.im.modules.ws.vo.WsResponseOut;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.tio.core.ChannelContext;
import org.tio.core.Tio;
import org.tio.http.common.HttpRequest;
import org.tio.http.common.HttpResponse;
import org.tio.websocket.common.WsRequest;
import org.tio.websocket.server.handler.IWsMsgHandler;

import java.util.Date;

/**
 * 科室客服-ws消息处理器
 * @author Tommy
 * @date 2022/5/30
 */
@Log4j2
@Component
public class DeptImWsMsgHandler implements IWsMsgHandler {

	@Autowired
	private DeptUserConnectRecordMapper deptUserConnectRecordMapper;

	@Autowired
	private UserMapper userMapper;

	@Autowired
	private UserExtMapper userExtMapper;

	/**
	 * 握手时走这个方法，业务可以在这里获取cookie，request参数等
	 */
	@Override
	public HttpResponse handshake(HttpRequest httpRequest, HttpResponse httpResponse, ChannelContext channelContext) {
		return httpResponse;
	}

	/**
	 * 握手之后走这个方法
	 */
	@Override
	public void onAfterHandshaked(HttpRequest httpRequest, HttpResponse httpResponse, ChannelContext channelContext) {
		try {
			// 获取jwt
			MyJwt myJwt = (MyJwt) channelContext.get(ImConst.JWT_INFO);
			// 查询用户
			UserEntity userEntity = userMapper.selectByPrimaryKey(myJwt.getUserId());
			Assert.notNull(userEntity, () -> new BizException(CodeMsg.ILLEGAL_USER));
			Assert.isTrue(Constant.TRUE.equals(userEntity.getStatus()), () -> new BizException(CodeMsg.CANCEL_USER));
			// 查询用户首次咨询标记
			Integer firstQuestionFlag = userExtMapper.selectFirstQuestionFlag(myJwt.getUserId(), myJwt.getDeptId());
			// 维护连接信息
			Date now = new Date();
			DeptUserConnectRecordEntity connectRecordEntity = DeptUserConnectRecordEntity.builder()
					.sessionId(channelContext.getId())
					.userId(myJwt.getUserId())
					.accountId(myJwt.getAccountId())
					.deptId(myJwt.getDeptId())
					.channelType(myJwt.getChannelType())
					.connectTime(now)
					.activeTime(now)
					.build();
			deptUserConnectRecordMapper.insertSelective(connectRecordEntity);
			// 缓存用户连接
			WsUtil.cacheUserChannelId(channelContext, myJwt);
			// 标记用户已读
			userExtMapper.markUserReadByUserIdAndDeptId(myJwt.getUserId(), myJwt.getDeptId());
			// 绑定连接信息
			channelContext.set(ImConst.USER_INFO, userEntity);
			channelContext.set(ImConst.DEPT_SYSTEM_REPLY_FLAG, false);
			channelContext.set(ImConst.DEPT_USER_FIRST_QUESTION_FLAG, Constant.TRUE.equals(firstQuestionFlag));
			Tio.bindUser(channelContext, myJwt.getUserId().toString());
		} catch (Exception e) {
			// 响应错误信息
			WsResponseOut wsResponseOut = WsResponseOut.error(CodeMsg.UNAUTHORIZED);
			if (e instanceof BizException) {
				wsResponseOut = WsResponseOut.error((BizException) e);
			}
			WsUtil.send(channelContext, wsResponseOut);
			// 关闭连接
			ThreadUtil.sleep(100L);
			Tio.remove(channelContext, CodeMsg.PARAMS_ERROR.getMsg());
		}
	}

	/**
	 * 字节消息（binaryType = arraybuffer）过来后会走这个方法
	 */
	@Override
	public Object onBytes(WsRequest wsRequest, byte[] bytes, ChannelContext channelContext) {
		return null;
	}

	/**
	 * 当客户端发close flag时，会走这个方法
	 */
	@Override
	public Object onClose(WsRequest wsRequest, byte[] bytes, ChannelContext channelContext) {
		Tio.remove(channelContext, "receive close flag");
		return null;
	}

	/*
	 * 字符消息（binaryType = blob）过来后会走这个方法
	 */
	@Override
	public Object onText(WsRequest wsRequest, String text, ChannelContext channelContext) {
		return null;
	}

}
