package com.jiahui.im.modules.ws.constant;

public class ImConst {

	/**
	 * 用于群聊的group id
	 */
	public static final String GROUP_ID = "im-group";

	/**
	 * jwt token
	 */
	public static final String JWT_TOKEN = "token";

	/**
	 * jwt解析信息
	 */
	public static final String JWT_INFO = "jwtInfo";

	/**
	 * 用户信息
	 */
	public static final String USER_INFO = "userInfo";

	/**
	 * 渠道类型 1-APP 2-公众号 3-小程序 4-企业微信
	 * - 从jwt中获取
	 */
//	public static final String CHANNEL_TYPE = "channelType";

	/**
	 * 科室ID
	 * - 从jwt中获取
	 */
//	public static final String DEPT_ID = "deptId";

	/**
	 * 系统版本
	 * - 从jwt中获取
	 */
//	public static final String SYSTEM_VERSION = "systemVersion";

	/**
	 * 设备型号
	 * - 从jwt中获取
	 */
//	public static final String DEVICE_MODEL = "deviceModel";

	/**
	 * app版本
	 * - 从jwt中获取
	 */
//	public static final String APP_VERSION = "appVersion";

	/**
	 * 科室客服-系统回复标识
	 */
	public static final String DEPT_SYSTEM_REPLY_FLAG = "deptSystemReplyFlag";

	/**
	 * 科室客服-用户首次咨询标识
	 */
	public static final String DEPT_USER_FIRST_QUESTION_FLAG = "deptUserFirstQuestionFlag";

	/**
	 * CC客服-用户首次咨询标识
	 */
	public static final String CC_USER_FIRST_QUESTION_FLAG = "ccUserFirstQuestionFlag";
}
