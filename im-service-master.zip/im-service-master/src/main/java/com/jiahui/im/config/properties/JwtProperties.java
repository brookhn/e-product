package com.jiahui.im.config.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * @author Tommy
 * @date 2021/7/27
 */
@Data
@Configuration
@ConfigurationProperties(prefix = "jwt")
public class JwtProperties {
    /**
     * jwt开关
     */
    private boolean enable;

    /**
     * jwt密钥
     */
    private String key;

    /**
     * jwt header标识
     */
    private String header;

    /**
     * jwt超时秒数
     */
    private int timeout;
}
