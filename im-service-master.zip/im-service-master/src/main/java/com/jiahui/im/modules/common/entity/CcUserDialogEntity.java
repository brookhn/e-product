package com.jiahui.im.modules.common.entity;

import java.io.Serializable;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * cc_user_dialog
 * @author 
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CcUserDialogEntity implements Serializable {
    /**
     * 主键
     */
    private Long id;

    /**
     * 会话id
     */
    private String conversationId;

    /**
     * 用户id
     */
    private Long userId;

    /**
     * 渠道类型 1-APP 2-公众号 3-小程序 4-企业微信
     */
    private Integer channelType;

    /**
     * 系统版本
     */
    private String systemVersion;

    /**
     * 设备型号
     */
    private String deviceModel;

    /**
     * app版本
     */
    private String appVersion;

    /**
     * 第一次接待的客服id
     */
    private Long firstKefuId;

    /**
     * 第一次接待的客服所在部门id
     */
    private Long firstDeptId;

    /**
     * 最后一次接待的客服id
     */
    private Long lastKefuId;

    /**
     * 最后一次接待的客服所在部门id
     */
    private Long lastDeptId;

    /**
     * 最后一次有效接待的客服id
     */
    private Long lastValidKefuId;

    /**
     * 最后一次有效接待的客服所在部门id
     */
    private Long lastValidDeptId;

    /**
     * 是否已接待 0-未接待 1-已接待
     */
    private Integer isRecept;

    /**
     * 客服第一次接待时间
     */
    private Date kefuFirstReceptTime;

    /**
     * 客服是否回复 0-未回复 1-已回复
     */
    private Integer isKefuAnswer;

    /**
     * 客服第一次回复时间
     */
    private Date kefuFirstAnswerTime;

    /**
     * 会话开始方式 1-用户发起 2-客服发起
     */
    private Integer startType;

    /**
     * 会话结束方式 10-用户结束排队 20-客服结束会话 22-超时结束会话
     */
    private Integer endType;

    /**
     * 会话开始时间
     */
    private Date startTime;

    /**
     * 会话结束时间
     */
    private Date endTime;

    /**
     * 会话结束对应的MongoDB主键
     */
    private String endMsgId;

    /**
     * 是否推评 0-否 1-是
     */
    private Integer isPushEvaluate;

    /**
     * 评价id
     */
    private Long evaluateId;

    /**
     * 是否排队 0-未排队 1-已排队
     */
    private Integer isRank;

    /**
     * 是否转接 0-未转接 1-已转接
     */
    private Integer isTransfer;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

    private static final long serialVersionUID = 1L;
}