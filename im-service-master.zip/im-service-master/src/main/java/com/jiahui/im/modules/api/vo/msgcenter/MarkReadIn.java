package com.jiahui.im.modules.api.vo.msgcenter;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.NotNull;

/**
 * @author Tommy
 * @date 2022/5/19
 */
@ApiModel
@Data
public class MarkReadIn {
    @ApiModelProperty(value = "账号id")
    @NotNull
    @Range(min = 1L)
    private Long accountId;
}
