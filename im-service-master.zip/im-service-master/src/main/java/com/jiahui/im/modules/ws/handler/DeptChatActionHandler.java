package com.jiahui.im.modules.ws.handler;

import cn.hutool.core.convert.Convert;
import cn.hutool.core.date.DateField;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.IdUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.jiahui.im.common.CodeMsg;
import com.jiahui.im.common.exception.BizException;
import com.jiahui.im.constant.Constant;
import com.jiahui.im.constant.KafkaConstant;
import com.jiahui.im.helper.MyJwt;
import com.jiahui.im.helper.RedisHelper;
import com.jiahui.im.modules.api.service.OssService;
import com.jiahui.im.modules.common.entity.DeptUserBindingEntity;
import com.jiahui.im.modules.common.entity.DeptUserUnboundEntity;
import com.jiahui.im.modules.common.entity.SysDeptConfigureEntity;
import com.jiahui.im.modules.common.entity.UserEntity;
import com.jiahui.im.modules.common.enums.ChannelTypeEnum;
import com.jiahui.im.modules.common.enums.DeptKefuNoticeEnum;
import com.jiahui.im.modules.common.enums.KefuTypeEnum;
import com.jiahui.im.modules.common.enums.MsgTypeEnum;
import com.jiahui.im.modules.common.enums.ReceptTypeEnum;
import com.jiahui.im.modules.common.enums.UserTypeEnum;
import com.jiahui.im.modules.common.mapper.DeptUserBindingMapper;
import com.jiahui.im.modules.common.mapper.DeptUserUnboundMapper;
import com.jiahui.im.modules.common.mapper.SysDeptConfigureMapper;
import com.jiahui.im.modules.common.mapper.UserExtMapper;
import com.jiahui.im.modules.common.mongo.ChatRecord;
import com.jiahui.im.modules.common.mongo.ChatRecordDao;
import com.jiahui.im.modules.ws.constant.ImConst;
import com.jiahui.im.modules.ws.converter.DeptChatConverter;
import com.jiahui.im.modules.ws.dto.kafka.ChatRecordDto;
import com.jiahui.im.modules.ws.dto.kafka.SyncChatRecordDto;
import com.jiahui.im.modules.ws.dto.kafka.kefu.DeptUnreceptNumDto;
import com.jiahui.im.modules.ws.dto.kafka.notice.NoticeDto;
import com.jiahui.im.modules.ws.enums.ClientActionEnum;
import com.jiahui.im.modules.ws.enums.ServerActionEnum;
import com.jiahui.im.modules.ws.util.WsInputChecker;
import com.jiahui.im.modules.ws.util.WsUtil;
import com.jiahui.im.modules.ws.vo.WsRequestIn;
import com.jiahui.im.modules.ws.vo.action.ChatActionIn;
import com.jiahui.im.modules.ws.vo.action.ChatMsgOut;
import com.jiahui.im.util.KefuUtil;
import com.jiahui.im.util.UserUtil;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;
import org.tio.core.ChannelContext;

import java.util.Objects;
import java.util.Optional;

/**
 * 科室客服-聊天指令处理器
 * @author Tommy
 * @date 2021/08/03
 */
@Log4j2
@Component
public class DeptChatActionHandler implements IActionHandler {

    @Autowired
    private KafkaTemplate<String, String> kafkaImTemplate;

    @Autowired
    private ChatRecordDao chatRecordDao;

    @Autowired
    private DeptUserBindingMapper deptUserBindingMapper;

    @Autowired
    private DeptUserUnboundMapper deptUserUnboundMapper;

    @Autowired
    private SysDeptConfigureMapper sysDeptConfigureMapper;

    @Autowired
    private UserExtMapper userExtMapper;

    @Autowired
    private OssService ossService;

    @Override
    public String getAction() {
        return ClientActionEnum.CHAT.getAction();
    }

    @Override
    public Integer getKefuType() {
        return KefuTypeEnum.DEPT.getType();
    }

    @Override
    public void handle(ChannelContext channelContext, WsRequestIn wsRequestIn) {
        MyJwt myJwt = (MyJwt) channelContext.get(ImConst.JWT_INFO);
        UserEntity userEntity = (UserEntity) channelContext.get(ImConst.USER_INFO);
        // 类型转换
        ChatActionIn chatActionIn = Convert.convert(ChatActionIn.class, wsRequestIn.getParams());
        // 校验入参
        try {
            WsInputChecker.checker().checkParams(chatActionIn);
        } catch (BizException e) {
            // 响应错误信息
            WsUtil.sendError(channelContext, e);
            return;
        }

        /* ---------------- 消息入库 ---------------- */
        DateTime now = DateTime.now();
        ChatRecord chatRecord = ChatRecord.builder()
                .userId(userEntity.getId())
                .fromId(userEntity.getId())
                .fromType(UserTypeEnum.USER.getType())
                .toId(0L)
                .toType(UserTypeEnum.KEFU.getType())
                .msgType(chatActionIn.getMsgType())
                .content(chatActionIn.getContent())
                .deptId(myJwt.getDeptId())
                .channelType(myJwt.getChannelType())
                .requestId(chatActionIn.getRequestId())
                .createTime(now)
                .updateTime(now)
                .build();
        try {
            chatRecordDao.save(chatRecord);
        } catch (DuplicateKeyException e1) {
            // 消息幂等性校验
            WsUtil.sendError(channelContext, CodeMsg.DUPLICATE_REQUEST_ID);
            return;
        } catch (Exception e2) {
            log.error("聊天消息写入MongoDB异常", e2);
            WsUtil.sendError(channelContext, CodeMsg.SYSTEM_EXCEPTION);
            return;
        }

        /* ---------------- 维护绑定关系 ---------------- */
        ReceptTypeEnum receptTypeEnum;
        DeptUserBindingEntity deptUserBindingEntity = deptUserBindingMapper.selectByUk(userEntity.getId(), myJwt.getDeptId());
        if (Objects.nonNull(deptUserBindingEntity)) {
            receptTypeEnum = ReceptTypeEnum.RECEIVING;
        } else {
            receptTypeEnum = ReceptTypeEnum.WAITING;
            // 维护未绑定表
            DeptUserUnboundEntity deptUserUnboundEntity = deptUserUnboundMapper.selectByUk(userEntity.getId(), myJwt.getDeptId());
            if (Objects.isNull(deptUserUnboundEntity)) {
                DeptUserUnboundEntity tempDeptUserUnboundEntity = DeptUserUnboundEntity.builder()
                        .userId(userEntity.getId())
                        .deptId(myJwt.getDeptId())
                        .userQuestionTime(now)
                        .build();
                try {
                    deptUserUnboundMapper.insertSelective(tempDeptUserUnboundEntity);
                    // 根据科室查询待接待人数
                    int unreceptCount = deptUserUnboundMapper.countByDeptId(myJwt.getDeptId());
                    // 发送kafka，通知同科室客服【待接待人数变更】事件
                    DeptUnreceptNumDto deptUnreceptNumDto = new DeptUnreceptNumDto(DeptKefuNoticeEnum.UNRECEPT_NUM.getType(), myJwt.getDeptId(), unreceptCount);
                    NoticeDto<DeptUnreceptNumDto> noticeDto = new NoticeDto<>(deptUnreceptNumDto.getNoticeType(), deptUnreceptNumDto);
                    kafkaImTemplate.send(KafkaConstant.TOPIC_DEPT_IM_NOTICE_MSG, JSON.toJSONString(noticeDto));
                } catch (DuplicateKeyException e) {
                    // do nothing
                }
            }
        }

        // 发送kafka，异步消费写入MySQL
        SyncChatRecordDto syncChatRecordDto = DeptChatConverter.INSTANCE.chatRecord2SyncDto(chatRecord);
        syncChatRecordDto.setReceptType(receptTypeEnum.getType());
        syncChatRecordDto.setAccountId(userEntity.getAccountId());
        syncChatRecordDto.setKafkaSendTime(DateUtil.current());
        kafkaImTemplate.send(KafkaConstant.TOPIC_DEPT_IM_CHAT_RECORD, syncChatRecordDto.getUserId().toString(), JSON.toJSONString(syncChatRecordDto));
        // 标记用户消息为未读
        RedisHelper.setBit(StrUtil.format(Constant.DEPT_USER_MSG_IS_READ, myJwt.getDeptId()), userEntity.getId(), Boolean.FALSE);
        // 维护用户首次咨询标记
        boolean userFirstQuestionFlag = (boolean) channelContext.get(ImConst.DEPT_USER_FIRST_QUESTION_FLAG);
        if (!userFirstQuestionFlag) {
            userExtMapper.updateFirstQuestionFlag(userEntity.getId(), myJwt.getDeptId());
            // 设置用户首次咨询标记
            channelContext.set(ImConst.DEPT_USER_FIRST_QUESTION_FLAG, true);
        }

        /* ---------------- 发送kafka【聊天消息】 ---------------- */
        ChatRecordDto chatRecordDto = DeptChatConverter.INSTANCE.chatRecord2Dto(chatRecord);
        chatRecordDto.setFromName(UserUtil.getShowName(userEntity));
        chatRecordDto.setFromHeadUrl(UserUtil.getShowHeadUrl(userEntity.getHeadUrl()));
        chatRecordDto.setFromNationality(userEntity.getNationality());
        chatRecordDto.setReceptType(receptTypeEnum.getType());
        chatRecordDto.setChannel(ChannelTypeEnum.fromType(myJwt.getChannelType()).getDesc());
        // 处理OSS资源
        Boolean isOssResource = Optional.ofNullable(MsgTypeEnum.fromType(chatRecord.getMsgType())).map(MsgTypeEnum::isOssResource).orElse(Boolean.FALSE);
        chatRecordDto.setObjectName(isOssResource ? chatRecord.getContent() : StrUtil.EMPTY);
        if (isOssResource) {
            // 获取OSS私有bucket文件链接
            String ossUrl = ossService.ossPresignedUrl(chatRecordDto.getContent(), chatRecordDto.getMsgType()).toString();
            chatRecordDto.setContent(ossUrl);
        }
        chatRecordDto.setKafkaSendTime(DateUtil.current());
        kafkaImTemplate.send(KafkaConstant.TOPIC_DEPT_IM_USER_MSG, JSON.toJSONString(chatRecordDto));

        // 处理非工作时间自动回复
        handleNonworkingReply(channelContext);
    }

    /**
     * 处理非工作时间自动回复
     * - 查询科室配置
     * - 判断是否非工作时间
     * - 一次连接仅产生一次自动回复，不存库
     * @param channelContext
     */
    private void handleNonworkingReply(ChannelContext channelContext) {
        MyJwt myJwt = (MyJwt) channelContext.get(ImConst.JWT_INFO);
        UserEntity userEntity = (UserEntity) channelContext.get(ImConst.USER_INFO);
        // 查询系统回复标识
        boolean systemReplyFlag = (boolean) channelContext.get(ImConst.DEPT_SYSTEM_REPLY_FLAG);
        if (systemReplyFlag) {
            return;
        }
        // 查询科室配置
        DateTime now = DateUtil.date();
        int hour = now.getField(DateField.HOUR_OF_DAY);
        SysDeptConfigureEntity sysDeptConfigureEntity = sysDeptConfigureMapper.selectByDeptId(myJwt.getDeptId());
        if (Objects.isNull(sysDeptConfigureEntity) //科室未配置
                || Constant.FALSE.equals(sysDeptConfigureEntity.getIsNonworkingReply()) //未开启自动回复
                || StrUtil.isBlank(sysDeptConfigureEntity.getNonworkingReplyMsg()) //未配置自动回复消息
                || (hour >= sysDeptConfigureEntity.getWorkingStartTime() && hour < sysDeptConfigureEntity.getWorkingEndTime())) {//工作时间
            return;
        }
        // 构建消息体
        ChatMsgOut chatMsgOut = ChatMsgOut.builder()
                .fromId(0L)
                .fromType(UserTypeEnum.KEFU.getType())
                .fromName(Constant.DEFAULT_KEFU_NAME)
                .fromHeadUrl(KefuUtil.getShowDeptHeadUrl(myJwt.getDeptId()))
                .toId(userEntity.getId())
                .toType(UserTypeEnum.USER.getType())
                .msgType(MsgTypeEnum.TEXT.getType())
                .content(sysDeptConfigureEntity.getNonworkingReplyMsg())
                .requestId(IdUtil.fastSimpleUUID())
                .sendTime(DateUtil.current())
                .build();
        // 回执发送方，不需要多端同步所以不走kafka
        WsUtil.send(channelContext, ServerActionEnum.CHAT, chatMsgOut);
        // 设置系统回复标识
        channelContext.set(ImConst.DEPT_SYSTEM_REPLY_FLAG, true);
    }
}
