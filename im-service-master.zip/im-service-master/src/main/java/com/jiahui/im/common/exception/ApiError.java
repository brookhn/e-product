package com.jiahui.im.common.exception;

import lombok.Setter;
import lombok.ToString;
import org.springframework.http.HttpStatus;

import java.util.Collections;
import java.util.Objects;


@Setter
@ToString
public class ApiError {

    private HttpStatus status;
    //    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy hh:mm:ss")
    private String msg = "";
    private int code = 200;
    private Object data;

    public ApiError() {
    }

    public ApiError(HttpStatus status, int code) {
        this.status = status;
        this.code = code;
    }

    public ApiError(HttpStatus status, int code, String msg) {
        this.status = status;
        this.code = code;
        this.msg = msg;
    }

    public ApiError(HttpStatus status, BizException ex) {
        this.status = status;
        this.code = ex.getCode();
        this.msg = ex.getMsg();
        this.data = ex.getData();
    }

    public ApiError(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public HttpStatus getStatus() {
        return status;
    }

    public String getMsg() {
        return msg;
    }

    public int getCode() {
        return code;
    }

    public Object getData() {
        return Objects.isNull(data) ? Collections.emptyMap() : data;
    }

}


