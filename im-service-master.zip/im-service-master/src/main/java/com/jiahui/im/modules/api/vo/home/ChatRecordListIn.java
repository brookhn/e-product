package com.jiahui.im.modules.api.vo.home;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author Tommy
 * @date 2021/8/10
 */
@ApiModel
@Data
public class ChatRecordListIn {
    @ApiModelProperty(value = "聊天记录ID")
    private String recordId;

    @ApiModelProperty(value = "每页数据量", example = "20")
    private int pageSize = 20;
}

