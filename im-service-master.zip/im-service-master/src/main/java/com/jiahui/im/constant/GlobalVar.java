package com.jiahui.im.constant;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

/**
 * @author sql
 * 全局变量类
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class GlobalVar {
    //redis 过期时间 单位/小时
    public static final int Timeout_Default = 24;

    //status 状态码
    public static final int Status_Ok = 200;
    public static final int Status_BadRequest = 400;
    public static final int Status_BadRequestParam = 400;
    public static final int Status_ServerErr = 500;

    // 通用变量
    public static final String SRC = "Src";
    public static final String IP = "Ip";
    public static final String USER_ID = "UserId";
    public static final String LOGID = "LogId";
    public static final String TIMESTAMP = "timestamp";
    public static final String SV_NAME = "im-service";

    //jwt 配置
    public static final String TTLS = "ttls";
    public static final String STATUS = "status";
    public static final String STATUS_MSG = "statusMsg";
    public static final String ISSUER = SV_NAME;
    
    //jwt 配置
    public static final String USERID = "UserId";
    public static final String ACCOUNT_ID = "AccountId";
    public static final String USERTYPE = "UserType";
    public static final String USERNAME = "UserName";
    public static final String HEADURL = "HeadUrl";
    public static final String NICK_NAME = "NickName";
    public static final String ROLE = "role";
    public static final String CHANNEL_TYPE = "channelType";
    public static final String DEPTID = "deptId";
    public static final String SYSTEM_VERSION = "systemVersion";
    public static final String DEVICE_MODEL = "deviceModel";
    public static final String APP_VERSION = "appVersion";
    public static final String KEFU_TYPE = "kefuType";
    public static final int TTLS_VALUE = 86400;// 24小时

    // 日期格式
    public static final String TIMEZONE = "GMT+8";
    public static final String FORMAT_DATE = "yyyy-MM-dd";
    public static final String FORMAT_DATETIME = "yyyy-MM-dd HH:mm:ss";
}