package com.jiahui.im.util;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.log4j.Log4j2;

/**
 * @note json转换工具类
 * @author SQL
 * @since 2021-03-05
 */
@Log4j2
public class JacksonUtils {

//	private static final Log log = LogFactory.getLog(JacksonUtils.class);

	private static final ObjectMapper objectMapper = new ObjectMapper();

	/*
	 * bean转为string类型的json
	 */
	public static String toJsonString(Object obj) {
		if (obj == null) {
			return null;
		}
		try {
			return objectMapper.writeValueAsString(obj);
		} catch (Exception e) {
			log.error("bean 转换成 json失败！", e);
		}
		return null;
	}

	/*
	 * string类型的json转为bean
	 */
	public static <T> T getObjectFromJsonString(String jsonString, Class<T> cls) {
		if (jsonString == null) {
			return null;
		}
		try {
			return objectMapper.readValue(jsonString, cls);
		} catch (Exception e) {
			log.error("json转换成 bean失败！", e);
		}
		return null;
	}

	/**
	 * 
	 * @param jsonString
	 * @param reference
	 * @return
	 */
	public static Object getObjectFromJsonString(String jsonString, TypeReference reference) {
		if (jsonString == null) {
			return null;
		}
		try {
			return objectMapper.readValue(jsonString, reference);
		} catch (Exception e) {
			log.error("json转换成 bean失败！", e);
		}
		return null;
	}
	
	public static JsonNode getJsonNode(String jsonString) {
		JsonNode jsonNode = null;
		try {
			jsonNode = objectMapper.readTree(jsonString);
		} catch (Exception e) {
			log.error("json readTree 失败！", e);
		}
		return jsonNode;
	}

}
