package com.jiahui.im.modules.ws.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
@ConfigurationProperties(prefix = "tio")
public class ImWsServerConfig {
	/**
	 * 协议名字(可以随便取，主要用于开发人员辨识)
	 */
	private String protocolName;
	
	/**
	 * 监听端口
	 */
	private Integer wsPort;

	/**
	 * 心跳超时时间，单位：毫秒
	 */
	private Integer heartbeatTimeout;

	/**
	 * 是否开启debug模式
	 */
	private Boolean debug;
}
