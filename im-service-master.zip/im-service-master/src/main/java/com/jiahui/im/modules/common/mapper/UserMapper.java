package com.jiahui.im.modules.common.mapper;

import com.jiahui.im.modules.common.entity.UserEntity;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UserMapper {
    UserEntity selectByPrimaryKey(Long id);
    
    int insertSelective(UserEntity record);

    int updateByPrimaryKeySelective(UserEntity record);

    /**
     * 根据账号id查询
     * @param accountId
     * @return
     */
    UserEntity selectByAccountId(Long accountId);
}