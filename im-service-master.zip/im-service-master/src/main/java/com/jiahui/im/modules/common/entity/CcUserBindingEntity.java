package com.jiahui.im.modules.common.entity;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * cc_user_binding
 * @author 
 */
@Data
public class CcUserBindingEntity implements Serializable {
    /**
     * 主键
     */
    private Long id;

    /**
     * 会话id
     */
    private String conversationId;

    /**
     * 用户id
     */
    private Long userId;

    /**
     * 渠道类型 1-APP 2-公众号 3-小程序 4-企业微信
     */
    private Integer channelType;

    /**
     * 系统版本
     */
    private String systemVersion;

    /**
     * 设备型号
     */
    private String deviceModel;

    /**
     * app版本
     */
    private String appVersion;

    /**
     * 客服id
     */
    private Long kefuId;

    /**
     * 客服所在部门id
     */
    private Long deptId;

    /**
     * 用户提问时间
     */
    private Date userQuestionTime;

    /**
     * 客服回复时间
     */
    private Date kefuAnswerTime;

    /**
     * 是否已经发送断开提醒
     */
    private Integer isNotice;

    /**
     * 关联cc_user_bind_record表id
     */
    private Long bindRecordId;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

    private static final long serialVersionUID = 1L;
}