package com.jiahui.im.util;

import java.security.MessageDigest;

import org.apache.commons.lang3.StringUtils;

/**
 * SHA加密工具类
 * @author Fanette Qiu
 * @date 2021/05/20 13:30
 **/
//@Log4j2
public class SHAUtil {
    /**
     * SHA-256加密
     * @param strText
     * @return
     */
    public static String SHA256(String strText) throws Exception {
        return SHA(strText, "SHA-256");
    }

    /**
     * SHA-512加密
     * @param strText
     * @return
     */
    public static String SHA512(String strText) throws Exception {
        return SHA(strText, "SHA-512");
    }

    /**
     * md5加密
     * @param strText
     * @return
     */
    public static String SHAMD5(String strText) throws Exception {
        return SHA(strText, "MD5");
    }

    /**
     * SHA加密
     * @param strText
     * @param strType
     * @return
     */
    private static String SHA(String strText, String strType) throws Exception {
        if (StringUtils.isNotBlank(strText)) {
            // 创建加密对象 并传入加密类型
            MessageDigest messageDigest = MessageDigest.getInstance(strType);
            // 传入要加密的字符串
            messageDigest.update(strText.getBytes());
            // 得到 byte 结果
            byte byteBuffer[] = messageDigest.digest();
            // byte 转 string
            StringBuffer strHexString = new StringBuffer();
            for (int i = 0; i < byteBuffer.length; i++) {
                String hex = Integer.toHexString(0xff & byteBuffer[i]);
                if (hex.length() == 1) {
                    strHexString.append('0');
                }
                strHexString.append(hex);
            }
//            log.info("字符串加密前：{}，加密后：{}", strText, strHexString);
            return strHexString.toString();
        }
        return null;
    }

    public static void main(String[] args) throws Exception {
        System.out.println("SHA256加密== " + SHA256("123"));
        System.out.println("SHA512加密== " + SHA512("123"));
        System.out.println("SHAMD5加密== " + SHAMD5("123"));
    }
}
