package com.jiahui.im.modules.common.dto.his.dict;

import lombok.Data;

@Data
public class DictRespDto {
	
	private String dictCode;
	
	private String dictValue;
	
	private String dictEngValue;
}
