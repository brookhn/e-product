package com.jiahui.im.modules.common.entity;

import com.jiahui.im.modules.common.enums.CcBindEventEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * cc_user_bind_record
 * @author 
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CcUserBindRecordEntity implements Serializable {
    /**
     * 主键
     */
    private Long id;

    /**
     * 会话id
     */
    private String conversationId;

    /**
     * 用户id
     */
    private Long userId;

    /**
     * 转接前客服id
     */
    private Long beforeKefuId;

    /**
     * 转接前部门id
     */
    private Long beforeDeptId;

    /**
     * 转接后客服id
     */
    private Long kefuId;

    /**
     * 转接后部门id
     */
    private Long deptId;

    /**
     * 事件类型 {@link CcBindEventEnum}
     */
    private Integer eventType;

    /**
     * 用户轮次提问时间
     */
    private Date userRoundQuestionTime;

    /**
     * 客服轮次回复时间
     */
    private Date kefuRoundAnswerTime;

    /**
     * 会话轮数
     */
    private Integer roundNum;

    /**
     * 轮次总响应时长（毫秒）
     */
    private Long totalResponseDuration;

    /**
     * 首轮响应时长（毫秒）
     */
    private Long firstResponseDuration;

    /**
     * 客服是否回复 0-未回复 1-已回复
     */
    private Integer isKefuAnswer;

    /**
     * 是否结束接待 0-未结束 1-已结束
     */
    private Integer isEndRecept;

    /**
     * 结束接待时间
     */
    private Date endReceptTime;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

    private static final long serialVersionUID = 1L;
}