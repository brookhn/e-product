package com.jiahui.im.modules.common.dto.his;

import com.jiahui.im.modules.common.enums.HisEnum;
import lombok.Data;

import java.util.List;
import java.util.Objects;

/**
 * @author Tommy
 * @date 2021/06/08
 */
@Data
public class HisRespDto<T> {
    /**
     * 查询状态 0-失败 1-成功
     */
    private String status;

	/**
	 * 返回信息 status为0和-1时返回
	 */
	private String msg;

    /**
     * 查询数量
     */
    private int datacnt;

    /**
     * 返回的具体数据 json 格式
     */
    private T data;

	/**
	 * 请求是否成功
	 * @return
	 */
	public boolean isSuccess() {
		return HisEnum.RESP_OK.getCode().equals(status);
	}

	/**
	 * 返回对象是否为空
	 * @return
	 */
	public boolean isNull() {
		return HisEnum.RESP_OK.getCode().equals(status) && Objects.isNull(data);
	}

	/**
	 * 返回集合是否为空
	 * @return
	 */
	public boolean isEmpty() {
		if (!HisEnum.RESP_OK.getCode().equals(status)) {
			return true;
		}
		if (Objects.isNull(data)) {
			return true;
		}
		if (data instanceof List) {
			List<T> rows = (List<T>) data;
			return rows.isEmpty();
		}
		return false;
	}
}
