package com.jiahui.im.modules.api.controller;

import com.jiahui.im.common.JsonOut;
import com.jiahui.im.modules.api.service.CcLoginService;
import com.jiahui.im.modules.api.service.LoginService;
import com.jiahui.im.modules.api.vo.login.LoginIn;
import com.jiahui.im.modules.api.vo.login.LoginOut;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/login")
@Api(tags = "登录接口")
public class LoginController {

	@Autowired
	private LoginService loginService;

	@ApiOperation(value = "用户登录", notes = "登录成功之后会把jwtToken放入响应头，header属性为Jwt-Token")
	@PostMapping("/doLogin")
	public JsonOut<LoginOut> login(@RequestBody @Validated LoginIn loginIn){
		return JsonOut.ok(loginService.login(loginIn));
	}
}
