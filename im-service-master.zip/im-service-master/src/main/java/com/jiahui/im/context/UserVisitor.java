package com.jiahui.im.context;

import com.jiahui.im.helper.MyJwt;
import lombok.Data;

/**
 * 请求访问信息
 * @author Tommy
 * @date 2021/6/16
 */
@Data
public class UserVisitor {

    /**
     * jwtToken
     */
    private String jwtToken;

    /**
     * 解析之后的jwt
     */
    private MyJwt myJwt;

    /**
     * IP地址
     */
    private String clientIp;
}