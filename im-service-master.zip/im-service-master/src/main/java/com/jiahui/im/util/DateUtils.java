package com.jiahui.im.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * 日期处理
 * 
 */
public class DateUtils {
	/** 时间格式(yyyy-MM-dd) */
	public final static String DATE_PATTERN = "yyyy-MM-dd";
	/** 时间格式(yyyy-MM-dd HH:mm:ss) */
	public final static String DATE_TIME_PATTERN = "yyyy-MM-dd HH:mm:ss";

    /**
     * 日期格式化 日期格式为：yyyy-MM-dd
     * @param date  日期
     * @return  返回yyyy-MM-dd格式日期
     */
	public static String format(Date date) {
        return format(date, DATE_PATTERN);
    }
	
	 /**
     * 日期格式化 日期格式为：yyyy-MM-dd
     * @return  返回yyyy-MM-dd格式日期
     */
	public static String formatDateTime() {
        return format(new Date(), "yyyyMMddHHmmss");
    }
	
	/**
     * 日期格式化 日期格式为：yyyy-MM-dd
     * @return  返回yyyy-MM-dd格式日期
     */
	public static String getYMD() {
        return format(new Date(), "yyyyMMdd");
    }

    /**
     * 日期格式化 日期格式为：yyyy-MM-dd
     * @param date  日期
     * @param pattern  格式，如：DateUtils.DATE_TIME_PATTERN
     * @return  返回yyyy-MM-dd格式日期
     */
    public static String format(Date date, String pattern) {
        if(date != null){
            SimpleDateFormat df = new SimpleDateFormat(pattern);
            return df.format(date);
        }
        return null;
    }
    
    public static DateFormat  getDateFormat(String pattern) {
    	return new SimpleDateFormat(pattern);
    }

    public static Integer getCurrentDateByInteger(Date date) {
		return Long.valueOf(date.getTime()/1000).intValue();
	}
    
    public static Integer getCurrentDateByInteger() {
		return Long.valueOf(System.currentTimeMillis()/1000).intValue();
	}
    
    public static Integer getDiffDate(Date sDate,Date eDate){
       return Long.valueOf((eDate.getTime()-sDate.getTime())/1000).intValue();
    }
    
    public static int differentDaysByMillisecond(Date start,Date end){
        Calendar s = Calendar.getInstance();
        s.setTime(start);
        Calendar e = Calendar.getInstance();
        e.setTime(end);
        if (s.get(Calendar.YEAR) != e.get(Calendar.YEAR)) {
        	return e.get(Calendar.YEAR) - s.get(Calendar.YEAR);
        } else {
        	return e.get(Calendar.DAY_OF_YEAR) - s.get(Calendar.DAY_OF_YEAR);
        }
    }
    
    /**
     * 获取本年第一天的时间
     * */
    public static Long getCurrentYearFirstDay(){
    	Calendar s = Calendar.getInstance();
    	int currentYear = s.get(Calendar.YEAR);
    	s.set(Calendar.YEAR, currentYear);
    	s.set(Calendar.MONTH, 0);
    	s.set(Calendar.DATE, 1);
    	s.set(Calendar.HOUR_OF_DAY, 0);
    	s.set(Calendar.MINUTE, 0);
    	s.set(Calendar.SECOND, 0);
    	return s.getTimeInMillis()/1000;
    }
    
    /**
     * 获取本年第一天的时间
     * */
    public static Long getYearFirstDay(int year){
    	Calendar s = Calendar.getInstance();
    	s.set(Calendar.YEAR, year);
    	s.set(Calendar.MONTH, 0);
    	s.set(Calendar.DATE, 1);
    	s.set(Calendar.HOUR_OF_DAY, 0);
    	s.set(Calendar.MINUTE, 0);
    	s.set(Calendar.SECOND, 0);
    	return s.getTimeInMillis()/1000;
    }
    
    /**
     * 获取下一年年第一天的时间
     * */
    public static Long getNextYearFirstDay(){
    	Calendar s = Calendar.getInstance();
    	int currentYear = s.get(Calendar.YEAR);
    	s.set(Calendar.YEAR, currentYear+1);
    	s.set(Calendar.MONTH, 0);
    	s.set(Calendar.DATE, 1);
    	s.set(Calendar.HOUR_OF_DAY, 0);
    	s.set(Calendar.MINUTE, 0);
    	s.set(Calendar.SECOND, 0);
    	return s.getTimeInMillis()/1000;
    }
    
    /**
     * 获取下一年的时间
     * */
    public static Long getNextYearTime(Long time){
    	Calendar s = Calendar.getInstance();
    	s.setTimeInMillis(time*1000);
    	int currentYear = s.get(Calendar.YEAR);
    	s.set(Calendar.YEAR, currentYear+1);
    	return s.getTimeInMillis()/1000;
    }
    
    /**
     * 获取指定时间的周N(如2020年1月1日的周五传入time , 6)
     * */
    public static Long getDayOfWeek(Long time, Integer week){
    	Calendar s = Calendar.getInstance();
    	s.setTimeInMillis(time*1000);
    	s.set(Calendar.DAY_OF_WEEK, week);
    	s.set(Calendar.HOUR_OF_DAY, 0);
    	s.set(Calendar.MINUTE, 0);
    	s.set(Calendar.SECOND, 0);
    	return s.getTimeInMillis()/1000;
    }
    
    /**
     * 获取指定时间的0点0分0秒
     * */
    public static Long setDayTime(Long time, Integer hour, Integer minute, Integer second){
    	Calendar s = Calendar.getInstance();
    	s.setTimeInMillis(time*1000L);
    	s.set(Calendar.HOUR_OF_DAY, hour);
    	s.set(Calendar.MINUTE, minute);
    	s.set(Calendar.SECOND, second);
    	return s.getTimeInMillis()/1000;
    }
    
    public static void main(String[] args) {
		System.out.println(setDayTime(1601546623L, 7, 0 ,0));
	}
}
