package com.jiahui.im.util;

import cn.hutool.core.util.StrUtil;
import com.jiahui.im.config.properties.SysProperties;
import com.jiahui.im.modules.common.service.CacheService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * 客服工具类
 * @author Tommy
 * @date 2022/1/24
 */
@Component
public class KefuUtil {

	private static CacheService cacheService;

	@Autowired
	public void setCacheService(CacheService cacheService) {
		KefuUtil.cacheService = cacheService;
	}

	/**
	 * 获取科室客服展示头像
	 * @param deptId
	 * @return
	 */
	public static String getShowDeptHeadUrl(Long deptId) {
		String headUrl = cacheService.getDeptHeadUrl(deptId);
		return StrUtil.blankToDefault(headUrl, SysProperties.deptDefaultKefuHeadUrl);
	}
}
