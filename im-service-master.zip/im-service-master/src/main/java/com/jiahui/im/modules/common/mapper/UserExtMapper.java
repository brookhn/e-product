package com.jiahui.im.modules.common.mapper;

import com.jiahui.im.modules.common.entity.UserExtEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface UserExtMapper {

    /**
     * 新增
     * @param record
     * @return
     */
    int insertSelective(UserExtEntity record);

    /**
     * 查询是否存在
     * @param userId
     * @param deptId
     * @return
     */
    Integer isExist(@Param("userId") Long userId, @Param("deptId") Long deptId);

    /**
     * 查询首次咨询标记
     * @param userId
     * @param deptId
     * @return
     */
    Integer selectFirstQuestionFlag(@Param("userId") Long userId, @Param("deptId") Long deptId);

    /**
     * 更新首次咨询标记
     * @param userId
     * @param deptId
     * @return
     */
    int updateFirstQuestionFlag(@Param("userId") Long userId, @Param("deptId") Long deptId);

    /**
     * 根据用户id和科室id更新用户已读状态
     * @param userId
     * @param deptId
     * @return
     */
    int markUserReadByUserIdAndDeptId(@Param("userId") Long userId, @Param("deptId") Long deptId);

    /**
     * 根据账号id和科室id更新用户已读状态
     * @param accountId
     * @param deptId
     * @return
     */
    int markUserReadByAccountIdAndDeptId(@Param("accountId") Long accountId, @Param("deptId") Long deptId);

    /**
     * 根据账号id和科室id集合更新用户已读状态
     * @param accountId
     * @param deptIdList
     * @return
     */
    int markUserReadByAccountIdAndDeptIdList(@Param("accountId") Long accountId, @Param("deptIdList") List<Long> deptIdList);

    /**
     * 根据账号id和科室id集合查询
     * @param accountId
     * @return
     */
    List<UserExtEntity> selectByAccountId(@Param("accountId") Long accountId, @Param("deptIdList") List<Long> deptIdList);
}