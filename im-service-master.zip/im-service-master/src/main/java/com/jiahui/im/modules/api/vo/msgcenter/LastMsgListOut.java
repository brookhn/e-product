package com.jiahui.im.modules.api.vo.msgcenter;

import com.jiahui.im.modules.common.entity.CcUserExtEntity;
import com.jiahui.im.modules.common.entity.UserExtEntity;
import com.jiahui.im.modules.common.enums.MsgTypeEnum;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;

/**
 * @author Tommy
 * @date 2022/5/19
 */
@ApiModel
@Data
@NoArgsConstructor
@AllArgsConstructor
public class LastMsgListOut {

    @ApiModelProperty(value = "记录列表")
    private List<Record> recordList = Collections.emptyList();

    @ApiModelProperty(value = "用户未读消息总数")
    private Integer userUnreadTotalNum = 0;

    @ApiModel("LastMsgListOutRecord")
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Record {
        @ApiModelProperty(value = "客服类型 1-科室客服 2-CC客服")
        private Integer kefuType;

        @ApiModelProperty(value = "科室id")
        private Long deptId = 0L;

        @ApiModelProperty(value = "用户未读消息数")
        private Integer userUnreadNum = 0;

        @ApiModelProperty(value = "客服发给用户最后一条消息时间 毫秒级时间戳")
        private Long kefuLastSendTime = 0L;

        @ApiModelProperty(value = "客服发给用户最后一条消息类型 1-文本 2-图片 3-语音 4-视频 5-word 6-PDF 7-文件")
        private Integer kefuLastMsgType = 0;

        @ApiModelProperty(value = "客服发给用户最后一条消息内容")
        private String kefuLastContent = "";

        public Record(Integer kefuType) {
            this.kefuType = kefuType;
        }

        public Record(Integer kefuType, Long deptId) {
            this.kefuType = kefuType;
            this.deptId = deptId;
        }

        public Record(CcUserExtEntity ccUserExt) {
            this.kefuType = 2;
            this.userUnreadNum = ccUserExt.getUserUnreadNum();
            this.kefuLastSendTime = Optional.ofNullable(ccUserExt.getKefuLastSendTime()).map(Date::getTime).orElse(0L);
            this.kefuLastMsgType = ccUserExt.getKefuLastMsgType();
            // 使用pushContent字段（content去除html标签）
            this.kefuLastContent = MsgTypeEnum.getShowContent(ccUserExt.getKefuLastMsgType(), ccUserExt.getKefuLastPushContent());
        }

        public Record(UserExtEntity deptUserExt) {
            this.kefuType = 1;
            this.deptId = deptUserExt.getDeptId();
            this.userUnreadNum = deptUserExt.getUserUnreadNum();
            this.kefuLastSendTime = Optional.ofNullable(deptUserExt.getKefuLastSendTime()).map(Date::getTime).orElse(0L);
            this.kefuLastMsgType = deptUserExt.getKefuLastMsgType();
            // 使用pushContent字段（content去除html标签）
            this.kefuLastContent = MsgTypeEnum.getShowContent(deptUserExt.getKefuLastMsgType(), deptUserExt.getKefuLastPushContent());
        }
    }
}

