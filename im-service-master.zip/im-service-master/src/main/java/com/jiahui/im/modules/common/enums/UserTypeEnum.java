package com.jiahui.im.modules.common.enums;

import com.google.common.collect.Maps;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Map;

/**
 * 用户类型
 * @author Tommy
 * @date 2021/6/8
 */
@Getter
@AllArgsConstructor
public enum UserTypeEnum {

    USER(1, "用户"),
    KEFU(2, "客服"),

    /**
     * 暂无系统角色
     */
//    SYSTEM(3, "系统"),
    ;

    /**
     * 类型
     */
    private final Integer type;

    /**
     * 描述
     */
    private final String desc;

    public static final Map<Integer, UserTypeEnum> map = Maps.newHashMap();

    static {
        for (UserTypeEnum e : UserTypeEnum.values()) {
            map.put(e.getType(), e);
        }
    }

    public static UserTypeEnum fromType(Integer type) {
        return map.get(type);
    }
}
