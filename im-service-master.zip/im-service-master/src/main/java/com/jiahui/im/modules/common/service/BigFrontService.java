package com.jiahui.im.modules.common.service;

import cn.hutool.core.collection.CollUtil;
import com.fasterxml.jackson.core.type.TypeReference;
import com.jiahui.im.config.properties.BigFrontProperties;
import com.jiahui.im.helper.RestHelper;
import com.jiahui.im.modules.common.dto.bigfront.BigFrontRespDto;
import com.jiahui.im.modules.common.dto.bigfront.DeptInfoDto;
import com.jiahui.im.modules.common.dto.bigfront.UserInfoDto;
import com.jiahui.im.modules.common.enums.BigFrontUrlEnum;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;

/**
 * 大前端接口服务
 * @author Tommy
 * @date 2022/01/14
 */
@Log4j2
@Service
public class BigFrontService {

    @Autowired
    private BigFrontProperties bigFrontProperties;

    /**
     * 根据ID查询用户详情信息
     * @param accountId
     * @return
     */
    public UserInfoDto getUserDetailInfo(Long accountId) {
        String url = bigFrontProperties.getPrefixUrl() + BigFrontUrlEnum.getUserDetailInfo.getUrl();
        UserInfoDto userInfoDto = RestHelper.doFormPostWithEncrypt(url, accountId, new TypeReference<UserInfoDto>() {});
        return userInfoDto;
    }

    /**
     * 根据ID获取一级科室数据
     * @param deptId
     * @return
     */
    public DeptInfoDto findGroupById(Long deptId) {
        String url = bigFrontProperties.getPrefixUrl() + BigFrontUrlEnum.findGroupById.getUrl() + deptId;
        DeptInfoDto deptInfoDto = RestHelper.doGetWithAuthForBigFront(url, new ParameterizedTypeReference<BigFrontRespDto<DeptInfoDto>>() {});
        return deptInfoDto;
    }

    /**
     * 获取全部一级科室数据
     * @return
     */
    public List<DeptInfoDto> getAllDepartmentInfo() {
        String url = bigFrontProperties.getPrefixUrl() + BigFrontUrlEnum.getAllDepartmentInfo.getUrl();
        List<DeptInfoDto> deptInfoDtoList = RestHelper.doGetWithAuthForBigFront(url, new ParameterizedTypeReference<BigFrontRespDto<List<DeptInfoDto>>>() {});
        return CollUtil.isEmpty(deptInfoDtoList) ? Collections.emptyList() : deptInfoDtoList;
    }
}
