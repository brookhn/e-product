package com.jiahui.im.modules.api.vo.oss;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GetPresignedUrlIn {

	/**
	 * oss文件名
	 */
	private String objectName;

	/**
	 * 消息类型 1-文本 2-图片 3-语音 4-视频 5-word 6-PDF 7-文件
	 */
	private Integer msgType;
}

