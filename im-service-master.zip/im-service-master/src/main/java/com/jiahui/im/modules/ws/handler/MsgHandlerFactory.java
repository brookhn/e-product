package com.jiahui.im.modules.ws.handler;

import cn.hutool.extra.spring.SpringUtil;
import com.google.common.collect.Maps;
import com.jiahui.im.common.CodeMsg;
import com.jiahui.im.helper.MyJwt;
import com.jiahui.im.modules.ws.constant.ImConst;
import com.jiahui.im.modules.ws.util.WsUtil;
import com.jiahui.im.modules.ws.vo.WsRequestIn;
import org.springframework.context.annotation.DependsOn;
import org.springframework.stereotype.Component;
import org.tio.core.ChannelContext;

import javax.annotation.PostConstruct;
import java.util.Map;
import java.util.Objects;

/**
 * 消息处理器工厂
 */
@Component
@DependsOn("cn.hutool.extra.spring.SpringUtil")
public class MsgHandlerFactory {

    /**
     * 指令处理器集合
     */
    private final Map<String, IActionHandler> actionHandlerMap = Maps.newHashMap();

    @PostConstruct
    private void initActionHandler() {
        Map<String, IActionHandler> springActionHandlerMap = SpringUtil.getBeansOfType(IActionHandler.class);
        for (IActionHandler actionHandler : springActionHandlerMap.values()) {
            String key = actionHandler.getAction() + "-" + actionHandler.getKefuType();
            actionHandlerMap.put(key, actionHandler);
        }
    }

    /**
     * 接收处理消息
     */
    public void receive(ChannelContext channelContext, WsRequestIn wsRequestIn) {
        // 获取连接信息
        MyJwt myJwt = (MyJwt) channelContext.get(ImConst.JWT_INFO);
        // 获取指令处理器
        String key = wsRequestIn.getAction() + "-" + myJwt.getKefuType();
        IActionHandler actionHandler = getActionHandler(key);
        if (Objects.isNull(actionHandler)) {
            WsUtil.sendError(channelContext, CodeMsg.UNSUPPORTED_ACTION);
            return;
        }
        actionHandler.handle(channelContext, wsRequestIn);
    }

    /**
     * 获取指令处理器
     * @param key
     * @return
     */
    private IActionHandler getActionHandler(String key) {
        return actionHandlerMap.get(key);
    }
}
