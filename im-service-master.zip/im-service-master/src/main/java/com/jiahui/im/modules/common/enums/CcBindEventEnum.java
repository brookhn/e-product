package com.jiahui.im.modules.common.enums;

import com.google.common.collect.Maps;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * CC客服-绑定事件类型
 * @author Tommy
 * @date 2021/6/8
 */
@Getter
@AllArgsConstructor
public enum CcBindEventEnum {

    SYSTEM_BIND(10, "系统绑定"),
    KEFU_BIND(11, "客服绑定"),
    NO_RANK_BIND(12, "无排队绑定"),
    ACTIVE_TRANSFER(20, "主动转接"),
    PASSIVE_TRANSFER(21, "被动转接"),
    SYSTEM_UNBIND(30, "系统解绑"),
    KEFU_UNBIND(31, "客服解绑"),
    ;

    /**
     * 类型
     */
    private final Integer type;

    /**
     * 描述
     */
    private final String desc;

    public static final Map<Integer, CcBindEventEnum> map = Maps.newHashMap();

    static {
        for (CcBindEventEnum e : CcBindEventEnum.values()) {
            map.put(e.getType(), e);
        }
    }

    public static CcBindEventEnum fromType(Integer type) {
        return map.get(type);
    }

    // 接待事件类型
    public static final List<Integer> receptEventTypeList = Arrays.asList(SYSTEM_BIND.type, KEFU_BIND.type, NO_RANK_BIND.type, ACTIVE_TRANSFER.type, PASSIVE_TRANSFER.type);
}
