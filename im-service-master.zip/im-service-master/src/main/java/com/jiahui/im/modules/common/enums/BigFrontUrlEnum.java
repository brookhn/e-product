package com.jiahui.im.modules.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum BigFrontUrlEnum {

	/**
	 * gateway服务
	 */
	test_getUserDetailInfoByUserId("/gateway/user/valid/getUserDetailInfoByUserId","仅供测试使用-根据用户ID查询用户信息"),
	test_getUserInfoByUnionId("/gateway/user/valid/getUserInfoByUnionId","仅供测试使用-根据unionId查询用户信息"),
	test_getUserInfoPage("/gateway/user/valid/getUserInfoPage","仅供测试使用-根据手机号或用户来源查询用户信息分页列表"),
	test_getUserInfoByPhone("/gateway/user/valid/getUserInfoByPhone","仅供测试使用-根据phone查询用户信息"),

	getUserDetailInfo("/gateway/user/getUserDetailInfo","根据ID查询用户详情信息"),
	getUserInfo("/gateway/user/getUserInfo","根据手机号或用户来源查询用户信息分页列表"),
	getUserInfoByUnionId("/gateway/user/getUserInfoByUnionId","根据unionId查询用户信息"),
	getUserInfoByPhone("/gateway/user/getUserInfoByPhone","根据phone查询用户信息"),

	findGroupById("/gateway/dept/findGroupById?deptGroupId=","根据ID获取一级科室数据"),
	getAllDepartmentInfo("/gateway/dept/getAllDepartmentInfo","一级科室数据获取-返回数据简化版"),

	/**
	 * app-message服务
	 */
	SEND_WECHAT_NOTICE_URI("/app-message/im/callback/wxNotice","发送微信通知"),
	SEND_APP_MESSAGE_URI("/app-message/im/callback/pushNotice","发送APP PUSH消息")
	;

	/**
	 * 接口路径
	 */
	private final String url;

	/**
	 * 接口描述
	 */
	private final String desc;
}
