package com.jiahui.im.helper;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.lang.Console;
import cn.hutool.core.thread.ThreadUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.jiahui.im.common.CodeMsg;
import com.jiahui.im.common.exception.BizException;
import com.jiahui.im.config.properties.JwtProperties;
import com.jiahui.im.constant.GlobalVar;
import com.jiahui.im.enums.JwtStatusEnum;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.SignatureException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.crypto.spec.SecretKeySpec;
import java.security.Key;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

/**
 * jwt工具类
 * @author Tommy
 * @date 2021/6/9
 */
@Component
public class JwtHelper {

    private static JwtProperties jwtProperties;

    @Autowired
    public void setJwtProperties(JwtProperties jwtProperties) {
        JwtHelper.jwtProperties = jwtProperties;
    }

    private static Claims genStatusClaims(JwtStatusEnum jwtStatusEnum) {
        // 状态 0正常 -1非法 -2已过期 -3jwt密钥非法 -4未知异常
        Map<String, Object> claimsMap = new HashMap<>();
        claimsMap.put(GlobalVar.STATUS, jwtStatusEnum.getStatus());
        claimsMap.put(GlobalVar.STATUS_MSG, jwtStatusEnum.getStatusMsg());
        return Jwts.claims(claimsMap);
    }

    /**
     * 解析jwt
     * @param jwtToken
     * @return
     */
	private static Claims parseJWT(String jwtToken) {
        if (StrUtil.isBlank(jwtToken) || jwtToken.length() < 64) {
            return genStatusClaims(JwtStatusEnum.ILLEGAL);
        }
        byte[] keybytes = Base64.getDecoder().decode(jwtProperties.getKey());
        if (Objects.isNull(keybytes) || keybytes.length < 16) {
            return genStatusClaims(JwtStatusEnum.SECRET_ILLEGAL);
        }
        try {
            Claims claims = Jwts.parser()
                    .setSigningKey(keybytes)
                    .parseClaimsJws(jwtToken)
                    .getBody();
            claims.put(GlobalVar.STATUS, JwtStatusEnum.SUCCESS.getStatus());
            return claims;
        } catch (MalformedJwtException | SignatureException e) {
            return genStatusClaims(JwtStatusEnum.ILLEGAL);
        } catch (ExpiredJwtException e1) {
            return genStatusClaims(JwtStatusEnum.EXPIRED);
        } catch (Exception ex) {
            return genStatusClaims(JwtStatusEnum.UNKNOWN);
        }
    }

    /**
     * 解析jwt
     * @param jwtToken
     * @return
     */
    public static MyJwt parseMyJwt(String jwtToken) {
        Claims claims = parseJWT(jwtToken);
        MyJwt myJwt = new MyJwt();
        // 状态 0正常 -1非法 -2已过期 -3jwt密钥非法 -4未知异常
        int status = claims.get(GlobalVar.STATUS, Integer.class);
        myJwt.setStatus(status);
        if (status != 0) {
            return myJwt;
        }
        myJwt.setStatusMsg(claims.get(GlobalVar.STATUS_MSG, String.class));
        /******生成jwt入参 start******/
        myJwt.setUserId(claims.get(GlobalVar.USERID, Long.class));
        myJwt.setAccountId(claims.get(GlobalVar.ACCOUNT_ID, Long.class));
        myJwt.setUserName(claims.get(GlobalVar.USERNAME, String.class));
        myJwt.setHeadUrl(claims.get(GlobalVar.HEADURL, String.class));
        myJwt.setChannelType(claims.get(GlobalVar.CHANNEL_TYPE, Integer.class));
        myJwt.setDeptId(claims.get(GlobalVar.DEPTID, Long.class));
        myJwt.setSystemVersion(claims.get(GlobalVar.SYSTEM_VERSION, String.class));
        myJwt.setDeviceModel(claims.get(GlobalVar.DEVICE_MODEL, String.class));
        myJwt.setAppVersion(claims.get(GlobalVar.APP_VERSION, String.class));
        myJwt.setKefuType(claims.get(GlobalVar.KEFU_TYPE, Integer.class));
        /******生成jwt入参 end******/
        myJwt.setIss(claims.getIssuer());
        myJwt.setJti(claims.getId());
        myJwt.setTtls(claims.get(GlobalVar.TTLS, Integer.class));
        myJwt.setExp(claims.getExpiration().getTime() / 1000L);
        return myJwt;
    }

    /**
     * 生成jwt
     * @param myJwt
     * @return
     */
    public static String createMyJwt(MyJwt myJwt) {
        if (Objects.isNull(myJwt)) {
            throw new BizException(CodeMsg.CODE_210004001);
        }
        byte[] keybytes = Base64.getDecoder().decode(jwtProperties.getKey());
        if (Objects.isNull(keybytes) || keybytes.length < 16) {
            throw new BizException(CodeMsg.CODE_210004001);
        }
        if (jwtProperties.getTimeout() < 1) {
            throw new BizException(CodeMsg.CODE_210004001);
        }
        long nowMillis = System.currentTimeMillis();
        Date now = new Date(nowMillis);
        SignatureAlgorithm signatureAlgorithm = SignatureAlgorithm.HS256;
        Key signingKey = new SecretKeySpec(keybytes, signatureAlgorithm.getJcaName());
        JwtBuilder builder = Jwts.builder()
                .setHeaderParam("typ", "JWT")
                .setHeaderParam("alg", "HS256")
                .setId(UUID.randomUUID().toString())
                .setIssuer(GlobalVar.ISSUER)
                .setIssuedAt(now)
                .setNotBefore(now)
                .setExpiration(DateUtil.offsetSecond(now, jwtProperties.getTimeout()))
                /******生成jwt入参 start******/
                .claim(GlobalVar.USERID, myJwt.getUserId())
                .claim(GlobalVar.ACCOUNT_ID, myJwt.getAccountId())
                .claim(GlobalVar.USERNAME, myJwt.getUserName())
                .claim(GlobalVar.HEADURL, myJwt.getHeadUrl())
                .claim(GlobalVar.CHANNEL_TYPE, myJwt.getChannelType())
                .claim(GlobalVar.DEPTID, myJwt.getDeptId())
                .claim(GlobalVar.SYSTEM_VERSION, myJwt.getSystemVersion())
                .claim(GlobalVar.DEVICE_MODEL, myJwt.getDeviceModel())
                .claim(GlobalVar.APP_VERSION, myJwt.getAppVersion())
                .claim(GlobalVar.KEFU_TYPE, myJwt.getKefuType())
                /******生成jwt入参 end******/
                .claim(GlobalVar.TTLS, jwtProperties.getTimeout())
                .signWith(signatureAlgorithm, signingKey);
        return builder.compact();
    }

    public static void main(String[] args) {
	    // 设置jwt配置
        JwtProperties jwtProperties = new JwtProperties();
        jwtProperties.setKey("IQlM43ZoWEVXNoPb8VEQ74fB5qW+cgvrWta+yogjyPKUbnS3uaf6W+ucZV1ciYZhNO1lv2M8m2IfLSbZmSlbBw==");
        jwtProperties.setHeader("Jwt-Token");
        jwtProperties.setTimeout(720000);
        JwtHelper.jwtProperties = jwtProperties;

        // 生成jwt
        MyJwt myJwt = new MyJwt();
        myJwt.setUserId(6L);
        myJwt.setAccountId(6L);
        myJwt.setUserName("gavin.gong");
        myJwt.setHeadUrl("https://img0.baidu.com/it/u=1406515706,336510358&fm=26&fmt=auto&gp=0.jpg");
        myJwt.setChannelType(1);
        myJwt.setDeptId(111L);
        myJwt.setKefuType(1);
        myJwt.setSystemVersion("a");
        myJwt.setDeviceModel("b");
        myJwt.setAppVersion("c");
        String jwtToken = JwtHelper.createMyJwt(myJwt);
        Console.error(jwtToken);

        ThreadUtil.sleep(3, TimeUnit.SECONDS);

        // 解析jwt
        MyJwt myJwt1 = JwtHelper.parseMyJwt(jwtToken);
        Console.error(JSON.toJSONString(myJwt1, true));
    }
}


