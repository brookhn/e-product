package com.jiahui.im.modules.common.enums;

import com.google.common.collect.Maps;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Map;

/**
 * 接待类型
 * @author Tommy
 * @date 2021/6/8
 */
@Getter
@AllArgsConstructor
public enum ReceptTypeEnum {

    WAITING(1, "待接待"),
    RECEIVING(2, "接待中"),
    ;

    /**
     * 类型
     */
    private final Integer type;

    /**
     * 描述
     */
    private final String desc;

    public static final Map<Integer, ReceptTypeEnum> map = Maps.newHashMap();

    static {
        for (ReceptTypeEnum e : ReceptTypeEnum.values()) {
            map.put(e.getType(), e);
        }
    }

    public static ReceptTypeEnum fromType(Integer type) {
        return map.get(type);
    }
}
