package com.jiahui.im.modules.common.dto.his.patient;

import lombok.Data;

@Data
public class EpisodeListRespDto {
	
	private String episodeId;
	
	private String patientId;
	
	private String regDate;
	
	private String patientName;
	
	private String regDeptCode;
	
	private String regDocCode;
	
	private String apptSrvtId;
	
}
