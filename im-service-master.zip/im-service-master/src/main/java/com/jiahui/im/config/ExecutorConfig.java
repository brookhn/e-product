package com.jiahui.im.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;

import java.util.concurrent.ThreadPoolExecutor;

/**
 * 线程池配置
 * @author Tommy
 * @date 2021/7/2
 */
@Configuration
@EnableAsync
public class ExecutorConfig {

    /**
     * 定时任务线程池
     * @return
     */
    @Bean
    public ThreadPoolTaskScheduler schedulerExecutor() {
        ThreadPoolTaskScheduler executor = new ThreadPoolTaskScheduler();
        executor.setPoolSize(10);//核心线程数
        executor.setThreadNamePrefix("schedulerExecutor-");//线程池名的前缀
        executor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());//线程池对拒绝任务的处理策略，由调用线程处理该任务
        executor.setWaitForTasksToCompleteOnShutdown(true);//设置线程池关闭的时候等待所有任务都完成再继续销毁其他的Bean
        executor.setAwaitTerminationSeconds(60);//设置线程池中任务终止的等待时间
        executor.initialize();//执行初始化
        return executor;
    }

    /**
     * 异步线程池
     * @return
     */
    @Bean
    public ThreadPoolTaskExecutor asyncTaskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(5);//核心线程数
        executor.setMaxPoolSize(5);//最大线程数
        executor.setQueueCapacity(200);//队列大小
        executor.setKeepAliveSeconds(60);//允许线程的空闲时间
        executor.setThreadNamePrefix("asyncTaskExecutor-");//线程池名的前缀
        executor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());//线程池对拒绝任务的处理策略，由调用线程处理该任务
        executor.setWaitForTasksToCompleteOnShutdown(true);//设置线程池关闭的时候等待所有任务都完成再继续销毁其他的Bean
        executor.setAwaitTerminationSeconds(60);//设置线程池中任务终止的等待时间
        executor.initialize();//执行初始化
        return executor;
    }
}
