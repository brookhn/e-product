package com.jiahui.im.modules.common.mapper;

import com.jiahui.im.modules.common.entity.DeptUserBindingEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface DeptUserBindingMapper {
    /**
     * 根据唯一索引查询
     * @param userId
     * @param deptId
     * @return
     */
    DeptUserBindingEntity selectByUk(@Param("userId") Long userId, @Param("deptId") Long deptId);
}