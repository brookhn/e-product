package com.jiahui.im.config;

import com.jiahui.im.interceptor.JwtInterceptor;
import com.jiahui.im.interceptor.SignAuthInterceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * @author Tommy
 * @date 2021/5/19
 */
@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Autowired
    private JwtInterceptor jwtInterceptor;

    @Autowired
    private SignAuthInterceptor signAuthInterceptor;

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("doc.html")
                .addResourceLocations("classpath:/META-INF/resources/");
        registry.addResourceHandler("/webjars/**")
                .addResourceLocations("classpath:/META-INF/resources/webjars/");
        registry.addResourceHandler("/favicon.ico")
                .addResourceLocations("classpath:/static/");
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        // jwt拦截器
        registry.addInterceptor(jwtInterceptor)
                .addPathPatterns("/**")
                .excludePathPatterns("/favicon.ico", "/error")
                // 登录相关
                .excludePathPatterns("/login/**")
                // swagger相关
                .excludePathPatterns("/doc.html", "/swagger-resources/**")
                // 消息中心相关
                .excludePathPatterns("/msg-center/**")
                // 注册用户事件
                .excludePathPatterns("/register-user/event/**")
        ;

        // 签名拦截器
        registry.addInterceptor(signAuthInterceptor)
                .addPathPatterns("/msg-center/**")
                .addPathPatterns("/register-user/event/**")
        ;
    }
}