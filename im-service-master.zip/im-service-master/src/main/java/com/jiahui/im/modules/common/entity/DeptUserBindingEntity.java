package com.jiahui.im.modules.common.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * 科室客服-用户绑定关系表
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DeptUserBindingEntity {
    /**
     * 主键
     */
    private Long id;

    /**
     * 关联用户id
     */
    private Long userId;

    /**
     * 科室id
     */
    private Long deptId;

    /**
     * 客服id
     */
    private Long kefuId;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;
}