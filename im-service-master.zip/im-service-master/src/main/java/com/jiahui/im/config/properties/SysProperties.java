package com.jiahui.im.config.properties;

import lombok.extern.log4j.Log4j2;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * @author Tommy
 * @date 2021/8/18
 */
@Log4j2
@Configuration
@ConfigurationProperties(prefix = "sys")
public class SysProperties {
    /**
     * 科室客服-默认客服头像
     */
    public static String deptDefaultKefuHeadUrl;

    /**
     * CC客服-默认客服头像
     */
    public static String ccDefaultKefuHeadUrl;

    /**
     * 默认用户头像
     */
    public static String defaultUserHeadUrl;

    /**
     * CC客服-默认接待上限
     */
    public static Integer ccDefaultReceptLimit;

    /**
     * 更新用户信息时间（单位：分钟）
     */
    public static Integer updateUserInfoTime;

    /**
     * 应用名称-环境
     */
    public static String applicationProfile;

    /**
     * 应用名称
     */
    public static String applicationName;

    /**
     * 启动环境
     */
    public static String profile = "";

    /**
     * 启动端口
     */
    public static String serverPort;

    public void setDeptDefaultKefuHeadUrl(String deptDefaultKefuHeadUrl) {
        log.info("SysProperties.deptDefaultKefuHeadUrl：{}", deptDefaultKefuHeadUrl);
        SysProperties.deptDefaultKefuHeadUrl = deptDefaultKefuHeadUrl;
    }

    public void setCcDefaultKefuHeadUrl(String ccDefaultKefuHeadUrl) {
        log.info("SysProperties.ccDefaultKefuHeadUrl：{}", ccDefaultKefuHeadUrl);
        SysProperties.ccDefaultKefuHeadUrl = ccDefaultKefuHeadUrl;
    }

    public void setDefaultUserHeadUrl(String defaultUserHeadUrl) {
        log.info("SysProperties.defaultUserHeadUrl：{}", defaultUserHeadUrl);
        SysProperties.defaultUserHeadUrl = defaultUserHeadUrl;
    }

    public void setCcDefaultReceptLimit(Integer ccDefaultReceptLimit) {
        log.info("SysProperties.ccDefaultReceptLimit：{}", ccDefaultReceptLimit);
        SysProperties.ccDefaultReceptLimit = ccDefaultReceptLimit;
    }

    public void setUpdateUserInfoTime(Integer updateUserInfoTime) {
        log.info("SysProperties.updateUserInfoTime：{}", updateUserInfoTime);
        SysProperties.updateUserInfoTime = updateUserInfoTime;
    }

    public void setApplicationProfile(String applicationProfile) {
        SysProperties.applicationProfile = applicationProfile;
    }

    public void setApplicationName(String applicationName) {
        SysProperties.applicationName = applicationName;
    }

    public void setProfile(String profile) {
        SysProperties.profile = profile;
    }

    public void setServerPort(String serverPort) {
        SysProperties.serverPort = serverPort;
    }
}
