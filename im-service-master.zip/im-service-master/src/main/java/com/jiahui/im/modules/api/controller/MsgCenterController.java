package com.jiahui.im.modules.api.controller;

import com.jiahui.im.common.JsonOut;
import com.jiahui.im.modules.api.service.MsgCenterService;
import com.jiahui.im.modules.api.vo.msgcenter.LastMsgListIn;
import com.jiahui.im.modules.api.vo.msgcenter.LastMsgListOut;
import com.jiahui.im.modules.api.vo.msgcenter.MarkAllReadIn;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Tommy
 * @date 2022/5/19
 */
@Api(tags = "消息中心相关接口")
@RestController
@RequestMapping("/msg-center")
public class MsgCenterController {

    @Autowired
    private MsgCenterService msgCenterService;

    @ApiOperation(value = "客服最新消息集合（含未读消息数）", notes = "含CC客服和科室客服")
    @PostMapping("/last-msg-list")
    public JsonOut<LastMsgListOut> lastMsgList(@RequestBody @Validated LastMsgListIn lastMsgListIn) {
        return JsonOut.ok(msgCenterService.lastMsgList(lastMsgListIn));
    }

    @ApiOperation(value = "标记全部消息为已读", notes = "含CC客服和科室客服")
    @PostMapping("/mark-all-read")
    public JsonOut markAllRead(@RequestBody @Validated MarkAllReadIn markAllReadIn) {
        msgCenterService.markAllReadIn(markAllReadIn);
        return JsonOut.ok();
    }
}
