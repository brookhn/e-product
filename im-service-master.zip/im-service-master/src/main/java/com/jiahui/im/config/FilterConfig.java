package com.jiahui.im.config;

import com.jiahui.im.filter.ContextFilter;
import com.jiahui.im.filter.CorsFilter;
import com.jiahui.im.filter.Log4j2Filter;
import com.jiahui.im.filter.RequestFilter;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class FilterConfig {

	/**
	 * 跨域过滤器
	 * @param filter
	 * @return
	 */
	@Bean
	public FilterRegistrationBean registrationCors(CorsFilter filter) {
		FilterRegistrationBean registration = new FilterRegistrationBean(filter);
		registration.addUrlPatterns("/*");
		registration.setOrder(-4);
		return registration;
	}

	/**
	 * 上下文过滤器
	 * - ContextFilter优先级要在Log4j2Filter之前
	 * @param filter
	 * @return
	 */
	@Bean
	public FilterRegistrationBean registrationContext(ContextFilter filter) {
		FilterRegistrationBean registration = new FilterRegistrationBean(filter);
		registration.addUrlPatterns("/*");
		registration.setOrder(-3);
		return registration;
	}

	/**
	 * 日志过滤器
	 * - Log4j2Filter优先级要在WebTraceFilter之前
	 * - WebTraceFilter默认order为-1
	 * - Log4j2Filter可定制一些日志字段以适配WebTraceFilter
	 * @return
	 */
	@Bean
	public FilterRegistrationBean<Log4j2Filter> log4j2Filter() {
		FilterRegistrationBean<Log4j2Filter> registrationBean = new FilterRegistrationBean<>();
		registrationBean.setFilter(new Log4j2Filter());
		registrationBean.setOrder(-2);
		registrationBean.addUrlPatterns("/*");
		return registrationBean;
	}

	/**
	 * 请求过滤器
	 * - RequestFilter优先级要在WebTraceFilter之后
	 * - WebTraceFilter默认order为-1
	 * - 由于需要在拦截器里面读取请求参数，所以需要该过滤器放在所有过滤器后面，保证RequestWrapper为最后一次包装类
	 * @return
	 */
	@Bean
	public FilterRegistrationBean<RequestFilter> requestFilter() {
		FilterRegistrationBean<RequestFilter> registrationBean = new FilterRegistrationBean<>();
		registrationBean.setFilter(new RequestFilter());
		registrationBean.setOrder(0);
		registrationBean.addUrlPatterns("/*");
		return registrationBean;
	}
}
