package com.jiahui.im.modules.common.dto.his.patient;

import lombok.Data;

@Data
public class PatientApptDetailRespDto {
	
	private String patientId;
	
	private String apptRemark;
	
	private String apptSrvtId;
	
	private String episodeType;
	
	private String episodeId;
	
	private String fromEpisodeType;
	
	private String fromEpisodeId	;
	
	private String apptState;
	
	private String doctorId;
	
	private String siteId;
	
	private String deptId;
	
	private String schSiteId;
	
	private String startTime;
	
	private String endTime;
	
	private String apptSource;
	
	private String remark;
	
	private String scheduleId;
	
	private String ressvcId;
	
	private String resSvcName;
	
	private String pactCode;
	
	private String payorId;
	
	private String rsvDetId;
	
	private String resSubType;
	
	private String applyDept;
	
	private String applyOper;
	
	private String rsvDate;
	
	private String execDept;
	
	private String execDoc;
	
	private String termId;
	
	private String termName;
	
	private String orderId;
	
	private String orderDoctor;
	
	private String orderDept;
	
	private String cancelOper;
	
	private String arriveOper;
	
	private String cancelReason;
	
	private String applyDate;
	
	private String createDate;
	
	private String operDate;
	
	private String operCode;
	
	
}
