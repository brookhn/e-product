package com.jiahui.im.modules.common.service;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.ObjectUtil;
import com.fasterxml.jackson.core.type.TypeReference;
import com.google.common.collect.Sets;
import com.jiahui.im.config.properties.HisProperties;
import com.jiahui.im.helper.RestHelper;
import com.jiahui.im.modules.common.dto.his.HisReqDto;
import com.jiahui.im.modules.common.dto.his.HisRespDto;
import com.jiahui.im.modules.common.dto.his.dict.DictRespDto;
import com.jiahui.im.modules.common.dto.his.patient.PatientReqDto;
import com.jiahui.im.modules.common.dto.his.patient.PatientRespDto;
import com.jiahui.im.modules.common.enums.HisDictNameEnum;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Set;

/**
 * @author Tommy
 * @date 2022/01/14
 */
@Log4j2
@Service
public class HisService {

    @Autowired
    private HisProperties hisProperties;

    /**
     * 字典列表
     * @param dictName
     * @return
     */
    public List<DictRespDto> dictList(String dictName) {
        HisReqDto<Object> hisReqDto = new HisReqDto<>(dictName);
        List<DictRespDto> respDtoList = RestHelper.doPostWithAuthForHis(hisProperties.getDictUrl(), hisReqDto,
                new TypeReference<HisRespDto<List<DictRespDto>>>() {});
        return ObjectUtil.defaultIfNull(respDtoList, Collections.emptyList());
    }

    /**
     * 查询就诊人信息
     * @param patientId
     * @return
     */
    public PatientRespDto patientInfo(String patientId) {
        HisReqDto<PatientReqDto> hisReqDto = new HisReqDto<>(HisDictNameEnum.PATIENT_INFO.getCode(), new PatientReqDto(Sets.newHashSet(patientId)));
        List<PatientRespDto> respDtoList = RestHelper.doPostWithAuthForHis(hisProperties.getPatientUrl(), hisReqDto,
                new TypeReference<HisRespDto<List<PatientRespDto>>>() {});
        return CollUtil.isEmpty(respDtoList) ? null : CollUtil.getFirst(respDtoList);
    }

    /**
     * 批量查询就诊人信息
     * @param patientId
     * @return
     */
    public List<PatientRespDto> batchPatientInfo(Set<String> patientId) {
        HisReqDto<PatientReqDto> hisReqDto = new HisReqDto<>(HisDictNameEnum.PATIENT_INFO.getCode(), new PatientReqDto(patientId));
        List<PatientRespDto> respDtoList = RestHelper.doPostWithAuthForHis(hisProperties.getPatientUrl(), hisReqDto,
                new TypeReference<HisRespDto<List<PatientRespDto>>>() {});
        return ObjectUtil.defaultIfNull(respDtoList, Collections.emptyList());
    }
}
