package com.jiahui.im.modules.ws.dto.kafka.kefu;

import com.jiahui.im.modules.common.enums.CcKefuNoticeEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * CC客服-接待成功
 * @author Tommy
 * @date 2021/8/11
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CcKefuReceivedDto {

	/**
	 * 通知类型 {@link CcKefuNoticeEnum}
	 */
	private Integer noticeType;

    /**
     * 用户id
	 */
	private Long userId;

    /**
     * 用户名称
	 */
	private String userName;

	/**
	 * 用户头像
	 */
	private String headUrl;

	/**
	 * 用户国籍
	 */
	private String nationality;

	/**
	 * 聊天来源
	 */
	private String channel;

    /**
     * 客服id
	 */
	private Long kefuId;

    /**
     * 客服名称
	 */
	private String kefuName;

	/**
	 * 客服头像
	 */
	private String kefuHeadUrl;

    /**
     * 部门id
	 */
	private Long deptId;

	/**
	 * 用户最后一次发消息时间（毫秒级时间戳）
	 */
	private Long userLastSendTime;

	/**
	 * 用户最后一条消息文件名
	 */
	private String userLastFileName;

	/**
	 * 用户最后一条消息文件大小（byte）
	 */
	private Long userLastFileSize;

	/**
	 * 用户最后一条消息类型 1-文本 2-图片 3-语音 4-视频 5-word 6-PDF 7-文件
	 */
	private Integer userLastMsgType;

	/**
	 * 用户最后一条消息内容
	 */
	private String userLastContent;

	/**
	 * 用户最后一条消息OSS对象名称
	 */
	private String userLastObjectName;

	/**
	 * 用户最后一条消息渠道类型 1-APP 2-公众号 3-小程序 4-企业微信
	 */
	private Integer userLastChannelType;

	/**
	 * 今日接待人数
	 */
	private Integer todayReceptNum;

	/**
	 * 接待时间（毫秒级时间戳）
	 */
	private Long receptTime;
}
