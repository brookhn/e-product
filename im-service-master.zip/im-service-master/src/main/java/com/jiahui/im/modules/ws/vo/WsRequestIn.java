package com.jiahui.im.modules.ws.vo;

import lombok.Data;

/**
 * ws请求对象
 * @author Tommy
 * @date 2021/8/2
 */
@Data
public class WsRequestIn<T> {
    /**
     * 操作指令
     */
    private String action;

    /**
     * 参数信息
     */
    private T params;

    /**
     * 时间戳
     */
    private Long timestamp;
}
