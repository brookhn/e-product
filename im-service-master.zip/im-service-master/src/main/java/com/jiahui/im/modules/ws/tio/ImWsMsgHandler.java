package com.jiahui.im.modules.ws.tio;

import cn.hutool.core.lang.Assert;
import cn.hutool.core.thread.ThreadUtil;
import cn.hutool.core.util.StrUtil;
import com.jiahui.im.common.CodeMsg;
import com.jiahui.im.common.exception.BizException;
import com.jiahui.im.helper.JwtHelper;
import com.jiahui.im.helper.MyJwt;
import com.jiahui.im.modules.common.enums.KefuTypeEnum;
import com.jiahui.im.modules.ws.constant.ImConst;
import com.jiahui.im.modules.ws.handler.MsgHandlerFactory;
import com.jiahui.im.modules.ws.util.WsInputChecker;
import com.jiahui.im.modules.ws.util.WsUtil;
import com.jiahui.im.modules.ws.vo.WsRequestIn;
import com.jiahui.im.modules.ws.vo.WsResponseOut;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.tio.core.ChannelContext;
import org.tio.core.Tio;
import org.tio.http.common.HttpRequest;
import org.tio.http.common.HttpResponse;
import org.tio.websocket.common.Opcode;
import org.tio.websocket.common.WsPacket;
import org.tio.websocket.common.WsRequest;
import org.tio.websocket.common.WsResponse;
import org.tio.websocket.server.handler.IWsMsgHandler;

@Log4j2
@Component
public class ImWsMsgHandler implements IWsMsgHandler {

	@Autowired
	private DeptImWsMsgHandler deptImWsMsgHandler;

	@Autowired
	private CcImWsMsgHandler ccImWsMsgHandler;

	@Autowired
	private MsgHandlerFactory msgHandlerFactory;

	/**
	 * 握手时走这个方法，业务可以在这里获取cookie，request参数等
	 */
	@Override
	public HttpResponse handshake(HttpRequest httpRequest, HttpResponse httpResponse, ChannelContext channelContext) {
//		String clientip = httpRequest.getClientIp();
//		log.info("[{}]收到来自{}的ws握手包,channelContext:{}", Thread.currentThread().getName(), clientip, channelContext);
		return httpResponse;
	}

	/**
	 * 握手之后走这个方法
	 */
	@Override
	public void onAfterHandshaked(HttpRequest httpRequest, HttpResponse httpResponse, ChannelContext channelContext) {
//		log.info("[{}]onAfterHandshaked=============={}", Thread.currentThread().getName(), channelContext);
		try {
			// 获取入参
			String jwtToken = httpRequest.getString(ImConst.JWT_TOKEN);
			// 解析jwt
			MyJwt myJwt = JwtHelper.parseMyJwt(jwtToken);
			Assert.isTrue(myJwt.getStatus() == 0, () -> new BizException(CodeMsg.UNAUTHORIZED));
			// 绑定连接信息
			channelContext.set(ImConst.JWT_INFO, myJwt);
			if (KefuTypeEnum.DEPT.getType().equals(myJwt.getKefuType())) {
				deptImWsMsgHandler.onAfterHandshaked(httpRequest, httpResponse, channelContext);
				return;
			}
			ccImWsMsgHandler.onAfterHandshaked(httpRequest, httpResponse, channelContext);
		} catch (Exception e) {
			// 响应错误信息
			WsResponseOut wsResponseOut = WsResponseOut.error(CodeMsg.UNAUTHORIZED);
			if (e instanceof BizException) {
				wsResponseOut = WsResponseOut.error((BizException) e);
			}
			WsUtil.send(channelContext, wsResponseOut);
			// 关闭连接
			ThreadUtil.sleep(100L);
			Tio.remove(channelContext, CodeMsg.PARAMS_ERROR.getMsg());
		}
	}

	/**
	 * 字节消息（binaryType = arraybuffer）过来后会走这个方法
	 */
	@Override
	public Object onBytes(WsRequest wsRequest, byte[] bytes, ChannelContext channelContext) {
		return null;
	}

	/**
	 * 当客户端发close flag时，会走这个方法
	 */
	@Override
	public Object onClose(WsRequest wsRequest, byte[] bytes, ChannelContext channelContext) {
//		log.info("[{}]onClose=============={},userid:{}", Thread.currentThread().getName(), channelContext, channelContext.userid);
		Tio.remove(channelContext, "receive close flag");
		return null;
	}

	/*
	 * 字符消息（binaryType = blob）过来后会走这个方法
	 */
	@Override
	public Object onText(WsRequest wsRequest, String text, ChannelContext channelContext) {
//		log.info("[{}]onText=============={},text:{}", Thread.currentThread().getName(), channelContext, text);
		// 获取连接信息
		MyJwt myJwt = (MyJwt) channelContext.get(ImConst.JWT_INFO);
		try {
			// 校验jwt是否过期
			WsInputChecker.checker().checkJwtExp(myJwt.getExp());
			// 心跳检查
			if (StrUtil.isBlank(text) || WsInputChecker.checker().checkPong(text)) {
				return null;
			}
			if (WsInputChecker.checker().checkPing(text)) {
				Tio.send(channelContext, WsResponse.fromText(Opcode.PONG.name(), WsPacket.CHARSET_NAME));
				return null;
			}
			// 校验入参
			WsRequestIn wsRequestIn = WsInputChecker.checker()
					// 校验json格式
					.checkJson(text)
					// 反序列化
					.transform(text);
			WsInputChecker.checker()
					// 校验指令
					.checkAction(wsRequestIn);
			// 消息分发
			msgHandlerFactory.receive(channelContext, wsRequestIn);
		} catch (BizException e) {
			WsUtil.sendError(channelContext, e);
			return null;
		} catch (Exception e) {
			WsUtil.sendError(channelContext, CodeMsg.SYSTEM_EXCEPTION);
			return null;
		}
		// 返回值是要发送给客户端的内容，一般都是返回null
		return null;
	}
}
