package com.jiahui.im.modules.api.service;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateField;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.aliyun.oss.HttpMethod;
import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClientBuilder;
import com.aliyun.oss.common.utils.BinaryUtil;
import com.aliyun.oss.model.GeneratePresignedUrlRequest;
import com.aliyun.oss.model.MatchMode;
import com.aliyun.oss.model.PolicyConditions;
import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.auth.sts.AssumeRoleRequest;
import com.aliyuncs.auth.sts.AssumeRoleResponse;
import com.aliyuncs.exceptions.ClientException;
import com.aliyuncs.http.MethodType;
import com.aliyuncs.profile.DefaultProfile;
import com.aliyuncs.profile.IClientProfile;
import com.jiahui.im.common.CodeMsg;
import com.jiahui.im.common.exception.BizException;
import com.jiahui.im.constant.Constant;
import com.jiahui.im.modules.api.vo.oss.DirectIn;
import com.jiahui.im.modules.api.vo.oss.DirectOut;
import com.jiahui.im.modules.api.vo.oss.GetPresignedUrlIn;
import com.jiahui.im.modules.api.vo.oss.STSTokenOut;
import com.jiahui.im.modules.common.enums.MsgTypeEnum;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Service;

import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@RefreshScope
@Log4j2
@Service
public class OssService {

	@Value("${oss.bucket-name}")
	private String bucketName;
	
	@Value("${oss.area}")
	private String area;
	
	@Value("${oss.access-key-id}")
	private String accessKeyId;
	
	@Value("${oss.access-key-secret}")
	private String accessKeySecret;
	
	@Value("${oss.endpoint}")
	private String endpoint;
	
	@Value("${oss.sts-endpoint}")
	private String stsEndpoint;
	
	@Value("${oss.sts-role-arn}")
	private String stsRoleArn;
	
	@Value("${oss.sts-duration-seconds}")
	private Long stsDurationSeconds;

	/**
	 * OSS私有bucket文件链接有效期（秒）
	 */
	@Value("${oss.presigned-url-timeout}")
	private Integer presignedUrlTimeout;
	
	/**
	 * oss 上传文件获取sts访问参数
	 * @return
	 */
	public STSTokenOut getStsToken() {
		try {
			String roleSessionName = "im-oss-sts";
			// 构造default profile
			IClientProfile profile = DefaultProfile.getProfile(area, accessKeyId, accessKeySecret);
			// 用profile构造client
			DefaultAcsClient client = new DefaultAcsClient(profile);
			final AssumeRoleRequest request = new AssumeRoleRequest();
			request.setSysEndpoint(stsEndpoint);
			request.setSysMethod(MethodType.POST);
			request.setRoleArn(stsRoleArn);
			request.setDurationSeconds(stsDurationSeconds);
			request.setRoleSessionName(roleSessionName);
			final AssumeRoleResponse response = client.getAcsResponse(request);
			if (Objects.isNull(response) || Objects.isNull(response.getCredentials())) {
				log.error("getStsToken response:{}", response);
				throw new BizException(CodeMsg.GET_STS_TOKEN_EXCEPTION);
			}
			STSTokenOut out = new STSTokenOut();
			out.setAccessKeyId(response.getCredentials().getAccessKeyId());
			out.setAccessKeySecret(response.getCredentials().getAccessKeySecret());
			out.setSecurityToken(response.getCredentials().getSecurityToken());
			out.setExpiration(response.getCredentials().getExpiration());
			out.setEndPoint(endpoint);
			out.setBucketName(bucketName);
			return out;
		} catch (ClientException e) {
			log.error("getStsToken异常::Errorcode:{},ErrorMessage:{},RequestId:{}", e.getErrCode(), e.getErrMsg(), e.getRequestId());
			throw new BizException(CodeMsg.GET_STS_TOKEN_EXCEPTION);
		} catch (Exception e) {
			log.error("getStsToken异常", e);
			throw new BizException(CodeMsg.GET_STS_TOKEN_EXCEPTION);
		}
	}

	/**
	 * 获取Oss直传参数
	 * @param directIn
	 * @return
	 */
	public DirectOut direct(DirectIn directIn) {
		DirectOut out = new DirectOut();
		PolicyConditions policyConds = new PolicyConditions();
		policyConds.addConditionItem(PolicyConditions.COND_CONTENT_LENGTH_RANGE, 0, 100*1024*1024);
		policyConds.addConditionItem(MatchMode.StartWith, PolicyConditions.COND_KEY, directIn.getDir());
		OSS ossClient = new OSSClientBuilder().build(endpoint, accessKeyId, accessKeySecret);
		final DateTime expiresDateTime = DateUtil.offsetSecond(new Date(), presignedUrlTimeout);
		String postPolicy = ossClient.generatePostPolicy(expiresDateTime, policyConds);
		byte[] binaryData = StrUtil.bytes(postPolicy, StandardCharsets.UTF_8);
		String encodedPolicy = BinaryUtil.toBase64String(binaryData);
		String postSignature = ossClient.calculatePostSignature(postPolicy);
		out.setAccessKeyId(accessKeyId);
		out.setEncodedPolicy(encodedPolicy);
		out.setPostSignature(postSignature);
		out.setBucketName(bucketName);
		out.setEndPoint(endpoint);
		out.setExpiresTime(expiresDateTime.getTime());
		return out;
	}

	/**
	 * 批量获取OSS私有bucket文件链接Map
	 * @param ossObjects 文件名集合
	 * @return Map key:文件名 value:URL
	 */
	public Map<String, URL> ossPresignedUrlMap(List<GetPresignedUrlIn> ossObjects) {
		if (CollUtil.isEmpty(ossObjects)) {
			return Collections.emptyMap();
		}
		Map<String,URL> urlMap = new HashMap<>();
		OSS ossClient = new OSSClientBuilder().build("https://"+endpoint, accessKeyId, accessKeySecret);
		DateTime expTime = DateTime.now().offset(DateField.SECOND, presignedUrlTimeout);
		for (GetPresignedUrlIn ossObject : ossObjects) {
			GeneratePresignedUrlRequest req = new GeneratePresignedUrlRequest(bucketName, ossObject.getObjectName(), HttpMethod.GET);
			req.setExpiration(expTime);
			req.setProcess(MsgTypeEnum.VIDEO.getType().equals(ossObject.getMsgType()) ? Constant.OSS_VIDEO_STYLE : null);
			URL url = ossClient.generatePresignedUrl(req);
			urlMap.put(ossObject.getObjectName(), url);
		}
		// 关闭OSSClient
		ossClient.shutdown();
		return urlMap;
	}

	/**
	 * 获取OSS私有bucket文件链接
	 * @param objectName
	 * @param msgType
	 * @return URL
	 */
	public URL ossPresignedUrl(String objectName,Integer msgType) {
		OSS ossClient = new OSSClientBuilder().build("https://"+endpoint, accessKeyId, accessKeySecret);
		DateTime expTime = DateTime.now().offset(DateField.SECOND, presignedUrlTimeout);
		GeneratePresignedUrlRequest req = new GeneratePresignedUrlRequest(bucketName, objectName, HttpMethod.GET);
		req.setExpiration(expTime);
		req.setProcess(MsgTypeEnum.VIDEO.getType().equals(msgType) ? Constant.OSS_VIDEO_STYLE : null);
		URL url = ossClient.generatePresignedUrl(req);
		// 关闭OSSClient
		ossClient.shutdown();
		return url;
	}
}
