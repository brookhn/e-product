package com.jiahui.im.modules.ws.dto.kafka.notice;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 排名变更
 * @author Tommy
 * @date 2022/3/24
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RankingDto {

	/**
	 * 通知类型 {@link com.jiahui.im.modules.common.enums.UserNoticeEnum}
	 */
	private Integer noticeType;

	/**
	 * 用户id
	 */
	private Long userId;

	/**
	 * 排名
	 */
	private Integer ranking;
}
