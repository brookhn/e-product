package com.jiahui.im.filter;

import cn.hutool.core.util.StrUtil;
import com.google.common.collect.Lists;
import com.jiahui.framework.web.invoke.log.constants.LogConst;
import com.jiahui.im.constant.GlobalVar;
import com.jiahui.im.context.UserThreadContext;
import com.jiahui.im.helper.JwtHelper;
import com.jiahui.im.helper.MyJwt;
import org.slf4j.MDC;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Objects;
import java.util.Optional;

/**
 * 日志过滤器
 * - Log4j2Filter优先级要在WebTraceFilter之前
 * - WebTraceFilter默认order为-1
 * - Log4j2Filter可定制一些日志字段以适配WebTraceFilter
 * @author Tommy
 * @date 2022/6/29
 */
public class Log4j2Filter extends OncePerRequestFilter {

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
		try {
			// 包装请求（扩展请求头）
			HeaderMapRequestWrapper requestWrapper = new HeaderMapRequestWrapper(request);
			// 传递请求信息
			transmitRequest(requestWrapper);
			filterChain.doFilter(requestWrapper, response);
		} finally {
			MDC.clear();
		}
	}

	/**
     * 传递请求信息
	 * @param requestWrapper
	 */
	private void transmitRequest(HeaderMapRequestWrapper requestWrapper) {
		// 获取jwt并解析
		String jwtToken = UserThreadContext.getUserVisitor().getJwtToken();
		MyJwt myJwt = StrUtil.isNotBlank(jwtToken) ? JwtHelper.parseMyJwt(jwtToken) : null;
		// 设置上下文
		UserThreadContext.getUserVisitor().setMyJwt(myJwt);
		// 定义需要处理的字段
		ArrayList<String> fieldList = Lists.newArrayList(LogConst.SRC, LogConst.USERID);
		fieldList.forEach(fieldName -> {
			// 获取字段值
			String fieldValue = requestWrapper.getHeader(fieldName);
			if (StrUtil.isBlank(fieldValue)) {
				Object attributeValue = requestWrapper.getAttribute(fieldName);
				fieldValue = Optional.ofNullable(attributeValue).map(e -> e.toString()).orElse("");
			}
			// 填充字段值
			if (StrUtil.isBlank(fieldValue)) {
				// 服务名
				if (LogConst.SRC.equals(fieldName)) {
					fieldValue = GlobalVar.SV_NAME;
				}
				// 用户id（这里使用账号id）
				if (LogConst.USERID.equals(fieldName)) {
					fieldValue = Optional.ofNullable(myJwt)
							.filter(e -> e.getStatus() == 0 && Objects.nonNull(e.getAccountId()))
							.map(e -> e.getAccountId().toString())
							.orElse("");
				}
			}
			// 向下传递
			requestWrapper.addHeader(fieldName, fieldValue);
			requestWrapper.setAttribute(fieldName, fieldValue);
			MDC.put(fieldName, fieldValue);
		});
	}
}
