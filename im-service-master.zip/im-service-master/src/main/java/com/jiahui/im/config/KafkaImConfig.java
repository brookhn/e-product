package com.jiahui.im.config;

import cn.hutool.core.net.NetUtil;
import com.jiahui.im.config.properties.KafkaImProperties;
import com.jiahui.im.config.properties.SysProperties;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.config.KafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.listener.ConcurrentMessageListenerContainer;
import org.springframework.kafka.listener.ContainerProperties;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Tommy
 * @date 2021/7/16
 */
@Configuration
@EnableKafka
public class KafkaImConfig {

    @Autowired
    private KafkaImProperties kafkaImProperties;

    /**********************************生产者配置**********************************/
    private Map<String, Object> producerImConfigs() {
        Map<String, Object> props = new HashMap<>();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaImProperties.getBootstrapServers());
        props.put(ProducerConfig.CLIENT_ID_CONFIG, kafkaImProperties.getClientId());
        props.put(ProducerConfig.RETRIES_CONFIG, kafkaImProperties.getProducer().getRetries());
        props.put(ProducerConfig.BATCH_SIZE_CONFIG, kafkaImProperties.getProducer().getBatchSize());
        props.put(ProducerConfig.LINGER_MS_CONFIG, kafkaImProperties.getProducer().getLingerMs());
        props.put(ProducerConfig.BUFFER_MEMORY_CONFIG, kafkaImProperties.getProducer().getBufferMemory());
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        return props;
    }

    @Bean
    public ProducerFactory<String, String> producerImFactory() {
        return new DefaultKafkaProducerFactory<>(producerImConfigs());
    }

    @Bean
    public KafkaTemplate<String, String> kafkaImTemplate(ProducerFactory producerImFactory) {
        KafkaTemplate template = new KafkaTemplate<>(producerImFactory);
        return template;
    }
    /**********************************生产者配置**********************************/


    /**********************************消费者配置**********************************/
    public Map<String, Object> consumerImConfigs() {
        Map<String, Object> props = new HashMap<>();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaImProperties.getBootstrapServers());
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, kafkaImProperties.getConsumer().getEnableAutoCommit());
        props.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, kafkaImProperties.getConsumer().getMaxPollRecords());
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, kafkaImProperties.getConsumer().getAutoOffsetReset());
        props.put(ConsumerConfig.HEARTBEAT_INTERVAL_MS_CONFIG, kafkaImProperties.getConsumer().getHeartBeatInterval());
        props.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, kafkaImProperties.getConsumer().getSessionTimeout());
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        // 动态消费组
        props.put(ConsumerConfig.GROUP_ID_CONFIG, SysProperties.applicationProfile + "-" + NetUtil.getLocalhostStr());
        return props;
    }

    @Bean
    public ConsumerFactory<Integer, String> consumerImFactory() {
        return new DefaultKafkaConsumerFactory<>(consumerImConfigs());
    }

    @Bean
    KafkaListenerContainerFactory<ConcurrentMessageListenerContainer<Integer, String>> imListenerContainerFactory(ConsumerFactory consumerImFactory) {
        ConcurrentKafkaListenerContainerFactory<Integer, String> factory = new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(consumerImFactory);
        factory.setConcurrency(kafkaImProperties.getConsumer().getConcurrency());
        factory.setBatchListener(true);
        factory.getContainerProperties().setAckMode(ContainerProperties.AckMode.MANUAL);
        return factory;
    }
    /**********************************消费者配置**********************************/
}
