package com.jiahui.im.modules.common.enums;

import com.google.common.collect.Maps;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Map;

/**
 * 消息类型
 * @author Tommy
 * @date 2021/6/8
 */
@Getter
@AllArgsConstructor
public enum MsgTypeEnum {

    TEXT(1, "文本", false, "[文本]"),
    IMAGE(2, "图片", true, "[图片]"),
    VOICE(3, "语音", true, "[语音]"),
    VIDEO(4, "视频", true, "[视频]"),
    WORD(5, "word", true, "[文件]"),
    PDF(6, "PDF", true, "[文件]"),
    FILE(7, "文件", true, "[文件]"),
    ;

    /**
     * 类型
     */
    private final Integer type;

    /**
     * 描述
     */
    private final String desc;

    /**
     * 是否oss资源
     */
    private final boolean isOssResource;

    /**
     * 默认文本
     */
    private final String defaultText;

    public static final Map<Integer, MsgTypeEnum> map = Maps.newHashMap();

    static {
        for (MsgTypeEnum e : MsgTypeEnum.values()) {
            map.put(e.getType(), e);
        }
    }

    public static MsgTypeEnum fromType(Integer type) {
        return map.get(type);
    }

    /**
     * 获取消息展示内容
     * @param type 消息类型
     * @param content 消息内容
     * @return
     */
    public static String getShowContent(Integer type, String content) {
        switch (type) {
            case 0:
                // 无消息
                return "";
            case 1:
                // 文本类型消息
                return content;
            default:
                // 非文本类型消息
                return map.get(type).getDefaultText();
        }
    }
}
