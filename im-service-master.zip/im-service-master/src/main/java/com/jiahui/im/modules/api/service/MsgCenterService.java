package com.jiahui.im.modules.api.service;

import cn.hutool.core.collection.CollUtil;
import com.google.common.collect.Lists;
import com.jiahui.im.modules.api.vo.msgcenter.LastMsgListIn;
import com.jiahui.im.modules.api.vo.msgcenter.LastMsgListOut;
import com.jiahui.im.modules.api.vo.msgcenter.MarkAllReadIn;
import com.jiahui.im.modules.common.entity.CcUserExtEntity;
import com.jiahui.im.modules.common.entity.UserExtEntity;
import com.jiahui.im.modules.common.mapper.CcUserExtMapper;
import com.jiahui.im.modules.common.mapper.UserExtMapper;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @author Tommy
 * @date 2021/08/12
 */
@Log4j2
@Service
public class MsgCenterService {

    @Autowired
    private CcUserExtMapper ccUserExtMapper;

    @Autowired
    private UserExtMapper userExtMapper;

    /**
     * 客服最新消息集合（含未读消息数）
     * @param lastMsgListIn
     */
    public LastMsgListOut lastMsgList(LastMsgListIn lastMsgListIn) {
        List<LastMsgListOut.Record> recordList = Lists.newArrayList();
        // 查询CC客服最新消息
        CcUserExtEntity ccUserExt = ccUserExtMapper.selectByAccountId(lastMsgListIn.getAccountId());
        LastMsgListOut.Record ccMsgRecord = Optional.ofNullable(ccUserExt).map(e -> new LastMsgListOut.Record(e)).orElse(new LastMsgListOut.Record(2));
        recordList.add(ccMsgRecord);

        // 查询科室客服最新消息
        if (CollUtil.isNotEmpty(lastMsgListIn.getDeptIdList())) {
            List<UserExtEntity> deptUserExtList = userExtMapper.selectByAccountId(lastMsgListIn.getAccountId(), lastMsgListIn.getDeptIdList());
            Map<Long, LastMsgListOut.Record> deptMsgRecordMap = deptUserExtList.stream()
                    .map(e -> new LastMsgListOut.Record(e))
                    .collect(Collectors.toMap(LastMsgListOut.Record::getDeptId, e -> e, (e1, e2) -> e1));
            // 请求几个科室就会返回几个科室数据
            lastMsgListIn.getDeptIdList().forEach(deptId -> {
                LastMsgListOut.Record deptMsgRecord = deptMsgRecordMap.getOrDefault(deptId, new LastMsgListOut.Record(1, deptId));
                recordList.add(deptMsgRecord);
            });
        }

        // 排序【按最近一条消息倒序】
        recordList.sort(Comparator.comparing(LastMsgListOut.Record::getKefuLastSendTime).reversed());

        // 计算未读消息总数
        int userUnreadTotalNum = recordList.stream().mapToInt(LastMsgListOut.Record::getUserUnreadNum).sum();
        return new LastMsgListOut(recordList, userUnreadTotalNum);
    }

    /**
     * 标记全部消息为已读
     * - 含CC客服和科室客服
     * @param markAllReadIn
     */
    public void markAllReadIn(MarkAllReadIn markAllReadIn) {
        // 标记CC客服已读
        ccUserExtMapper.markUserReadByAccountId(markAllReadIn.getAccountId());

        // 标记科室客服已读
        if (CollUtil.isNotEmpty(markAllReadIn.getDeptIdList())) {
            userExtMapper.markUserReadByAccountIdAndDeptIdList(markAllReadIn.getAccountId(), markAllReadIn.getDeptIdList());
        }
    }
}
