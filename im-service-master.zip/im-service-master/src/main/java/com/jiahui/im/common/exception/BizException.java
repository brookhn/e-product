package com.jiahui.im.common.exception;

import com.jiahui.im.common.CodeMsg;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.HashMap;

/**
 * @author SQL
 * 业务异常定义
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class BizException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    /**
     * 异常码
     */
    private Integer code;

    /**
     * 异常描述
     */
    private String msg;

    /**
     * 异常数据
     */
    private Object data;

    public BizException(Integer code, String msg, Object data) {
        this.setCode(code);
        this.setMsg(msg);
        this.setData(data);
    }

    public BizException(Integer code, String msg) {
        this.setCode(code);
        this.setMsg(msg);
        this.setData(new HashMap<>(1));
    }

    public BizException() {
        this.setCode(CodeMsg.EXCEPTION.code());
        this.setMsg(CodeMsg.EXCEPTION.msg());
    }

    public BizException(CodeMsg codeMsg) {
        this.setCode(codeMsg.code());
        this.setMsg(codeMsg.msg());
    }

    public BizException(CodeMsg codeMsg, Object data) {
        this.setCode(codeMsg.code());
        this.setMsg(codeMsg.msg());
        this.setData(data);
    }
}
