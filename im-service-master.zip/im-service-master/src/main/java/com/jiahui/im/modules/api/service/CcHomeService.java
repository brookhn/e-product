package com.jiahui.im.modules.api.service;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.lang.Assert;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.jiahui.im.common.CodeMsg;
import com.jiahui.im.common.PageOut;
import com.jiahui.im.common.exception.BizException;
import com.jiahui.im.constant.KafkaConstant;
import com.jiahui.im.context.UserThreadContext;
import com.jiahui.im.helper.MyJwt;
import com.jiahui.im.modules.api.vo.home.ChatRecordListIn;
import com.jiahui.im.modules.api.vo.home.ChatRecordListOut;
import com.jiahui.im.modules.api.vo.home.CheckRequestIdIn;
import com.jiahui.im.modules.api.vo.home.CheckRequestIdOut;
import com.jiahui.im.modules.api.vo.home.EvaluateIn;
import com.jiahui.im.modules.api.vo.home.NewestChatRecordListIn;
import com.jiahui.im.modules.api.vo.home.NewestChatRecordListOut;
import com.jiahui.im.modules.api.vo.home.RankInfoOut;
import com.jiahui.im.modules.api.vo.oss.GetPresignedUrlIn;
import com.jiahui.im.modules.common.entity.CcUserDialogEntity;
import com.jiahui.im.modules.common.entity.CcUserEvaluateEntity;
import com.jiahui.im.modules.common.entity.CcUserUnboundEntity;
import com.jiahui.im.modules.common.enums.CcKefuNoticeEnum;
import com.jiahui.im.modules.common.enums.DialogEndTypeEnum;
import com.jiahui.im.modules.common.enums.MsgTypeEnum;
import com.jiahui.im.modules.common.enums.UserNoticeEnum;
import com.jiahui.im.modules.common.mapper.CcUserDialogMapper;
import com.jiahui.im.modules.common.mapper.CcUserEvaluateMapper;
import com.jiahui.im.modules.common.mapper.CcUserUnboundMapper;
import com.jiahui.im.modules.common.mongo.CcChatRecord;
import com.jiahui.im.modules.common.mongo.CcChatRecordDao;
import com.jiahui.im.modules.ws.dto.kafka.kefu.CcRankNumDto;
import com.jiahui.im.modules.ws.dto.kafka.notice.NoticeDto;
import com.jiahui.im.modules.ws.dto.kafka.notice.RankingDto;
import com.jiahui.im.modules.ws.dto.kafka.notice.UserEndRankDto;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.net.URL;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * CC客服-主页
 * @author Tommy
 * @date 2021/08/12
 */
@Log4j2
@Service
public class CcHomeService {

    @Autowired
    private KafkaTemplate<String, String> kafkaImTemplate;

    @Autowired
    private CcChatRecordDao ccChatRecordDao;

    @Autowired
    private OssService ossService;

    @Autowired
    private CcUserDialogMapper ccUserDialogMapper;

    @Autowired
    private CcUserEvaluateMapper ccUserEvaluateMapper;

    @Autowired
    private CcUserUnboundMapper ccUserUnboundMapper;

    /**
     * 聊天记录列表
     * @param chatRecordListIn
     * @return
     */
    public ChatRecordListOut chatRecordList(ChatRecordListIn chatRecordListIn) {
        MyJwt myJwt = UserThreadContext.getUserVisitor().getMyJwt();
        // 查询数据库
        PageOut<CcChatRecord> pageOut = ccChatRecordDao.pageByUserId(myJwt.getUserId(), chatRecordListIn.getRecordId(), chatRecordListIn.getPageSize());
        List<CcChatRecord> ccChatRecordList = pageOut.getRows();
        if (CollUtil.isEmpty(ccChatRecordList)) {
            return new ChatRecordListOut();
        }
        // 获取OSS私有bucket文件链接
        List<GetPresignedUrlIn> objectList = ccChatRecordList.stream()
                .filter(e -> Optional.ofNullable(MsgTypeEnum.fromType(e.getMsgType())).map(MsgTypeEnum::isOssResource).orElse(false))
                .map(o -> new GetPresignedUrlIn(o.getContent(), o.getMsgType())).collect(Collectors.toList());
        Map<String, URL> ossURLMap = ossService.ossPresignedUrlMap(objectList);
        // 排序反转
        CollUtil.reverse(ccChatRecordList);
        // 查询已结束未评价的会话（60分钟内已结束未评价的会话）
        Set<String> conversationIdSet = ccChatRecordList.stream().map(CcChatRecord::getConversationId).collect(Collectors.toSet());
        List<CcUserDialogEntity> dialogEntityList = ccUserDialogMapper.selectNoEvaluate(conversationIdSet);
        Set<String> endMsgIdSet = dialogEntityList.stream().map(CcUserDialogEntity::getEndMsgId).collect(Collectors.toSet());
        // 组装数据
        List<ChatRecordListOut.Record> recordList = ccChatRecordList.stream().map(e -> new ChatRecordListOut.Record(e, myJwt.getHeadUrl(), ossURLMap, endMsgIdSet)).collect(Collectors.toList());
        return new ChatRecordListOut(recordList, pageOut.getTotalCount());
    }

    /**
     * 最新聊天记录列表
     * @param newestChatRecordListIn
     * @return
     */
    public NewestChatRecordListOut newestChatRecordList(NewestChatRecordListIn newestChatRecordListIn) {
        MyJwt myJwt = UserThreadContext.getUserVisitor().getMyJwt();
        // 查询数据库
        List<CcChatRecord> ccChatRecordList = ccChatRecordDao.newestByUserId(myJwt.getUserId(), newestChatRecordListIn.getRecordId());
        if (CollUtil.isEmpty(ccChatRecordList)) {
            return new NewestChatRecordListOut();
        }
        // 获取OSS私有bucket文件链接
        List<GetPresignedUrlIn> objectList = ccChatRecordList.stream()
                .filter(e -> Optional.ofNullable(MsgTypeEnum.fromType(e.getMsgType())).map(MsgTypeEnum::isOssResource).orElse(false))
                .map(o -> new GetPresignedUrlIn(o.getContent(), o.getMsgType())).collect(Collectors.toList());
        Map<String, URL> ossURLMap = ossService.ossPresignedUrlMap(objectList);
        // 查询已结束未评价的会话（60分钟内已结束未评价的会话）
        Set<String> conversationIdSet = ccChatRecordList.stream().map(CcChatRecord::getConversationId).collect(Collectors.toSet());
        List<CcUserDialogEntity> dialogEntityList = ccUserDialogMapper.selectNoEvaluate(conversationIdSet);
        Set<String> endMsgIdSet = dialogEntityList.stream().map(CcUserDialogEntity::getEndMsgId).collect(Collectors.toSet());
        // 组装数据
        List<NewestChatRecordListOut.Record> recordList = ccChatRecordList.stream().map(e -> new NewestChatRecordListOut.Record(e, myJwt.getHeadUrl(), ossURLMap, endMsgIdSet)).collect(Collectors.toList());
        return new NewestChatRecordListOut(recordList, recordList.size());
    }

    /**
     * 排队信息
     */
    public RankInfoOut rankInfo() {
        MyJwt myJwt = UserThreadContext.getUserVisitor().getMyJwt();
        // 获取用户排名
        int ranking = ccUserUnboundMapper.getRanking(myJwt.getUserId());
        return new RankInfoOut(ranking);
    }

    /**
     * 检查消息是否发送成功
     * @param checkRequestIdIn
     * @return
     */
    public CheckRequestIdOut checkRequestId(CheckRequestIdIn checkRequestIdIn) {
        CheckRequestIdOut checkRequestIdOut = new CheckRequestIdOut(checkRequestIdIn.getRequestId());
        MyJwt myJwt = UserThreadContext.getUserVisitor().getMyJwt();
        // 查询消息
        CcChatRecord ccChatRecord = ccChatRecordDao.queryByRequestId(myJwt.getUserId(), checkRequestIdIn.getRequestId());
        if (Objects.isNull(ccChatRecord)) {
            return checkRequestIdOut;
        }
        checkRequestIdOut.setRecordId(ccChatRecord.getId());
        return checkRequestIdOut;
    }

    /**
     * 评价
     * @param evaluateIn
     * @return
     */
    public void evaluate(EvaluateIn evaluateIn) {
        // 校验会话
        CcUserDialogEntity dialogEntity = ccUserDialogMapper.selectByUk(evaluateIn.getConversationId());
        Assert.notNull(dialogEntity, () -> new BizException(CodeMsg.CODE_400003700));
        Assert.isTrue(!dialogEntity.getEndType().equals(0L), () -> new BizException(CodeMsg.CODE_400003701));
        Assert.isTrue(dialogEntity.getEvaluateId().equals(0L), () -> new BizException(CodeMsg.CODE_400003702));
        // 新增评价
        CcUserEvaluateEntity tempEvaluateEntity = CcUserEvaluateEntity.builder()
                .conversationId(evaluateIn.getConversationId())
                .userId(dialogEntity.getUserId())
                .score(evaluateIn.getScore())
                .build();
        try {
            ccUserEvaluateMapper.insertSelective(tempEvaluateEntity);
        } catch (DuplicateKeyException e) {
            throw new BizException(CodeMsg.CODE_400003702);
        }
        ccUserDialogMapper.updateEvaluateId(evaluateIn.getConversationId(), tempEvaluateEntity.getId());
    }

    /**
     * 结束排队
     */
    @Transactional(value = "kefuImTransactionManager", rollbackFor = Exception.class)
    public void endRank() {
        MyJwt myJwt = UserThreadContext.getUserVisitor().getMyJwt();
        CcUserUnboundEntity unboundEntity = ccUserUnboundMapper.selectByUk(myJwt.getUserId());
        Assert.notNull(unboundEntity, () -> new BizException(CodeMsg.CODE_400003800));
        // 删除排队数据
        int count = ccUserUnboundMapper.deleteByUk(myJwt.getUserId());
        Assert.isTrue(count > 0, () -> new BizException(CodeMsg.CODE_400003800));
        // 查询会话结束对应的MongoDB主键
        CcChatRecord ccChatRecord = ccChatRecordDao.conversationLastRecord(unboundEntity.getConversationId());
        String endMsgId = Optional.ofNullable(ccChatRecord).map(CcChatRecord::getId).orElse(StrUtil.EMPTY);
        // 更新会话表
        CcUserDialogEntity tempDialogEntity = CcUserDialogEntity.builder()
                .conversationId(unboundEntity.getConversationId())
                .endType(DialogEndTypeEnum.USER_END_QUEUE.getType())
                .endTime(DateUtil.date())
                .endMsgId(endMsgId)
                .build();
        ccUserDialogMapper.updateByUk(tempDialogEntity);

        // 排在后面的用户排名受影响，排在前面的用户排名不受影响
        List<CcUserUnboundEntity> rankList = ccUserUnboundMapper.selectRankByLowerId(unboundEntity.getId());
        rankList.forEach(e -> {
            // 发送kafka，通知用户【排名变更】
            RankingDto userRankingDto = new RankingDto(UserNoticeEnum.RANKING.getType(), e.getUserId(), e.getRanking());
            NoticeDto<RankingDto> noticeDto = new NoticeDto<>(userRankingDto.getNoticeType(), userRankingDto);
            kafkaImTemplate.send(KafkaConstant.TOPIC_CC_IM_USER_NOTICE_MSG, JSON.toJSONString(noticeDto));
        });
        /* ----------------发送kafka，通知用户【用户结束排队】---------------- */
        UserEndRankDto userEndRankDto1 = new UserEndRankDto(UserNoticeEnum.USER_END_RANK.getType(), myJwt.getUserId());
        NoticeDto<UserEndRankDto> userNoticeDto1 = new NoticeDto<>(userEndRankDto1.getNoticeType(), userEndRankDto1);
        kafkaImTemplate.send(KafkaConstant.TOPIC_CC_IM_USER_NOTICE_MSG, JSON.toJSONString(userNoticeDto1));
        /* ----------------发送kafka，通知客服【用户结束排队】---------------- */
        UserEndRankDto userEndRankDto2 = new UserEndRankDto(CcKefuNoticeEnum.USER_END_RANK.getType(), myJwt.getUserId());
        NoticeDto<UserEndRankDto> userNoticeDto2 = new NoticeDto<>(userEndRankDto2.getNoticeType(), userEndRankDto2);
        kafkaImTemplate.send(KafkaConstant.TOPIC_CC_IM_KEFU_NOTICE_MSG, JSON.toJSONString(userNoticeDto2));
        /* ----------------发送kafka，通知客服【排队人数变更】---------------- */
        int rankNum = ccUserUnboundMapper.count();
        CcRankNumDto ccRankNumDto = new CcRankNumDto(CcKefuNoticeEnum.RANK_NUM.getType(), rankNum);
        NoticeDto<CcRankNumDto> rankNumNoticeDto = new NoticeDto<>(ccRankNumDto.getNoticeType(), ccRankNumDto);
        kafkaImTemplate.send(KafkaConstant.TOPIC_CC_IM_KEFU_NOTICE_MSG, JSON.toJSONString(rankNumNoticeDto));
    }
}
