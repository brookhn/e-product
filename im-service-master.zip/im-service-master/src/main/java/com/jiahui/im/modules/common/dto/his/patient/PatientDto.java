package com.jiahui.im.modules.common.dto.his.patient;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PatientDto {

    /**
     * 姓名
     */
    private String name;

    /**
     * 性别（M男 F女）
     */
    private String gender;

    /**
     * 生日
     */
    private Date birthDate;

    /**
     * 国籍
     */
    private String nationality;
	
    /**
     * 国籍编码
     */
    private String nationalityCode;

    /**
     * 语言
     */
    private String language;
	
	 /**
     * 语言code
     */
    private String languageCode;

    /**
     * 手机号
     */
    private String mobile;

    /**
     * MRN
     */
    private String mrn;

    /**
     * 证件类型编码：IDCARD 身份证 PASSPORT 护照 TAIWANPT 台胞证 MAINLAND 港澳居民来往内地通行证 BIRTH 出生证 ORTHERS 其他
     */
    private String certificatesType;

    /**
     * 证件号码
     */
    private String certificatesNum;

    /**
     * 邮箱
     */
    private String email;

    /**
     * 家庭住址
     */
    private String homeAddress;

    /**
     * 关系：1 本人 2 子女 3 配偶 4 其他 5 父母
     */
    private Integer relations;
	
	/**
     * 关系：1 本人 2 子女 3 配偶 4 其他 5 父母
     */
    private String relationName;
}
