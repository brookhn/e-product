package com.jiahui.im.modules.api.vo.home;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

/**
 * @author Tommy
 * @date 2021/8/10
 */
@ApiModel
@Data
public class EvaluateIn {
    @ApiModelProperty(value = "会话id")
    @NotEmpty
    private String conversationId;

    @ApiModelProperty(value = "评价分数 1-满意 2-一般 3-不满意")
    @NotNull
    @Range(min = 1, max = 3)
    private Integer score;
}

