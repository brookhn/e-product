package com.jiahui.im.modules.common.dto.his.patient;

import lombok.Data;

@Data
public class QueryBillDetailReqDto {
	
	private String episodeType = "OP";
	
	private String patientId;
	
	private String startTime;
	
	private String endTime;
	
}
