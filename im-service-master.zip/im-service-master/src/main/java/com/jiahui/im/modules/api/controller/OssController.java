package com.jiahui.im.modules.api.controller;

import com.jiahui.im.common.JsonOut;
import com.jiahui.im.modules.api.service.OssService;
import com.jiahui.im.modules.api.vo.oss.DirectIn;
import com.jiahui.im.modules.api.vo.oss.DirectOut;
import com.jiahui.im.modules.api.vo.oss.OssPresignedUrlIn;
import com.jiahui.im.modules.api.vo.oss.STSTokenOut;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/oss")
@Api(tags = "oss相关接口")
public class OssController {
	@Autowired
    private OssService ossService;
	
	@PostMapping(value="/getStsToken")
	@ApiOperation(value = "获取StsToken")
    public JsonOut<STSTokenOut> getStsToken() {
		return JsonOut.ok(ossService.getStsToken());
    }
	
	@PostMapping(value="/ossPresignedUrl")
	@ApiOperation(value = "获取Oss私有bucket文件链接")
    public JsonOut<String> ossPresignedUrl(@RequestBody @Validated OssPresignedUrlIn ossPresignedUrlIn) {
		return JsonOut.ok(ossService.ossPresignedUrl(ossPresignedUrlIn.getObjectName(), ossPresignedUrlIn.getMsgType()).toString());
    }

	@PostMapping(value="/direct")
	@ApiOperation(value = "获取Oss直传参数")
	public JsonOut<DirectOut> direct(@RequestBody @Validated DirectIn directIn) {
		return JsonOut.ok(ossService.direct(directIn));
	}
}
