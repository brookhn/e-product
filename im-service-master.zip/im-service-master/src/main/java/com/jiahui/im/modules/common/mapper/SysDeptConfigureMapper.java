package com.jiahui.im.modules.common.mapper;

import com.jiahui.im.modules.common.entity.SysDeptConfigureEntity;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SysDeptConfigureMapper {
    /**
     * 查询科室配置
     * @param deptId
     * @return
     */
    SysDeptConfigureEntity selectByDeptId(Long deptId);
}