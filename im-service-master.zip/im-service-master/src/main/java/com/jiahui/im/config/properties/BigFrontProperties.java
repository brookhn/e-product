package com.jiahui.im.config.properties;

import com.google.common.collect.Maps;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.Map;

/**
 * @author Tommy
 * @date 2021/6/10
 */
@Data
@Configuration
@ConfigurationProperties(prefix = "big-front")
public class BigFrontProperties {

    /**
     * 认证信息
     */
    private Map<String, String> authMap = Maps.newHashMap();

    /**
     * 加密KEY
     */
    private String encryptKey;

    /**
     * 加密偏移量
     */
    private String encryptIv;

    /**
     * 请求路径前缀
     */
    private String prefixUrl;
}
