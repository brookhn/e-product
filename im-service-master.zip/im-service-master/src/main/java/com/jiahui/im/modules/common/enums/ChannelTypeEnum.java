package com.jiahui.im.modules.common.enums;

import com.google.common.collect.Maps;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Map;

/**
 * 渠道类型
 * @author Tommy
 * @date 2021/6/8
 */
@Getter
@AllArgsConstructor
public enum ChannelTypeEnum {

    UNKNOWN(0, "未知"),
    APP(1, "APP"),
//    MP_WECHAT(2, "公众号"),
    MINI_APP(3, "小程序"),
//    WORK_WECHAT(4, "企业微信"),
    ;

    /**
     * 类型
     */
    private final Integer type;

    /**
     * 描述
     */
    private final String desc;

    public static final Map<Integer, ChannelTypeEnum> map = Maps.newHashMap();
    public static final Map<Integer, ChannelTypeEnum> validMap = Maps.newHashMap();

    static {
        for (ChannelTypeEnum e : ChannelTypeEnum.values()) {
            map.put(e.getType(), e);
        }
        validMap.putAll(map);
        validMap.remove(ChannelTypeEnum.UNKNOWN.getType());
    }

    public static ChannelTypeEnum fromType(Integer type) {
        return map.getOrDefault(type, UNKNOWN);
    }

    public static ChannelTypeEnum fromValidType(Integer type) {
        return validMap.get(type);
    }
}
