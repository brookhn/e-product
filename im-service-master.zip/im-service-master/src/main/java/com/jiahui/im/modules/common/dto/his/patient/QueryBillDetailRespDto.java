package com.jiahui.im.modules.common.dto.his.patient;

import lombok.Data;

@Data
public class QueryBillDetailRespDto {
	
	private String billId;
	
	private String episodeId;
	
	private String patientId;
	
	private String episodeType;
	
	private String deptCode;
	
	private String siteId;
	
	private String episodeDate;
	
	private String pactCode;
	
	private String pactName;
	
	private String cardNo;
	
	private String totalCost;
	
	private String pubCost;
	
	private String payCost;
	
	private String ownCost;
	
	private String ecoCost;
	
	private String deCost;
	
	private String payState;
	
	private String invoiceId;
	
	private String validState;
	
	private String debt;
	
	private String createDate;
	
	private String transType;
	
	private String alreadyPayed;
	
	private String invoiceState;
	
	private String payorId;
	
	private String payorClass;
}
