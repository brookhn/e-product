package com.jiahui.im.modules.common.dto.bigfront;

import lombok.Data;

import java.util.List;
import java.util.Objects;

/**
 * @author Tommy
 * @date 2021/8/16
 */
@Data
public class BigFrontRespDto<T> {
    /**
     * 语言
     */
    private String lang;

    /**
     * 返回码
     */
    private int code;

    /**
     * 返回描述
     */
    private String msg;

    /**
     * 返回的具体数据 json 格式
     */
    private T data;

    /**
     * 请求是否成功
     * @return
     */
    public boolean isSuccess() {
        return code == 0;
    }

    /**
     * 返回对象是否为空
     * @return
     */
    public boolean isNull() {
        return code == 0 && Objects.isNull(data);
    }

    /**
     * 返回集合是否为空
     * @return
     */
    public boolean isEmpty() {
        if (code != 0) {
            return true;
        }
        if (Objects.isNull(data)) {
            return true;
        }
        if (data instanceof List) {
            List<T> rows = (List<T>) data;
            return rows.isEmpty();
        }
        return false;
    }
}
