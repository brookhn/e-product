package com.jiahui.im.modules.ws.tio;

import cn.hutool.core.date.TimeInterval;
import lombok.extern.log4j.Log4j2;
import org.springframework.scheduling.annotation.Scheduled;
import org.tio.core.ChannelContext;
import org.tio.core.Tio;
import org.tio.server.ServerTioConfig;
import org.tio.utils.lock.ReadLockHandler;
import org.tio.utils.lock.SetWithLock;
import org.tio.websocket.common.Opcode;
import org.tio.websocket.common.WsResponse;

import java.util.Set;

/**
 * 心跳维护
 * PS：心跳由客户端维护，服务端通过ServerTioConfig.setHeartbeatTimeout方法设置心跳超时时间，超时自动断开连接
 * @author Tommy
 * @date 2021/8/18
 */
@Log4j2
//@Component
@Deprecated
public class ImWsHeartbeat {

    /**
     * 定时向客户端发送心跳
     */
    @Scheduled(fixedDelay = 1000 * 10L, initialDelay = 1000 * 5L)
    public void heartbeat() {
        // 获取所有连接
        ServerTioConfig tioConfig = ImWebsocketStarter.getServerGroupContext();
        SetWithLock<ChannelContext> setWithLock = Tio.getAll(tioConfig);
        TimeInterval timeInterval = new TimeInterval();
        // 发送心跳
        setWithLock.handle((ReadLockHandler<Set<ChannelContext>>) set ->
                set.parallelStream().forEach(channelContext -> {
                    WsResponse wsResponse = new WsResponse();
                    wsResponse.setWsOpcode(Opcode.PING);
                    Tio.send(channelContext, wsResponse);
                }));
        log.info("发送心跳成功，连接数:{}，耗时:{}ms", setWithLock.size(), timeInterval.intervalMs());
    }
}
