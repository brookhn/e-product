package com.jiahui.im.common.exception;

import com.jiahui.im.common.CodeMsg;

/**
 * 未经授权异常
 * @author Tommy
 * @date 2021/6/10
 */
public class UnauthorizedException extends BizException{

    public UnauthorizedException(Integer code, String message){
        super(code, message);
    }

    public UnauthorizedException(CodeMsg codeMsg){
        super(codeMsg);
    }
}
