package com.jiahui.im.util;

import org.apache.commons.lang3.StringUtils;

/**
 * 文本工具类
 * @author Fanette Qiu
 * @date 2021/05/16 22:37
 **/
public class TextUtil {

    /**
     * 纯英文校验
     * @param checkStr
     * @return
     */
    public static boolean validPureEnglish(String checkStr) {
        if (StringUtils.isNotEmpty(checkStr)) {
//            String regex = "^[a-zA-Z0-9/^/$/.//,;:'!@#%&/*/|/?/+/(/)/[/]/{/}]+$";
            String regex = "^[a-zA-Z]+$";
            return checkStr.matches(regex);
        }
        return false;
    }

    /**
     * 纯中文校验
     * @param checkStr
     * @return
     */
    public static boolean validPureChinese(String checkStr) {
        if (StringUtils.isNotEmpty(checkStr)) {
            String regex = "^[\\u4e00-\\u9fa5]+$";
            return checkStr.matches(regex);
        }
        return false;
    }


    public static void main(String[] args) {

        String s = "你好啊";

        System.out.println(validPureChinese(s));

    }

}
