package com.jiahui.im.config;

import com.jiahui.framework.datasource.config.JiaHuiDataSourceProperties;
import com.jiahui.framework.datasource.core.DynamicDataSource;
import lombok.extern.log4j.Log4j2;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import javax.sql.DataSource;

@Log4j2
@Configuration
@MapperScan(basePackages = { "com.jiahui.im.modules.*.mapper" }, sqlSessionTemplateRef = "kefuImSqlSessionTemplate")
public class DSKefuImConfig {

	@Bean
	@Primary
	public DataSource kefuImDataSource(JiaHuiDataSourceProperties dbProp) {
		DynamicDataSource dataSource = new DynamicDataSource("imnormal", dbProp);
		return dataSource;
	}

	@Bean
	@Primary
	public SqlSessionFactory kefuImSqlSessionFactory(@Qualifier("kefuImDataSource") DataSource dataSource) throws Exception {
		try {
			SqlSessionFactoryBean bean = new SqlSessionFactoryBean();
			bean.setDataSource(dataSource);
			bean.setMapperLocations(new PathMatchingResourcePatternResolver().getResources("classpath:mybatis/*/*.xml"));
			return bean.getObject();
		}catch (Exception e){
			log.error("kefuImSqlSessionFactory error", e);
			throw e;
		}
	}

	@Bean
	@Primary
	public DataSourceTransactionManager kefuImTransactionManager(@Qualifier("kefuImDataSource") DataSource dataSource) {
		return new DataSourceTransactionManager(dataSource);
	}

	@Bean
	@Primary
	public SqlSessionTemplate kefuImSqlSessionTemplate(@Qualifier("kefuImSqlSessionFactory") SqlSessionFactory sqlSessionFactory) {
		return new SqlSessionTemplate(sqlSessionFactory);
	}
}
