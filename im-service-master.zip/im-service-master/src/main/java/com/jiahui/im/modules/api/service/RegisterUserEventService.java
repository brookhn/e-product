package com.jiahui.im.modules.api.service;

import com.alibaba.fastjson.JSON;
import com.jiahui.im.constant.KafkaConstant;
import com.jiahui.im.modules.api.vo.registeruser.RegisterUserEventIn;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Log4j2
@Service
public class RegisterUserEventService {

    @Autowired
    private KafkaTemplate<String, String> kafkaImTemplate;

    /**
     * 注册用户事件推送
     * @param registerUserEventIn
     */
    public void push(RegisterUserEventIn registerUserEventIn) {
        log.info("注册用户事件推送===>>>>>>message:{}", registerUserEventIn);
        kafkaImTemplate.send(KafkaConstant.TOPIC_IM_REGISTER_USER_EVENT, JSON.toJSONString(registerUserEventIn));
    }
}
