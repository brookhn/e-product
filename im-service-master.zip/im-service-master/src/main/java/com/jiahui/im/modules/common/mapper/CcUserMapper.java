package com.jiahui.im.modules.common.mapper;

import com.jiahui.im.modules.common.entity.CcUserEntity;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CcUserMapper {
    int deleteByPrimaryKey(Long id);

    int insertSelective(CcUserEntity record);

    CcUserEntity selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(CcUserEntity record);

    /**
     * 根据账号id查询
     * @param accountId
     * @return
     */
    CcUserEntity selectByAccountId(Long accountId);

    /**
     * 根据手机号查询有效数据
     * @param phone
     * @return
     */
    CcUserEntity selectByPhone(String phone);

    /**
     * 根据手机号注销未注册的用户
     * @param phone
     * @return
     */
    int invalidByPhone(String phone);
}