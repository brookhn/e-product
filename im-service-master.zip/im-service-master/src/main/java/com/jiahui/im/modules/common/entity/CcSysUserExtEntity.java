package com.jiahui.im.modules.common.entity;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * cc_sys_user_ext
 * @author 
 */
@Data
public class CcSysUserExtEntity implements Serializable {
    /**
     * 主键
     */
    private Long id;

    /**
     * 客服id
     */
    private Long kefuId;

    /**
     * 接待中数量
     */
    private Integer receivingNum;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

    private static final long serialVersionUID = 1L;
}