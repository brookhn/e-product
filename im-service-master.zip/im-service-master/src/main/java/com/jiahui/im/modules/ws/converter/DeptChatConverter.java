package com.jiahui.im.modules.ws.converter;

import com.jiahui.im.modules.common.mongo.ChatRecord;
import com.jiahui.im.modules.ws.dto.kafka.ChatRecordDto;
import com.jiahui.im.modules.ws.dto.kafka.SyncChatRecordDto;
import com.jiahui.im.modules.ws.vo.action.ChatMsgOut;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @author Tommy
 * @date 2021/8/4
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface DeptChatConverter {

    DeptChatConverter INSTANCE = Mappers.getMapper(DeptChatConverter.class);

    @Mapping(target = "sendTime", expression = "java(chatRecord.getCreateTime().getTime())")
    ChatRecordDto chatRecord2Dto(ChatRecord chatRecord);

    ChatMsgOut chatRecordDto2Out(ChatRecordDto chatRecordDto);

    @Mapping(target = "createTime", expression = "java(chatRecord.getCreateTime().getTime())")
    @Mapping(target = "updateTime", expression = "java(chatRecord.getUpdateTime().getTime())")
    SyncChatRecordDto chatRecord2SyncDto(ChatRecord chatRecord);
}