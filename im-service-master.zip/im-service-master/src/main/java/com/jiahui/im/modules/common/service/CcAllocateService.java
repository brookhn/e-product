package com.jiahui.im.modules.common.service;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.extra.spring.SpringUtil;
import com.alibaba.fastjson.JSON;
import com.jiahui.im.common.CodeMsg;
import com.jiahui.im.common.exception.BizException;
import com.jiahui.im.config.properties.SysProperties;
import com.jiahui.im.constant.Constant;
import com.jiahui.im.constant.KafkaConstant;
import com.jiahui.im.modules.api.service.OssService;
import com.jiahui.im.modules.common.dto.chat.CcReceptNumDto;
import com.jiahui.im.modules.common.dto.chat.CcUserExtDto;
import com.jiahui.im.modules.common.entity.CcUserBindRecordEntity;
import com.jiahui.im.modules.common.entity.CcUserBindingEntity;
import com.jiahui.im.modules.common.entity.CcUserDialogEntity;
import com.jiahui.im.modules.common.entity.CcUserUnboundEntity;
import com.jiahui.im.modules.common.enums.CcBindEventEnum;
import com.jiahui.im.modules.common.enums.CcKefuNoticeEnum;
import com.jiahui.im.modules.common.enums.ChannelTypeEnum;
import com.jiahui.im.modules.common.enums.DialogStartTypeEnum;
import com.jiahui.im.modules.common.enums.MsgTypeEnum;
import com.jiahui.im.modules.common.enums.UserNoticeEnum;
import com.jiahui.im.modules.common.mapper.CcSysUserExtMapper;
import com.jiahui.im.modules.common.mapper.CcUserBindRecordMapper;
import com.jiahui.im.modules.common.mapper.CcUserBindingMapper;
import com.jiahui.im.modules.common.mapper.CcUserDialogMapper;
import com.jiahui.im.modules.common.mapper.CcUserExtMapper;
import com.jiahui.im.modules.ws.converter.CcChatConverter;
import com.jiahui.im.modules.ws.dto.kafka.kefu.CcKefuReceivedDto;
import com.jiahui.im.modules.ws.dto.kafka.notice.NoticeDto;
import com.jiahui.im.modules.ws.dto.kafka.notice.ReceivedDto;
import com.jiahui.im.modules.ws.vo.action.ChatActionIn;
import com.jiahui.im.util.UserUtil;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Optional;

/**
 * CC客服-分配逻辑
 * @author Tommy
 * @date 2022/01/19
 */
@Log4j2
@Service
public class CcAllocateService {

    @Autowired
    private OssService ossService;

    @Autowired
    private KafkaTemplate<String, String> kafkaImTemplate;

    @Autowired
    private CcUserBindRecordMapper ccUserBindRecordMapper;

    @Autowired
    private CcUserBindingMapper ccUserBindingMapper;

    @Autowired
    private CcUserDialogMapper ccUserDialogMapper;

    @Autowired
    private CcSysUserExtMapper ccSysUserExtMapper;

    @Autowired
    private CcUserExtMapper ccUserExtMapper;

    /**
     * 分配新用户（不排队直接分配）
     */
    public Pair<Boolean, Long> allocateNewUser(CcUserUnboundEntity ccUserUnbound, ChatActionIn chatActionIn) {
        // 查询可分配的客服
        List<CcReceptNumDto> receptNumList = ccSysUserExtMapper.selectAllocatable(SysProperties.ccDefaultReceptLimit, CcBindEventEnum.receptEventTypeList);
        if (CollUtil.isEmpty(receptNumList)) {
            // 没有在线客服|接待全部达上限
            return Pair.of(false, null);
        }
        // 接待中数量升序->今日接待量升序
        receptNumList.sort(Comparator.comparing(CcReceptNumDto::getReceivingNum).thenComparing(CcReceptNumDto::getReceptNum));
        // 遍历客服，分配用户
        int allocateNum = 0;
        int retryFailNum = 0;
        Long bindRecordId = null;
        for (CcReceptNumDto ccReceptNumDto : receptNumList) {
            ++allocateNum;
            try {
                // 接待用户
                CcAllocateService ccAllocateService = SpringUtil.getBean(CcAllocateService.class);
                Pair<Boolean, Long> receptPair = ccAllocateService.recept(ccUserUnbound, ccReceptNumDto, chatActionIn);
                if (receptPair.getLeft()) {
                    // 接待成功，结束分配
                    bindRecordId = receptPair.getRight();
                    log.info("分配成功，用户id：{}，客服id：{}", ccUserUnbound.getUserId(), ccReceptNumDto.getKefuId());
                    break;
                } else {
                    ++retryFailNum;
                    // 接待失败，继续分配给下一个客服
                    log.warn("接待已达上限，用户id：{}，客服id：{}", ccUserUnbound.getUserId(), ccReceptNumDto.getKefuId());
                    continue;
                }
            } catch (Exception e) {
                // 接待失败，事务已经被@Transactional回滚（用户已经被接待，并发操作导致异常），结束分配
                log.warn("接待用户异常", e);
                // 查询接待中数据，容忍bindRecordId为空
                CcUserBindingEntity bindingEntity = ccUserBindingMapper.selectByUk(ccUserUnbound.getUserId());
                bindRecordId = Optional.ofNullable(bindingEntity).map(CcUserBindingEntity::getBindRecordId).orElse(null);
                break;
            }
        }
        log.info("结束分配，空闲客服数：{}，分配次数：{}，失败次数：{}，bindRecordId：{}", receptNumList.size(), allocateNum, retryFailNum, bindRecordId);
        // 接待失败，客服接待全部达上限
        if (receptNumList.size() == retryFailNum) {
            return Pair.of(false, null);
        }
        return Pair.of(true, bindRecordId);
    }

    /**
     * 接待用户
     * 1、更新接待人数
     * 2、记录绑定操作
     * 3、绑定客服
     * 4、记录会话
     * 5、发送kafka，通知用户&客服【接待成功】
     * 返回值说明：
     * - true：接待成功
     * - false：接待失败，只有该客服达到接待上限时才返回false。后续操作：继续分配给下一个客服
     * - 异常：用户已经被接待，并发操作导致
     */
    @Transactional(value = "kefuImTransactionManager", rollbackFor = Exception.class)
    public Pair<Boolean, Long> recept(CcUserUnboundEntity ccUserUnbound, CcReceptNumDto ccReceptNumDto, ChatActionIn chatActionIn) {
        // 更新接待人数
        int updateCount = ccSysUserExtMapper.incrReceivingNum(ccReceptNumDto.getKefuId(), SysProperties.ccDefaultReceptLimit);
        if(updateCount == 0) {
            // 其他操作导致达到接待上限
            return Pair.of(false, null);
        }
        // 记录【绑定】操作
        CcUserBindRecordEntity tempCcUserBindRecordEntity = CcUserBindRecordEntity.builder()
                .conversationId(ccUserUnbound.getConversationId())
                .userId(ccUserUnbound.getUserId())
                .kefuId(ccReceptNumDto.getKefuId())
                .deptId(ccReceptNumDto.getDeptId())
                .eventType(CcBindEventEnum.NO_RANK_BIND.getType())
                .userRoundQuestionTime(new Date())
                .build();
        ccUserBindRecordMapper.insertSelective(tempCcUserBindRecordEntity);
        // 绑定客服
        CcUserBindingEntity tempCcUserBindingEntity = CcChatConverter.INSTANCE.ccUserUnboundEntity2Binding(ccUserUnbound);
        tempCcUserBindingEntity.setKefuId(ccReceptNumDto.getKefuId());
        tempCcUserBindingEntity.setDeptId(ccReceptNumDto.getDeptId());
        tempCcUserBindingEntity.setBindRecordId(tempCcUserBindRecordEntity.getId());
        try {
            ccUserBindingMapper.insertSelective(tempCcUserBindingEntity);
        } catch (DuplicateKeyException e) {
            throw new BizException(CodeMsg.EXCEPTION, StrUtil.format("绑定客服失败，用户id：{}，客服id：{}", ccUserUnbound.getUserId(), ccReceptNumDto.getKefuId()));
        }
        // 记录会话
        CcUserDialogEntity tempCcUserDialogEntity = CcUserDialogEntity.builder()
                // 初始字段
                .conversationId(ccUserUnbound.getConversationId())
                .userId(ccUserUnbound.getUserId())
                .channelType(ccUserUnbound.getChannelType())
                .systemVersion(ccUserUnbound.getSystemVersion())
                .deviceModel(ccUserUnbound.getDeviceModel())
                .appVersion(ccUserUnbound.getAppVersion())
                .startType(DialogStartTypeEnum.USER.getType())
                .startTime(DateUtil.date())
                .isRank(Constant.FALSE)
                // 接待字段
                .firstKefuId(ccReceptNumDto.getKefuId())
                .firstDeptId(ccReceptNumDto.getDeptId())
                .lastKefuId(ccReceptNumDto.getKefuId())
                .lastDeptId(ccReceptNumDto.getDeptId())
                .isRecept(Constant.TRUE)
                .kefuFirstReceptTime(DateUtil.date())
                .build();
        try {
            ccUserDialogMapper.insertSelective(tempCcUserDialogEntity);
        } catch (DuplicateKeyException e) {
            throw new BizException(CodeMsg.EXCEPTION, StrUtil.format("记录会话失败，用户id：{}，客服id：{}", ccUserUnbound.getUserId(), ccReceptNumDto.getKefuId()));
        }
        // 发送kafka，通知用户&客服
        sendKafka(ccUserUnbound, ccReceptNumDto, chatActionIn);
        return Pair.of(true, tempCcUserBindRecordEntity.getId());
    }

    /**
     * 发送kafka
     * @param ccUserUnbound
     * @param ccReceptNumDto
     */
    private void sendKafka(CcUserUnboundEntity ccUserUnbound, CcReceptNumDto ccReceptNumDto, ChatActionIn chatActionIn) {
        DateTime now = DateUtil.date();
        /* ----------------发送kafka，通知用户【接待成功】---------------- */
        ReceivedDto receivedDto = ReceivedDto.builder()
                .noticeType(UserNoticeEnum.RECEIVED.getType())
                .userId(ccUserUnbound.getUserId())
                .kefuId(ccReceptNumDto.getKefuId())
                .receptTime(now.getTime())
                .build();
        NoticeDto<ReceivedDto> userNoticeDto = new NoticeDto<>(receivedDto.getNoticeType(), receivedDto);
        kafkaImTemplate.send(KafkaConstant.TOPIC_CC_IM_USER_NOTICE_MSG, JSON.toJSONString(userNoticeDto));

        /* ----------------发送kafka，通知客服【接待成功】---------------- */
        // 查询用户最后一次发消息记录（此时最后一次发消息记录还未落库，需要从入参获取）
        CcUserExtDto ccUserExtDto = ccUserExtMapper.selectByUserId(ccUserUnbound.getUserId());
        // 查询客服今日接待人数
        int todayReceptNum = ccUserBindRecordMapper.todayReceptNumByKefuId(ccReceptNumDto.getKefuId(), CcBindEventEnum.receptEventTypeList);
        // 查询客服信息
        CcKefuReceivedDto ccKefuReceivedDto = CcKefuReceivedDto.builder()
                .noticeType(CcKefuNoticeEnum.RECEIVED.getType())
                .userId(ccUserExtDto.getUserId())
                .userName(UserUtil.getShowName(ccUserExtDto))
                .headUrl(UserUtil.getShowHeadUrl(ccUserExtDto.getHeadUrl()))
                .nationality(ccUserExtDto.getNationality())
                .channel(ChannelTypeEnum.fromType(ccUserExtDto.getLastChannelType()).getDesc())
                .kefuId(ccReceptNumDto.getKefuId())
                .kefuName(ccReceptNumDto.getUserName())
                .kefuHeadUrl(SysProperties.ccDefaultKefuHeadUrl)
                .deptId(ccReceptNumDto.getDeptId())
                .userLastSendTime(now.getTime())
                .userLastFileName(StrUtil.EMPTY)
                .userLastFileSize(0L)
                .userLastMsgType(chatActionIn.getMsgType())
                .userLastContent(chatActionIn.getContent())
                .userLastChannelType(ccUserUnbound.getChannelType())
                .todayReceptNum(todayReceptNum)
                .receptTime(now.getTime())
                .build();
        // 处理OSS资源
        Boolean isOssResource = Optional.ofNullable(MsgTypeEnum.fromType(ccKefuReceivedDto.getUserLastMsgType())).map(MsgTypeEnum::isOssResource).orElse(Boolean.FALSE);
        ccKefuReceivedDto.setUserLastObjectName(isOssResource ? ccKefuReceivedDto.getUserLastContent() : StrUtil.EMPTY);
        if (isOssResource) {
            // 获取OSS私有bucket文件链接
            String ossUrl = ossService.ossPresignedUrl(ccKefuReceivedDto.getUserLastContent(), ccKefuReceivedDto.getUserLastMsgType()).toString();
            ccKefuReceivedDto.setUserLastContent(ossUrl);
        }
        NoticeDto<CcKefuReceivedDto> kefuNoticeDto = new NoticeDto<>(ccKefuReceivedDto.getNoticeType(), ccKefuReceivedDto);
        kafkaImTemplate.send(KafkaConstant.TOPIC_CC_IM_KEFU_NOTICE_MSG, JSON.toJSONString(kefuNoticeDto));
    }
}
