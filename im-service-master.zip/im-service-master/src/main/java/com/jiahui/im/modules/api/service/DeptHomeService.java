package com.jiahui.im.modules.api.service;

import cn.hutool.core.collection.CollUtil;
import com.jiahui.im.common.PageOut;
import com.jiahui.im.context.UserThreadContext;
import com.jiahui.im.helper.MyJwt;
import com.jiahui.im.modules.api.vo.home.ChatRecordListIn;
import com.jiahui.im.modules.api.vo.home.ChatRecordListOut;
import com.jiahui.im.modules.api.vo.home.CheckRequestIdIn;
import com.jiahui.im.modules.api.vo.home.CheckRequestIdOut;
import com.jiahui.im.modules.api.vo.home.NewestChatRecordListIn;
import com.jiahui.im.modules.api.vo.home.NewestChatRecordListOut;
import com.jiahui.im.modules.api.vo.oss.GetPresignedUrlIn;
import com.jiahui.im.modules.common.enums.MsgTypeEnum;
import com.jiahui.im.modules.common.mongo.ChatRecord;
import com.jiahui.im.modules.common.mongo.ChatRecordDao;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.net.URL;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * 科室客服-主页
 * @author Tommy
 * @date 2021/08/12
 */
@Log4j2
@Service
public class DeptHomeService {

    @Autowired
    private ChatRecordDao chatRecordDao;

    @Autowired
    private OssService ossService;

    /**
     * 聊天记录列表
     * @param chatRecordListIn
     * @return
     */
    public ChatRecordListOut chatRecordList(ChatRecordListIn chatRecordListIn) {
        MyJwt myJwt = UserThreadContext.getUserVisitor().getMyJwt();
        // 查询数据库
        PageOut<ChatRecord> pageOut = chatRecordDao.pageByUserId(myJwt.getUserId(), myJwt.getDeptId(), chatRecordListIn.getRecordId(), chatRecordListIn.getPageSize());
        List<ChatRecord> chatRecordList = pageOut.getRows();
        if (CollUtil.isEmpty(chatRecordList)) {
            return new ChatRecordListOut();
        }
        // 获取OSS私有bucket文件链接
        List<GetPresignedUrlIn> objectList = chatRecordList.stream()
                .filter(e -> Optional.ofNullable(MsgTypeEnum.fromType(e.getMsgType())).map(MsgTypeEnum::isOssResource).orElse(false))
                .map(o -> new GetPresignedUrlIn(o.getContent(),o.getMsgType())).collect(Collectors.toList());
        final Map<String, URL> ossURLMap = ossService.ossPresignedUrlMap(objectList);
        // 排序反转
        CollUtil.reverse(chatRecordList);
        // 组装数据
        List<ChatRecordListOut.Record> recordList = chatRecordList.stream().map(e -> new ChatRecordListOut.Record(e, myJwt.getHeadUrl(), ossURLMap)).collect(Collectors.toList());
        return new ChatRecordListOut(recordList, pageOut.getTotalCount());
    }

    /**
     * 最新聊天记录列表
     * @param newestChatRecordListIn
     * @return
     */
    public NewestChatRecordListOut newestChatRecordList(NewestChatRecordListIn newestChatRecordListIn) {
        MyJwt myJwt = UserThreadContext.getUserVisitor().getMyJwt();
        // 查询数据库
        List<ChatRecord> chatRecordList = chatRecordDao.newestByUserId(myJwt.getUserId(), myJwt.getDeptId(), newestChatRecordListIn.getRecordId());
        if (CollUtil.isEmpty(chatRecordList)) {
            return new NewestChatRecordListOut();
        }
        // 获取OSS私有bucket文件链接
        List<GetPresignedUrlIn> objectList = chatRecordList.stream()
                .filter(e -> Optional.ofNullable(MsgTypeEnum.fromType(e.getMsgType())).map(MsgTypeEnum::isOssResource).orElse(false))
                .map(o -> new GetPresignedUrlIn(o.getContent(),o.getMsgType())).collect(Collectors.toList());
        final Map<String, URL> ossURLMap = ossService.ossPresignedUrlMap(objectList);
        // 组装数据
        List<NewestChatRecordListOut.Record> recordList = chatRecordList.stream().map(e -> new NewestChatRecordListOut.Record(e, myJwt.getHeadUrl(), ossURLMap)).collect(Collectors.toList());
        return new NewestChatRecordListOut(recordList, recordList.size());
    }

    /**
     * 检查消息是否发送成功
     * @param checkRequestIdIn
     * @return
     */
    public CheckRequestIdOut checkRequestId(CheckRequestIdIn checkRequestIdIn) {
        CheckRequestIdOut checkRequestIdOut = new CheckRequestIdOut(checkRequestIdIn.getRequestId());
        MyJwt myJwt = UserThreadContext.getUserVisitor().getMyJwt();
        // 查询消息
        ChatRecord chatRecord = chatRecordDao.queryByRequestId(myJwt.getUserId(), myJwt.getDeptId(), checkRequestIdIn.getRequestId());
        if (Objects.isNull(chatRecord)) {
            return checkRequestIdOut;
        }
        checkRequestIdOut.setRecordId(chatRecord.getId());
        return checkRequestIdOut;
    }
}
