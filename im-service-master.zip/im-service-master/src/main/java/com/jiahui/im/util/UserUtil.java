package com.jiahui.im.util;

import cn.hutool.core.util.StrUtil;
import com.jiahui.im.config.properties.SysProperties;
import com.jiahui.im.constant.Constant;
import com.jiahui.im.modules.common.dto.chat.CcUserExtDto;
import com.jiahui.im.modules.common.entity.CcUserEntity;
import com.jiahui.im.modules.common.entity.UserEntity;

/**
 * 用户工具类
 * @author Tommy
 * @date 2022/1/24
 */
public class UserUtil {

	/**
	 * 获取展示名称
	 * @param patientName
	 * @param userName
	 * @return
	 */
	public static String getShowName(String patientName, String userName) {
		return StrUtil.blankToDefault(patientName, StrUtil.blankToDefault(userName, Constant.DEFAULT_USER_NAME));
	}

	/**
	 * 获取展示名称
	 * @return
	 */
	public static String getShowName(CcUserEntity user) {
		return StrUtil.blankToDefault(user.getPatientName(), StrUtil.blankToDefault(user.getUserName(), Constant.DEFAULT_USER_NAME));
	}

	/**
	 * 获取展示名称
	 * @return
	 */
	public static String getShowName(CcUserExtDto user) {
		return StrUtil.blankToDefault(user.getPatientName(), StrUtil.blankToDefault(user.getUserName(), Constant.DEFAULT_USER_NAME));
	}

	/**
	 * 获取展示头像
	 * @return
	 */
	public static String getShowHeadUrl(String headUrl) {
		return StrUtil.blankToDefault(headUrl, SysProperties.defaultUserHeadUrl);
	}

	/**
	 * 获取展示名称
	 * @param user
	 * @return
	 */
	public static String getShowName(UserEntity user) {
		return StrUtil.blankToDefault(user.getPatientName(),
				StrUtil.blankToDefault(user.getNickName(),
						StrUtil.blankToDefault(user.getUserName(), Constant.DEFAULT_USER_NAME)));
	}
}
