package com.jiahui.im.modules.common.enums;

import com.google.common.collect.Maps;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Map;

/**
 * CC客服-客服通知消息类型
 * @author Tommy
 * @date 2022/1/20
 */
@Getter
@AllArgsConstructor
public enum CcKefuNoticeEnum {

    /* ------------------------------------ 通用通知  ------------------------------------ */
    APPLY_RECEPT(1, "申请接待"),
    REFUSE_RECEPT(2, "拒绝接待"),
    RECEIVED(3, "接待成功"),
    UNBIND(4, "解绑成功"),

    RANK_NUM(31, "排队人数变更"),
    USER_END_RANK(32, "用户结束排队"),


    /* ------------------------------------ 系统通知  ------------------------------------ */
    CHANGE_AGENT(10001, "坐席变更"),
    DISABLE(10002, "账号禁用"),

    /**
     * 呼叫通知
     */
    CALL_BEGIN(10101, "外呼开始"),
    ;

    /**
     * 类型
     */
    private final Integer type;

    /**
     * 描述
     */
    private final String desc;

    public static final Map<Integer, CcKefuNoticeEnum> map = Maps.newHashMap();

    static {
        for (CcKefuNoticeEnum e : CcKefuNoticeEnum.values()) {
            map.put(e.getType(), e);
        }
    }

    public static CcKefuNoticeEnum fromType(Integer type) {
        return map.get(type);
    }
}
