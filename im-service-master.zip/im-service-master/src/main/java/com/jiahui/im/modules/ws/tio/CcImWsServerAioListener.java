package com.jiahui.im.modules.ws.tio;

import cn.hutool.core.util.StrUtil;
import com.jiahui.im.helper.MyJwt;
import com.jiahui.im.modules.common.entity.CcUserConnectRecordEntity;
import com.jiahui.im.modules.common.enums.SessionBreakTypeEnum;
import com.jiahui.im.modules.common.mapper.CcUserConnectRecordMapper;
import com.jiahui.im.modules.ws.constant.ImConst;
import com.jiahui.im.modules.ws.util.WsUtil;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.tio.core.ChannelContext;
import org.tio.core.intf.Packet;
import org.tio.websocket.server.WsServerAioListener;

import java.util.Date;

/**
 * CC客服-AIO监听
 * @author Tommy
 * @date 2022/5/30
 */
@Log4j2
@Component
public class CcImWsServerAioListener extends WsServerAioListener {

	@Autowired
	private CcUserConnectRecordMapper ccUserConnectRecordMapper;

	/**
	 * 连接建立之后
	 * @param channelContext
	 * @param isConnected
	 * @param isReconnect
	 * @throws Exception
	 */
	@Override
	public void onAfterConnected(ChannelContext channelContext, boolean isConnected, boolean isReconnect) throws Exception {

	}

	/**
	 * 服务端->客户端发消息之后
	 * @param channelContext
	 * @param packet
	 * @param isSentSuccess
	 * @throws Exception
	 */
	@Override
	public void onAfterSent(ChannelContext channelContext, Packet packet, boolean isSentSuccess) throws Exception {
		// 维护连接信息
		CcUserConnectRecordEntity connectRecordEntity = CcUserConnectRecordEntity.builder()
				.sessionId(channelContext.getId())
				.activeTime(new Date())
				.build();
		ccUserConnectRecordMapper.updateByUk(connectRecordEntity);
	}

	/**
	 * 客户端/服务端关闭连接之前
	 * @param channelContext
	 * @param throwable
	 * @param remark
	 * @param isRemove
	 * @throws Exception
	 */
	@Override
	public void onBeforeClose(ChannelContext channelContext, Throwable throwable, String remark, boolean isRemove) throws Exception {
		// 维护连接信息
		CcUserConnectRecordEntity connectRecordEntity = CcUserConnectRecordEntity.builder()
				.sessionId(channelContext.getId())
				.breakTime(new Date())
				.breakType(SessionBreakTypeEnum.AUTOMATIC.getType())
				.remark(StrUtil.subByCodePoint(remark, 0, 200))
				.build();
		ccUserConnectRecordMapper.updateByUk(connectRecordEntity);

		// 删除用户连接
		MyJwt myJwt = (MyJwt) channelContext.get(ImConst.JWT_INFO);
		WsUtil.delUserChannelId(channelContext, myJwt);
	}

	/**
	 * 接收到客户端消息&解码之后
	 * @param channelContext
	 * @param packet
	 * @param packetSize
	 * @throws Exception
	 */
	@Override
	public void onAfterDecoded(ChannelContext channelContext, Packet packet, int packetSize) throws Exception {

	}

	/**
	 * 接收到客户端消息之后
	 * @param channelContext
	 * @param receivedBytes
	 * @throws Exception
	 */
	@Override
	public void onAfterReceivedBytes(ChannelContext channelContext, int receivedBytes) throws Exception {
		// 维护连接信息
		CcUserConnectRecordEntity connectRecordEntity = CcUserConnectRecordEntity.builder()
				.sessionId(channelContext.getId())
				.activeTime(new Date())
				.build();
		ccUserConnectRecordMapper.updateByUk(connectRecordEntity);
	}

	/**
	 * 接收到客户端消息&处理之后
	 * @param channelContext
	 * @param packet
	 * @param cost
	 * @throws Exception
	 */
	@Override
	public void onAfterHandled(ChannelContext channelContext, Packet packet, long cost) throws Exception {

	}

}
