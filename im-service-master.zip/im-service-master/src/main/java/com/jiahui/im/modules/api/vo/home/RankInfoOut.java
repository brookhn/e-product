package com.jiahui.im.modules.api.vo.home;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Tommy
 * @date 2022/3/17
 */
@ApiModel
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RankInfoOut {
    @ApiModelProperty(value = "是否排队中 0-否 1-是")
    private Integer status = 0;

    @ApiModelProperty(value = "前方排队人数 ")
    private Integer ranking = 0;

    public RankInfoOut(Integer ranking) {
        this.status = ranking > 0 ? 1 : 0;
        this.ranking = ranking;
    }
}
