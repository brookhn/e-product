package com.jiahui.im.modules.ws.dto.kafka;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SyncCcChatRecordDto {

	/**
	 * 主键
	 */
	private String id;

	/**
	 * 用户ID
	 */
	private Long userId;

	/**
	 * 发送者ID
	 */
	private Long fromId;

	/**
	 * 发送者类型 1-用户 2-客服 3-系统
	 */
	private Integer fromType;

	/**
	 * 接收者ID
	 */
	private Long toId;

	/**
	 * 接收者类型 1-用户 2-客服 3-系统
	 */
	private Integer toType;

	/**
	 * 文件名
	 */
	private String fileName;

	/**
	 * 文件大小（byte）
	 */
	private Long fileSize;

	/**
	 * 消息类型 1-文本 2-图片 3-语音 4-视频 5-word 6-PDF 7-文件
	 */
	private Integer msgType;

	/**
	 * 消息内容
	 */
	private String content;

	/**
	 * 部门ID
	 */
	private Long deptId;

	/**
	 * 渠道类型 1-APP 2-公众号 3-小程序 4-企业微信
	 */
	private Integer channelType;

	/**
	 * 系统版本
	 */
	private String systemVersion;

	/**
	 * 设备型号
	 */
	private String deviceModel;

	/**
	 * app版本
	 */
	private String appVersion;

	/**
	 * 请求标识
	 */
	private String requestId;

	/**
	 * 会话ID
	 */
	private String conversationId;

	/**
	 * 创建时间 毫秒级时间戳
	 */
	private Long createTime;

	/**
	 * 更新时间 毫秒级时间戳
	 */
	private Long updateTime;

	/******************************以上字段为mongo中已有字段，以下字段为补充字段******************************/

	/**
	 * 关联cc_user_bind_record表id
	 */
	private Long bindRecordId;

	/**
	 * 用户账号id
	 */
	private Long accountId;

	/**
	 * 用于APP消息推送的消息内容（content去除html标签）
	 */
	private String pushContent = "";

	/**
	 * kafka发送时间 毫秒级时间戳
	 */
	private Long kafkaSendTime;
}
