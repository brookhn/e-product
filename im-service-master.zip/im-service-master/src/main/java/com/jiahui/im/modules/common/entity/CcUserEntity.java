package com.jiahui.im.modules.common.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * cc_user
 * @author 
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CcUserEntity implements Serializable {
    /**
     * 主键
     */
    private Long id;

    /**
     * 账号id
     */
    private Long accountId;

    /**
     * 电话
     */
    private String phone;

    /**
     * 姓名
     */
    private String userName;

    /**
     * 绑定本人性别 M-男 F-女
     */
    private String gender;

    /**
     * 头像
     */
    private String headUrl;

    /**
     * 注册来源编码
     */
    private String terminalCode;

    /**
     * 注册来源
     */
    private String terminal;

    /**
     * 注册时间
     */
    private Date registerTime;

    /**
     * 绑定本人mrn
     */
    private String mrn;

    /**
     * 绑定本人姓名
     */
    private String patientName;

    /**
     * 绑定本人生日
     */
    private Date birthday;

    /**
     * 绑定本人国籍编码
     */
    private String nationalityCode;

    /**
     * 绑定本人国籍
     */
    private String nationality;

    /**
     * 绑定家庭成员数量
     */
    private Integer bindCount;

    /**
     * 备注
     */
    private String remark;

    /**
     * 状态 0-无效 1-有效
     */
    private Integer status;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

    private static final long serialVersionUID = 1L;
}