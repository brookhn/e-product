package com.jiahui.im.modules.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

/**
 * 终端类型
 *
 * @author yatao.xu
 * @version 1.0.0
 * @date 2021-01-15
 **/
@Getter
@AllArgsConstructor
public enum MATerminalDictEnum {
    IOS("ios", "IOS"),
    Android("android", "安卓"),
    WMP("wmp", "微信小程序"),
    H5("h5", "h5"),
    I_PAD("ipad", "IPAD"),
    INTEGRATED_MACHINE("integrated_machine", "一体机"),
    NO_SOURCE("no_source", "未知")
    ;
    private String code;
    private String desc;

    public static MATerminalDictEnum findByCode(String code) {
        if (StringUtils.isEmpty(code)) {
            return NO_SOURCE;
        }
        for (MATerminalDictEnum payTypeEnum : MATerminalDictEnum.values()) {
            if (payTypeEnum.getCode().equalsIgnoreCase(code)) {
                return payTypeEnum;
            }
        }
        return NO_SOURCE;
    }
}
