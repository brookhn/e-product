package com.jiahui.im.modules.common.dto.his.patient;

import java.util.List;

import lombok.Data;

@Data
public class PatientApptListRespDto {
	
	private String patientId;
	
	private String patientName;
	
	private String patientEName;
	
	private String patientFirstName;
	
	private String patientFamilyName;
	
	private String englishFamilyName;
	
	private String gender;
	
	private String birthDate;
	
	private String idiomaticLanguage;
	
	private List<PatientApptDetailRespDto> list;
}
