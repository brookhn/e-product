package com.jiahui.im.constant;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * kafka常量
 */
@Component
public class KafkaConstant {

    /**
     * kafka topic
     */
    /** -------------------CC客服--------------------- */
    public static String TOPIC_CC_IM_USER_MSG;//用户消息
    public static String TOPIC_CC_IM_KEFU_MSG;//客服消息
    public static String TOPIC_CC_IM_USER_NOTICE_MSG;//用户通知消息
    public static String TOPIC_CC_IM_KEFU_NOTICE_MSG;//客服通知消息
    public static String TOPIC_CC_IM_CHAT_RECORD;//聊天记录
    public static String TOPIC_CC_IM_USER_ALLOCATE;//用户排队分配

    /** -------------------科室客服--------------------- */
    public static String TOPIC_DEPT_IM_USER_MSG;//用户消息
    public static String TOPIC_DEPT_IM_KEFU_MSG;//客服消息
    public static String TOPIC_DEPT_IM_NOTICE_MSG;//通知消息
    public static String TOPIC_DEPT_IM_CHAT_RECORD;//聊天记录

    /** -------------------注册用户--------------------- */
    public static String TOPIC_IM_REGISTER_USER_EVENT;//注册用户事件

    @Value("${kafka.topic.CC_IM_USER_MSG}")
    public void setTopicCcImUserMsg(String topicCcImUserMsg) {
        TOPIC_CC_IM_USER_MSG = topicCcImUserMsg;
    }

    @Value("${kafka.topic.CC_IM_KEFU_MSG}")
    public void setTopicCcImKefuMsg(String topicCcImKefuMsg) {
        TOPIC_CC_IM_KEFU_MSG = topicCcImKefuMsg;
    }

    @Value("${kafka.topic.CC_IM_USER_NOTICE_MSG}")
    public void setTopicCcImUserNoticeMsg(String topicCcImUserNoticeMsg) {
        TOPIC_CC_IM_USER_NOTICE_MSG = topicCcImUserNoticeMsg;
    }

    @Value("${kafka.topic.CC_IM_KEFU_NOTICE_MSG}")
    public void setTopicCcImKefuNoticeMsg(String topicCcImKefuNoticeMsg) {
        TOPIC_CC_IM_KEFU_NOTICE_MSG = topicCcImKefuNoticeMsg;
    }

    @Value("${kafka.topic.CC_IM_CHAT_RECORD}")
    public void setTopicCcImChatRecord(String topicCcImChatRecord) {
        TOPIC_CC_IM_CHAT_RECORD = topicCcImChatRecord;
    }

    @Value("${kafka.topic.CC_IM_USER_ALLOCATE}")
    public void setTopicCcImUserAllocate(String topicCcImUserAllocate) {
        TOPIC_CC_IM_USER_ALLOCATE = topicCcImUserAllocate;
    }

    @Value("${kafka.topic.DEPT_IM_USER_MSG}")
    public void setTopicDeptImUserMsg(String topicDeptImUserMsg) {
        TOPIC_DEPT_IM_USER_MSG = topicDeptImUserMsg;
    }

    @Value("${kafka.topic.DEPT_IM_KEFU_MSG}")
    public void setTopicDeptImKefuMsg(String topicDeptImKefuMsg) {
        TOPIC_DEPT_IM_KEFU_MSG = topicDeptImKefuMsg;
    }

    @Value("${kafka.topic.DEPT_IM_NOTICE_MSG}")
    public void setTopicDeptImNoticeMsg(String topicDeptImNoticeMsg) {
        TOPIC_DEPT_IM_NOTICE_MSG = topicDeptImNoticeMsg;
    }

    @Value("${kafka.topic.DEPT_IM_CHAT_RECORD}")
    public void setTopicDeptImChatRecord(String topicDeptImChatRecord) {
        TOPIC_DEPT_IM_CHAT_RECORD = topicDeptImChatRecord;
    }

    @Value("${kafka.topic.IM_REGISTER_USER_EVENT}")
    public void setTopicImRegisterUserEvent(String topicImRegisterUserEvent) {
        TOPIC_IM_REGISTER_USER_EVENT = topicImRegisterUserEvent;
    }
}
