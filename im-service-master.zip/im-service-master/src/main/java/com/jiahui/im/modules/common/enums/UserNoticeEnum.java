package com.jiahui.im.modules.common.enums;

import com.google.common.collect.Maps;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Map;

/**
 * 用户通知消息类型
 * @author Tommy
 * @date 2022/1/20
 */
@Getter
@AllArgsConstructor
public enum UserNoticeEnum {

    RECEIVED(1, "接待成功"),
    RANKING(2, "排名变更"),

    END_RECEPT(20, "结束接待"),
    USER_END_RANK(40, "用户结束排队"),
    ;

    /**
     * 类型
     */
    private final Integer type;

    /**
     * 描述
     */
    private final String desc;

    public static final Map<Integer, UserNoticeEnum> map = Maps.newHashMap();

    static {
        for (UserNoticeEnum e : UserNoticeEnum.values()) {
            map.put(e.getType(), e);
        }
    }

    public static UserNoticeEnum fromType(Integer type) {
        return map.get(type);
    }
}
