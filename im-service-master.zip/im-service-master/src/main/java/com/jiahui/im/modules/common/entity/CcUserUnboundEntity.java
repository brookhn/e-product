package com.jiahui.im.modules.common.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * cc_user_unbound
 * @author 
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CcUserUnboundEntity implements Serializable {
    /**
     * 主键
     */
    private Long id;

    /**
     * 会话id
     */
    private String conversationId;

    /**
     * 用户id
     */
    private Long userId;

    /**
     * 渠道类型 1-APP 2-公众号 3-小程序 4-企业微信
     */
    private Integer channelType;

    /**
     * 系统版本
     */
    private String systemVersion;

    /**
     * 设备型号
     */
    private String deviceModel;

    /**
     * app版本
     */
    private String appVersion;

    /**
     * 用户提问时间
     */
    private Date userQuestionTime;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

    private static final long serialVersionUID = 1L;

    /* ----------------以下字段为扩展字段---------------- */
    /**
     * 排名
     */
    private Integer ranking;
}