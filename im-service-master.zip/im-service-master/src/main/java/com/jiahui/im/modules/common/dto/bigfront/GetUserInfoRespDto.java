package com.jiahui.im.modules.common.dto.bigfront;

import lombok.Data;

import java.util.List;

@Data
public class GetUserInfoRespDto {
    /**
     * 页码
	 */
	private Integer current;

	/**
	 * 总页数
	 */
	private Integer pages;

	/**
	 * 当前页数据量
	 */
	private Integer size;

	/**
	 * 总数据量
	 */
	private Integer total;

	/**
	 * 数据
	 */
	private List<UserInfoDto> records;
}
