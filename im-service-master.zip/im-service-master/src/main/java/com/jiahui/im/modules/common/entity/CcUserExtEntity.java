package com.jiahui.im.modules.common.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * cc_user_ext
 * @author 
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CcUserExtEntity implements Serializable {
    /**
     * 主键
     */
    private Long id;

    /**
     * 用户id
     */
    private Long userId;

    /**
     * 用户首次咨询标记 0-未咨询 1-已咨询
     */
    private Integer firstQuestionFlag;

    /**
     * 用户首次咨询时间
     */
    private Date firstQuestionTime;

    /**
     * 用户首次咨询渠道类型 1-APP 2-公众号 3-小程序 4-企业微信 61-电话呼入 62-电话呼出
     */
    private Integer firstQuestionChannelType;

    /**
     * 最后一条消息发送者类型 1-用户 2-客服
     */
    private Integer lastFromType;

    /**
     * 用户最后一条消息对应的MongoDB主键
     */
    private String lastMsgId;

    /**
     * 用户最后一条消息时间
     */
    private Date lastSendTime;

    /**
     * 用户最后一条消息文件名
     */
    private String lastFileName;

    /**
     * 用户最后一条消息文件大小（byte）
     */
    private Long lastFileSize;

    /**
     * 用户最后一条消息类型 1-文本 2-图片 3-语音 4-视频 5-word 6-PDF 7-文件
     */
    private Integer lastMsgType;

    /**
     * 用户最后一条消息内容
     */
    private String lastContent;

    /**
     * 用户最后一条消息渠道类型 1-APP 2-公众号 3-小程序 4-企业微信
     */
    private Integer lastChannelType;

    /**
     * 用户是否已读
     */
    private Integer isUserRead;

    /**
     * 用户已读消息对应的MongoDB主键
     */
    private String userReadMsgId;

    /**
     * 用户未读消息数
     */
    private Integer userUnreadNum;

    /**
     * 客服发给用户最后一条消息对应的MongoDB主键
     */
    private String kefuLastMsgId;

    /**
     * 客服发给用户最后一条消息时间
     */
    private Date kefuLastSendTime;

    /**
     * 客服发给用户最后一条消息文件名
     */
    private String kefuLastFileName;

    /**
     * 客服发给用户最后一条消息文件大小（Integer）
     */
    private Long kefuLastFileSize;

    /**
     * 客服发给用户最后一条消息类型 1-文本 2-图片 3-语音 4-视频 5-word 6-PDF 7-文件
     */
    private Integer kefuLastMsgType;

    /**
     * 客服发给用户最后一条消息内容
     */
    private String kefuLastContent;

    /**
     * 客服发给用户最后一条用于APP消息推送的消息内容（content去除html标签）
     */
    private String kefuLastPushContent;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

    private static final long serialVersionUID = 1L;
}