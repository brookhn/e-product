package com.jiahui.im.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum JwtStatusEnum {

    SUCCESS(0, "正常"),
    ILLEGAL(-1, "JWT非法"),
    EXPIRED(-2, "JWT已过期"),
    SECRET_ILLEGAL(-3, "JWT服务密钥非法"),
    UNKNOWN(-4, "未知异常"),
    ;

    /**
     * 状态
     */
    private final int status;

    /**
     * 状态描述
     */
    private final String statusMsg;
}
