package com.jiahui.im.modules.api.controller;

import com.jiahui.im.common.JsonOut;
import com.jiahui.im.modules.api.service.RegisterUserEventService;
import com.jiahui.im.modules.api.vo.registeruser.RegisterUserEventIn;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(tags = "注册用户事件")
@RestController
@RequestMapping("/register-user/event")
public class RegisterUserEventController {

    @Autowired
    private RegisterUserEventService registerUserEventService;

    @ApiOperation(value = "注册用户事件推送")
    @PostMapping(value = "/push")
    public JsonOut push(@RequestBody @Validated RegisterUserEventIn registerUserEventIn) {
        registerUserEventService.push(registerUserEventIn);
        return JsonOut.ok();
    }
}
