package com.jiahui.im.modules.common.dto.his.patient;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;

@Data
public class PatientRespDto {
	
	private String patientId;
	
	private String firstName;
	
	private String fullName;
	
	private String lastName;
	
	private String enFirstName;
	
	private String enLastName;
	
	private String postType;
	
	private String postId;

	@JsonFormat(pattern="yyyy-MM-dd",timezone = "GMT+8")
	private Date birthDate;

	private String gender;
	
	private String homeAddress;
	
	private String tel;
	
	private String createDate;
	
	private String dist;
	
	private String nationCode;
	
	private String counCode;
	
	private String marriage;
	
	private String email;
	
	private String linkManName;
	
	private String linkManTel;
	
	private String linkManAddress;
	
	private String linkManRelaCode;
	
	private String mainLanguage;
	
	private String addrCountry;
	
	private String addrProvince;
	
	private String addrCity;
	
	private String addrRegion;
	
	private String addrStreet;
	
	private String faceCollected;
	
	private String faceAuthorized;
	
	private String faceUploadStatus;
	
	private String vipFlag;
	
	private String jhoneFlag;
	
	private String staffFlag;
	
	private String primeFlag;
	
	private String finaceWarning;
	
	private String other;
	
	private String drugAbuse;
	
	private String infectionControl;
	
	private String adverseEvents;
	
	private String normalWarning;
	
	private String Religion;
	
	private String familyRegister;
	
}
