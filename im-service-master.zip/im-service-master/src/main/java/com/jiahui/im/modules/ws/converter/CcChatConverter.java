package com.jiahui.im.modules.ws.converter;

import com.jiahui.im.modules.common.entity.CcUserBindingEntity;
import com.jiahui.im.modules.common.entity.CcUserUnboundEntity;
import com.jiahui.im.modules.common.mongo.CcChatRecord;
import com.jiahui.im.modules.ws.dto.kafka.CcChatRecordDto;
import com.jiahui.im.modules.ws.dto.kafka.SyncCcChatRecordDto;
import com.jiahui.im.modules.ws.vo.action.ChatMsgOut;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @author Tommy
 * @date 2021/8/4
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface CcChatConverter {

    CcChatConverter INSTANCE = Mappers.getMapper(CcChatConverter.class);

    @Mapping(target = "sendTime", expression = "java(chatRecord.getCreateTime().getTime())")
    CcChatRecordDto chatRecord2Dto(CcChatRecord chatRecord);

    ChatMsgOut chatRecordDto2Out(CcChatRecordDto chatRecordDto);

    @Mapping(target = "createTime", expression = "java(chatRecord.getCreateTime().getTime())")
    @Mapping(target = "updateTime", expression = "java(chatRecord.getUpdateTime().getTime())")
    SyncCcChatRecordDto chatRecord2SyncDto(CcChatRecord chatRecord);

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "createTime", ignore = true)
    @Mapping(target = "updateTime", ignore = true)
    CcUserBindingEntity ccUserUnboundEntity2Binding(CcUserUnboundEntity entity);
}