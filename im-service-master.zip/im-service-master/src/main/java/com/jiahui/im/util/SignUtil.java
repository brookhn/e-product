package com.jiahui.im.util;

import cn.hutool.core.util.IdUtil;
import cn.hutool.crypto.digest.DigestUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONValidator;
import com.alibaba.fastjson.serializer.SerializerFeature;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * 签名工具类
 * @author Tommy
 * @date 2022/07/05
 */
public class SignUtil {

    /**
     * 获取毫秒级时间戳
     * @return
     */
    public static String getTimestamp() {
        return String.valueOf(System.currentTimeMillis());
    }

    /**
     * 获取随机字符串（不少于32位）
     * @return
     */
    public static String getNonce() {
        return IdUtil.fastSimpleUUID();
    }

    /**
     * 获取签名
     * @param timestamp
     * @param nonce
     * @param body
     * @return
     */
    public static String getSign(String timestamp, String nonce, Object body) {
        // 处理请求体body
        String sortedBody = handleBody(body);
        // 生成签名
        return generateSign(timestamp, nonce, sortedBody);
    }

    /**
     * 获取签名请求头
     * @param body
     * @return
     */
    public static Map<String, String> getSignMap(Object body) {
        // 处理请求体body
        String sortedBody = handleBody(body);
        // 生成签名
        String timestamp = String.valueOf(System.currentTimeMillis());
        String nonce = IdUtil.fastSimpleUUID();
        String sign = generateSign(timestamp, nonce, sortedBody);
        // 组装返回数据
        Map<String, String> signMap = new HashMap<>();
        signMap.put("timestamp", timestamp);
        signMap.put("nonce", nonce);
        signMap.put("sign", sign);
        return signMap;
    }

    /**
     * 处理请求体body
     * @param body
     * @return
     */
    public static String handleBody(Object body) {
        String sortedBody;
        if (Objects.isNull(body)) {
            sortedBody = "";
        } else if (body instanceof String) {
            String dataStr = (String) body;
            sortedBody = dataStr;
            boolean isJsonStr = JSONValidator.from(dataStr).validate();
            if (isJsonStr) {
                // 对请求体内json进行字典排序
                sortedBody = JSON.toJSONString(JSON.parse(dataStr), SerializerFeature.MapSortField);
            }
        } else {
            // 对请求体内json进行字典排序
            sortedBody = JSON.toJSONString(body, SerializerFeature.MapSortField);
        }
        return sortedBody;
    }

    /**
     * 生成签名
     * @param timestamp
     * @param nonce
     * @param sortedBody
     * @return
     */
    public static String generateSign(String timestamp, String nonce, String sortedBody) {
        // 生成签名
        Map<String, String> tempMap = new HashMap<>();
        tempMap.put("timestamp", timestamp);
        tempMap.put("nonce", nonce);
        tempMap.put("data", sortedBody);
        String tempStr = JSON.toJSONString(tempMap, SerializerFeature.MapSortField);
        // 加动态盐
        int index = tempStr.length() % nonce.length() / 2;
        String salt = nonce.substring(index);
        tempStr += salt;
        return DigestUtil.sha256Hex(tempStr);
    }
}
