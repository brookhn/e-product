package com.jiahui.im.modules.common.dto.his.patient;

import lombok.Data;

@Data
public class PatientReportRespDto {
	
	private String reportType;
	
	private String reportTime;
	
	private String reportStatus;
	
	private String checkName;
	
	private String isRead;
}
