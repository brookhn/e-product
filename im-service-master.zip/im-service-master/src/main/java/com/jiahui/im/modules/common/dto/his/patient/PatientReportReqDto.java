package com.jiahui.im.modules.common.dto.his.patient;

import lombok.Data;

@Data
public class PatientReportReqDto {
	
	private String mrn;
	
	private String beginTime;
	
	private String endTime;
	
}
