package com.jiahui.im.modules.common.dto.bigfront;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.ToString;

import java.util.Date;
import java.util.List;

@Data
@ToString
public class UserInfoDto {
	/**
	 * 用户ID
	 */
	private Long id;

	/**
	 * 头像
	 */
	private String avatar;

	/**
	 * 性别 0-未知 1-男 2-女
	 */
	private String gender;

	/**
	 * 昵称
	 */
	private String nickName;

	/**
	 * 手机号
	 */
	private String phone;

	/**
	 * 注册来源编码
	 */
	private String terminal;

	/**
	 * 注册时间
	 */
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
	private Date createTime;

	/**
	 * 绑定列表
	 */
	private List<Relation> patientRelationList;

	@Data
	public static class Relation {
		/**
		 * 授权关系
		 */
		private Integer authRelation;

		/**
		 * 病人MRN
		 */
		private String patientCode;
	}
}
