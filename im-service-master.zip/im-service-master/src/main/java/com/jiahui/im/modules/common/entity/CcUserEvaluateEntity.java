package com.jiahui.im.modules.common.entity;

import java.io.Serializable;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * cc_user_evaluate
 * @author 
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CcUserEvaluateEntity implements Serializable {
    /**
     * 主键
     */
    private Long id;

    /**
     * 会话id
     */
    private String conversationId;

    /**
     * 用户id
     */
    private Long userId;

    /**
     * 评价分数 1-满意 2-一般 3-不满意
     */
    private Integer score;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

    private static final long serialVersionUID = 1L;
}