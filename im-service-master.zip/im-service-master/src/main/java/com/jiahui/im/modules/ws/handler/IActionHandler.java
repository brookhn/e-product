package com.jiahui.im.modules.ws.handler;

import com.jiahui.im.modules.ws.vo.WsRequestIn;
import org.tio.core.ChannelContext;

public interface IActionHandler {

    /**
     * 指令类型
     * @return
     */
    String getAction();

    /**
     * 客服类型
     * @return
     */
    Integer getKefuType();

    /**
     * 处理当前请求
     * @param channelContext
     * @param wsRequestIn
     * @return
     */
    void handle(ChannelContext channelContext, WsRequestIn wsRequestIn);
}
