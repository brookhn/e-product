package com.jiahui.im;

import com.alibaba.fastjson.JSON;
import com.jiahui.im.modules.common.dto.his.patient.PatientRespDto;
import com.jiahui.im.modules.common.service.HisService;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.HashSet;
import java.util.List;

/**
 * @author Tommy
 * @date 2021/06/09
 */
public class HisTest extends ApplicationTest{

    @Autowired
    private HisService hisService;

    @Test
    public void test() {
        HashSet<String> set = new HashSet<>();
        set.add("0016001207");
        List<PatientRespDto> patientRespDtos = hisService.batchPatientInfo(set);
        System.out.println(JSON.toJSONString(patientRespDtos, true));
    }
}
