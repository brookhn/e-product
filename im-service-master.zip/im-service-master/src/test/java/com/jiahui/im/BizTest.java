package com.jiahui.im;

import org.junit.Test;

/**
 * @author Tommy
 * @date 2021/06/09
 */
public class BizTest extends ApplicationTest{

    @Test
    public void test1() {

    }
}
