package com.jiahui.framework.datasource.helper;

import com.alibaba.nacos.api.NacosFactory;
import com.alibaba.nacos.api.config.ConfigService;
import com.alibaba.nacos.api.exception.NacosException;
import com.jiahui.framework.datasource.config.JiaHuiDataSourceProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Properties;

public class MyNacosClient {
    private static final MyNacosClient instance = new MyNacosClient();
    private volatile ConfigService configService;
    private static final Logger logger = LoggerFactory.getLogger(MyNacosClient.class);

    private ConfigService getConfigServiceCore(JiaHuiDataSourceProperties properties) {
        if (configService == null) {
            synchronized (this) {
                if (configService == null) {
                    Properties nacosProperties = new Properties();
                    nacosProperties.put("serverAddr", properties.getNacosServerAddr());
                    nacosProperties.put("username", properties.getNacosUserName());
                    nacosProperties.put("password", properties.getNacosPassword());
                    nacosProperties.put("namespace",properties.getNacosNamespace());
                    try {
                        configService = NacosFactory.createConfigService(nacosProperties);
                    } catch (NacosException e) {
                        logger.error("initNacosClientErr:{}", e.getMessage(), e);
                        throw new RuntimeException("initNacosClientErr", e);
                    }
                }
            }
        }
        return configService;
    }

    public static ConfigService getConfigService(JiaHuiDataSourceProperties properties) {
        return instance.getConfigServiceCore(properties);
    }

}
