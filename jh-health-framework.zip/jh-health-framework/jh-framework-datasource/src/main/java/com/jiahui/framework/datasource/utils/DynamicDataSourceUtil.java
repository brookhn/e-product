package com.jiahui.framework.datasource.utils;

import com.alibaba.nacos.api.NacosFactory;
import com.alibaba.nacos.api.config.ConfigService;
import com.alibaba.nacos.api.exception.NacosException;
import com.jiahui.framework.datasource.consts.CommonConst;
import com.jiahui.framework.datasource.domain.SecretKeyEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.io.StringReader;
import java.util.Properties;

public class DynamicDataSourceUtil {
    private static final DynamicDataSourceUtil instance = new DynamicDataSourceUtil();
    private volatile ConfigService configService;
    private static final Logger logger = LoggerFactory.getLogger(DynamicDataSourceUtil.class);
    private static volatile SecretKeyEntity entity = null;

    private ConfigService getConfigServiceCore(String serverAddr, String userName, String password, String namespace) {
        if (configService == null) {
            synchronized (this) {
                if (configService == null) {
                    Properties nacosProperties = new Properties();
                    nacosProperties.put("serverAddr", serverAddr);
                    nacosProperties.put("username", userName);
                    nacosProperties.put("password", password);
                    nacosProperties.put("namespace", namespace);
                    try {
                        configService = NacosFactory.createConfigService(nacosProperties);
                    } catch (NacosException e) {
                        logger.error("initNacosClientErr:{}", e.getMessage(), e);
                        throw new RuntimeException("initNacosClientErr", e);
                    }
                }
            }
        }
        return configService;
    }

    public synchronized static SecretKeyEntity getSecretKeyConfig(String serverAddr, String namespace) throws NacosException, IOException {
        if (entity != null && StringUtils.hasText(entity.getPrivateKey()) && StringUtils.hasText(entity.getPublicKey())) {
            return entity;
        }
        String userName = "data-source";
        String password = "Mr7a4jfjKX3CSTmrUO8b";
        ConfigService configService = instance.getConfigServiceCore(serverAddr, userName, password, namespace);
        String secretKeyContent = configService.getConfig(CommonConst.DB_SECRET_KEY_FILE, CommonConst.DATA_SOURCE_GROUP, 5000);
        if (!StringUtils.hasText(secretKeyContent)) {
            throw new RuntimeException(CommonConst.DB_SECRET_KEY_FILE + "未配置");
        }
        Properties properties = new Properties();
        properties.load(new StringReader(secretKeyContent));
        String encryptedPrivateKey = properties.getProperty("db.privateKey");
        String encryptedPublicKey = properties.getProperty("db.publicKey");
        String privateKey = EncryptUtil.encryptByDecrypt(encryptedPrivateKey);
        String publicKey = EncryptUtil.encryptByDecrypt(encryptedPublicKey);
        entity = new SecretKeyEntity(privateKey, publicKey);
        return entity;
    }
}
