package com.jiahui.framework.datasource.consts;

/**
 * 环境配置管理类
 */
public class DataSourceConst {

    //约定的DBA_GROUP和配置文件后缀properties
    public static final String DBA_GROUP = "DBA_GROUP";

    public static final String DRIVER_CLASS_NAME = "spring.datasource.%s.driverClassName";
    public static final String JDBC_URL = "spring.datasource.%s.jdbcUrl";
    public static final String USER_NAME = "spring.datasource.%s.username";
    public static final String PASSWORD = "spring.datasource.%s.password";
    public static final String TYPE = "spring.datasource.%s.type";

    //数据库连接池hikari配置
    public static final String HIKARI_MINIMUM_IDLE = "spring.datasource.%s.minimumIdle";
    public static final String HIKARI_MAXIMUM_POOL_SIZE = "spring.datasource.%s.maximumPoolSize";
    public static final String HIKARI_READONLY = "spring.datasource.%s.readOnly";
    public static final String HIKARI_CONNECTION_TIME_OUT = "spring.datasource.%s.connectionTimeout";
    public static final String HIKARI_IDLE_TIMEOUT = "spring.datasource.%s.idleTimeout";
    public static final String HIKARI_MAX_LIFETIME = "spring.datasource.%s.maxLifetime";
    public static final String HIKARI_VALIDATION_TIMEOUT = "spring.datasource.%s.validationTimeout";
    public static final String HIKARI_CONNECTION_TEST_QUERY = "spring.datasource.%s.connectionTestQuery";
    public static final String HIKARI_CONNECTION_INIT_SQL = "spring.datasource.%s.connectionInitSql";

    //数据库连接池druid配置
    public static final String DRUID_INITIALSIZE = "spring.datasource.%s.initialSize";
    public static final String DRUID_MAXACTIVE = "spring.datasource.%s.maxActive";
    public static final String DRUID_MINIDLE = "spring.datasource.%s.minIdle";
    public static final String DRUID_MAXWAIT = "spring.datasource.%s.maxWait";
    public static final String DRUID_KEEPALIVE = "spring.datasource.%s.keepAlive";
    public static final String DRUID_MIN_EVICTABLE_IDLE_TIME_MILLIS = "spring.datasource.%s.minEvictableIdleTimeMillis";
    public static final String DRUID_MAX_EVICTABLE_IDLE_TIME_MILLIS = "spring.datasource.%s.maxEvictableIdleTimeMillis";
    public static final String DRUID_CONNECTIONINITSQLS = "spring.datasource.%s.connectionInitSqls";
    public static final String DRUID_FILTERS = "spring.datasource.%s.filters";
    public static final String DRUID_TIMEBETWEENEVICTIONRUNSMILLIS = "spring.datasource.%s.timeBetweenEvictionRunsMillis";
    public static final String DRUID_VALIDATIONQUERY = "spring.datasource.%s.validationQuery";
    public static final String DRUID_VALIDATION_QUERY_TIMEOUT= "spring.datasource.%s.validationQueryTimeout";
    public static final String DRUID_TESTWHILEIDLE = "spring.datasource.%s.testWhileIdle";
    public static final String DRUID_TESTONBORROW = "spring.datasource.%s.testOnBorrow";
    public static final String DRUID_TESTONRETURN = "spring.datasource.%s.testOnReturn";
    public static final String DRUID_CONNECTION_ERROR_RETRY_ATTEMPTS = "spring.datasource.%s.connectionErrorRetryAttempts";
    public static final String DRUID_TIME_BETWEEN_CONNECT_ERROR_MILLIS = "spring.datasource.%s.timeBetweenConnectErrorMillis";
    public static final String DRUID_BREAK_AFTER_ACQUIRE_FAILURE = "spring.datasource.%s.breakAfterAcquireFailure";
}
