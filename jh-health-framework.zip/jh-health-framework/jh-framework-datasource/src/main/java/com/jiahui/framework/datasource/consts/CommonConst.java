package com.jiahui.framework.datasource.consts;

public interface CommonConst {
    String DB_SECRET_KEY_FILE = "db-secret-key.properties";
    String DATA_SOURCE_GROUP = "DATA-SOURCE";
}
