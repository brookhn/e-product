package com.jiahui.framework.datasource.utils;

import cn.hutool.core.codec.BCD;
import cn.hutool.core.util.StrUtil;
import cn.hutool.crypto.SmUtil;
import cn.hutool.crypto.asymmetric.KeyType;
import cn.hutool.crypto.asymmetric.SM2;
import cn.hutool.crypto.symmetric.AES;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

public class EncryptUtil {

    private static final Logger logger = LoggerFactory.getLogger(EncryptUtil.class);

    private static String KEY = "4jfjKX3CSTmrUO8b";
    private static String IV = "FCzOozQphUMFlQts";

    public static String decrypt(String str, String privateKey, String publicKey) {
        SM2 sm2 = SmUtil.sm2(BCD.strToBcd(privateKey), BCD.strToBcd(publicKey));
        try {
            String decryptStr = StrUtil.utf8Str(sm2.decryptFromBcd(str, KeyType.PrivateKey));
            return decryptStr;
        } catch (Exception ex) {
            logger.error("decryptErr:{}", ex.getMessage(), ex);
            throw new RuntimeException("decryptErr", ex);
        }
    }

    public static String encryptByDecrypt(String str) {
        if (!StringUtils.hasText(str)) {
            return "";
        }
        AES aes = new AES("CBC", "PKCS7Padding",
                // 密钥，可以自定义
                KEY.getBytes(),
                // iv加盐，按照实际需求添加
                IV.getBytes());
        return aes.decryptStr(str);
    }

}
