package com.jiahui.framework.datasource.helper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;


public class DataSourceHelp {
    private static final Logger log = LoggerFactory.getLogger(DataSourceHelp.class);

    private static final char[] ID_CHARACTERS = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();

    private static final ScheduledExecutorService scheduledExecutorService =
            Executors.newScheduledThreadPool(1, new ResourceReleaseThreadFactory());

    public static void asyncRelease(ReleaseDataSourceRunnable releaseDSRunnable) {
        scheduledExecutorService.schedule(releaseDSRunnable, 2, TimeUnit.SECONDS);
    }

    public static void shutdown() {
        if (!scheduledExecutorService.isShutdown()) {
            scheduledExecutorService.shutdown();
            log.info("close task of < release useless database connection pool > ");
        }
    }

//    /**
//     * 生成数据源名称
//     */
//    public static String generatePoolName(String prefix) {
//        prefix = (prefix == null || prefix.isEmpty()) ? "HikariPool-" : (prefix + "-HikariPool-");
//        try {
//            // Pool number is global to the VM to avoid overlapping pool numbers in classloader scoped environments
//            synchronized (System.getProperties()) {
//                final String next = String.valueOf(Integer.getInteger("com.zaxxer.hikari.pool_number", 0) + 1);
//                System.setProperty("com.zaxxer.hikari.pool_number", next);
//                return prefix + next;
//            }
//        } catch (AccessControlException e) {
//            // The SecurityManager didn't allow us to read/write system properties
//            // so just generate a random pool number instead
//            final ThreadLocalRandom random = ThreadLocalRandom.current();
//            final StringBuilder buf = new StringBuilder(prefix);
//
//            for (int i = 0; i < 4; i++) {
//                buf.append(ID_CHARACTERS[random.nextInt(62)]);
//            }
//
//            log.info("assigned random pool name '{}' (security manager prevented access to system properties)", buf);
//
//            return buf.toString();
//        }
//    }


}
