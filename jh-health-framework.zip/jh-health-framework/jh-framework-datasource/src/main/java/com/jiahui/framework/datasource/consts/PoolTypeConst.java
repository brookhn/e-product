package com.jiahui.framework.datasource.consts;

public interface PoolTypeConst {
    String HIKARI = "hikari";
    String DRUID = "druid";
}
