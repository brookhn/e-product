package com.jiahui.framework.datasource.core;

import com.jiahui.framework.datasource.consts.PoolTypeConst;
import com.jiahui.framework.datasource.domain.DataSourceConfigProperties;

import javax.sql.DataSource;

public class DataSourceFactory {

    public static DataSource createDataSource(DataSourceConfigProperties config) {
        IDataSourceManager dataSourceManager;
        if (config.getType().indexOf(PoolTypeConst.DRUID) > -1) {
            dataSourceManager = new DruidDataSourceManager();
        } else {
            dataSourceManager = new HikariDataSourceManager();
        }
        return dataSourceManager.createDataSource(config);
    }

}
