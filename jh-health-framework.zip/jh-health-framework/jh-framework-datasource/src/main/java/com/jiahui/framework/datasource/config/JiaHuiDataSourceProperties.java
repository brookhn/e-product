package com.jiahui.framework.datasource.config;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.EnvironmentAware;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.PriorityOrdered;
import org.springframework.core.env.Environment;

@Configuration
@ComponentScan(basePackages = {"com.jiahui.framework.datasource"})
public class JiaHuiDataSourceProperties implements EnvironmentAware, PriorityOrdered {

    @Value("${spring.application.name}")
    private String applicationName;

    @Value("${spring.cloud.nacos.config.server-addr}")
    private String configServerAddr;

    @Value("${spring.cloud.nacos.config.namespace}")
    private String configNamespace;

    @Value("${spring.profiles.active}")
    private String onProfile;

    /**
     * 解决druid log warn:discard long time none received connection
     */
    static {
        System.setProperty("druid.mysql.usePingMethod", "false");
    }

    private Environment env;

    @Override
    public void setEnvironment(Environment environment) {
        env = environment;
    }

    public String getApplicationName() {
        return applicationName;
    }

    public String getNacosServerAddr() {
        return configServerAddr;
    }

    public String getNacosUserName() {
        return "prod".equals(onProfile) ? "db-ticket-reader" : "db-reader";
    }

    public String getNacosPassword() {
        return "prod".equals(onProfile) ? "B50azhSbXntV8zR5ANYc" : "123456";
    }

    public String getNacosNamespace() {
        return configNamespace;
    }

    @Override
    public int getOrder() {
        return PriorityOrdered.HIGHEST_PRECEDENCE;
    }

}
