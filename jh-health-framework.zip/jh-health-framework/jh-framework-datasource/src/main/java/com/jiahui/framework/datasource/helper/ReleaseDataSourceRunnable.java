package com.jiahui.framework.datasource.helper;

import com.alibaba.druid.pool.DruidDataSource;
import com.zaxxer.hikari.HikariDataSource;
import com.zaxxer.hikari.HikariPoolMXBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sql.DataSource;


public class ReleaseDataSourceRunnable implements Runnable {
    private static final Logger log = LoggerFactory.getLogger(ReleaseDataSourceRunnable.class);

    private DataSource dataSource;
    private long startTime;
    private long forceCloseWaitSeconds = 300; //超过指定时间强制close,单位s

    public ReleaseDataSourceRunnable(DataSource dataSource, long forceCloseWaitSeconds) {
        this.dataSource = dataSource;
        this.forceCloseWaitSeconds = forceCloseWaitSeconds;
        startTime = System.currentTimeMillis();
    }

    private boolean forceClose() {
        //小于0不强制关闭
        if (forceCloseWaitSeconds < 0) {
            return false;
        }
        //等于0立刻关闭
        if (forceCloseWaitSeconds == 0) {
            return true;
        }
        //超时后关闭
        return (System.currentTimeMillis() - startTime) / 1000 > forceCloseWaitSeconds;
    }


    @Override
    public void run() {
        try {
            if (dataSource instanceof HikariDataSource) {
                HikariDataSource hikariDataSource = (HikariDataSource) this.dataSource;
                HikariPoolMXBean hikariPoolMXBean = hikariDataSource.getHikariPoolMXBean();
                if (hikariPoolMXBean != null) {
                    //evict idle connections
                    hikariPoolMXBean.softEvictConnections();

                    int activeConnections = hikariPoolMXBean.getActiveConnections();
                    if (activeConnections <= 0 || forceClose()) {
                        hikariDataSource.close();
                    } else {
                        DataSourceHelp.asyncRelease(this);
                    }
                } else {
                    hikariDataSource.close();
                }
            } else if (dataSource instanceof DruidDataSource) {
                DruidDataSource druidDataSource = (DruidDataSource) this.dataSource;
                int activeConnections = druidDataSource.getActiveCount();
                if (activeConnections <= 0 || forceClose()) {
                    druidDataSource.close();
                } else {
                    DataSourceHelp.asyncRelease(this);
                }
            }
        } catch (Exception e) {
            log.error("An exception occurred while releasing the old datasource:", e);
        }


    }
}
