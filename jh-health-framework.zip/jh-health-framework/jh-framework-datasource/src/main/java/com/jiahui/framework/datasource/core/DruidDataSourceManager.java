package com.jiahui.framework.datasource.core;

import com.alibaba.druid.DruidRuntimeException;
import com.alibaba.druid.pool.DruidDataSource;
import com.jiahui.framework.datasource.domain.DataSourceConfigProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import javax.sql.DataSource;
import java.sql.SQLException;

public class DruidDataSourceManager implements IDataSourceManager {

    private static Logger logger = LoggerFactory.getLogger(DruidDataSourceManager.class);

    @Override
    public DataSource createDataSource(DataSourceConfigProperties config) {
        DruidDataSource dataSource = new DruidDataSource();
        dataSource.setUrl(config.getJdbcUrl());
        dataSource.setUsername(config.getUsername());
        dataSource.setPassword(config.getPassword());
        dataSource.setDriverClassName(config.getDriverClassName());
        dataSource.setName(config.getName());
        dataSource.setInitialSize(config.getInitialSize());
        dataSource.setMaxActive(config.getMaxActive());
        dataSource.setMinIdle(config.getMinIdle());
        dataSource.setMaxWait(config.getMaxWait());
        dataSource.setValidationQuery(config.getValidationQuery());
        dataSource.setValidationQueryTimeout(config.getValidationQueryTimeout());

        if (config.getKeepAlive() != null) {
            dataSource.setKeepAlive(config.getKeepAlive());
        }
        if (config.getTimeBetweenEvictionRunsMillis() != null) {
            dataSource.setTimeBetweenEvictionRunsMillis(config.getTimeBetweenEvictionRunsMillis());
        }
        if (config.getMinEvictableIdleTimeMillis() != null) {
            dataSource.setMinEvictableIdleTimeMillis(config.getMinEvictableIdleTimeMillis());
        }
        if (config.getMaxEvictableIdleTimeMillis() != null) {
            dataSource.setMaxEvictableIdleTimeMillis(config.getMaxEvictableIdleTimeMillis());
        }
        if (config.isTestWhileIdle() != null) {
            dataSource.setTestWhileIdle(config.isTestWhileIdle());
        }
        if (config.isTestOnBorrow() != null) {
            dataSource.setTestOnBorrow(config.isTestOnBorrow());
        }
        if (config.isTestOnReturn() != null) {
            dataSource.setTestOnReturn(config.isTestOnReturn());
        }
        if (!CollectionUtils.isEmpty(config.getConnectionInitSqls())) {
            dataSource.setConnectionInitSqls(config.getConnectionInitSqls());
        }
        if (config.getConnectionErrorRetryAttempts() != null) {
            dataSource.setConnectionErrorRetryAttempts(config.getConnectionErrorRetryAttempts());
        }
        if (config.getTimeBetweenConnectErrorMillis() != null) {
            dataSource.setTimeBetweenConnectErrorMillis(config.getTimeBetweenConnectErrorMillis());
        }
        if (config.getBreakAfterAcquireFailure() != null) {
            dataSource.setBreakAfterAcquireFailure(config.getBreakAfterAcquireFailure());
        }
        try {
            if (StringUtils.hasText(config.getFilters())) {
                dataSource.setFilters(config.getFilters());
            }
            dataSource.init();
            logger.info("DruidDataSource Start Completed");
        } catch (SQLException ex) {
            throw new DruidRuntimeException("DruidDataSourceInitErr", ex);
        }
        return dataSource;
    }

}
