//package com.jiahui.framework.datasource.config;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.boot.SpringApplication;
//import org.springframework.boot.env.EnvironmentPostProcessor;
//import org.springframework.boot.env.PropertiesPropertySourceLoader;
//import org.springframework.core.Ordered;
//import org.springframework.core.env.ConfigurableEnvironment;
//import org.springframework.core.env.PropertySource;
//import org.springframework.core.io.Resource;
//import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
//import org.springframework.core.io.support.ResourcePatternResolver;
//
//import java.io.IOException;
//import java.util.List;
//
//public class ProfileEnvironmentPostProcessor implements EnvironmentPostProcessor, Ordered {
//
//    private static Logger logger = LoggerFactory.getLogger(ProfileEnvironmentPostProcessor.class);
//
//    @Override
//    public void postProcessEnvironment(ConfigurableEnvironment environment, SpringApplication application) {
//        ResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
//        try {
//            Resource[] resources = resolver.getResources("classpath*:jh-datasource.properties");
//            // 加载配置
//            PropertySource<?> source = loadProfiles(resources[0]);
//            // 添加到Environment
//            environment.getPropertySources().addFirst(source);
//        } catch (IOException e) {
//            logger.error("ProfileEnvironmentPostProcessor postProcessEnvironment error ", e);
//        }
//
//    }
//
//    @Override
//    public int getOrder() {
//        return 0;
//    }
//
//    private PropertySource<?> loadProfiles(Resource resource) throws IOException {
//        PropertiesPropertySourceLoader sourceLoader = new PropertiesPropertySourceLoader();
//        List<PropertySource<?>> propertySources = sourceLoader.load(resource.getFilename(), resource);
//        return propertySources.get(0);
//    }
//}