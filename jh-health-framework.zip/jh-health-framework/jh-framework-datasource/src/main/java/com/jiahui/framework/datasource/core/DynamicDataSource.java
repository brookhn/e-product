package com.jiahui.framework.datasource.core;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.nacos.api.config.ConfigService;
import com.jiahui.framework.datasource.config.JiaHuiDataSourceProperties;
import com.jiahui.framework.datasource.consts.DataSourceConst;
import com.jiahui.framework.datasource.domain.DataSourceConfigProperties;
import com.jiahui.framework.datasource.domain.SecretKeyEntity;
import com.jiahui.framework.datasource.helper.DataSourceConfigHelper;
import com.jiahui.framework.datasource.helper.DataSourceHelp;
import com.jiahui.framework.datasource.helper.MyNacosClient;
import com.jiahui.framework.datasource.helper.ReleaseDataSourceRunnable;
import com.jiahui.framework.datasource.utils.DynamicDataSourceUtil;
import com.zaxxer.hikari.HikariDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.jdbc.datasource.AbstractDataSource;
import org.springframework.util.StringUtils;

import javax.sql.DataSource;
import java.io.Closeable;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;


public class DynamicDataSource extends AbstractDataSource implements DisposableBean, Closeable {
    private static final Logger log = LoggerFactory.getLogger(DynamicDataSource.class);

//    private volatile DataSource dataSource;
//
//    private final ReadWriteLock readWriteLock = new ReentrantReadWriteLock();
//    private final Lock readLock = readWriteLock.readLock();
//    private final Lock writeLock = readWriteLock.writeLock();

    private final AtomicReference<DataSource> atomicDataSource = new AtomicReference<>();

    protected DynamicDataSource() {

    }

    public DynamicDataSource(String dbName, JiaHuiDataSourceProperties dataSourceProperties) {
        try {
            ConfigService configService = MyNacosClient.getConfigService(dataSourceProperties);
            String appName = dataSourceProperties.getApplicationName();
            String fileName = String.format("%s-jdbc.properties", appName);
            String content = configService.getConfig(fileName, DataSourceConst.DBA_GROUP, 5000);
            if (!StringUtils.hasText(content)) {
                throw new RuntimeException(fileName + "不存在");
            }
            SecretKeyEntity secretKeyEntity = DynamicDataSourceUtil.getSecretKeyConfig(dataSourceProperties.getNacosServerAddr()
                    , dataSourceProperties.getNacosNamespace());
            String privateKey = secretKeyEntity.getPrivateKey();
            String publicKey = secretKeyEntity.getPublicKey();
            List<DataSourceConfigProperties> configs = DataSourceConfigHelper.resolveConfig(content, privateKey, publicKey);
            DataSourceConfigProperties configProperties = configs.stream().filter(p -> dbName.equalsIgnoreCase(p.getName())).findFirst().orElse(null);
            if (configProperties == null) {
                throw new RuntimeException(dbName + "数据库未找到对应的配置");
            }
            DataSource dataSource = DataSourceFactory.createDataSource(configProperties);
            atomicDataSource.set(dataSource);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw new RuntimeException("DynamicDataSourceInitErr", e);
        }
    }

    @Override
    public Connection getConnection() throws SQLException {
        return determineTargetDataSource().getConnection();
    }

    @Override
    public Connection getConnection(String username, String password) throws SQLException {
        return determineTargetDataSource().getConnection(username, password);
    }

    /**
     * 线程安全
     */
    public void updateDataSource(DataSourceConfigProperties configProperties, long forceCloseWaitSeconds) {
//        Exception exception = null;
//        try {
//            writeLock.lock();
//            createNewDataSource(configProperties, forceCloseWaitSeconds);
//        } catch (Exception e) {
//            exception = e;
//        } finally {
//            writeLock.unlock();
//        }
//        if (exception != null) {
//            log.error("更新数据源时出现异常:", exception);
//        }
        createNewDataSource(configProperties, forceCloseWaitSeconds);
    }

    public DataSource determineTargetDataSource() {
//        try {
//            readLock.lock();
//            return dataSource;
//        } catch (Exception e) {
//            log.error("获取数据源时出现异常:", e);
//        } finally {
//            readLock.unlock();
//        }
//        throw new DataSourceLookupFailureException("未查询到数据源");
        return atomicDataSource.get();
    }

    private void createNewDataSource(DataSourceConfigProperties config, long forceCloseWaitSeconds) {
//        DataSource releaseDataSource = dataSource;
//        dataSource = DataSourceFactory.createDataSource(config);
        DataSource dataSource = DataSourceFactory.createDataSource(config);
        //cas 原子更新
        DataSource releaseDataSource = atomicDataSource.getAndSet(dataSource);
        if (releaseDataSource != null) {
            //即使在新数据源创建后再去关闭老数据源,还是不能保证老数据源获取连接前不被关闭
            //使用延时任务关闭数据源
            DataSourceHelp.asyncRelease(new ReleaseDataSourceRunnable(releaseDataSource, forceCloseWaitSeconds));
        }
    }

    @Override
    public void close() {
        DataSource dataSource = atomicDataSource.get();
        if (dataSource != null) {
            if (dataSource instanceof HikariDataSource) {
                HikariDataSource hikariDataSource = (HikariDataSource) dataSource;
                hikariDataSource.close();
            } else if (dataSource instanceof DruidDataSource) {
                DruidDataSource druidDataSource = (DruidDataSource) dataSource;
                druidDataSource.close();
            }
        }
    }

    @Override
    public void destroy() {
        DataSourceHelp.shutdown();
        close();
    }

}
