package com.jiahui.framework.datasource.config;

import com.jiahui.framework.datasource.core.DynamicDataSource;
import com.zaxxer.hikari.HikariConfigMXBean;
import com.zaxxer.hikari.HikariDataSource;
import com.zaxxer.hikari.metrics.micrometer.MicrometerMetricsTrackerFactory;
import io.micrometer.core.instrument.MeterRegistry;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.autoconfigure.metrics.MetricsAutoConfiguration;
import org.springframework.boot.actuate.autoconfigure.metrics.export.simple.SimpleMetricsExportAutoConfiguration;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.jdbc.DataSourceUnwrapper;
import org.springframework.boot.jdbc.metadata.DataSourcePoolMetadataProvider;
import org.springframework.boot.jdbc.metadata.HikariDataSourcePoolMetadata;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;
import java.util.Collection;

@Configuration(proxyBeanMethods = false)
@AutoConfigureAfter({MetricsAutoConfiguration.class, DataSourceAutoConfiguration.class,
        SimpleMetricsExportAutoConfiguration.class})
@ConditionalOnClass({DataSource.class, MeterRegistry.class})
@ConditionalOnBean({DataSource.class, MeterRegistry.class})
@ConditionalOnProperty(name = "dynamic-datasource.metric.disable", havingValue = "false", matchIfMissing = true)
public class DynamicDataSourceMetricAutoConfig {

    @Bean
    public DataSourcePoolMetadataProvider jiaHuiHikariDataSourceMetadataProvider() {
        return (dataSource) -> {
            if (dataSource instanceof DynamicDataSource) {
                DynamicDataSource dynamicDataSource = (DynamicDataSource) dataSource;
                DataSource ds = dynamicDataSource.determineTargetDataSource();
                if (ds instanceof HikariDataSource) {
                    HikariDataSource hikariDataSource = DataSourceUnwrapper.unwrap(ds, HikariConfigMXBean.class,
                            HikariDataSource.class);
                    if (hikariDataSource != null) {
                        return new HikariDataSourcePoolMetadata(hikariDataSource);
                    }
                    return null;
                }
            }
            return null;
        };
    }

    @Configuration(proxyBeanMethods = false)
    @ConditionalOnClass(HikariDataSource.class)
    @ConditionalOnProperty(name = "dynamic-datasource.metric.disable", havingValue = "false", matchIfMissing = true)
    static class JiaHuiHikariDataSourceMetricsConfig {

        private static final Log logger = LogFactory.getLog(JiaHuiHikariDataSourceMetricsConfig.class);

        private final MeterRegistry registry;

        JiaHuiHikariDataSourceMetricsConfig(MeterRegistry registry) {
            this.registry = registry;
        }

        @Autowired
        void bindMetricsRegistry2MyHikariDataSources(Collection<DataSource> dataSources) {
            for (DataSource dataSource : dataSources) {
                if (dataSource instanceof DynamicDataSource) {
                    DynamicDataSource dynamicDataSource = (DynamicDataSource) dataSource;
                    DataSource ds = dynamicDataSource.determineTargetDataSource();
                    if (ds instanceof HikariDataSource) {
                        HikariDataSource hikariDataSource = DataSourceUnwrapper.unwrap(ds, HikariConfigMXBean.class,
                                HikariDataSource.class);
                        if (hikariDataSource != null) {
                            bindMetricsRegistry2MyHikariDataSource(hikariDataSource);
                        }
                    }
                }
            }
        }

        private void bindMetricsRegistry2MyHikariDataSource(HikariDataSource hikari) {
            if (hikari.getMetricRegistry() == null && hikari.getMetricsTrackerFactory() == null) {
                try {
                    hikari.setMetricsTrackerFactory(new MicrometerMetricsTrackerFactory(this.registry));
                } catch (Exception ex) {
                    logger.warn(ex.getMessage(), ex);
                }
            }
        }

    }

}
