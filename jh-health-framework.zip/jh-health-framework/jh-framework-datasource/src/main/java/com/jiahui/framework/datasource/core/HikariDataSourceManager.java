package com.jiahui.framework.datasource.core;

import com.jiahui.framework.datasource.domain.DataSourceConfigProperties;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import javax.sql.DataSource;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class HikariDataSourceManager implements IDataSourceManager {

    private static Logger logger = LoggerFactory.getLogger(HikariDataSourceManager.class);
    private DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");

    private HikariConfig convert2HikariConfig(DataSourceConfigProperties config) {
        HikariConfig hikariConfig = new HikariConfig();
        hikariConfig.setJdbcUrl(config.getJdbcUrl());
        hikariConfig.setUsername(config.getUsername());
        hikariConfig.setPassword(config.getPassword());
        hikariConfig.setDriverClassName(config.getDriverClassName());
        hikariConfig.setMinimumIdle(config.getMinimumIdle());
        hikariConfig.setMaximumPoolSize(config.getMaximumPoolSize());

        if (config.getIdleTimeout() != null) {
            hikariConfig.setIdleTimeout(config.getIdleTimeout());
        }
        if (config.getMaxLifetime() != null) {
            hikariConfig.setMaxLifetime(config.getMaxLifetime());
        }
        if (config.getConnectionTimeout() == null) {
            hikariConfig.setConnectionTimeout(30000);
        } else {
            hikariConfig.setConnectionTimeout(config.getConnectionTimeout());
        }
        if (config.getValidationTimeout() != null) {
            hikariConfig.setValidationTimeout(config.getValidationTimeout());
        }
        if (StringUtils.hasText(config.getConnectionTestQuery())) {
            hikariConfig.setConnectionTestQuery(config.getConnectionTestQuery());
        }
        if (StringUtils.hasText(config.getConnectionInitSql())) {
            hikariConfig.setConnectionInitSql(config.getConnectionInitSql());
        }
        hikariConfig.setPoolName(config.getPoolName() + LocalDateTime.now().format(formatter));
        return hikariConfig;
    }

    @Override
    public DataSource createDataSource(DataSourceConfigProperties config) {
        HikariConfig hikariConfig = convert2HikariConfig(config);
        HikariDataSource dataSource = new HikariDataSource(hikariConfig);
        logger.info("HikariDataSource Start Completed");
        return dataSource;
    }
}
