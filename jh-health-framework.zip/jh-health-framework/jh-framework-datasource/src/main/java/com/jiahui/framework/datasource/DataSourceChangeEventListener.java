package com.jiahui.framework.datasource;

import com.alibaba.nacos.api.config.ConfigService;
import com.alibaba.nacos.api.config.listener.Listener;
import com.jiahui.framework.datasource.config.JiaHuiDataSourceProperties;
import com.jiahui.framework.datasource.consts.DataSourceConst;
import com.jiahui.framework.datasource.core.DynamicDataSource;
import com.jiahui.framework.datasource.utils.DynamicDataSourceUtil;
import com.jiahui.framework.datasource.domain.DataSourceConfigProperties;
import com.jiahui.framework.datasource.domain.SecretKeyEntity;
import com.jiahui.framework.datasource.helper.DataSourceConfigHelper;
import com.jiahui.framework.datasource.helper.MyNacosClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;

@Component
public class DataSourceChangeEventListener implements ApplicationListener<ApplicationReadyEvent>, ApplicationContextAware {

    private static Logger logger = LoggerFactory.getLogger(DataSourceChangeEventListener.class);

    @Value("${spring.datasource.dynamic.forceCloseWaitSeconds:300}")
    private int forceCloseWaitSeconds = 300;

    @Value("${spring.datasource.dynamic.switch:true}")
    private boolean dynamicSwitch;

    private ApplicationContext context;

    @Autowired
    private JiaHuiDataSourceProperties dataSourceProperties;

    private volatile AtomicBoolean initFlag = new AtomicBoolean(false);

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.context = applicationContext;
    }

    @Override
    public void onApplicationEvent(ApplicationReadyEvent readyEvent) {
        logger.info("DataSourceChangeEventListener start...");
        //防止重复触发
        if (!initFlag.compareAndSet(false, true)) {
            return;
        }
        try {

            SecretKeyEntity secretKeyEntity = DynamicDataSourceUtil.getSecretKeyConfig(dataSourceProperties.getNacosServerAddr(),
                    dataSourceProperties.getNacosNamespace());
            String privateKey = secretKeyEntity.getPrivateKey();
            String publicKey = secretKeyEntity.getPublicKey();

            ConfigService configService = MyNacosClient.getConfigService(dataSourceProperties);
            configService.addListener(String.format("%s-jdbc.properties", dataSourceProperties.getApplicationName()), DataSourceConst.DBA_GROUP, new Listener() {
                @Override
                public void receiveConfigInfo(String configInfo) {
                    try {
                        if (!StringUtils.hasText(configInfo) || !dynamicSwitch) {
                            return;
                        }
                        logger.info("receiveConfigInfo:{}", configInfo);
                        List<DataSourceConfigProperties> configs = DataSourceConfigHelper.resolveConfig(configInfo, privateKey, publicKey);
                        if (CollectionUtils.isEmpty(configs)) {
                            return;
                        }

                        if (configs.size() == 1) {
                            DynamicDataSource dataSource = context.getBean(DynamicDataSource.class);
                            dataSource.updateDataSource(configs.get(0), forceCloseWaitSeconds);
                        } else {
                            for (DataSourceConfigProperties dbProp : configs) {
                                DynamicDataSource dataSource = context.getBean(dbProp.getName(), DynamicDataSource.class);
                                dataSource.updateDataSource(dbProp, forceCloseWaitSeconds);
                            }
                        }
                    } catch (Throwable throwable) {
                        logger.error("receiveConfigInfo resolve fail ", throwable);
                    }
                }

                @Override
                public Executor getExecutor() {
                    return null;
                }
            });
        } catch (Exception e) {
            logger.error("listenDataSourceConfigErr:{}", e.getMessage(), e);
        }

    }

}
