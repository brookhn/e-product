package com.jiahui.framework.datasource.helper;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.jiahui.framework.datasource.consts.DataSourceConst;
import com.jiahui.framework.datasource.consts.PoolTypeConst;
import com.jiahui.framework.datasource.domain.DataSourceConfigProperties;
import com.jiahui.framework.datasource.utils.EncryptUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class DataSourceConfigHelper {

    private static final Logger logger = LoggerFactory.getLogger(DataSourceConfigHelper.class);

    private static final String DB_PREFIX = "spring.datasource.";

    private static final String DB_PATTERN = "spring.datasource.*.jdbcUrl";

    private static final String DB_KEY_JDBC = ".jdbcUrl";

    /**
     * 获取nacos数据源配置类
     *
     * @param config
     * @return
     */
    public static List<DataSourceConfigProperties> resolveConfig(String config, String privateKey, String publicKey) {
        List<DataSourceConfigProperties> dbProps = Lists.newArrayList();
        Map<String, Object> configMap = convertToMap(config);
        Set<String> dbNames = getDataSourceNames(configMap);
        for (String dbName : dbNames) {
            DataSourceConfigProperties p = map2ConfigProperties(dbName, configMap, privateKey, publicKey);
            dbProps.add(p);
        }
        return dbProps;
    }

    public static Set<String> getDataSourceNames(Map<String, Object> configMap) {
        Set<String> dbNames = Sets.newHashSet();
        for (String key : configMap.keySet()) {
            if (key.matches(DB_PATTERN)) {
                dbNames.add(key.substring(key.indexOf(DB_PREFIX) + DB_PREFIX.length(), key.lastIndexOf(DB_KEY_JDBC)));
            }
        }
        return dbNames;
    }


    private static Map<String, Object> convertToMap(String content) {
        Map<String, Object> configMap = new LinkedHashMap<>();
        Properties properties = new Properties();
//        if ("yaml".equals(fileExtension)) {
//            ByteArrayResource resource = new ByteArrayResource(content.getBytes(Charset.forName("UTF-8")));
//            YamlPropertiesFactoryBean yamlFactory = new YamlPropertiesFactoryBean();
//            yamlFactory.setResources(resource);
//            properties = yamlFactory.getObject();
//        } else {
        ByteArrayInputStream inputStream = new ByteArrayInputStream(content.getBytes(StandardCharsets.UTF_8));
        try {
            properties.load(inputStream);
        } catch (IOException ex) {
            logger.error("loadPropertiesErr:{}", ex.getMessage(), ex);
        }
//        }
        for (Map.Entry<Object, Object> entry : properties.entrySet()) {
            configMap.put(entry.getKey().toString(), entry.getValue());
        }
        return configMap;
    }

    private static String getDriverClassName(Map<String, Object> configMap, String dbName) {
        Object obj = configMap.get(String.format(DataSourceConst.DRIVER_CLASS_NAME, dbName));
        Assert.notNull(obj, String.format("%s driverClassName is required", dbName));
        return obj.toString();
    }

    private static String getJdbcUrl(Map<String, Object> configMap, String dbName) {
        Object obj = configMap.get(String.format(DataSourceConst.JDBC_URL, dbName));
        Assert.notNull(obj, String.format("%s JdbcUrl is required", dbName));
        return obj.toString();
    }

    private static String getUsername(Map<String, Object> configMap, String dbName) {
        Object obj = configMap.get(String.format(DataSourceConst.USER_NAME, dbName));
        Assert.notNull(obj, String.format("%s username is required", dbName));
        return obj.toString();
    }

    private static String getPassword(Map<String, Object> configMap, String dbName) {
        Object obj = configMap.get(String.format(DataSourceConst.PASSWORD, dbName));
        Assert.notNull(obj, String.format("%s password is required", dbName));
        return obj.toString();
    }

    private static String getType(Map<String, Object> configMap, String dbName) {
        Object obj = configMap.get(String.format(DataSourceConst.TYPE, dbName));
        if (Objects.isNull(obj)) {
            return PoolTypeConst.HIKARI;
        }
        return obj.toString();
    }

    private static DataSourceConfigProperties map2ConfigProperties(String dbName, Map<String, Object> configMap, String privateKey, String publicKey) {
        DataSourceConfigProperties dbProp = new DataSourceConfigProperties();
        //datasource通用配置
        dbProp.setName(dbName);
        dbProp.setPoolName(dbName);
        dbProp.setDriverClassName(getDriverClassName(configMap, dbName));
        String jdbcUrl = getJdbcUrl(configMap, dbName);
        dbProp.setJdbcUrl(EncryptUtil.decrypt(jdbcUrl, privateKey, publicKey));
        String username = getUsername(configMap, dbName);
        dbProp.setUsername(EncryptUtil.decrypt(username, privateKey, publicKey));
        String password = getPassword(configMap, dbName);
        dbProp.setPassword(EncryptUtil.decrypt(password, privateKey, publicKey));
        dbProp.setType(getType(configMap, dbName));

        //hikariCP连接池配置
        Object minimumIdle = configMap.get(String.format(DataSourceConst.HIKARI_MINIMUM_IDLE, dbName));
        if (Objects.nonNull(minimumIdle)) {
            dbProp.setMinimumIdle(Integer.parseInt(minimumIdle.toString()));
        }
        Object maximumPoolSize = configMap.get(String.format(DataSourceConst.HIKARI_MAXIMUM_POOL_SIZE, dbName));
        if (Objects.nonNull(maximumPoolSize)) {
            dbProp.setMaximumPoolSize(Integer.parseInt(maximumPoolSize.toString()));
        }
        Object idleTimeout = configMap.get(String.format(DataSourceConst.HIKARI_IDLE_TIMEOUT, dbName));
        if (Objects.nonNull(idleTimeout)) {
            dbProp.setIdleTimeout(Long.parseLong(idleTimeout.toString()));
        }
        Object maxLifetime = configMap.get(String.format(DataSourceConst.HIKARI_MAX_LIFETIME, dbName));
        if (Objects.nonNull(maxLifetime)) {
            dbProp.setMaxLifetime(Long.parseLong(maxLifetime.toString()));
        }
        Object connectionTimeout = configMap.get(String.format(DataSourceConst.HIKARI_CONNECTION_TIME_OUT, dbName));
        if (Objects.nonNull(connectionTimeout)) {
            dbProp.setConnectionTimeout(Long.parseLong(connectionTimeout.toString()));
        }
        Object validationTimeout = configMap.get(String.format(DataSourceConst.HIKARI_VALIDATION_TIMEOUT, dbName));
        if (validationTimeout != null) {
            dbProp.setValidationTimeout(Integer.parseInt(validationTimeout.toString()));
        }
        Object connectionTestQuery = configMap.get(String.format(DataSourceConst.HIKARI_CONNECTION_TEST_QUERY, dbName));
        if (connectionTestQuery != null) {
            dbProp.setConnectionTestQuery(connectionTestQuery.toString());
        }
        Object readOnly = configMap.get(String.format(DataSourceConst.HIKARI_READONLY, dbName));
        if (Objects.nonNull(readOnly)) {
            dbProp.setReadOnly(Boolean.parseBoolean(readOnly.toString().trim()));
        }
        Object connectionInitSql = configMap.get(String.format(DataSourceConst.HIKARI_CONNECTION_INIT_SQL, dbName));
        if (Objects.nonNull(connectionInitSql)) {
            dbProp.setConnectionInitSql(connectionInitSql.toString());
        }

        //druid数据库连接池配置
        Object initialSize = configMap.get(String.format(DataSourceConst.DRUID_INITIALSIZE, dbName));
        if (Objects.nonNull(initialSize)) {
            dbProp.setInitialSize(Integer.parseInt(initialSize.toString()));
        }
        Object maxActive = configMap.get(String.format(DataSourceConst.DRUID_MAXACTIVE, dbName));
        if (Objects.nonNull(maxActive)) {
            dbProp.setMaxActive(Integer.parseInt(maxActive.toString()));
        }
        Object minIdle = configMap.get(String.format(DataSourceConst.DRUID_MINIDLE, dbName));
        if (Objects.nonNull(minIdle)) {
            dbProp.setMinIdle(Integer.parseInt(minIdle.toString()));
        }
        Object maxWait = configMap.get(String.format(DataSourceConst.DRUID_MAXWAIT, dbName));
        if (Objects.nonNull(maxWait)) {
            dbProp.setMaxWait(Long.parseLong(maxWait.toString()));
        }
        Object keepAlive = configMap.get(String.format(DataSourceConst.DRUID_KEEPALIVE, dbName));
        if (Objects.nonNull(keepAlive)) {
            dbProp.setKeepAlive(Boolean.valueOf(keepAlive.toString()));
        }
        Object minEvictableIdleTimeMillis = configMap.get(String.format(DataSourceConst.DRUID_MIN_EVICTABLE_IDLE_TIME_MILLIS, dbName));
        if (Objects.nonNull(minEvictableIdleTimeMillis)) {
            dbProp.setMinEvictableIdleTimeMillis(Long.parseLong(minEvictableIdleTimeMillis.toString()));
        }
        Object maxEvictableIdleTimeMillis = configMap.get(String.format(DataSourceConst.DRUID_MAX_EVICTABLE_IDLE_TIME_MILLIS, dbName));
        if (Objects.nonNull(maxEvictableIdleTimeMillis)) {
            dbProp.setMaxEvictableIdleTimeMillis(Long.parseLong(maxEvictableIdleTimeMillis.toString()));
        }
        Object connectionInitSqls = configMap.get(String.format(DataSourceConst.DRUID_CONNECTIONINITSQLS, dbName));
        if (Objects.nonNull(connectionInitSqls) && com.alibaba.nacos.common.utils.StringUtils.isNotBlank(connectionInitSqls.toString())) {
            String[] sqls = connectionInitSqls.toString().split(",");
            List<String> strings = Arrays.asList(sqls);
            dbProp.setConnectionInitSqls(strings);
        }
        Object filters = configMap.get(String.format(DataSourceConst.DRUID_FILTERS, dbName));
        if (Objects.nonNull(filters)) {
            dbProp.setFilters(filters.toString());
        }
        Object timeBetweenEvictionRunsMillis = configMap.get(String.format(DataSourceConst.DRUID_TIMEBETWEENEVICTIONRUNSMILLIS, dbName));
        if (Objects.nonNull(timeBetweenEvictionRunsMillis)) {
            dbProp.setTimeBetweenEvictionRunsMillis(Long.parseLong(timeBetweenEvictionRunsMillis.toString()));
        }
        Object validationQuery = configMap.get(String.format(DataSourceConst.DRUID_VALIDATIONQUERY, dbName));
        if (Objects.nonNull(validationQuery)) {
            String validationQueryStr = validationQuery.toString();
            if (StringUtils.hasText(validationQueryStr)) {
                dbProp.setValidationQuery(validationQueryStr);
            }
        }
        Object validationQueryTimeout = configMap.get(String.format(DataSourceConst.DRUID_VALIDATION_QUERY_TIMEOUT, dbName));
        if (Objects.nonNull(validationQueryTimeout)) {
            dbProp.setValidationQueryTimeout(Integer.parseInt(validationQueryTimeout.toString()));
        }
        Object testWhileIdle = configMap.get(String.format(DataSourceConst.DRUID_TESTWHILEIDLE, dbName));
        if (Objects.nonNull(testWhileIdle)) {
            dbProp.setTestWhileIdle(Boolean.valueOf(testWhileIdle.toString()));
        }
        Object testOnBorrow = configMap.get(String.format(DataSourceConst.DRUID_TESTONBORROW, dbName));
        if (Objects.nonNull(testOnBorrow)) {
            dbProp.setTestOnBorrow(Boolean.valueOf(testOnBorrow.toString()));
        }
        Object testOnReturn = configMap.get(String.format(DataSourceConst.DRUID_TESTONRETURN, dbName));
        if (Objects.nonNull(testOnReturn)) {
            dbProp.setTestOnReturn(Boolean.valueOf(testOnReturn.toString()));
        }
        Object obj = configMap.get(String.format(DataSourceConst.DRUID_CONNECTION_ERROR_RETRY_ATTEMPTS, dbName));
        if (obj != null) {
            dbProp.setConnectionErrorRetryAttempts(Integer.parseInt(obj.toString()));
        }
        obj = configMap.get(String.format(DataSourceConst.DRUID_TIME_BETWEEN_CONNECT_ERROR_MILLIS, dbName));
        if (obj != null) {
            dbProp.setTimeBetweenConnectErrorMillis(Long.parseLong(obj.toString()));
        }
        obj = configMap.get(String.format(DataSourceConst.DRUID_BREAK_AFTER_ACQUIRE_FAILURE, dbName));
        if (obj != null) {
            dbProp.setBreakAfterAcquireFailure(Boolean.parseBoolean(obj.toString()));
        }
        return dbProp;
    }
}
