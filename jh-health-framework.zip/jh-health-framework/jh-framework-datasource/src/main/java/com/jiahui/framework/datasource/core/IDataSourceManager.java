package com.jiahui.framework.datasource.core;

import com.jiahui.framework.datasource.domain.DataSourceConfigProperties;

import javax.sql.DataSource;

public interface IDataSourceManager {
    DataSource createDataSource(DataSourceConfigProperties config);
}
