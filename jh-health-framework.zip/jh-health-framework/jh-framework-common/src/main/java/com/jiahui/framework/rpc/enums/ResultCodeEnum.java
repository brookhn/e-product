package com.jiahui.framework.rpc.enums;

public enum ResultCodeEnum {

    SUCCESS(200, ""),

    ERROR(5000, "系统异常"),

    NETWORK_ERROR(5001, "网络异常，请稍后重试"),

    VALIDATE_FAILED(10001, "参数校验失败");

    private int code;
    private String msg;

    ResultCodeEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public int getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }
}
