package com.jiahui.framework.openfegin.extension.config;

import com.jiahui.framework.utility.consts.TraceConst;
import com.jiahui.framework.utility.trace.MyThreadLocalHelper;
import feign.RequestInterceptor;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConditionalOnClass(FeignClient.class)
public class FeignTraceAutoConfiguration {
    @Bean
    public RequestInterceptor requestInterceptor() {
        RequestInterceptor requestInterceptor = template -> {
            String traceId = MyThreadLocalHelper.getTraceId();
            template.header(TraceConst.TRACE_ID, traceId);
        };
        return requestInterceptor;
    }
}
