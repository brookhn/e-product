package com.jiahui.framework.utility.consts;

public class TraceConst {
    public final static String TRACE_ID = "traceid";
    public static final String SKY_WALKING_IGNORE = "[Ignored Trace]";
}
