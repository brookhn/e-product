package com.jiahui.framework.utility.trace.aop;

import com.jiahui.framework.utility.consts.TraceConst;
import com.jiahui.framework.utility.trace.TraceIdUtil;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.MDC;

@Aspect
public class TraceIdAspect {

    @Pointcut("@annotation(com.jiahui.framework.utility.trace.annotations.TraceIdAop)")
    private void traceId() {
    }

    @Before("traceId()")
    public void before() {
        String traceId = TraceIdUtil.getTraceId();
        MDC.put(TraceConst.TRACE_ID, traceId);
    }

    @After("traceId()")
    public void after() {
        MDC.clear();
    }
}
