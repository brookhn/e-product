package com.jiahui.framework.utility.trace;

import com.alibaba.ttl.TransmittableThreadLocal;
import com.jiahui.framework.utility.consts.TraceConst;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class MyThreadLocalHelper {
    private final static ThreadLocal<Map<String, Object>> threadLocal = new TransmittableThreadLocal<>();

    public static void set(String key, Object value) {
        Map<String, Object> map = threadLocal.get();
        if (map == null) {
            map = new HashMap<>();
            threadLocal.set(map);
        }
        map.put(key, value);
    }

    public static Object get(String key) {
        Map<String, Object> map = threadLocal.get();
        if (map == null) {
            return null;
        }
        return map.get(key);
    }

    public static String getTraceId() {
        return Optional.ofNullable(get(TraceConst.TRACE_ID))
                .map(p -> p.toString())
                .orElse(TraceIdUtil.getTraceId());
    }

    public static void setTraceId(final String traceId) {
        set(TraceConst.TRACE_ID, traceId);
    }


    public static void remove() {
        threadLocal.remove();
    }
}