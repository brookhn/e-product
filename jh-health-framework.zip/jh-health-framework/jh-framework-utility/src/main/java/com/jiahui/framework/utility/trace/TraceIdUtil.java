package com.jiahui.framework.utility.trace;

import com.jiahui.framework.utility.consts.TraceConst;
import org.apache.commons.lang3.StringUtils;
import org.apache.skywalking.apm.toolkit.trace.TraceContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.UUID;

public class TraceIdUtil {

    private static final Logger log = LoggerFactory.getLogger(TraceIdUtil.class);

    public static String getTraceId() {
        String traceId;
        try {
            traceId = TraceContext.traceId();
            if (!StringUtils.isNotBlank(traceId) || traceId.equals(TraceConst.SKY_WALKING_IGNORE)) {
                log.warn("TraceContext.traceId() is exception");
                traceId = UUID.randomUUID().toString();
            }
        } catch (Exception ex) {
            log.error("getTraceIdErr", ex);
            traceId = UUID.randomUUID().toString();
        }
        return traceId;
    }

}
