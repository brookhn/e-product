package com.jiahui.framework.web.invoke.log.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import javax.servlet.http.HttpServletRequest;
import java.net.InetAddress;

public class IpUtil {
    private static final Logger log = LoggerFactory.getLogger(ObjectMapperUtil.class);

    public static String getServerIp() {
        try {
            InetAddress address = InetAddress.getLocalHost();
            return address.getHostAddress();
        } catch (Exception ex) {
            log.error("getServerIp:{}", ex.getMessage(), ex);
            return null;
        }
    }

    public static String getClientIp(HttpServletRequest request) {
        String clientIp = request.getHeader("X-Forwarded-For");
        if (StringUtils.hasText(clientIp)) {
            int index = clientIp.indexOf(",");
            return index > -1 ? clientIp.substring(0, index) : clientIp;
        } else {
            clientIp = request.getHeader("X-Real-IP");
        }
        if (StringUtils.hasText(clientIp) && !"unknown".equalsIgnoreCase(clientIp)) {
            return clientIp;
        }
        return request.getRemoteAddr();
    }
}
