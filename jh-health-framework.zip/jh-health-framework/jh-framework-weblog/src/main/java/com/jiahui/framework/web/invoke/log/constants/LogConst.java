package com.jiahui.framework.web.invoke.log.constants;


public class LogConst {
    /**
     * request进入的时间戳（ms)
     */
    public static final String CURRENT_TIME = "current_time";
    /**
     * 服务响应的时间戳（ms）
     */
    public static final String RESPONSE_TIME = "response_time";
    /**
     * http状态码
     */
    public static final String HTTP_STATUS = "http_status";
    /**
     * 接口业务响应码
     */
    public static final String CODE = "code";
    /**
     * http请求头
     */
    public static final String REQUEST_HEADERS = "request_headers";
    /**
     * 请求参数
     */
    public static final String REQUEST_PARAM = "request_param";
    /**
     * 响应头数据
     */
    public static final String RESPONSE_HEADERS = "response_headers";
    /**
     * 服务返回内容
     */
    public static final String RESPONSE_BODY = "response_body";
    /**
     * 调用方ip地址
     */
    public static final String IP = "ip";
    /**
     * 来源服务名
     */
    public static final String SRC = "src";
    /**
     * 用户ID
     */
    public static final String USERID = "userid";
    /**
     * 服务版本号
     */
    public static final String APP_VERSION = "appversion";
    /**
     * 服务名称
     */
    public static final String APP_NAME = "appname";
    /**
     * 请求Uri，不包括域名
     */
    public static final String URI = "uri";
//    /**
//     * es的索引名称
//     */
//    public static final String INDEX_NAME = "indexname";
    /**
     * client 浏览器属性
     */
    public static final String USERAGENT = "user_agent";

    /**
     * http请求方式
     */
    public static final String HTTP_METHOD = "http_method";
    /**
     * 接口耗时
     */
    public static final String SPEND_TIME = "spend_time";

    public final static String SERVER_IP = "server_ip";

    public final static String APP_ENV = "appenv";
}
