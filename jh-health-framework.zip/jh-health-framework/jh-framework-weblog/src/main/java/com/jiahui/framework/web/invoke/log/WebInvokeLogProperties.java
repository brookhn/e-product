package com.jiahui.framework.web.invoke.log;

import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.Set;


@ConfigurationProperties(prefix = "web-invoke-log")
public class WebInvokeLogProperties {

    //@NotEmpty
    private Set<String> filterUrlPatterns;
    //@Nullable
    private Integer filterOrder;

    private Set<String> logRequestHeaders;

    private Set<String> logResponseHeaders;

    private Set<String> extendLogFields;

    private TaskProperties task = new TaskProperties();

    private KafkaProperties kafka;

    private Set<String> excludedUrls;

    public WebInvokeLogProperties() {
//        this.filterUrlPatterns = new LinkedHashSet<>();
        this.filterOrder = -1;
    }

    public Set<String> getFilterUrlPatterns() {
        return filterUrlPatterns;
    }

    public void setFilterUrlPatterns(Set<String> filterUrlPatterns) {
        this.filterUrlPatterns = filterUrlPatterns;
    }

    public Integer getFilterOrder() {
        return filterOrder;
    }

    public void setFilterOrder(Integer filterOrder) {
        this.filterOrder = filterOrder;
    }

    public Set<String> getLogRequestHeaders() {
        return logRequestHeaders;
    }

    public void setLogRequestHeaders(Set<String> logRequestHeaders) {
        this.logRequestHeaders = logRequestHeaders;
    }

    public Set<String> getLogResponseHeaders() {
        return logResponseHeaders;
    }

    public void setLogResponseHeaders(Set<String> logResponseHeaders) {
        this.logResponseHeaders = logResponseHeaders;
    }

    public Set<String> getExtendLogFields() {
        return extendLogFields;
    }

    public void setExtendLogFields(Set<String> extendLogFields) {
        this.extendLogFields = extendLogFields;
    }

    public TaskProperties getTask() {
        return task;
    }

    public void setTask(TaskProperties task) {
        this.task = task;
    }

    public KafkaProperties getKafka() {
        return kafka;
    }

    public void setKafka(KafkaProperties kafka) {
        this.kafka = kafka;
    }

    public Set<String> getExcludedUrls() {
        return excludedUrls;
    }

    public void setExcludedUrls(Set<String> excludedUrls) {
        this.excludedUrls = excludedUrls;
    }

    public static class TaskProperties {
        private int corePoolSize;

        private int maxPoolSize;

        private int keepAliveSeconds;

        private int queueCapacity;

        private boolean waitForTasksToCompleteOnShutdown;

        private int awaitTerminationSeconds;

        private String threadNamePrefix;

        public TaskProperties() {
            this.corePoolSize = 1;
            this.maxPoolSize = 5;
            this.keepAliveSeconds = 60;
            this.queueCapacity = 1000;
            this.waitForTasksToCompleteOnShutdown = true;
            this.awaitTerminationSeconds = 5;
            this.threadNamePrefix = "web-invoke-log-";
        }

        public int getCorePoolSize() {
            return corePoolSize;
        }

        public void setCorePoolSize(int corePoolSize) {
            this.corePoolSize = corePoolSize;
        }

        public int getMaxPoolSize() {
            return maxPoolSize;
        }

        public void setMaxPoolSize(int maxPoolSize) {
            this.maxPoolSize = maxPoolSize;
        }

        public int getKeepAliveSeconds() {
            return keepAliveSeconds;
        }

        public void setKeepAliveSeconds(int keepAliveSeconds) {
            this.keepAliveSeconds = keepAliveSeconds;
        }

        public int getQueueCapacity() {
            return queueCapacity;
        }

        public void setQueueCapacity(int queueCapacity) {
            this.queueCapacity = queueCapacity;
        }

        public boolean isWaitForTasksToCompleteOnShutdown() {
            return waitForTasksToCompleteOnShutdown;
        }

        public void setWaitForTasksToCompleteOnShutdown(boolean waitForTasksToCompleteOnShutdown) {
            this.waitForTasksToCompleteOnShutdown = waitForTasksToCompleteOnShutdown;
        }

        public int getAwaitTerminationSeconds() {
            return awaitTerminationSeconds;
        }

        public void setAwaitTerminationSeconds(int awaitTerminationSeconds) {
            this.awaitTerminationSeconds = awaitTerminationSeconds;
        }

        public String getThreadNamePrefix() {
            return threadNamePrefix;
        }

        public void setThreadNamePrefix(String threadNamePrefix) {
            this.threadNamePrefix = threadNamePrefix;
        }
    }

}
