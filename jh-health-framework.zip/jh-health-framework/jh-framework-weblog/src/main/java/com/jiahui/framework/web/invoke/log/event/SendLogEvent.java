package com.jiahui.framework.web.invoke.log.event;

import org.springframework.context.ApplicationEvent;

import java.util.Map;

public class SendLogEvent extends ApplicationEvent {

    public SendLogEvent(Map<String, Object> source) {
        super(source);
    }

    public Map<String, Object> getSendMsg() {
        return (Map<String, Object>) source;
    }
}
