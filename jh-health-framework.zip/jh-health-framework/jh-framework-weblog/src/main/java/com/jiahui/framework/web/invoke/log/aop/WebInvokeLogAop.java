//package com.jiahui.framework.web.invoke.log.aop;
//
//import com.jiahui.framework.web.invoke.log.constants.CommonConst;
//import com.jiahui.framework.web.invoke.log.constants.LogConst;
//import org.aspectj.lang.JoinPoint;
//import org.aspectj.lang.annotation.Aspect;
//import org.aspectj.lang.annotation.Before;
//import org.aspectj.lang.annotation.Pointcut;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.multipart.MultipartFile;
//import org.springframework.web.multipart.support.StandardMultipartHttpServletRequest;
//
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//import java.util.ArrayList;
//import java.util.List;
//
//
//@Aspect
//public class WebInvokeLogAop {
//
//    private static final Logger log = LoggerFactory.getLogger(WebInvokeLogAop.class);
//
//    @Autowired
//    private HttpServletRequest request;
//
//    /**
//     * TODO 直接对RestController进行拦截
//     */
//    @Pointcut("@within(org.springframework.stereotype.Controller) || @within(org.springframework.web.bind.annotation.RestController)")
//    public void controllerPointCut() {
//    }
//
//    @Before("controllerPointCut()")
//    public void doBefore(JoinPoint joinPoint) {
//
//        Object[] args = joinPoint.getArgs();
//        List<Object> list = new ArrayList<>();
//        for (int i = 0; i < args.length; i++) {
//            if (args[i] instanceof HttpServletRequest || args[i] instanceof HttpServletResponse || args[i] instanceof StandardMultipartHttpServletRequest || args[i] instanceof MultipartFile) {
//                log.warn("过滤不能解析参数");
//            } else {
//                list.add(args[i]);
//            }
//        }
//        request.setAttribute(LogConst.REQUEST_PARAM, list);
//    }
//
////    /**
////     * 获取api response log
////     *
////     * @throws Throwable
////     */
////    @AfterReturning(returning = "ret", pointcut = "controllerPointCut()")
////    public void doAfterReturning(Object ret) throws Throwable {
////        request.setAttribute(LogConst.RESPONSE_BODY, ret);
////    }
////
////    @Pointcut("@annotation(org.springframework.web.bind.annotation.ExceptionHandler) && (@within(org.springframework.web.bind.annotation.RestControllerAdvice) || @within(org.springframework.web.bind.annotation.ControllerAdvice))")
////    public void exceptionPointCut() {
////    }
////
////    @AfterReturning(pointcut = "exceptionPointCut()", returning = "result")
////    public void doAfterExceptionReturn(Object result) {
////        try {
////            if (result instanceof ResponseEntity) {
////                ResponseEntity responseEntity = (ResponseEntity) result;
////                request.setAttribute(LogConst.RESPONSE_BODY, responseEntity.getBody());
////            } else {
////                request.setAttribute(LogConst.RESPONSE_BODY, result);
////            }
////        } catch (Exception e) {
////            log.error(e.getMessage(), e);
////        }
////    }
//}
