package com.jiahui.framework.web.invoke.log.constants;

public interface CommonConst {
    String SPRING_APPLICATION_NAME = "spring.application.name";
    String SPRING_PROFILES_ACTIVE = "spring.profiles.active";
    String APP_VERSION = "spring.cloud.nacos.discovery.metadata.version";
    String PROD_ENV = "prod";
    String TEST_KAFKA_BOOTSTRAP_SERVERS = "jih-kafka01-test.jihint.com:9092,jih-kafka02-test.jihint.com:9092,jih-kafka03-test.jihint.com:9092";
    String PROD_KAFKA_BOOTSTRAP_SERVERS = "jih-kafka01-log-prod.jihint.com:9092,jih-kafka02-log-prod.jihint.com:9092,jih-kafka03-log-prod.jihint.com:9092";
    String HTTP_METHOD_GET = "GET";
}
