package com.jiahui.framework.web.invoke.log.listener;

import com.jiahui.framework.utility.consts.TraceConst;
import com.jiahui.framework.web.invoke.log.constants.TopicConst;
import com.jiahui.framework.web.invoke.log.utils.ObjectMapperUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

import java.util.Map;
import java.util.UUID;

/**
 * 日志异步发送Kafka
 */
public class KafkaLogSender implements LogSender {

    private static final Logger log = LoggerFactory.getLogger(KafkaLogSender.class);

    private KafkaTemplate<String, String> kafkaTemplate;

    public KafkaLogSender(KafkaTemplate<String, String> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    @Override
    public void send(Map<String, Object> logMap) {
        String logJson = ObjectMapperUtil.toJsonStr(logMap);
//        kafkaTemplate.sendDefault(logJson);
        String traceId = logMap.getOrDefault(TraceConst.TRACE_ID, UUID.randomUUID().toString()).toString();
        ListenableFuture<SendResult<String, String>> future = kafkaTemplate.send(TopicConst.INVOKE_LOG_TOPIC, traceId, logJson);
        future.addCallback(new ListenableFutureCallback<SendResult<String, String>>() {
            @Override
            public void onFailure(Throwable ex) {
                log.error(ex.getMessage(), ex);
            }

            @Override
            public void onSuccess(SendResult<String, String> result) {

            }
        });
//        if (log.isDebugEnabled()) {
//            log.debug("send log:{}", logJson);
//        }
    }
}
