package com.jiahui.framework.web.invoke.log.config;

import com.jiahui.framework.web.invoke.log.WebInvokeLogProperties;
import com.jiahui.framework.web.invoke.log.constants.CommonConst;
import com.jiahui.framework.web.invoke.log.filter.WebTraceFilter;
import com.jiahui.framework.web.invoke.log.listener.KafkaLogSender;
import com.jiahui.framework.web.invoke.log.listener.SendLogEventListener;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.boot.autoconfigure.kafka.KafkaAutoConfiguration;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.support.LoggingProducerListener;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.util.CollectionUtils;

import javax.annotation.PostConstruct;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * 调用日志配置
 */
@Configuration
@EnableConfigurationProperties(WebInvokeLogProperties.class)
@AutoConfigureAfter(KafkaAutoConfiguration.class)
@ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
public class WebInvokeLogAutoConfiguration {

    private static final Logger log = LoggerFactory.getLogger(WebInvokeLogAutoConfiguration.class);

    @Value("${spring.application.name}")
    private String applicationName;
    //应用版本号
    @Value("${spring.cloud.nacos.discovery.metadata.version}")
    private String applicationVersion;
    @Autowired
    private WebInvokeLogProperties webLogProperties;

    @Value("${spring.profiles.active}")
    private String onProfile;

    @Bean("webInvokeLogTask")
    public Executor taskExecutor() {
        WebInvokeLogProperties.TaskProperties task = webLogProperties.getTask();
        // 先把线程填满到corePoolSize，再放队列,队列满了新建线程
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(task.getCorePoolSize());
        executor.setMaxPoolSize(task.getMaxPoolSize());
        executor.setQueueCapacity(task.getQueueCapacity());
        executor.setKeepAliveSeconds(task.getKeepAliveSeconds());
        executor.setThreadNamePrefix(task.getThreadNamePrefix());
        executor.setRejectedExecutionHandler(new RejectedExecutionHandler() {
            @Override
            public void rejectedExecution(Runnable r, ThreadPoolExecutor executor) {
//                log.error("memory snapshot,maxMemory:{},freeMemory:{},totalMemory:{}",
//                        Runtime.getRuntime().maxMemory(), Runtime.getRuntime().freeMemory(), Runtime.getRuntime().totalMemory());
            }
        });
        executor.setWaitForTasksToCompleteOnShutdown(task.isWaitForTasksToCompleteOnShutdown());
        executor.setAwaitTerminationSeconds(task.getAwaitTerminationSeconds());
        return executor;
    }

    @Bean("webInvokeLogKafkaProducerFactory")
    @ConditionalOnProperty(name = "web-invoke-log.default-listener.disable", havingValue = "false", matchIfMissing = true)
    public ProducerFactory<String, String> webInvokeLogKafkaProducerFactory() {
//        initConfig();
        KafkaProperties kafka = webLogProperties.getKafka();
        if (kafka == null) {
            kafka = new KafkaProperties();
        }
//        kafka.setClientId(applicationName);

        Map<String, Object> props = kafka.buildProducerProperties();
        //region 未配置kafka bootstrap.servers
        if (!CollectionUtils.isEmpty(kafka.getBootstrapServers())) {
            kafka.getBootstrapServers().removeIf("localhost:9092"::equals);
        }
        if (CollectionUtils.isEmpty(kafka.getBootstrapServers())) {
            if (CommonConst.PROD_ENV.equals(onProfile)) {
                props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, CommonConst.PROD_KAFKA_BOOTSTRAP_SERVERS);
            } else {
                props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, CommonConst.TEST_KAFKA_BOOTSTRAP_SERVERS);
            }
        }
        //endregion
        props.putIfAbsent(ProducerConfig.RETRIES_CONFIG, 0);
        props.putIfAbsent(ProducerConfig.ACKS_CONFIG, "0");
        props.putIfAbsent(ProducerConfig.LINGER_MS_CONFIG, 100);
        props.putIfAbsent(ProducerConfig.BATCH_SIZE_CONFIG, 524288);
        props.putIfAbsent(ProducerConfig.MAX_REQUEST_SIZE_CONFIG, 2097152);
        props.putIfAbsent(ProducerConfig.COMPRESSION_TYPE_CONFIG, "gzip");
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);

        DefaultKafkaProducerFactory<String, String> factory = new DefaultKafkaProducerFactory<>(
                props);
        String transactionIdPrefix = kafka.getProducer()
                .getTransactionIdPrefix();
        if (transactionIdPrefix != null) {
            factory.setTransactionIdPrefix(transactionIdPrefix);
        }
        return factory;
    }

    @Bean("webInvokeLogKafkaTemplate")
    @ConditionalOnProperty(name = "web-invoke-log.default-listener.disable", havingValue = "false", matchIfMissing = true)
    public KafkaTemplate<String, String> webInvokeLogKafkaTemplate() {
        KafkaTemplate<String, String> kafkaTemplate = new KafkaTemplate<>(
                webInvokeLogKafkaProducerFactory());
        kafkaTemplate.setProducerListener(new LoggingProducerListener<>());
        return kafkaTemplate;
    }

    @Bean
    @ConditionalOnProperty(name = "web-invoke-log.default-listener.disable", havingValue = "false", matchIfMissing = true)
    public DefaultSendLogEventListenerBuilder defaultSendLogEventListenerBuilder(ConfigurableApplicationContext context) {
        return new DefaultSendLogEventListenerBuilder(webInvokeLogKafkaTemplate(), context);
    }

    @Bean
    @ConditionalOnProperty(name = "web-invoke-log.default-listener.disable", havingValue = "false", matchIfMissing = true)
    public FilterRegistrationBean<WebTraceFilter> webTraceFilterRegistrationBean(ConfigurableApplicationContext context) {
        FilterRegistrationBean<WebTraceFilter> registrationBean = new FilterRegistrationBean<>();
        WebTraceFilter webLogFilter = new WebTraceFilter(webLogProperties, context);
        registrationBean.setFilter(webLogFilter);
        registrationBean.setOrder(webLogProperties.getFilterOrder() == null ? -1 : webLogProperties.getFilterOrder());
        Set<String> filterUrlPatterns = webLogProperties.getFilterUrlPatterns();
        if (CollectionUtils.isEmpty(filterUrlPatterns)) {
            filterUrlPatterns = new LinkedHashSet<>();
            filterUrlPatterns.add("/*");
        }
        for (String filterUrlPattern : filterUrlPatterns) {
            registrationBean.addUrlPatterns(filterUrlPattern);
        }
        return registrationBean;
    }


//    @Bean
//    public WebInvokeLogAop webInvokeLogAop() {
//        return new WebInvokeLogAop();
//    }

    /**
     * 默认SendLogEventListener配置，采用kafka发送，支持白名单链接过滤
     */
    public class DefaultSendLogEventListenerBuilder {

        private KafkaTemplate<String, String> kafkaTemplate;

        private ConfigurableApplicationContext context;

        public DefaultSendLogEventListenerBuilder(KafkaTemplate<String, String> kafkaTemplate, ConfigurableApplicationContext context) {
            this.kafkaTemplate = kafkaTemplate;
            this.context = context;
        }

        @PostConstruct
        public void build() {
            KafkaLogSender kafkaLogSender = new KafkaLogSender(kafkaTemplate);
            SendLogEventListener sendLogEventListener = new SendLogEventListener(
                    webLogProperties.getExcludedUrls(),
                    taskExecutor(),
                    kafkaLogSender);

            context.addApplicationListener(sendLogEventListener);
        }
    }
}
