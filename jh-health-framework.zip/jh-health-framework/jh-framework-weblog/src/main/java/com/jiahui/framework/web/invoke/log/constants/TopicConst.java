package com.jiahui.framework.web.invoke.log.constants;

public interface TopicConst {
    String INVOKE_LOG_TOPIC = "JH-INVOKE-LOG";
}
