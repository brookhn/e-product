package com.jiahui.framework.web.invoke.log.filter;

import com.fasterxml.jackson.databind.JsonNode;
import com.jiahui.framework.utility.consts.TraceConst;
import com.jiahui.framework.utility.trace.MyThreadLocalHelper;
import com.jiahui.framework.utility.trace.TraceIdUtil;
import com.jiahui.framework.web.invoke.log.WebInvokeLogProperties;
import com.jiahui.framework.web.invoke.log.constants.CommonConst;
import com.jiahui.framework.web.invoke.log.constants.LogConst;
import com.jiahui.framework.web.invoke.log.event.SendLogEvent;
import com.jiahui.framework.web.invoke.log.utils.IpUtil;
import com.jiahui.framework.web.invoke.log.utils.ObjectMapperUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.http.MediaType;
import org.springframework.util.CollectionUtils;
import org.springframework.web.util.ContentCachingRequestWrapper;
import org.springframework.web.util.ContentCachingResponseWrapper;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.stream.Collectors;


public class WebTraceFilter implements Filter {
    /**
     * 需要记录的请求头
     */
    private final Set<String> logRequestHeaders;
//    /**
//     * 需要记录的响应头
//     */
//    private final Set<String> logResponseHeaders;
    /**
     * 日志扩展字段，从{@link HttpServletRequest#getAttribute(String)}获取
     */
    private final Set<String> extendLogFields;

    private ConfigurableApplicationContext context;

    private static final String OPTIONS = "OPTIONS";

    public final static int MAX_LENGTH = 1024 * 50;

    private static final Logger logger = LoggerFactory.getLogger(WebTraceFilter.class);

    public WebTraceFilter(WebInvokeLogProperties webLogProperties, ConfigurableApplicationContext context) {
        if (CollectionUtils.isEmpty(webLogProperties.getLogRequestHeaders())) {
            logRequestHeaders = Collections.emptySet();
        } else {
            logRequestHeaders = webLogProperties.getLogRequestHeaders().stream()
                    .filter(p -> StringUtils.isNotEmpty(p))
                    .map(p -> p.toLowerCase()).collect(Collectors.toSet());
        }
//        if (CollectionUtils.isEmpty(webLogProperties.getLogResponseHeaders())) {
//            logResponseHeaders = Collections.emptySet();
//        } else {
//            logResponseHeaders = webLogProperties.getLogResponseHeaders().stream()
//                    .filter(p -> StringUtils.isNotEmpty(p))
//                    .map(p -> p.toLowerCase()).collect(Collectors.toSet());
//        }
        extendLogFields = webLogProperties.getExtendLogFields();
        this.context = context;
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
    }

    private String getTraceId(HttpServletRequest request) {
        String traceId = request.getHeader(TraceConst.TRACE_ID);
        if (StringUtils.isBlank(traceId)) {
            traceId = request.getParameter(TraceConst.TRACE_ID);
            if (StringUtils.isBlank(traceId)) {
                traceId = TraceIdUtil.getTraceId();
            }
        }
        return traceId;
    }

    /**
     * 支持{@link javax.servlet.http.HttpServletRequest#getAttribute(String)}白名单配置,方便业务方扩展业务字段 ✅
     * 多索引发送需求,indexName可配置化，请求日志定向发送,增加新的SendLog监听者，由监听者对Uri做过滤，INDEXNAME由监听者插入✅
     * 入参 出参 json字符串化 ✅
     * request header 自定义字段监控，json字符串化 ✅
     * kafka日志发送托管 ✅
     * 线程池配置 ✅
     * 域名是否要去除 servletContextPath ✅ 去除servletContextPath
     *
     * @param request
     * @param response
     * @param chain
     * @throws IOException
     * @throws ServletException
     */
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest httpServletRequest = (HttpServletRequest) request;
        HttpServletResponse _response = (HttpServletResponse) response;

        String requestURI = httpServletRequest.getRequestURI();
        if (requestURI.indexOf("/swagger-") > -1 || requestURI.indexOf("/actuator/") > -1
                || requestURI.indexOf("/webjars/") > -1 || requestURI.indexOf("/favicon.ico") > -1
                || requestURI.indexOf(".html") > -1) {
            chain.doFilter(request, response);
            return;
        }
        if (OPTIONS.equalsIgnoreCase(httpServletRequest.getMethod())) {
            chain.doFilter(request, response);
            return;
        }
        ConfigurableEnvironment env = context.getEnvironment();
        String appName = env.getProperty(CommonConst.SPRING_APPLICATION_NAME);
        String traceId = getTraceId(httpServletRequest);
        Map<String, Object> logMap = new LinkedHashMap<>(32);
        logMap.put(TraceConst.TRACE_ID, traceId);
        logMap.put(LogConst.APP_VERSION, env.getProperty(CommonConst.APP_VERSION, "0.0.1"));
        logMap.put(LogConst.APP_NAME, appName);
        logMap.put(LogConst.APP_ENV, env.getProperty(CommonConst.SPRING_PROFILES_ACTIVE, CommonConst.PROD_ENV));
        ContentCachingRequestWrapper requestWrapper = new ContentCachingRequestWrapper(httpServletRequest);
        ContentCachingResponseWrapper responseWrapper = new ContentCachingResponseWrapper(_response);
        try {
            MyThreadLocalHelper.setTraceId(traceId);
            MDC.put(TraceConst.TRACE_ID, traceId);
            long inTime = System.currentTimeMillis();
            logMap.put(LogConst.CURRENT_TIME, inTime);

            chain.doFilter(requestWrapper, responseWrapper);

            long outTime = System.currentTimeMillis();
            long timeSpan = outTime - inTime;
            logMap.put(LogConst.RESPONSE_TIME, outTime);
            logMap.put(LogConst.HTTP_STATUS, _response.getStatus());
            String servletContextPath = env.getProperty("server.servlet.context-path", "");
            logMap.put(LogConst.URI, httpServletRequest.getRequestURI().replace(servletContextPath, ""));
            logMap.put(LogConst.USERAGENT, httpServletRequest.getHeader("User-Agent"));
            logMap.put(LogConst.HTTP_METHOD, httpServletRequest.getMethod());
            logMap.put(LogConst.SPEND_TIME, timeSpan);

            logMap.put(LogConst.SERVER_IP, IpUtil.getServerIp());
            logMap.put(LogConst.IP, IpUtil.getClientIp(httpServletRequest));
            Object source = httpServletRequest.getAttribute(LogConst.SRC);
            logMap.put(LogConst.SRC, Objects.isNull(source) ? "" : source.toString());
            String userIdStr = httpServletRequest.getHeader(LogConst.USERID);
            if (StringUtils.isNotBlank(userIdStr)) {
                logMap.put(LogConst.USERID, userIdStr);
                MDC.put(LogConst.USERID, userIdStr);
            } else {
                logMap.put(LogConst.USERID, "");
            }

            // 通用attribute配置
            if (!CollectionUtils.isEmpty(extendLogFields)) {
                Enumeration<String> attributeNames = httpServletRequest.getAttributeNames();
                while (attributeNames.hasMoreElements()) {
                    String attributeName = attributeNames.nextElement();
                    if (StringUtils.isNotBlank(attributeName) && extendLogFields.contains(attributeName)) {
                        Object obj = httpServletRequest.getAttribute(attributeName);
                        if (Objects.isNull(obj)) {
                            logMap.put(attributeName.toLowerCase(), "");
                        } else if (obj instanceof Boolean || obj instanceof String || obj instanceof Number || obj instanceof BigDecimal) {
                            logMap.put(attributeName.toLowerCase(), obj);
                        }
                    }
                }
            }

            //region 请求头处理 摊平
            if (!CollectionUtils.isEmpty(logRequestHeaders)) {
                Enumeration<String> headerNames = httpServletRequest.getHeaderNames();
                while (headerNames.hasMoreElements()) {
                    String headerName = headerNames.nextElement();
                    if (StringUtils.isEmpty(headerName)) {
                        continue;
                    }
                    String value = httpServletRequest.getHeader(headerName);
                    String headerField = headerName.toLowerCase();
                    if (logRequestHeaders.contains(headerField) && StringUtils.isNotEmpty(value) && value.length() <= 100) {
                        // 绝大部分header都不会有多值情况，忽略这种场景处理
                        logMap.put(headerField, value);
                    }
                }
            }
            //endregion
            try {
                handleRequestResponse(requestWrapper, responseWrapper, logMap);
            } catch (Exception ex) {
                logger.error(ex.getMessage(), ex);
            }
        } finally {
            responseWrapper.copyBodyToResponse();
            try {
//                //region 响应头处理
//                if (!CollectionUtils.isEmpty(logResponseHeaders)) {
//                    Map<String, String> responseHeaderMap = new LinkedHashMap<>();
//                    Collection<String> headerNames = _response.getHeaderNames();
//                    for (String headerName : headerNames) {
//                        if (logResponseHeaders.contains(headerName.toLowerCase())) {
//                            responseHeaderMap.put(headerName, _response.getHeader(headerName));
//                        }
//                    }
//                    logMap.put(LogConst.RESPONSE_HEADERS, CollectionUtils.isEmpty(responseHeaderMap) ? "" : ObjectMapperUtil.toJsonStr(responseHeaderMap));
//                }
//                //endregion

                context.publishEvent(new SendLogEvent(logMap));
            } catch (Exception ex) {
                logger.error(ex.getMessage(), ex);
            }
            MyThreadLocalHelper.remove();
            MDC.clear();
        }
    }

    private void handleRequestResponse(ContentCachingRequestWrapper requestWrapper, ContentCachingResponseWrapper responseWrapper, Map<String, Object> logMap) {
        String requestStr = "";
        String requestContentType = requestWrapper.getContentType();
        if (StringUtils.isBlank(requestContentType)) {
            requestContentType = "";
        }
        if (CommonConst.HTTP_METHOD_GET.equalsIgnoreCase(requestWrapper.getMethod())) {
            //get请求 requestBody
            if (requestContentType.indexOf(MediaType.APPLICATION_JSON_VALUE) > -1) {
                requestStr = new String(requestWrapper.getContentAsByteArray(), StandardCharsets.UTF_8);
            } else {
                requestStr = requestWrapper.getQueryString();
            }
        } else {
            if (requestContentType.indexOf("json") > -1) {
                requestStr = new String(requestWrapper.getContentAsByteArray(), StandardCharsets.UTF_8);
            }
            if (StringUtils.isBlank(requestStr) && !CollectionUtils.isEmpty(requestWrapper.getParameterMap())) {
                requestStr = ObjectMapperUtil.toJsonStr(requestWrapper.getParameterMap());
            }
        }
        if (StringUtils.isNotBlank(requestStr) && requestStr.length() > MAX_LENGTH) {
            logger.warn("request too long");
            requestStr = requestStr.substring(0, MAX_LENGTH);
        }
        logMap.put(LogConst.REQUEST_PARAM, requestStr);
        String contentType = responseWrapper.getContentType();
        if (contentType == null || contentType.isEmpty()) {
            return;
        }
        String bizCode = "0";
        String responseStr = "";
        if (contentType.indexOf(MediaType.APPLICATION_JSON_VALUE) > -1
                || contentType.indexOf(MediaType.TEXT_PLAIN_VALUE) > -1) {
            try {
                byte[] responseBytes = responseWrapper.getContentAsByteArray();
                responseStr = new String(responseBytes, StandardCharsets.UTF_8);
                if (contentType.indexOf(MediaType.APPLICATION_JSON_VALUE) > -1) {
                    JsonNode node = ObjectMapperUtil.parseJsonNode(responseStr);
                    bizCode = Optional.ofNullable(node).map(p -> p.get("code")).filter(p -> p != null)
                            .map(p -> p.asText()).orElse("0");
                }
                if (responseStr.length() > MAX_LENGTH) {
                    responseStr = responseStr.substring(0, MAX_LENGTH);
                }
            } catch (Exception ex) {
                logger.error(ex.getMessage(), ex);
            }
        }
        logMap.put(LogConst.CODE, bizCode);
        logMap.put(LogConst.RESPONSE_BODY, responseStr);
    }

    @Override
    public void destroy() {

    }
}
