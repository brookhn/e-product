package com.jiahui.framework.web.invoke.log.listener;

import com.jiahui.framework.web.invoke.log.constants.LogConst;
import com.jiahui.framework.web.invoke.log.event.SendLogEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.EventListener;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.stream.Collectors;


public class SendLogEventListener implements ApplicationListener<SendLogEvent> {

    private Executor executor;

    private LogSender logSender;

    private Set<String> excludedUrls;

    public SendLogEventListener(
            Set<String> excludedUrls,
            Executor executor,
            LogSender logSender) {
        if (!CollectionUtils.isEmpty(excludedUrls)) {
            this.excludedUrls = excludedUrls.stream().filter(p -> StringUtils.hasText(p)).collect(Collectors.toSet());
        }
        this.executor = executor;
        this.logSender = logSender;
    }

    @EventListener
    @Override
    public void onApplicationEvent(SendLogEvent event) {
//        if (!StringUtils.hasText(indexName)) {
//            return;
//        }
        Map<String, Object> logMap = event.getSendMsg();
        if (CollectionUtils.isEmpty(logMap)) {
            return;
        }
        String uri = logMap.getOrDefault(LogConst.URI, "").toString();
        if (!CollectionUtils.isEmpty(excludedUrls) && excludedUrls.contains(uri)) {
            return;
        }
        executor.execute(() -> {
//            doHandle(event);
            logSender.send(logMap);
        });
    }

//    /**
//     * 日志数据预处理
//     * 日志json序列化
//     * 日志发送
//     *
//     * @param event
//     */
//    private void doHandle(SendLogEvent event) {
////        if (!accept(event)) {
////            return;
////        }
//        Map<String, Object> logMap = event.getSendMsg();
//        if (!CollectionUtils.isEmpty(logMap)) {
////            logMap = logMapPreHandle(logMap);
//            logSender.send(logMap);
//        }
//    }

//    /**
//     * 对map进行拷贝 和 对象数据json序列化
//     *
//     * @param logMap
//     */
//    protected Map<String, Object> logMapPreHandle(Map<String, Object> logMap) {
//        Map<String, Object> _logMap = new LinkedHashMap<>(logMap);
////        _logMap.put(LogConst.REQUEST_PARAM, toJsonStr(logMap.get(LogConst.REQUEST_PARAM)));
////        _logMap.put(LogConst.RESPONSEBODY, toJsonStr(logMap.get(LogConst.RESPONSEBODY)));
//        Map<String, String> requestHeaderMap = (Map<String, String>) logMap.get(LogConst.REQUEST_HEADERS);
//        _logMap.put(LogConst.REQUEST_HEADERS, requestHeaderMap.isEmpty() ? "" : toJsonStr(requestHeaderMap));
//        Map<String, String> responseHeaderMap = (Map<String, String>) logMap.get(LogConst.RESPONSE_HEADERS);
//        _logMap.put(LogConst.RESPONSE_HEADERS, responseHeaderMap.isEmpty() ? "" : toJsonStr(responseHeaderMap));
////        _logMap.put(LogConst.INDEX_NAME, indexName);
//        return _logMap;
//
//    }

//    /**
//     * @param object
//     * @return
//     */
//    protected String toJsonStr(Object object) {
//        return ObjectMapperUtil.toJsonStr(object);
//    }
}
