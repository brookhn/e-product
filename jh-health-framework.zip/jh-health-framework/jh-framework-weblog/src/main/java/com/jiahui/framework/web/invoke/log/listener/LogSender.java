package com.jiahui.framework.web.invoke.log.listener;

import java.util.Map;

public interface LogSender {

    void send(Map<String, Object> logMap);
}
