package com.jiahui.search.repository;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.github.benmanes.caffeine.cache.LoadingCache;
import com.jiahui.search.entity.PluginConfig;
import com.jiahui.search.repository.dao.PluginConfigMapper;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.List;
import java.util.concurrent.TimeUnit;

@Repository
public class PluginConfigRepo {


    @Resource
    private PluginConfigMapper mapper;

    public List<PluginConfig> queryAllPluginConfig() {
        LambdaQueryWrapper<PluginConfig> queryWrapper = new QueryWrapper<PluginConfig>()
                .lambda();
        return mapper.selectList(queryWrapper);
    }

    /**
     * 条件查询
     *
     * @param param
     * @return
     */
    public List<PluginConfig> queryList(PluginConfig param) {
        LambdaQueryWrapper<PluginConfig> queryWrapper = new QueryWrapper<PluginConfig>()
                .lambda();
        queryWrapper.eq(PluginConfig::getStatus, param.getStatus());
        return mapper.selectList(queryWrapper);
    }

    public PluginConfig getByIndexConfigId(Long indexConfigId) {
        LambdaQueryWrapper<PluginConfig> queryWrapper = new QueryWrapper<PluginConfig>()
                .lambda();
        queryWrapper.eq(PluginConfig::getIndexId, indexConfigId).last(" limit 1 ");
        return mapper.selectOne(queryWrapper);
    }

    private LoadingCache<Long, PluginConfig> pluginConfigCache = Caffeine.newBuilder()
            .maximumSize(1000)
            .expireAfterWrite(2, TimeUnit.HOURS)
            .refreshAfterWrite(30, TimeUnit.SECONDS)
            .build(key -> mapper.selectById(key));

    public PluginConfig selectCacheById(Long indexId) {
        return pluginConfigCache.get(indexId);
    }

}
