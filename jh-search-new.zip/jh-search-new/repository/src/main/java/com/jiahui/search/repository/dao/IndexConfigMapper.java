package com.jiahui.search.repository.dao;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiahui.search.entity.IndexConfig;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author zzc
 * @since 2022-01-27
 */
public interface IndexConfigMapper extends BaseMapper<IndexConfig> {

}
