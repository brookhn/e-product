package com.jiahui.search.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;

import lombok.*;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode(callSuper = false)
@TableName("plugin_config")
public class PluginConfig implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键id
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
     * 应用id
     */
    @TableField("app_key")
    private String appKey;

    /**
     * 索引id
     */
    @TableField("index_id")
    private Long indexId;

    /**
     * 全量同步sql
     */
    @TableField("full_sync_sql")
    private String fullSyncSql;

    /**
     * 全量同步range sql
     */
    @TableField("full_sync_range_sql")
    private String fullSyncRangeSql;

    /**
     * 全量同步配置
     */
    @TableField("full_sync_config")
    private String fullSyncConfig;

    /**
     * 主查询数据源名称（匹配对应数据库连接串）
     */
    @TableField("full_sync_db_name")
    private String fullSyncDbName;

    /**
     * 增量同步配置
     */
    @TableField("incr_sync_config")
    private String incrSyncConfig;

    /**
     * datawrapper数据源名称列表（匹配对应数据库连接串）
     */
    @TableField("incr_sync_db_names")
    private String incrSyncDbNames;

    /**
     * 同步任务主键
     */
    @TableField("id_field_name")
    private String idFieldName;

    /**
     * wrapper jar 地址
     */
    @TableField("wrapper_jar_url")
    private String wrapperJarUrl;

    @TableField("wrapper_class")
    private String wrapperClass;

    /**
     * 备份JAR包地址
     */
    @TableField("backup_jar_url")
    private String backupJarUrl;

    /**
     * 创建时间
     */
    @TableField("create_time")
    private LocalDateTime createTime;

    /**
     * 创建人
     */
    @TableField("create_user")
    private String createUser;

    /**
     * 更新时间
     */
    @TableField("update_time")
    private LocalDateTime updateTime;

    /**
     * 更新人
     */
    @TableField("update_user")
    private String updateUser;

    /**
     * 状态 0 停用 1.启用
     */
    @TableField("status")
    private Integer status;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getAppKey() {
        return appKey;
    }

    public void setAppKey(String appKey) {
        this.appKey = appKey;
    }

    public Long getIndexId() {
        return indexId;
    }

    public void setIndexId(Long indexId) {
        this.indexId = indexId;
    }

    public String getFullSyncSql() {
        return fullSyncSql;
    }

    public void setFullSyncSql(String fullSyncSql) {
        this.fullSyncSql = fullSyncSql;
    }

    public String getFullSyncRangeSql() {
        return fullSyncRangeSql;
    }

    public void setFullSyncRangeSql(String fullSyncRangeSql) {
        this.fullSyncRangeSql = fullSyncRangeSql;
    }

    public String getFullSyncConfig() {
        return fullSyncConfig;
    }

    public void setFullSyncConfig(String fullSyncConfig) {
        this.fullSyncConfig = fullSyncConfig;
    }

    public String getFullSyncDbName() {
        return fullSyncDbName;
    }

    public void setFullSyncDbName(String fullSyncDbName) {
        this.fullSyncDbName = fullSyncDbName;
    }

    public String getIncrSyncConfig() {
        return incrSyncConfig;
    }

    public void setIncrSyncConfig(String incrSyncConfig) {
        this.incrSyncConfig = incrSyncConfig;
    }

    public String getIncrSyncDbNames() {
        return incrSyncDbNames;
    }

    public void setIncrSyncDbNames(String incrSyncDbNames) {
        this.incrSyncDbNames = incrSyncDbNames;
    }

    public String getIdFieldName() {
        return idFieldName;
    }

    public void setIdFieldName(String idFieldName) {
        this.idFieldName = idFieldName;
    }

    public String getWrapperJarUrl() {
        return wrapperJarUrl;
    }

    public void setWrapperJarUrl(String wrapperJarUrl) {
        this.wrapperJarUrl = wrapperJarUrl;
    }

    public String getBackupJarUrl() {
        return backupJarUrl;
    }

    public void setBackupJarUrl(String backupJarUrl) {
        this.backupJarUrl = backupJarUrl;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public LocalDateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(LocalDateTime updateTime) {
        this.updateTime = updateTime;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

    public String getWrapperClass() {
        return wrapperClass;
    }

    public void setWrapperClass(String wrapperClass) {
        this.wrapperClass = wrapperClass;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}