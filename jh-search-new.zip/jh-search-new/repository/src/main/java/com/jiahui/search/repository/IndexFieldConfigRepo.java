package com.jiahui.search.repository;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.jiahui.search.entity.IndexFieldConfigEntity;
import com.jiahui.search.repository.dao.IndexFieldConfigMapper;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.List;

@Repository
public class IndexFieldConfigRepo {
    @Resource
    private IndexFieldConfigMapper mapper;

    public List<IndexFieldConfigEntity> getByIndexConfigId(Long indexConfigId) {
        LambdaQueryWrapper<IndexFieldConfigEntity> queryWrapper = new QueryWrapper<IndexFieldConfigEntity>()
                .lambda();
        queryWrapper.eq(IndexFieldConfigEntity::getIndexConfigId, indexConfigId);
        return mapper.selectList(queryWrapper);
    }
}
