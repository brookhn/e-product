package com.jiahui.search.repository.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiahui.search.entity.CompensateRecord;

public interface CompensateRecordMapper extends BaseMapper<CompensateRecord> {
}
