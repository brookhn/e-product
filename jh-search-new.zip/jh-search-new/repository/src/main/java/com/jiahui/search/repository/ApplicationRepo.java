package com.jiahui.search.repository;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.github.benmanes.caffeine.cache.LoadingCache;
import com.jiahui.search.entity.Application;
import com.jiahui.search.repository.dao.ApplicationMapper;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.concurrent.TimeUnit;

@Component
@Repository
public class ApplicationRepo {
    @Resource
    private ApplicationMapper mapper;


    LoadingCache<String, Application> cache = Caffeine.newBuilder()
                .maximumSize(10000)
                .refreshAfterWrite(1, TimeUnit.SECONDS)
                .build(key -> getByAppKey(key));


    public Application getFromCacheByAppKey(String appKey) {
        // 查找缓存，如果缓存不存在则生成缓存元素,  如果无法生成则返回null
        return cache.get(appKey);
    }

    public Application getByAppKey(String appKey) {
        LambdaQueryWrapper<Application> queryWrapper = new QueryWrapper<Application>()
                .lambda();
        queryWrapper.eq(Application::getAppKey, appKey).last(" limit 1 ");
        return mapper.selectOne(queryWrapper);
    }
}
