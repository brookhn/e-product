package com.jiahui.search.repository.config;

import com.jiahui.framework.datasource.config.JiaHuiDataSourceProperties;
import com.jiahui.framework.datasource.core.DynamicDataSource;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;

@Configuration
@MapperScan(basePackages = {"com.jiahui.search.repository.dao"})
public class SearchDBConfig {


    @Bean("consoleDataSource")
    public DataSource searchDBDataSource(JiaHuiDataSourceProperties dbProp) {
        DynamicDataSource dataSource = new DynamicDataSource("jh-search-console", dbProp);
        return dataSource;
    }
}
