package com.jiahui.search.repository.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiahui.search.entity.IndexFieldConfigEntity;

public interface IndexFieldConfigMapper extends BaseMapper<IndexFieldConfigEntity> {
}
