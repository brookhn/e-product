package com.jiahui.search.repository;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.jiahui.search.entity.IndexConfig;
import com.jiahui.search.repository.dao.IndexConfigMapper;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;

@Repository
public class IndexConfigRepo {
    @Resource
    private IndexConfigMapper mapper;

    public IndexConfig getById(Long id) {
        LambdaQueryWrapper<IndexConfig> queryWrapper = new QueryWrapper<IndexConfig>()
                .lambda();
        queryWrapper.eq(IndexConfig::getId, id).last(" limit 1 ");
        return mapper.selectOne(queryWrapper);
    }
}
