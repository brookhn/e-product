package com.jiahui.search.common.enums;

/**
 * 210002xxx datawrapper 错误码
 * 21003xxx indexing 错误码
 * 21001xxx console 错误码
 * 21004xxx querying 错误码
 */
public enum CodeEnum {
    /**
     * 参数异常
     */
    PARAMS_EMPTY(210001000, "参数为空"),
    PARAMS_ERROR(210001001, "参数错误"),
    /**
     * 业务异常
     */
    DATA_WRAPPER_EXCEPTION(21000001, "DataWrapper异常"),
    REQUEST_LIMIT_EXCEPTION(21000002, "请求频繁，请稍后重试"),
    //    CODE_210002002(210002002, "获取上传参数异常"),
//    CODE_210002003(210002003, "获取资源bucket异常"),
//    CODE_210002004(210002004, "获取资源URL异常"),
    CODE_210002001(210002001, "重复启动同步任务"),


    CODE_210002002(210002002, "同步任务plugin不存在"),
    CODE_210002003(210002003, "同步任务doIndex异常"),
    CODE_210002004(210002004, "jar包未找到"),
    CODE_210002005(210002005, "全量同步任务启动异常"),
    CODE_210002006(210002006, "jdbcTemplate非空不允许重复赋值"),
    CODE_210002007(210002007, "抓取数据异常，ID不匹配"),
    CODE_210002008(210002008, "全量写ES异常"),
    CODE_210002009(210002009, "全量抓取数据异常，未包含idField"),
    CODE_210002010(210002010, "增量indexer异常"),
    CODE_210002011(210002011, "插件异常"),
    CODE_210002012(210002012, "插件配置异常"),

    //    CODE_210002006(210002006, "异常对象异常"),
    CODE_210005000(210005000, "external json解析异常:"),


    EXCEPTION_ES_SEARCH(210004000, "查询es异常"),
    APP_KEY_NOT_EXISTS(210004001, "APP_KEY_NOT_EXISTS"),

    RETRY(210004002, "重试"),

    DESERIALIZATION_FAILED(210004100, "deserialization failed"),
    TRANS_AGG_FAILED(210004101, "trans agg result failed"),

    SENTINEL_BLOCK_EXCEPTION(210004150, "SENTINEL BLOCK EXCEPTION"),
    SENTINEL_FLOW_BLOCK(210004151, "资源限流"),
    SENTINEL_DEGRADE_BLOCK(210004152, "服务降级"),
    SENTINEL_PARAM_FLOW_BLOCK(210004153, "热点参数限流"),
    SENTINEL_SYSTEM_BLOCK(210004154, "触发系统保护规则"),
    SENTINEL_AUTHORITY_BLOCK(210004155, "授权规则不通过"),

    INDEX_CONFIG_NOT_EXISTS(210003001, "IndexConfig不存在"),

    FULL_INDEX_RUNNING(210003002, "全量任务正在运行中"),

    CREATE_INDEX_ERR(210003003, "创建索引异常"),

    DELETE_INDEX_ERR(210003003, "DeleteIndexErr"),

    ADD_ALIAS_ERR(210003005, "创建别名异常"),

    ALIAS_NOT_EXISTS(210003006, "IndexConfig不存在"),

    PUBLISH_NACOS_ERR(210003007, "发布naocs异常"),

    UPDATE_INDEX_SETTINGS_ERR(210003008, "PutSettingsErr"),

    READY_FULL_INDEX_RUNNING(210003009, "全量任务"),

    UPDATE_ALIAS_ERR(210003010, "别名更新异常"),

    CHECK_REBUILD_ERR(210003011, "检查索引Rebuild异常"),

    PUT_MAPPING_ERR(210003012, "修改mapping异常"),

    FULL_INDEX_FINISH(210003013, "全量任务已结束"),

    NONE(0, ""),
    EXCEPTION(500, "系统异常"),
    BAD_REQUEST(400, "错误请求"),
    SUCCESS(200, "成功");


    private int code;
    private String msg;

    CodeEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public int getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }

}
