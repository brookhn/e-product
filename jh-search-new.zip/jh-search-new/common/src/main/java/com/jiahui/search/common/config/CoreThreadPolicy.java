package com.jiahui.search.common.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * 核心线程池拒绝策略,线程池满转到主线程运行
 */
public class CoreThreadPolicy implements RejectedExecutionHandler {

    private Logger logger = LoggerFactory.getLogger(CoreThreadPolicy.class);


    private ThreadPoolExecutor.CallerRunsPolicy callerRunsPolicy = new ThreadPoolExecutor.CallerRunsPolicy();

    public CoreThreadPolicy() {
    }

    @Override
    public void rejectedExecution(Runnable r, ThreadPoolExecutor e) {
        logger.warn(String.format("线程池已满:%s,%s", r.toString(), e.toString()));
        callerRunsPolicy.rejectedExecution(r, e);
    }
}
