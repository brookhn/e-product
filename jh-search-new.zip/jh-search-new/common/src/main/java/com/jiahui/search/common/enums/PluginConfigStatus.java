package com.jiahui.search.common.enums;

public enum PluginConfigStatus {

    RUNNING(1, "已启用"),
    STOPPED(0, "已停用");

    private Integer code;
    private String msg;

    PluginConfigStatus(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }
}
