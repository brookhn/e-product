package com.jiahui.search.common.rest;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Setter;
import lombok.ToString;
import org.springframework.http.HttpStatus;

/**
 * @author ivy.wang
 * @date 2021/8/5
 */
@Setter
@ToString
public class ApiError extends JsonResult{

    @JsonIgnore
    private HttpStatus status;

    public ApiError() {
    }

    public ApiError(HttpStatus status, long code) {
        this.status = status;
       setCode(code);
    }

    public ApiError(HttpStatus status, long code, String msg) {
        this.status = status;
        setCode(code);
        setMsg(msg);
    }

    public ApiError(long code, String msg) {
        setCode(code);
        setMsg(msg);
    }

    public HttpStatus getStatus() {
        return status;
    }

}
