package com.jiahui.search.common.exception;

import com.jiahui.search.common.enums.CodeEnum;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@ToString
@EqualsAndHashCode(callSuper = true)
public class DataWrapperException extends RuntimeException {

    private Integer code;
    private String msg;

    public DataWrapperException(CodeEnum codeMsg) {
        this(codeMsg.getCode(), codeMsg.getMsg());
    }

    public DataWrapperException(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public DataWrapperException() {
        super();
        this.setCode(CodeEnum.DATA_WRAPPER_EXCEPTION.getCode());
        this.setMsg("DataWrapper执行异常");
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
