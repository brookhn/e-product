package com.jiahui.search.common.exception;

import com.jiahui.search.common.enums.CodeEnum;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * @author SQL
 * 业务异常定义
 */
@Builder
@ToString
@EqualsAndHashCode(callSuper = true)
public class BizException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    private Integer code;
    private String msg;


    public BizException(Integer code, String msg, Throwable cause) {
        super(msg, cause);
        this.code = code;
        this.msg = msg;
    }

    public BizException(Integer code, String msg) {
        super(msg);
        this.code = code;
        this.msg = msg;
    }

    public BizException() {
        this.setCode(CodeEnum.EXCEPTION.getCode());
        this.setMsg(CodeEnum.EXCEPTION.getMsg());
    }

    public BizException(CodeEnum codeMsg) {
        this(codeMsg.getCode(), codeMsg.getMsg());
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
