package com.jiahui.search.common.rest;

import com.jiahui.framework.rpc.rest.ResultVO;
import com.jiahui.search.common.enums.CodeEnum;

import java.io.Serializable;
import java.util.Objects;

/**
 * @author ivy.wang
 */
public class JsonResult<T> extends ResultVO implements Serializable {

    public JsonResult() {
    }

    public static <T> JsonResult<T> success(T data) {
        JsonResult<T> resp = new JsonResult<T>();
        resp.setData(data);
        return resp;
    }

    public static <T> JsonResult<T> success() {
        JsonResult<T> resp = new JsonResult<T>();
        return resp;
    }

    public static <T> JsonResult<T> successWithCode(CodeEnum code) {
        JsonResult<T> resp = new JsonResult<T>();
        resp.setCode(code.getCode());
        resp.setMsg(code.getMsg());
        return resp;
    }

    public static <T> JsonResult<T> failureWithError(CodeEnum code) {
        JsonResult<T> resp = new JsonResult<T>();
        resp.setCode(code.getCode());
        resp.setMsg(code.getMsg());
        return resp;
    }

    public static <T> JsonResult<T> failure(CodeEnum code, String errMsg) {
        JsonResult<T> resp = new JsonResult<T>();
        resp.setCode(code.getCode());
        resp.setMsg(errMsg);
        return resp;
    }

    public static <T> JsonResult<T> failure(String code, String errMsg) {
        JsonResult<T> resp = new JsonResult<T>();
        if (Objects.nonNull(code)) {
            resp.setCode(Long.parseLong(code));
        }
        resp.setMsg(errMsg);
        return resp;
    }
}
