package com.jiahui.search.indexer.core;

import cn.hutool.core.util.StrUtil;

public class RedisKeyManager {

    private static final String VERSION = "V2";

    private static final String PREFIX = "Search";

    public static String getDeltaDocIds(String indexAlias) {
        return StrUtil.format("{}:{}:DeltaIndexIds:{}", VERSION, PREFIX, indexAlias);
    }

    public static String getFullIndexTaskStart(String indexAlias) {
        return StrUtil.format("{}:{}:FullIndexTaskStart:{}", VERSION, PREFIX, indexAlias);
    }

    public static String getDeltaIndexPrepareLock(Long indexConfigId) {
        return StrUtil.format("{}:{}:DeltaIndexPrepare:{}", VERSION, PREFIX, indexConfigId);
    }

    public static String getReadyFullIndexLock(Long indexConfigId) {
        return StrUtil.format("{}:{}:ReadyFullIndexLock:{}", VERSION, PREFIX, indexConfigId);
    }

    public static String getNewIndexName(String indexAlias) {
        return StrUtil.format("{}:{}:NewIndex:{}", VERSION, PREFIX, indexAlias);
    }

    public static String getReadyFullIndexToken(String token) {
        return StrUtil.format("{}:{}:ReadyFullIndexToken:{}", VERSION, PREFIX, token);
    }

}
