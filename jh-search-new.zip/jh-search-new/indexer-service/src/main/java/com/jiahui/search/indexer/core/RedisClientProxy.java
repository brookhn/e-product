package com.jiahui.search.indexer.core;


import org.redisson.api.RBucket;
import org.redisson.api.RLock;
import org.redisson.api.RSet;
import org.redisson.api.RedissonClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.io.Serializable;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

@Component
public class RedisClientProxy {

    private static final Logger logger = LoggerFactory.getLogger(RedisClientProxy.class);
    @Autowired
    private RedissonClient redissonClient;

    /**
     * 单位秒
     *
     * @param key
     * @param timeToLive
     * @return
     */
    public boolean trySet(String key, long timeToLive) {
        RBucket<Integer> bucket = redissonClient.getBucket(key);
        try {
            return bucket.trySet(1, timeToLive, TimeUnit.SECONDS);
        } catch (Exception ex) {
            logger.error("trySetErr", ex);
            return true;
        }
    }

    public <T extends Serializable> boolean set(String key, T t, long timeToLive) {
        try {
            RBucket<T> bucket = redissonClient.getBucket(key);
            bucket.set(t, timeToLive, TimeUnit.SECONDS);
            return true;
        } catch (Exception ex) {
            logger.error("setErr", ex);
            return false;
        }
    }

    public <T> T get(String key) {
        try {
            RBucket<T> bucket = redissonClient.getBucket(key);
            return bucket.get();
        } catch (Exception ex) {
            logger.error("getErr", ex);
            return null;
        }
    }

    public RSet<String> getSet(String key) {
        try {
            return redissonClient.<String>getSet(key);
        } catch (Exception ex) {
            logger.error("getSetErr", ex);
            return null;
        }
    }

    public boolean add2Set(String key, Set<String> set, long timeToLive) {
        if (CollectionUtils.isEmpty(set)) {
            return false;
        }
        try {
            RSet<String> redisSet = redissonClient.getSet(key);
            redisSet.expire(timeToLive, TimeUnit.SECONDS);
            return set.addAll(set);
        } catch (Exception ex) {
            logger.error("add2SetErr", ex);
            return false;
        }
    }

    public boolean deleteSet(String key) {
        try {
            return redissonClient.getSet(key).delete();
        } catch (Exception ex) {
            logger.error("deleteSetErr", ex);
            return true;
        }
    }

    public boolean delete(String key) {
        try {
            return redissonClient.getBucket(key).delete();
        } catch (Exception ex) {
            logger.error("deleteErr", ex);
            return true;
        }
    }

    public <T, R> R lock(String key, T req, long leaseTime, Function<T, R> func) {
        R r = null;
        RLock lock = null;
        try {
            lock = redissonClient.getLock(key);
            lock.lock(leaseTime, TimeUnit.SECONDS);
            r = func.apply(req);
        } catch (Exception ex) {
            logger.error("lockErr", ex);
        } finally {
            try {
                if (lock != null) {
                    lock.unlock();
                }
            } catch (Exception ex) {
                logger.error(ex.getMessage(), ex);
            }
        }
        return r;
    }
}
