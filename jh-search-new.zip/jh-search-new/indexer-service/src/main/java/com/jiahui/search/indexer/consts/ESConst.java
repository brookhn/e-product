package com.jiahui.search.indexer.consts;

public class ESConst {
    public static final String NUMBER_OF_REPLICAS = "index.number_of_replicas";
    public static final String NUMBER_OF_SHARDS = "index.number_of_shards";
    public static final String REFRESH_INTERVAL = "index.refresh_interval";
}
