package com.jiahui.search.indexer.config;

import com.google.common.base.Splitter;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.Header;
import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultConnectionKeepAliveStrategy;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.nio.conn.PoolingNHttpClientConnectionManager;
import org.apache.http.impl.nio.reactor.DefaultConnectingIOReactor;
import org.apache.http.message.BasicHeader;
import org.apache.http.nio.reactor.IOReactorException;
import org.apache.http.nio.reactor.IOReactorExceptionHandler;
import org.apache.http.util.EntityUtils;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestClientBuilder;
import org.elasticsearch.client.RestHighLevelClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Configuration
@EnableConfigurationProperties(ElasticsearchProperties.class)
public class ESConfig {

    @Autowired
    private ElasticsearchProperties esProperties;
    private static final Logger logger = LoggerFactory.getLogger(ESConfig.class);

    private HttpHost[] getHttpHosts() {
        CredentialsProvider basicCredentialsProvider = new BasicCredentialsProvider();
        basicCredentialsProvider.setCredentials(
                new AuthScope(esProperties.getHost(), 80),
                new UsernamePasswordCredentials(esProperties.getUsername(), esProperties.getPassword()));
        CloseableHttpClient httpclient = HttpClients.custom()
                .setDefaultCredentialsProvider(basicCredentialsProvider)
                .build();
        String nodesContent = "";
        CloseableHttpResponse response = null;
        try {
            HttpGet httpget = new HttpGet("http://" + esProperties.getHost() + "/_cat/nodes?h=http_address");
            response = httpclient.execute(httpget);
            nodesContent = EntityUtils.toString(response.getEntity());
            if (StringUtils.isBlank(nodesContent)) {
                throw new IllegalArgumentException("未获取到es节点信息");
            }
            logger.info("nodes:{}", nodesContent);
        } catch (IOException ex) {
            logger.error(ex.getMessage(), ex);
        } finally {
            try {
                if (response != null) {
                    response.close();
                }
                httpclient.close();
            } catch (IOException e) {
                logger.error(e.getMessage(), e);
            }
        }
        List<String> nodes = Splitter.on("\n").omitEmptyStrings().trimResults().splitToList(nodesContent);
        HttpHost[] httpHosts = new HttpHost[nodes.size()];
        for (int i = 0; i < nodes.size(); i++) {
            String[] parts = StringUtils.split(nodes.get(i), ":");
            HttpHost httpHost = new HttpHost(parts[0], Integer.parseInt(parts[1]), "http");
            httpHosts[i] = httpHost;
        }
        return httpHosts;
    }

    @Bean
    @ConditionalOnMissingBean
    public RestHighLevelClient restHighLevelClient() throws IOException {
        HttpHost[] httpHosts = getHttpHosts();
        RestClientBuilder builder = RestClient.builder(httpHosts);

        // Callback used the default {@link RequestConfig} being set to the {@link CloseableHttpClient}
        builder.setRequestConfigCallback(requestConfigBuilder -> {
            requestConfigBuilder.setConnectTimeout(esProperties.getConnectTimeout());
            requestConfigBuilder.setSocketTimeout(esProperties.getSocketTimeout());
            requestConfigBuilder.setConnectionRequestTimeout(esProperties.getConnectionRequestTimeout());
            return requestConfigBuilder;
        });


        // Callback used to customize the {@link CloseableHttpClient} instance used by a {@link RestClient} instance.
        builder.setHttpClientConfigCallback(httpClientBuilder -> {
            httpClientBuilder.setMaxConnTotal(esProperties.getMaxConnectTotal());
            httpClientBuilder.setMaxConnPerRoute(esProperties.getMaxConnectPerRoute());

            // Callback used the basic credential auth
            final CredentialsProvider credentialsProvider = new BasicCredentialsProvider();
            credentialsProvider.setCredentials(AuthScope.ANY, new UsernamePasswordCredentials(esProperties.getUsername(), esProperties.getPassword()));
            httpClientBuilder.setDefaultCredentialsProvider(credentialsProvider);

            List<Header> headers = new ArrayList<>(2);
            headers.add(new BasicHeader("Connection", "keep-alive"));
            //10m
            headers.add(new BasicHeader("Keep-Alive", "600"));
            httpClientBuilder.setDefaultHeaders(headers);
            httpClientBuilder.setKeepAliveStrategy(DefaultConnectionKeepAliveStrategy.INSTANCE);
            try {
                DefaultConnectingIOReactor ioReactor = new DefaultConnectingIOReactor();
                ioReactor.setExceptionHandler(new IOReactorExceptionHandler() {
                    @Override
                    public boolean handle(IOException e) {
                        logger.error(e.getMessage(), e);
                        return true;
                    }

                    @Override
                    public boolean handle(RuntimeException e) {
                        logger.warn(e.getMessage(), e);
                        return true;
                    }
                });
                httpClientBuilder.setConnectionManager(new PoolingNHttpClientConnectionManager(ioReactor));
            } catch (IOReactorException e) {
                throw new RuntimeException(e);
            }

            return httpClientBuilder;
        });

        return new RestHighLevelClient(builder);
    }
}