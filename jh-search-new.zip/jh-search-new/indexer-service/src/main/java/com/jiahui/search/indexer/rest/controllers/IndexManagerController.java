package com.jiahui.search.indexer.rest.controllers;

import com.jiahui.framework.rpc.rest.ResultVO;
import com.jiahui.search.index.manager.contract.*;
import com.jiahui.search.indexer.service.IndexManagerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;

@RestController
@RequestMapping
public class IndexManagerController {

    @Autowired
    private IndexManagerService indexManagerService;

    @PostMapping("/createIndex")
    public ResultVO<CreateIndexResponseType> createIndex(CreateIndexRequestType request) throws IOException {
        return indexManagerService.createIndex(request.getIndexConfigId());
    }

    //修改线上索引mapping
    @PostMapping("/putMapping")
    public ResultVO<PutMappingResponseType> putMapping(@RequestBody PutMappingRequestType request) {
        return indexManagerService.putMapping(request);
    }

    @PostMapping("/closeIndex")
    public ResultVO<CloseIndexResponseType> closeIndex(@RequestBody CloseIndexRequestType request) {
        return indexManagerService.closeIndex(request);
    }

    @PostMapping("/openIndex")
    public ResultVO<OpenIndexResponseType> openIndex(@RequestBody OpenIndexRequestType request) {
        return indexManagerService.openIndex(request);
    }

    @PostMapping("/deleteIndex")
    public ResultVO<DeleteIndexResponseType> deleteIndex(@RequestBody DeleteIndexRequestType request) {
        return indexManagerService.deleteIndex(request);
    }

}
