package com.jiahui.search.indexer.domain.model;

import java.util.Map;

public class DocModel {
    /**
     * 索引名
     */
    private String indexName;
    /**
     *
     */
    private String docId;
    /**
     * 路由Key
     */
    private String routeKey;
    /**
     * 数据
     */
    private Map<String, Object> data;

    private boolean delete;

    public String getIndexName() {
        return indexName;
    }

    public void setIndexName(String indexName) {
        this.indexName = indexName;
    }

    public String getDocId() {
        return docId;
    }

    public void setDocId(String docId) {
        this.docId = docId;
    }

    public String getRouteKey() {
        return routeKey;
    }

    public void setRouteKey(String routeKey) {
        this.routeKey = routeKey;
    }

    public Map<String, Object> getData() {
        return data;
    }

    public void setData(Map<String, Object> data) {
        this.data = data;
    }

    public boolean isDelete() {
        return delete;
    }

    public void setDelete(boolean delete) {
        this.delete = delete;
    }

    public DocModel() {

    }
}
