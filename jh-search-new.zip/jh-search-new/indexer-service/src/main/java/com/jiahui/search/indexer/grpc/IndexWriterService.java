package com.jiahui.search.indexer.grpc;


import com.jiahui.search.indexer.contract.FullIndexRequest;
import com.jiahui.search.indexer.contract.IncrementIndexRequest;
import com.jiahui.search.indexer.contract.IndexResponse;
import com.jiahui.search.indexer.contract.IndexWriterApiGrpc;
import com.jiahui.search.indexer.service.FullIndexWriterService;
import com.jiahui.search.indexer.service.IncrementIndexWriterService;
import io.grpc.stub.StreamObserver;
import net.devh.boot.grpc.server.service.GrpcService;
import org.springframework.beans.factory.annotation.Autowired;

@GrpcService
public class IndexWriterService extends IndexWriterApiGrpc.IndexWriterApiImplBase {

    @Autowired
    private FullIndexWriterService fullIndexWriterService;
    @Autowired
    private IncrementIndexWriterService incrementIndexWriterService;

    @Override
    public void fullIndex(final FullIndexRequest req, final StreamObserver<IndexResponse> responseObserver) {
        IndexResponse response = fullIndexWriterService.fullIndex(req.getIndexConfigId(), req.getDocsList());
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    @Override
    public void incrementIndex(final IncrementIndexRequest req, final StreamObserver<IndexResponse> responseObserver) {
        IndexResponse response = incrementIndexWriterService.incrementIndex(req);
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

}
