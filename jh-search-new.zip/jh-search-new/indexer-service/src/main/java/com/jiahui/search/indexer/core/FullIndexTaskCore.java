package com.jiahui.search.indexer.core;

import com.alibaba.cloud.nacos.NacosConfigManager;
import com.alibaba.cloud.nacos.NacosConfigProperties;
import com.alibaba.nacos.api.config.ConfigService;
import com.alibaba.nacos.client.config.listener.impl.PropertiesListener;
import com.github.rholder.retry.*;
import com.jiahui.search.common.utils.JsonUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.Properties;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

@Component
public class FullIndexTaskCore {
    private static final Logger logger = LoggerFactory.getLogger(FullIndexTaskCore.class);

    @Autowired
    private NacosConfigManager nacosConfigManager;

    private final AtomicReference<Properties> atomicProperties = new AtomicReference<>(new Properties());

    private static final String FULL_INDEX_TASK_DATA_ID = "full-index-task.properties";

    @Autowired
    private RedisClientProxy redisClientProxy;

    final Retryer<Boolean> retryer = RetryerBuilder.<Boolean>newBuilder()
            .retryIfResult(res -> !res)
            .retryIfException()
            // 重试次数
            .withStopStrategy(StopStrategies.stopAfterAttempt(3))
            // 重试间隔
            .withWaitStrategy(WaitStrategies.fixedWait(50, TimeUnit.MILLISECONDS))
            .build();

    @PostConstruct
    public void init() {
        ConfigService configService = nacosConfigManager.getConfigService();
        NacosConfigProperties nacosConfigProperties = nacosConfigManager.getNacosConfigProperties();
        try {
            String content = configService.getConfigAndSignListener(FULL_INDEX_TASK_DATA_ID, nacosConfigProperties.getGroup(), 10000, new PropertiesListener() {
                @Override
                public void innerReceive(Properties p) {
                    Properties oldValue = atomicProperties.getAndSet(p);
                    logger.info("old:{},new:{}", JsonUtil.serialize(oldValue.entrySet()), JsonUtil.serialize(p.entrySet()));
                }
            });
            Properties properties = new Properties();
            properties.load(new StringReader(content));
            atomicProperties.getAndSet(properties);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
    }

    public String getFullIndexNewIndex(String indexAlias) {
        String value = atomicProperties.get().getProperty(indexAlias + ".fullIndexNewIndex");
        if (StringUtils.isBlank(value) || "null".equalsIgnoreCase(value)) {
            value = redisClientProxy.<String>get(RedisKeyManager.getNewIndexName(indexAlias));
        }
        return "null".equalsIgnoreCase(value) ? StringUtils.EMPTY : value;
    }

    private boolean publishConfig(String indexAlias, String newIndexName) {
        ConfigService configService = nacosConfigManager.getConfigService();
        NacosConfigProperties nacosConfigProperties = nacosConfigManager.getNacosConfigProperties();
        boolean publishSuccess = false;
        try {
            String content = configService.getConfig(FULL_INDEX_TASK_DATA_ID, nacosConfigProperties.getGroup(), 10000);
            Properties properties = new Properties();
            properties.load(new StringReader(content));
            properties.setProperty(indexAlias + ".fullIndexNewIndex", newIndexName);
            StringWriter writer = new StringWriter();
            properties.store(new PrintWriter(writer), "");
            content = writer.getBuffer().toString();
            writer.close();
            publishSuccess = configService.publishConfig(FULL_INDEX_TASK_DATA_ID, nacosConfigProperties.getGroup(), content, "properties");
        } catch (Exception e) {
            logger.error("publishConfigErr", e);
        }
        return publishSuccess;
    }

    public void setFullIndexTaskStop(String indexAlias) {
        try {
            retryer.call(() -> publishConfig(indexAlias, "null"));
        } catch (ExecutionException e) {
            logger.error("setFullIndexTaskStopErr", e);
        } catch (RetryException e) {
            logger.error("setFullIndexTaskStopErr", e);
        }
        redisClientProxy.delete(RedisKeyManager.getNewIndexName(indexAlias));
    }

    public boolean setFullIndexTaskStart(String indexAlias, String newIndexName) {
        boolean success = false;
        //写redis
        redisClientProxy.<String>set(RedisKeyManager.getNewIndexName(indexAlias), newIndexName, 86400);
        //写nacos
        try {
            success = retryer.call(() -> publishConfig(indexAlias, newIndexName));
        } catch (ExecutionException e) {
            logger.error("setFullIndexTaskStartErr", e);
        } catch (RetryException e) {
            logger.error("setFullIndexTaskStartErr", e);
        }
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            logger.error(e.getMessage(), e);
        }
        return success;
    }
}
