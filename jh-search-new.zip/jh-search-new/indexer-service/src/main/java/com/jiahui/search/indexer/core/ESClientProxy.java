package com.jiahui.search.indexer.core;

import cn.hutool.core.util.StrUtil;
import com.jiahui.search.common.enums.CodeEnum;
import com.jiahui.search.common.exception.BizException;
import com.jiahui.search.common.utils.JsonUtil;
import com.jiahui.search.entity.IndexFieldConfigEntity;
import com.jiahui.search.indexer.enums.IndexFieldTypeEnum;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.util.EntityUtils;
import org.elasticsearch.action.admin.cluster.health.ClusterHealthRequest;
import org.elasticsearch.action.admin.cluster.health.ClusterHealthResponse;
import org.elasticsearch.action.admin.indices.alias.IndicesAliasesRequest;
import org.elasticsearch.action.admin.indices.alias.get.GetAliasesRequest;
import org.elasticsearch.action.admin.indices.delete.DeleteIndexRequest;
import org.elasticsearch.action.admin.indices.forcemerge.ForceMergeRequest;
import org.elasticsearch.action.admin.indices.forcemerge.ForceMergeResponse;
import org.elasticsearch.action.admin.indices.open.OpenIndexRequest;
import org.elasticsearch.action.admin.indices.open.OpenIndexResponse;
import org.elasticsearch.action.admin.indices.settings.put.UpdateSettingsRequest;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.action.support.master.AcknowledgedResponse;
import org.elasticsearch.client.*;
import org.elasticsearch.client.core.CountRequest;
import org.elasticsearch.client.core.CountResponse;
import org.elasticsearch.client.indices.*;
import org.elasticsearch.cluster.health.ClusterHealthStatus;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.xcontent.XContentBuilder;
import org.elasticsearch.common.xcontent.XContentFactory;
import org.elasticsearch.core.TimeValue;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.rest.RestStatus;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Component
public class ESClientProxy {

    private static final Logger logger = LoggerFactory.getLogger(ESClientProxy.class);

    @Autowired
    private RestHighLevelClient client;

    /**
     * 批量插入
     *
     * @param bulkRequest
     * @return
     */
    public BulkResponse bulk(BulkRequest bulkRequest) throws IOException {
//        bulkRequest.waitForActiveShards(ActiveShardCount.ALL);
        BulkResponse response = client.bulk(bulkRequest, RequestOptions.DEFAULT);
        return response;
    }

    /**
     * 索引是否存在
     *
     * @param index
     * @return
     */
    public boolean existsIndex(String index) {
        GetIndexRequest request = new GetIndexRequest(index);
        try {
            return client.indices().exists(request, RequestOptions.DEFAULT);
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
            return false;
        }
    }

    /**
     * 创建索引
     *
     * @param index
     * @return
     */
    public boolean createIndex(String index, Settings settings, List<IndexFieldConfigEntity> fields) throws IOException {
        CreateIndexRequest request = new CreateIndexRequest(index);
        request.settings(settings);
        XContentBuilder builder = buildMapping(fields);
        request.mapping(builder);
        CreateIndexResponse createIndexResponse = client.indices().create(request, RequestOptions.DEFAULT);
        return Optional.ofNullable(createIndexResponse).map(p -> {
            logger.info("CreateIndexSuccess:{},NewIndex:{}", p.isAcknowledged(), p.index());
            return p.isAcknowledged();
        }).orElse(false);
    }

    public boolean openIndex(String index) {
        OpenIndexRequest request = new OpenIndexRequest(index);
        request.timeout(TimeValue.timeValueMinutes(2));
        try {
            OpenIndexResponse response = client.indices().open(request, RequestOptions.DEFAULT);
            return Optional.ofNullable(response).map(p -> p.isAcknowledged()).orElse(false);
        } catch (IOException e) {
            logger.error("openIndexErr", e);
            return false;
        }
    }

    public boolean closeIndex(String index) {
        CloseIndexRequest request = new CloseIndexRequest(index);
        request.setTimeout(TimeValue.timeValueMinutes(2));
        try {
            CloseIndexResponse response = client.indices().close(request, RequestOptions.DEFAULT);
            return Optional.ofNullable(response).map(p -> p.isAcknowledged()).orElse(false);
        } catch (IOException e) {
            logger.error("openIndexErr", e);
            return false;
        }
    }

    public void indexStatus(String indexName) {
        RestClient restClient = client.getLowLevelClient();
        Response response = null;
        Request request = new Request("GET", StrUtil.format("/_cat/indices/{}?v=true&s=index", indexName));
        try {
            response = restClient.performRequest(request);
        } catch (IOException e) {

        }

        List<Map<String, String>> list = null;
        if (response != null) {
            try {
                String rawBody = EntityUtils.toString(response.getEntity());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }


    /**
     * 别名是否存在
     *
     * @param alias
     * @return
     */
    public boolean existsAlias(String alias) {
        GetAliasesRequest request = new GetAliasesRequest(alias);
        try {
            boolean exists = client.indices().existsAlias(request, RequestOptions.DEFAULT);
            return exists;
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
            return false;
        }
    }

    public String getOnlineIndex(String alias) throws IOException {
        GetAliasesRequest request = new GetAliasesRequest(alias);
        GetAliasesResponse response = client.indices().getAlias(request, RequestOptions.DEFAULT);
        String onlineIndex = Optional.ofNullable(response).filter(p -> p.status() == RestStatus.OK
                && !CollectionUtils.isEmpty(response.getAliases())).map(p -> {
                    logger.info("GetAliasesResponse:{}", JsonUtil.serialize(response.getAliases()));
                    return p.getAliases().keySet().stream().findFirst().orElse(null);
                }
        ).orElse(null);
        return onlineIndex;
    }

    public boolean addAlias(String index, String alias) throws IOException {
        IndicesAliasesRequest indicesAliasesRequest = new IndicesAliasesRequest();
        IndicesAliasesRequest.AliasActions addAction =
                new IndicesAliasesRequest.AliasActions(IndicesAliasesRequest.AliasActions.Type.ADD)
                        .index(index)
                        .alias(alias);
        indicesAliasesRequest.addAliasAction(addAction);
        AcknowledgedResponse response = client.indices().updateAliases(indicesAliasesRequest, RequestOptions.DEFAULT);
        return Optional.ofNullable(response).map(p -> p.isAcknowledged()).orElse(false);
    }

    /**
     * @param originIndex
     * @param newIndex
     * @param alias
     * @return
     * @throws IOException
     */
    public boolean updateAlias(String originIndex, String newIndex, String alias) throws IOException {
        IndicesAliasesRequest indicesAliasesRequest = new IndicesAliasesRequest();
        if (StringUtils.isNotBlank(originIndex)) {
            IndicesAliasesRequest.AliasActions removeAction =
                    new IndicesAliasesRequest.AliasActions(IndicesAliasesRequest.AliasActions.Type.REMOVE)
                            .index(originIndex)
                            .alias(alias);
            indicesAliasesRequest.addAliasAction(removeAction);
        }
        IndicesAliasesRequest.AliasActions addAction =
                new IndicesAliasesRequest.AliasActions(IndicesAliasesRequest.AliasActions.Type.ADD)
                        .index(newIndex)
                        .alias(alias);
        indicesAliasesRequest.addAliasAction(addAction);
        AcknowledgedResponse response = client.indices().updateAliases(indicesAliasesRequest, RequestOptions.DEFAULT);
        return Optional.ofNullable(response).map(p -> p.isAcknowledged()).orElse(false);
    }

    /**
     * 删除索引
     *
     * @param indexName
     * @return
     */
    public boolean deleteIndex(String indexName) throws IOException {
        DeleteIndexRequest request = new DeleteIndexRequest(indexName);
        request.timeout("5m");
        AcknowledgedResponse response = client.indices().delete(request, RequestOptions.DEFAULT);
        return Optional.ofNullable(response).filter(p -> p.isAcknowledged()).map(p -> p.isAcknowledged())
                .<BizException>orElseThrow(() -> {
                    throw new BizException(CodeEnum.DELETE_INDEX_ERR);
                });
    }

    public XContentBuilder buildMapping(List<IndexFieldConfigEntity> fields) throws IOException {
        XContentBuilder builder = XContentFactory.jsonBuilder();
        builder.startObject();
        {
            builder.startObject("properties");
            {
                for (IndexFieldConfigEntity entity : fields) {
                    builder.startObject(entity.getFieldName());
                    {
                        builder.field("type", entity.getIndexFieldType());
                        if (IndexFieldTypeEnum.TEXT.getValue().equalsIgnoreCase(entity.getIndexFieldType())) {
                            if (StringUtils.isNotBlank(entity.getIndexAnalyzer())) {
                                builder.field("analyzer", entity.getIndexAnalyzer());
                            }
                            if (StringUtils.isNotBlank(entity.getSearchAnalyzer())) {
                                builder.field("search_analyzer", entity.getSearchAnalyzer());
                            }
                            if (entity.getNorms() != null && entity.getNorms() == 0) {
                                builder.field("norms", false);
                            }
                            if (entity.getIsIndex() != null && entity.getIsIndex() == 0) {
                                builder.field("index", false);
                            }
                        } else if (IndexFieldTypeEnum.DATE.getValue().equalsIgnoreCase(entity.getIndexFieldType())) {
                            builder.field("format", "yyyy-MM-dd HH:mm:ss||strict_date_optional_time||epoch_millis");
                        } else if (IndexFieldTypeEnum.KEYWORD.getValue().equalsIgnoreCase(entity.getIndexFieldType())) {
                            builder.field("ignore_above", 256);
                        }
                    }
                    builder.endObject();
                }
            }
            builder.endObject();
        }
        builder.endObject();
        return builder;
    }

    public boolean putMapping(String indexName, List<IndexFieldConfigEntity> fields) {
        PutMappingRequest request = new PutMappingRequest(indexName);
        try {
            XContentBuilder builder = buildMapping(fields);
            request.source(builder);
            AcknowledgedResponse response = client.indices().putMapping(request, RequestOptions.DEFAULT);
            return Optional.ofNullable(response).map(p -> p.isAcknowledged()).orElse(false);
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
            return false;
        }
    }


    public ForceMergeResponse forceMerge(String indexName) throws IOException {
        ForceMergeRequest request = new ForceMergeRequest(indexName);
        request.maxNumSegments(1);
        request.flush(true);
        ForceMergeResponse response = client.indices().forcemerge(request, RequestOptions.DEFAULT);
        return response;
    }

    public boolean updateSettings(String indexName, Settings settings) {
        UpdateSettingsRequest request = new UpdateSettingsRequest(indexName);
        request.settings(settings);
        try {
            AcknowledgedResponse response =
                    client.indices().putSettings(request, RequestOptions.DEFAULT);
            return Optional.ofNullable(response).map(p -> p.isAcknowledged()).orElse(false);
        } catch (IOException e) {
            logger.error("updateSettingsErr", e);
            return false;
        }
    }

    public boolean checkHealth(String indexName) throws IOException {
        ClusterHealthRequest request = new ClusterHealthRequest();
        request.indices(indexName);
        ClusterHealthResponse response = client.cluster().health(request, RequestOptions.DEFAULT);
        ClusterHealthStatus healthStatus = Optional.ofNullable(response).filter(p -> p.getStatus() == ClusterHealthStatus.GREEN)
                .map(p -> p.getStatus()).orElse(ClusterHealthStatus.RED);
        return healthStatus == ClusterHealthStatus.GREEN;
    }

    public long count(String index) {
        CountRequest countRequest = new CountRequest();
        countRequest.indices(index);
        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        searchSourceBuilder.query(QueryBuilders.matchAllQuery());
        countRequest.source(searchSourceBuilder);
        try {
            CountResponse response = client.count(countRequest, RequestOptions.DEFAULT);
            return Optional.ofNullable(response).map(p -> p.getCount()).orElse(0l);
        } catch (IOException e) {
            logger.error("countErr", e);
            return 0l;
        }
    }
}
