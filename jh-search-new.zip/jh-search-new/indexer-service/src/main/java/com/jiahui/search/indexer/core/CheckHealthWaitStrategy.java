package com.jiahui.search.indexer.core;

import com.github.rholder.retry.Attempt;
import com.github.rholder.retry.WaitStrategy;

public class CheckHealthWaitStrategy implements WaitStrategy {

    @Override
    public long computeSleepTime(Attempt failedAttempt) {
        long number = failedAttempt.getAttemptNumber();
        if (number >= 1 && number <= 3) {
            return 2000;
        } else if (number >= 4 && number <= 10) {
            return 5000;
        } else {
            return 10000;
        }
    }

}
