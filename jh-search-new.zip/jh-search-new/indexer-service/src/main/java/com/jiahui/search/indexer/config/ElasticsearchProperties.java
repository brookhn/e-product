package com.jiahui.search.indexer.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "es")
public class ElasticsearchProperties {
    private String host;
    private String username;
    private String password;
    /**
     * 连接超时时间(毫秒)
     */
    private int connectTimeout = 2000;

    /**
     * socket 超时时间
     */
    private int socketTimeout = 30000;
    /**
     * 连接请求超时时间
     */
    private int connectionRequestTimeout = 5000;

    /**
     * 每个路由的最大连接数量
     */
    private int maxConnectPerRoute = 200;

    /**
     * 最大连接总数量
     */
    private int maxConnectTotal = 512;

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getConnectTimeout() {
        return connectTimeout;
    }

    public void setConnectTimeout(int connectTimeout) {
        this.connectTimeout = connectTimeout;
    }

    public int getSocketTimeout() {
        return socketTimeout;
    }

    public void setSocketTimeout(int socketTimeout) {
        this.socketTimeout = socketTimeout;
    }

    public int getConnectionRequestTimeout() {
        return connectionRequestTimeout;
    }

    public void setConnectionRequestTimeout(int connectionRequestTimeout) {
        this.connectionRequestTimeout = connectionRequestTimeout;
    }

    public int getMaxConnectPerRoute() {
        return maxConnectPerRoute;
    }

    public void setMaxConnectPerRoute(int maxConnectPerRoute) {
        this.maxConnectPerRoute = maxConnectPerRoute;
    }

    public int getMaxConnectTotal() {
        return maxConnectTotal;
    }

    public void setMaxConnectTotal(int maxConnectTotal) {
        this.maxConnectTotal = maxConnectTotal;
    }
}