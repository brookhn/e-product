package com.jiahui.search.indexer.config;

import com.jiahui.search.common.config.DefaultThreadFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.*;

/**
 * @author zzc
 */
@Configuration
public class ThreadPoolConfig {

    private static final Logger logger = LoggerFactory.getLogger(ThreadPoolConfig.class);

    @Bean(destroyMethod = "shutdown")
    public ExecutorService coreThreadPool() {
        ExecutorService executor = new ThreadPoolExecutor(50,
                100, 60, TimeUnit.SECONDS,
                new LinkedBlockingQueue<Runnable>(1000), new DefaultThreadFactory("coreThreadPool-"), new CoreThreadPolicy());
        return executor;
    }


    /**
     * 核心线程池拒绝策略,线程池满转到主线程运行
     */
    public class CoreThreadPolicy implements RejectedExecutionHandler {


        private ThreadPoolExecutor.CallerRunsPolicy callerRunsPolicy = new ThreadPoolExecutor.CallerRunsPolicy();

        public CoreThreadPolicy() {
        }

        /**
         * Executes task r in the caller's thread, unless the executor has been shut down, in which case the task is discarded.
         *
         * @param r the runnable task requested to be executed
         * @param e the executor attempting to execute this task
         */
        @Override
        public void rejectedExecution(Runnable r, ThreadPoolExecutor e) {
            logger.warn(String.format("线程池已满:%s,%s", r.toString(), e.toString()));
            callerRunsPolicy.rejectedExecution(r, e);
        }
    }
}
