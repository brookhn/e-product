package com.jiahui.search.indexer.service;

import com.jiahui.framework.rpc.rest.ResultVO;
import com.jiahui.search.common.enums.CodeEnum;
import com.jiahui.search.common.exception.BizException;
import com.jiahui.search.entity.IndexConfig;
import com.jiahui.search.entity.IndexFieldConfigEntity;
import com.jiahui.search.index.manager.contract.*;
import com.jiahui.search.indexer.consts.ESConst;
import com.jiahui.search.indexer.core.ESClientProxy;
import com.jiahui.search.indexer.core.IndexWriterCore;
import com.jiahui.search.repository.IndexFieldConfigRepo;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.common.settings.Settings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;

import java.io.IOException;
import java.util.List;

@Service
public class IndexManagerService {

    private static final Logger logger = LoggerFactory.getLogger(FullIndexWriterService.class);

    @Autowired
    private IndexWriterCore indexWriterCore;

    @Autowired
    private ESClientProxy clientProxy;

    @Autowired
    private IndexFieldConfigRepo indexFieldConfigRepo;

    @PostMapping("/createIndex")
    public ResultVO<CreateIndexResponseType> createIndex(Long indexConfigId) throws IOException {
        ResultVO<CreateIndexResponseType> result = new ResultVO<>();
        IndexConfig indexConfig = indexWriterCore.getIndexConfigFromCache(indexConfigId);
        if (indexConfig == null) {
            throw new BizException(CodeEnum.INDEX_CONFIG_NOT_EXISTS.getCode(), CodeEnum.INDEX_CONFIG_NOT_EXISTS.getMsg());
        }
        List<IndexFieldConfigEntity> fields = indexWriterCore.getFieldConfigFromDB(indexConfig.getId());
        String onlineIndex = clientProxy.getOnlineIndex(indexConfig.getIndexAlias());
        if (StringUtils.isBlank(onlineIndex)) {
            String indexName = indexConfig.getIndexName() + "_a";
            Settings settings = Settings.builder()
                    .put(ESConst.NUMBER_OF_REPLICAS, 0)
                    .put(ESConst.NUMBER_OF_SHARDS, indexConfig.getNumberOfShards())
                    .put(ESConst.REFRESH_INTERVAL, "-1")
                    .build();
            boolean createSuccess = clientProxy.createIndex(indexName, settings, fields);
            if (!createSuccess) {
                throw new BizException(CodeEnum.CREATE_INDEX_ERR.getCode(), CodeEnum.CREATE_INDEX_ERR.getMsg());
            }
            boolean addAliasSuccess = clientProxy.addAlias(indexName, indexConfig.getIndexAlias());
            if (!addAliasSuccess) {
                throw new BizException(CodeEnum.ADD_ALIAS_ERR.getCode(), CodeEnum.ADD_ALIAS_ERR.getMsg());
            }
        }
        return result;
    }

    //修改线上索引mapping
    public ResultVO<PutMappingResponseType> putMapping(PutMappingRequestType request) {
        ResultVO<PutMappingResponseType> result = new ResultVO<>();
        IndexConfig indexConfig = indexWriterCore.getIndexConfigFromCache(request.getIndexConfigId());
        if (indexConfig == null) {
            throw new BizException(CodeEnum.INDEX_CONFIG_NOT_EXISTS.getCode(), CodeEnum.INDEX_CONFIG_NOT_EXISTS.getMsg());
        }
        List<IndexFieldConfigEntity> fieldConfigList = indexFieldConfigRepo.getByIndexConfigId(request.getIndexConfigId());
        boolean putMappingSuccess = clientProxy.putMapping(indexConfig.getIndexAlias(), fieldConfigList);
        if (!putMappingSuccess) {
            throw new BizException(CodeEnum.PUT_MAPPING_ERR);
        }
        return result;
    }

    public ResultVO<CloseIndexResponseType> closeIndex(CloseIndexRequestType request) {
        ResultVO<CloseIndexResponseType> result = new ResultVO<>();
        IndexConfig indexConfig = indexWriterCore.getIndexConfigFromCache(request.getIndexConfigId());
        if (indexConfig == null) {
            throw new BizException(CodeEnum.INDEX_CONFIG_NOT_EXISTS.getCode(), CodeEnum.INDEX_CONFIG_NOT_EXISTS.getMsg());
        }
        String index_a = indexConfig.getIndexAlias() + "_a";
        if (clientProxy.existsIndex(index_a)) {
            clientProxy.closeIndex(index_a);
        }
        String index_b = indexConfig.getIndexAlias() + "_b";
        if (clientProxy.existsIndex(index_b)) {
            clientProxy.closeIndex(index_b);
        }
        return result;
    }

    public ResultVO<OpenIndexResponseType> openIndex(OpenIndexRequestType request) {
        ResultVO<OpenIndexResponseType> result = new ResultVO<>();
        IndexConfig indexConfig = indexWriterCore.getIndexConfigFromCache(request.getIndexConfigId());
        if (indexConfig == null) {
            throw new BizException(CodeEnum.INDEX_CONFIG_NOT_EXISTS);
        }
        boolean openSuccess = clientProxy.openIndex(indexConfig.getIndexAlias());
        if (!openSuccess) {
            throw new BizException(-1, "");
        }
        return result;
    }

    public ResultVO<DeleteIndexResponseType> deleteIndex(DeleteIndexRequestType request) {
        ResultVO<DeleteIndexResponseType> result = new ResultVO<>();
        return result;
    }
}
