package com.jiahui.search.indexer.service;

import cn.hutool.core.util.StrUtil;
import com.github.rholder.retry.*;
import com.jiahui.framework.rpc.rest.ResultVO;
import com.jiahui.search.common.enums.CodeEnum;
import com.jiahui.search.common.exception.BizException;
import com.jiahui.search.entity.IndexConfig;
import com.jiahui.search.entity.IndexFieldConfigEntity;
import com.jiahui.search.index.writer.rest.contract.PrepareIndexResponse;
import com.jiahui.search.index.writer.rest.contract.ReadyFullIndexRequest;
import com.jiahui.search.indexer.consts.ESConst;
import com.jiahui.search.indexer.contract.DocDto;
import com.jiahui.search.indexer.contract.IndexResponse;
import com.jiahui.search.indexer.core.*;
import com.jiahui.search.indexer.domain.model.DocModel;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.common.settings.Settings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.io.IOException;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

@Service
public class FullIndexWriterService {

    private static final Logger logger = LoggerFactory.getLogger(FullIndexWriterService.class);

    @Autowired
    private ESClientProxy clientProxy;
    @Autowired
    private IndexWriterCore indexWriterCore;
    @Autowired
    private FullIndexTaskCore fullIndexTaskCore;
    @Autowired
    private RedisClientProxy redisClientProxy;

    final Retryer<Boolean> retryer = RetryerBuilder.<Boolean>newBuilder()
            .retryIfResult(res -> !res)
            .retryIfException()
            // 重试次数
            .withStopStrategy(StopStrategies.stopAfterAttempt(3))
            // 重试间隔
            .withWaitStrategy(WaitStrategies.fixedWait(50, TimeUnit.MILLISECONDS))
            .build();

    final Retryer<Boolean> checkHealthRetryer = RetryerBuilder.<Boolean>newBuilder()
            .retryIfResult(res -> !res)
            .retryIfException()
            .withStopStrategy(StopStrategies.stopAfterAttempt(100))
            .withWaitStrategy(new CheckHealthWaitStrategy())
            .build();

    public ResultVO<PrepareIndexResponse> prepareFullIndex(Long indexConfigId) {
        ResultVO<PrepareIndexResponse> result = null;
        IndexConfig indexConfig = indexWriterCore.getIndexConfigFromCache(indexConfigId);
        if (indexConfig == null) {
            throw new BizException(CodeEnum.INDEX_CONFIG_NOT_EXISTS);
        }
        List<IndexFieldConfigEntity> fields = indexWriterCore.getFieldConfigFromDB(indexConfig.getId());
        //有全量任务在跑返回失败
        String redisKey = RedisKeyManager.getFullIndexTaskStart(indexConfig.getIndexAlias());
        if (!redisClientProxy.trySet(redisKey, 3600 * 24)) {
            throw new BizException(CodeEnum.FULL_INDEX_RUNNING.getCode(),
                    indexConfig.getIndexAlias() + CodeEnum.FULL_INDEX_RUNNING.getMsg());
        }
        String onlineIndex = null;
        try {
            onlineIndex = clientProxy.getOnlineIndex(indexConfig.getIndexAlias());
        } catch (IOException e) {
            logger.error("getOnlineIndexErr", e);
            clean(indexConfig);
            throw new BizException(CodeEnum.EXCEPTION.getCode(), e.getMessage(), e);
        }
//        if (StringUtils.isBlank(onlineIndex)) {
//            clean(indexConfig);
//            result = new ResultVO<>(CodeEnum.ALIAS_NOT_EXISTS.getCode(),
//                    indexConfig.getIndexAlias() + CodeEnum.ALIAS_NOT_EXISTS.getMsg());
//            return result;
//        }
        String newIndexName = indexWriterCore.getNewIndexName(onlineIndex, indexConfig.getIndexAlias());
        try {
            if (clientProxy.existsIndex(newIndexName)) {
                clientProxy.deleteIndex(newIndexName);
            }
            Settings settings = Settings.builder()
                    .put(ESConst.NUMBER_OF_REPLICAS, 0)
                    .put(ESConst.NUMBER_OF_SHARDS, indexConfig.getNumberOfShards())
                    .put(ESConst.REFRESH_INTERVAL, "-1")
                    .build();
            boolean success = clientProxy.createIndex(newIndexName, settings, fields);
            if (!success) {
                clean(indexConfig);
                result = new ResultVO<>(CodeEnum.CREATE_INDEX_ERR.getCode(), CodeEnum.CREATE_INDEX_ERR.getMsg());
                return result;
            }
            if (StringUtils.isBlank(onlineIndex)) {
                success = clientProxy.addAlias(newIndexName, indexConfig.getIndexAlias());
                if (success) {
                    logger.info("{}别名创建成功", indexConfig.getIndexAlias());
                } else {
                    result.setCode(CodeEnum.ADD_ALIAS_ERR.getCode());
                    result.setMsg(CodeEnum.ADD_ALIAS_ERR.getMsg());
                    return result;
                }
            }
        } catch (IOException e) {
            clean(indexConfig);
            logger.error("createIndexErr", e);
            throw new BizException(CodeEnum.EXCEPTION.getCode(), e.getMessage(), e);
        }

        boolean success = fullIndexTaskCore.setFullIndexTaskStart(indexConfig.getIndexAlias(), newIndexName);
        if (!success) {
            clean(indexConfig);
            result = new ResultVO<>(CodeEnum.PUBLISH_NACOS_ERR.getCode(), CodeEnum.PUBLISH_NACOS_ERR.getMsg());
            return result;
        }

        result = new ResultVO<>();
        result.setData(PrepareIndexResponse.builder().indexName(newIndexName).build());
        return result;
    }

    public IndexResponse fullIndex(Long indexConfigId, List<DocDto> docs) {
        try {
            IndexConfig indexConfig = indexWriterCore.getIndexConfigFromCache(indexConfigId);
            List<DocModel> list = indexWriterCore.convertDoc(indexConfigId, docs);
            Set<String> deltaDocIds = redisClientProxy.getSet(RedisKeyManager.getDeltaDocIds(indexConfig.getIndexAlias()));
            //判断Id在增量索引中是否已处理过
            if (!CollectionUtils.isEmpty(deltaDocIds)) {
                list.removeIf(p -> deltaDocIds.contains(p.getDocId()));
            }
            String newIndexName = fullIndexTaskCore.getFullIndexNewIndex(indexConfig.getIndexAlias());
            int count = indexWriterCore.bulk(list, newIndexName);
            //TODO:比对写入和返回数量
            logger.info("索引{}批量写入:{}", indexConfig.getIndexAlias(), count);
            return IndexResponse.newBuilder().setAffectedRowCount(count).setCode(CodeEnum.SUCCESS.getCode())
                    .setMsg(CodeEnum.SUCCESS.getMsg()).build();
        } catch (Exception ex) {
            logger.error("fullIndexErr", ex);
            return IndexResponse.newBuilder().setCode(CodeEnum.EXCEPTION.getCode())
                    .setMsg(ex.getMessage()).build();
        }
    }

    private void clean(IndexConfig indexConfig) {
        try {
            fullIndexTaskCore.setFullIndexTaskStop(indexConfig.getIndexAlias());
            redisClientProxy.deleteSet(RedisKeyManager.getDeltaDocIds(indexConfig.getIndexAlias()));
            redisClientProxy.delete(RedisKeyManager.getFullIndexTaskStart(indexConfig.getIndexAlias()));
        } catch (Exception e) {
            logger.error("CleanFullIndexErr", e);
        }
    }

    private boolean updateAlias(String newIndexName, String indexAlias) throws IOException {
        String onlineIndex = clientProxy.getOnlineIndex(indexAlias);
        if (StringUtils.isBlank(onlineIndex)) {
            return false;
        }
        return clientProxy.updateAlias(onlineIndex, newIndexName, indexAlias);
    }

    public ResultVO<Boolean> readyFullIndex(ReadyFullIndexRequest request) {
        IndexConfig indexConfig = indexWriterCore.getIndexConfigFromCache(request.getIndexConfigId());
        if (!request.isDone()) {
            logger.warn("{}全量索引失败", indexConfig.getIndexAlias());
            clean(indexConfig);
            ResultVO<Boolean> result = new ResultVO<>(CodeEnum.SUCCESS.getCode(), "FullIndexErr", false);
            return result;
        }
        String lockKey = RedisKeyManager.getReadyFullIndexLock(indexConfig.getId());
        ResultVO<Boolean> result = redisClientProxy.lock(lockKey, indexConfig, 3600, p -> readyFullIndexCore(p));
        return result;
    }

    public ResultVO<Boolean> readyFullIndexCore(IndexConfig indexConfig) {
        ResultVO<Boolean> result = null;
        try {
            String newIndexName = fullIndexTaskCore.getFullIndexNewIndex(indexConfig.getIndexAlias());
            if (StringUtils.isBlank(newIndexName)) {
                result = new ResultVO<>(CodeEnum.FULL_INDEX_FINISH.getCode(), CodeEnum.FULL_INDEX_FINISH.getMsg());
                return result;
            }
//            //合并索引
//            try {
//                clientProxy.forceMerge(newIndexName);
//            } catch (Exception ex) {
//                logger.error("forceMergeErr", ex);
//            }

            //开启副本
            Settings settings = Settings.builder().put(ESConst.NUMBER_OF_REPLICAS, indexConfig.getNumberOfReplicas())
                    .put(ESConst.REFRESH_INTERVAL, indexConfig.getRefreshInterval()).build();
            boolean success = retryer.call(() -> clientProxy.updateSettings(newIndexName, settings));
            if (!success) {
                result = new ResultVO<>(CodeEnum.UPDATE_INDEX_SETTINGS_ERR.getCode(), CodeEnum.UPDATE_INDEX_SETTINGS_ERR.getMsg());
                return result;
            }

            //检查集群状态
            try {
                checkHealthRetryer.call(() -> clientProxy.checkHealth(newIndexName));
            } catch (ExecutionException e) {
                logger.error("checkHealthErr", e);
            } catch (RetryException e) {
                logger.error("setFullIndexTaskStopErr", e);
            }

            //检查索引数量
            success = checkRebuild(indexConfig.getIndexAlias(), newIndexName);
            if (!success) {
                result = new ResultVO<>(CodeEnum.CHECK_REBUILD_ERR.getCode(), CodeEnum.CHECK_REBUILD_ERR.getMsg());
                return result;
            }
            //别名切换到新索引
            success = retryer.call(() -> updateAlias(newIndexName, indexConfig.getIndexAlias()));
            if (success) {
                logger.info("别名{}切换到新索引{}", indexConfig.getIndexAlias(), newIndexName);
            } else {
                result = new ResultVO<>(CodeEnum.UPDATE_ALIAS_ERR.getCode(), CodeEnum.UPDATE_ALIAS_ERR.getMsg());
                return result;
            }

        } catch (Exception e) {
            logger.error("readyFullIndexErr", e);
            result = new ResultVO<>(CodeEnum.EXCEPTION.getCode(), e.getMessage());
            return result;
        } finally {
            clean(indexConfig);
        }

        result = new ResultVO<>(true);
        return result;
    }

    private boolean checkRebuild(String alias, String newIndex) {
        long count1 = clientProxy.count(alias);
        long count2 = clientProxy.count(newIndex);
        String msg = StrUtil.format("{}原索引数据量:{},新索引数据量:{}", alias, count1, count2);
        logger.info(msg);
        if (count2 >= count1) {
            return true;
        } else {
            if (100 * (count1 - count2) / count1 < 5) {
                return true;
            }
        }
        return false;
    }
}
