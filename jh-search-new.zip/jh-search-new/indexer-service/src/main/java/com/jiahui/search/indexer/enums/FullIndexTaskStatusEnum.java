package com.jiahui.search.indexer.enums;

public enum FullIndexTaskStatusEnum {
    RUNNING(1),
    STOP(2);

    FullIndexTaskStatusEnum(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    private int value;


}
