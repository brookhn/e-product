package com.jiahui.search.indexer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.ComponentScan;

@EnableDiscoveryClient
@ComponentScan(basePackages = {"com.jiahui.search.*"})
@SpringBootApplication
public class IndexerApplication {

    public static void main(final String... args) {
        SpringApplication.run(IndexerApplication.class, args);
    }

}
