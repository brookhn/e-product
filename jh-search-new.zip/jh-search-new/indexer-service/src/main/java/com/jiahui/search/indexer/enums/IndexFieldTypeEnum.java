package com.jiahui.search.indexer.enums;

public enum IndexFieldTypeEnum {
    KEYWORD("keyword"),
    TEXT("text"),
    INT("int"),
    LONG("long"),
    FLOAT("float"),
    DOUBLE("double"),
    DATE("date"),
    OBJECT("object"),
    array("array");

    IndexFieldTypeEnum(String value) {
        this.value = value;
    }

    private String value;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
