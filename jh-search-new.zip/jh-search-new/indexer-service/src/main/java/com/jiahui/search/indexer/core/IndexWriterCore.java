package com.jiahui.search.indexer.core;

import cn.hutool.core.date.DateUtil;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.github.benmanes.caffeine.cache.LoadingCache;
import com.github.rholder.retry.*;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import com.google.common.primitives.Doubles;
import com.google.common.primitives.Floats;
import com.google.common.primitives.Ints;
import com.google.common.primitives.Longs;
import com.jiahui.search.common.utils.JsonUtil;
import com.jiahui.search.entity.IndexConfig;
import com.jiahui.search.entity.IndexFieldConfigEntity;
import com.jiahui.search.entity.PluginConfig;
import com.jiahui.search.indexer.contract.DocDto;
import com.jiahui.search.indexer.domain.model.DocModel;
import com.jiahui.search.repository.IndexConfigRepo;
import com.jiahui.search.repository.IndexFieldConfigRepo;
import com.jiahui.search.repository.PluginConfigRepo;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.action.delete.DeleteRequest;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.common.xcontent.XContentType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import java.util.stream.Collectors;

@Component
public class IndexWriterCore {
    private static final Logger logger = LoggerFactory.getLogger(IndexWriterCore.class);
    @Autowired
    private ESClientProxy clientProxy;
    @Autowired
    private PluginConfigRepo pluginConfigRepo;
    @Autowired
    private IndexFieldConfigRepo indexFieldConfigRepo;
    @Autowired
    private IndexConfigRepo indexConfigRepo;

    @Resource(name = "coreThreadPool")
    private ExecutorService threadPool;

    private LoadingCache<String, String> onlineIndexCache = Caffeine.newBuilder()
            .maximumSize(500)
            .expireAfterWrite(5, TimeUnit.MINUTES)
            .refreshAfterWrite(5, TimeUnit.SECONDS)
            .build(key -> getOnlineIndex(key));

    private LoadingCache<Long, IndexConfig> indexConfigCache = Caffeine.newBuilder()
            .maximumSize(1000)
            .expireAfterWrite(2, TimeUnit.HOURS)
            .refreshAfterWrite(30, TimeUnit.SECONDS)
            .build(key -> getIndexConfigById(key));

    private LoadingCache<Long, Map<String, String>> fieldConfigCache = Caffeine.newBuilder()
            .maximumSize(1000)
            .expireAfterWrite(1, TimeUnit.HOURS)
            .refreshAfterWrite(10, TimeUnit.SECONDS)
            .build(key -> getFieldTypeMap(key));

    private LoadingCache<Long, PluginConfig> pluginConfigCache = Caffeine.newBuilder()
            .maximumSize(1000)
            .expireAfterWrite(12, TimeUnit.HOURS)
            .refreshAfterWrite(10, TimeUnit.MINUTES)
            .build(key -> getPluginConfigByIndexConfigId(key));

    private Map<String, Function<Object, Object>> typeConverts = ImmutableMap.<String, Function<Object, Object>>builder()
            .put("String", (Object obj) -> Objects.isNull(obj) ? StringUtils.EMPTY : obj.toString().trim())
            .put("Integer", (Object obj) -> Objects.isNull(obj) ? 0 : Ints.tryParse(obj.toString()))
            .put("Long", (Object obj) -> Objects.isNull(obj) ? 0l : Longs.tryParse(obj.toString()))
            .put("Float", (Object obj) -> Objects.isNull(obj) ? 0f : Floats.tryParse(obj.toString()))
            .put("Double", (Object obj) -> Objects.isNull(obj) ? 0d : Doubles.tryParse(obj.toString()))
            .put("Date", (Object obj) -> {
                if (Objects.isNull(obj)) {
                    LocalDateTime date = LocalDateTime.of(1900, 1, 1, 0, 0, 0);
                    return date.toInstant(ZoneOffset.of("+8")).toEpochMilli();
                }
                String str = obj.toString();
                return DateUtil.parse(str).getTime();
            })
            .put("LongList", (Object obj) -> {
                if (Objects.isNull(obj)) {
                    return null;
                }
                String str = JsonUtil.serialize(obj);
                List<Long> list = JsonUtil.json2List(str, Long.class);
                return list;
            })
            .put("StrList", (Object obj) -> {
                if (Objects.isNull(obj)) {
                    return null;
                }
                String str = JsonUtil.serialize(obj);
                List<String> list = JsonUtil.json2List(str, String.class);
                return list;
            })
            .build();

    final Retryer<BulkResponse> bulkRetryer = RetryerBuilder.<BulkResponse>newBuilder()
            .retryIfResult(r -> Objects.isNull(r) || r.hasFailures())
            .retryIfException()
            // 重试次数
            .withStopStrategy(StopStrategies.stopAfterAttempt(3))
            // 重试间隔
            .withWaitStrategy(WaitStrategies.fixedWait(50, TimeUnit.MILLISECONDS))
            .build();

    public String getOnlineIndex(String alias) {
        try {
            return clientProxy.getOnlineIndex(alias);
        } catch (IOException e) {
            logger.error("getOnlineIndexErr", e);
            return null;
        }
    }

    public String getOnlineIndexFromCache(String alias) {
        return onlineIndexCache.get(alias);
    }

    public List<IndexFieldConfigEntity> getFieldConfigFromDB(Long indexConfigId) {
        List<IndexFieldConfigEntity> fields = indexFieldConfigRepo.getByIndexConfigId(indexConfigId);
        return fields;
    }

    private Map<String, String> getFieldTypeMap(Long indexConfigId) {
        List<IndexFieldConfigEntity> list = indexFieldConfigRepo.getByIndexConfigId(indexConfigId);
        Map<String, String> map = list.stream().collect(Collectors.toMap(p -> p.getFieldName(), p -> p.getFieldType(), (p1, p2) -> p2));
        return map;
    }

    public IndexConfig getIndexConfigFromCache(Long id) {
        IndexConfig indexConfig = indexConfigCache.get(id);
        return indexConfig;
    }

    private IndexConfig getIndexConfigById(Long id) {
        IndexConfig indexConfig = indexConfigRepo.getById(id);
        return indexConfig;
    }

    private PluginConfig getPluginConfigByIndexConfigId(Long indexConfigId) {
        PluginConfig pluginConfig = pluginConfigRepo.getByIndexConfigId(indexConfigId);
        return pluginConfig;
    }

    public int bulkCore(List<DocModel> list, String indexName) {
        BulkRequest bulkRequest = new BulkRequest();
        for (DocModel docModel : list) {
            if (docModel.isDelete()) {
                DeleteRequest deleteRequest = new DeleteRequest(indexName, docModel.getDocId());
                bulkRequest.add(deleteRequest);
            } else {
                IndexRequest indexRequest = new IndexRequest(indexName).id(docModel.getDocId()).
                        source(docModel.getData(), XContentType.JSON);
                bulkRequest.add(indexRequest);
            }
        }
        BulkResponse response = null;
        try {
            response = bulkRetryer.call(() -> clientProxy.bulk(bulkRequest));
        } catch (ExecutionException e) {
            logger.error(e.getMessage(), e);
        } catch (RetryException e) {
            logger.error("bulkRetryErr", e);
        }
        if (response == null) {
            logger.error("bulkErr,BulkResponse is null");
            return 0;
        }
        if (response.hasFailures()) {
            logger.error("bulkErr:{}", response.buildFailureMessage());
            return 0;
        }
        return Optional.ofNullable(response.getItems()).map(p -> p.length).orElse(0);
    }

    public int parallelBulk(List<DocModel> list, String indexName) {
        List<List<DocModel>> partitions = Lists.partition(list, 50);
        List<CompletableFuture<Integer>> futureList = partitions.stream().map(partition -> {
            CompletableFuture<Integer> f = CompletableFuture.supplyAsync(() -> bulkCore(partition, indexName), threadPool);
            return f;
        }).collect(Collectors.toList());
        CompletableFuture<List<Integer>> future = CompletableFuture.allOf(futureList.toArray(new CompletableFuture[futureList.size()]))
                .thenApply(v ->
                        futureList.stream().
                                map(f -> f.join()).
                                collect(Collectors.<Integer>toList()));
        int totalCount = future.join().stream().reduce((sum, i) -> {
            sum += i;
            return sum;
        }).orElse(0);
        return totalCount;
    }

    public int bulk(List<DocModel> list, String indexName) {
        if (CollectionUtils.isEmpty(list)) {
            return 0;
        }
        if (list.size() > 50) {
            return parallelBulk(list, indexName);
        } else {
            return bulkCore(list, indexName);
        }
    }

    public List<DocModel> convertDoc(Long indexConfigId, List<DocDto> docs) {
        PluginConfig pluginConfig = pluginConfigCache.get(indexConfigId);
        Map<String, String> fieldTypeMap = fieldConfigCache.get(indexConfigId);
        String idField = pluginConfig.getIdFieldName();
        List<DocModel> list = new ArrayList<>();
        for (DocDto doc : docs) {
            String dataStr = doc.getData();
            Map<String, Object> dataRow = JsonUtil.parseStringObjectMap(dataStr);
            Object idObj = dataRow.get(idField);
            if (Objects.isNull(idObj)) {
                continue;
            }
            String idStr = idObj.toString();
            if (!StringUtils.isNumeric(idStr)) {
                logger.warn("{}:非数值类型", idStr);
                break;
            }
            DocModel docModel = new DocModel();
            docModel.setDocId(idStr);
            if (DocDto.OpEnum.Delete.equals(doc.getOp())) {
                docModel.setDelete(true);
            } else {
                Map<String, Object> data = new LinkedHashMap<>();
                for (Map.Entry<String, Object> entry : dataRow.entrySet()) {
                    String fieldType = fieldTypeMap.get(entry.getKey());
                    if (StringUtils.isBlank(fieldType)) {
                        logger.error(entry.getKey() + "字段未配置");
                        continue;
                    }
                    //类型转换
                    Function<Object, Object> func = typeConverts.get(fieldType);
                    Object targetObj = func.apply(entry.getValue());
                    data.put(entry.getKey(), targetObj);
                }
                docModel.setData(data);
            }
            list.add(docModel);
        }
        logger.info("indexData:{}", JsonUtil.serialize(list));
        return list;
    }

    public String getNewIndexName(String onlineIndex, String alias) {
        String newIndexName;
        if (StringUtils.isBlank(onlineIndex)) {
            newIndexName = alias + "_a";
        } else if (onlineIndex.endsWith("_a")) {
            newIndexName = alias + "_b";
        } else {
            newIndexName = alias + "_a";
        }
        return newIndexName;
    }
}
