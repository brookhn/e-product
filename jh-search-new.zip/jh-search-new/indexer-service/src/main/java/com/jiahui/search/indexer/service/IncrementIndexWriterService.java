package com.jiahui.search.indexer.service;


import com.jiahui.framework.rpc.rest.ResultVO;
import com.jiahui.search.common.enums.CodeEnum;
import com.jiahui.search.entity.IndexConfig;
import com.jiahui.search.entity.IndexFieldConfigEntity;
import com.jiahui.search.index.writer.rest.contract.PrepareIndexResponse;
import com.jiahui.search.indexer.consts.ESConst;
import com.jiahui.search.indexer.contract.IncrementIndexRequest;
import com.jiahui.search.indexer.contract.IndexResponse;
import com.jiahui.search.indexer.core.*;
import com.jiahui.search.indexer.domain.model.DocModel;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.common.settings.Settings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class IncrementIndexWriterService {
    @Autowired
    private ESClientProxy clientProxy;
    @Autowired
    private IndexWriterCore indexWriterCore;
    @Autowired
    private FullIndexTaskCore fullIndexTaskCore;
    @Autowired
    private RedisClientProxy redisClientProxy;

    private static final Logger logger = LoggerFactory.getLogger(IncrementIndexWriterService.class);

    public IndexResponse incrementIndex(IncrementIndexRequest req) {
        IndexConfig indexConfig = indexWriterCore.getIndexConfigFromCache(req.getIndexConfigId());
        if (indexConfig == null) {
            return IndexResponse.newBuilder().setCode(CodeEnum.INDEX_CONFIG_NOT_EXISTS.getCode())
                    .setMsg(CodeEnum.INDEX_CONFIG_NOT_EXISTS.getMsg()).build();
        }
        //是否有全量索引在跑
        try {
            List<DocModel> docModels = indexWriterCore.convertDoc(indexConfig.getId(), req.getDocsList());
            String newIndexName = fullIndexTaskCore.getFullIndexNewIndex(indexConfig.getIndexAlias());
            if (StringUtils.isNotBlank(newIndexName)) {
                Set<String> docIds = docModels.stream().map(p -> p.getDocId()).collect(Collectors.toSet());
                String redisKey = RedisKeyManager.getDeltaDocIds(indexConfig.getIndexAlias());
                redisClientProxy.add2Set(redisKey, docIds, 3600);
            }
            int count = indexWriterCore.bulk(docModels, indexConfig.getIndexAlias());
            if (count > 0 && StringUtils.isNotBlank(newIndexName)) {
                indexWriterCore.bulk(docModels, newIndexName);
            }
            return IndexResponse.newBuilder().setAffectedRowCount(count).setCode(CodeEnum.SUCCESS.getCode())
                    .setMsg(CodeEnum.SUCCESS.getMsg()).build();
        } catch (Exception ex) {
            return IndexResponse.newBuilder().setCode(CodeEnum.EXCEPTION.getCode())
                    .setMsg(ex.getMessage()).build();
        }
    }

    public ResultVO<PrepareIndexResponse> prepareIndex(Long indexConfigId) {
        ResultVO<PrepareIndexResponse> result = new ResultVO<>();
        IndexConfig indexConfig = indexWriterCore.getIndexConfigFromCache(indexConfigId);
        if (indexConfig == null) {
            result.setCode(CodeEnum.INDEX_CONFIG_NOT_EXISTS.getCode());
            result.setMsg(CodeEnum.INDEX_CONFIG_NOT_EXISTS.getMsg());
            return result;
        }
        return redisClientProxy.lock(RedisKeyManager.getDeltaIndexPrepareLock(indexConfig.getId()), indexConfig, 300,
                p -> prepareIndex(p));
    }

    public ResultVO<PrepareIndexResponse> prepareIndex(IndexConfig indexConfig) {
        ResultVO<PrepareIndexResponse> result = new ResultVO<>();
        List<IndexFieldConfigEntity> fields = indexWriterCore.getFieldConfigFromDB(indexConfig.getId());
        //查询别名是否存在
        String onlineIndex = null;
        try {
            onlineIndex = clientProxy.getOnlineIndex(indexConfig.getIndexAlias());
        } catch (IOException e) {
            logger.error("getOnlineIndexErr", e);
            result.setCode(CodeEnum.EXCEPTION.getCode());
            result.setMsg(e.getMessage());
            return result;
        }
        if (StringUtils.isBlank(onlineIndex)) {
            try {
                String newIndex = indexConfig.getIndexAlias() + "_a";
                Settings settings = Settings.builder()
                        .put(ESConst.NUMBER_OF_REPLICAS, 0)
                        .put(ESConst.NUMBER_OF_SHARDS, indexConfig.getNumberOfShards())
                        .put(ESConst.REFRESH_INTERVAL, indexConfig.getRefreshInterval())
                        .build();
                boolean success = clientProxy.createIndex(newIndex, settings, fields);
                if (!success) {
                    result.setCode(CodeEnum.CREATE_INDEX_ERR.getCode());
                    result.setMsg(CodeEnum.CREATE_INDEX_ERR.getMsg());
                    return result;
                }
                success = clientProxy.addAlias(newIndex, indexConfig.getIndexAlias());
                if (!success) {
                    result.setCode(CodeEnum.ADD_ALIAS_ERR.getCode());
                    result.setMsg(CodeEnum.ADD_ALIAS_ERR.getMsg());
                    return result;
                }
                result.setData(PrepareIndexResponse.builder().indexName(newIndex).build());
            } catch (Exception e) {
                logger.error("createIndexErr", e);
                result.setCode(CodeEnum.RETRY.getCode());
                result.setMsg(e.getMessage());
            }
        } else {
            boolean success = clientProxy.putMapping(indexConfig.getIndexAlias(), fields);
            if (!success) {
                result.setCode(CodeEnum.PUT_MAPPING_ERR.getCode());
                result.setMsg(CodeEnum.PUT_MAPPING_ERR.getMsg());
                return result;
            }
            result.setData(PrepareIndexResponse.builder().indexName(onlineIndex).build());
        }

        return result;
    }

}
