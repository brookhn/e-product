package com.jiahui.search.indexer.rest.controllers;

import com.jiahui.framework.rpc.rest.ResultVO;
import com.jiahui.search.index.writer.rest.contract.PrepareIndexRequest;
import com.jiahui.search.index.writer.rest.contract.PrepareIndexResponse;
import com.jiahui.search.index.writer.rest.contract.ReadyFullIndexRequest;
import com.jiahui.search.indexer.service.FullIndexWriterService;
import com.jiahui.search.indexer.service.IncrementIndexWriterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping
public class IndexWriterController {
    @Autowired
    private FullIndexWriterService fullIndexWriterService;
    @Autowired
    private IncrementIndexWriterService incrementIndexWriterService;

    @PostMapping("/prepareFullIndex")
    public ResultVO<PrepareIndexResponse> prepareFullIndex(@RequestBody PrepareIndexRequest request) {
        return fullIndexWriterService.prepareFullIndex(request.getIndexConfigId());
    }

    @PostMapping("/prepareIncrementIndex")
    public ResultVO<PrepareIndexResponse> prepareIncrementIndex(@RequestBody PrepareIndexRequest request) {
        return incrementIndexWriterService.prepareIndex(request.getIndexConfigId());
    }

    @PostMapping("/readyFullIndex")
    public ResultVO<Boolean> readyFullIndex(@RequestBody ReadyFullIndexRequest request) {
        return fullIndexWriterService.readyFullIndex(request);
    }
}
