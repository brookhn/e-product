package com.jiahui.search.index.manager.contract;

public class PutMappingResponseType {
}
