package com.jiahui.search.index.manager.contract;

public class CreateIndexResponseType {

    private String indexName;

    public String getIndexName() {
        return indexName;
    }

    public void setIndexName(String indexName) {
        this.indexName = indexName;
    }
}
