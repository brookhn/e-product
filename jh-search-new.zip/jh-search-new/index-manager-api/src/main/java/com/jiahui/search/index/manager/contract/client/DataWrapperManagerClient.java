package com.jiahui.search.index.manager.contract.client;

import com.jiahui.framework.rpc.rest.ResultVO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;

@FeignClient( value = "datawrapper-service")
public interface   DataWrapperManagerClient {

    @PostMapping(path = "/startFullTask", headers = {"Content-Type=application/json;charset=UTF-8"})
    ResultVO<String> startFullTask(String indexId);

    @PostMapping(path = "/stopFullTask", headers = {"Content-Type=application/json;charset=UTF-8"})
    ResultVO<String> stopFulTask(String indexId);


}
