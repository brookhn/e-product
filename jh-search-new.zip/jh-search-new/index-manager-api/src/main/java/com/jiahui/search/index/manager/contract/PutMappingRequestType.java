package com.jiahui.search.index.manager.contract;

public class PutMappingRequestType {
    private Long indexConfigId;

    public Long getIndexConfigId() {
        return indexConfigId;
    }

    public void setIndexConfigId(Long indexConfigId) {
        this.indexConfigId = indexConfigId;
    }
}
