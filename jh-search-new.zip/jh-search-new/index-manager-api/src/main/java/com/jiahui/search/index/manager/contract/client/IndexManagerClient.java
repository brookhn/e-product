package com.jiahui.search.index.manager.contract.client;

import com.jiahui.framework.rpc.rest.ResultVO;
import com.jiahui.search.index.manager.contract.*;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient( value = "indexer-service")
public interface IndexManagerClient {
    @PostMapping(path = "/createIndex",headers = {"Content-Type=application/json;charset=UTF-8"})
    ResultVO<CreateIndexResponseType> createIndex(@RequestBody CreateIndexRequestType request);

    @PostMapping(path = "/closeIndex", headers = {"Content-Type=application/json;charset=UTF-8"})
    ResultVO<CloseIndexResponseType> closeIndex(@RequestBody CloseIndexRequestType request);

    @PostMapping(path = "/deleteIndex", headers = {"Content-Type=application/json;charset=UTF-8"})
    ResultVO<DeleteIndexResponseType> deleteIndex(@RequestBody DeleteIndexRequestType request);

    @PostMapping(path = "/openIndex", headers = {"Content-Type=application/json;charset=UTF-8"})
    ResultVO<OpenIndexResponseType> openIndex(@RequestBody OpenIndexRequestType request);

    @PostMapping(path = "/putMapping", headers = {"Content-Type=application/json;charset=UTF-8"})
    ResultVO<PutMappingResponseType> putMapping(@RequestBody PutMappingRequestType request);
}
