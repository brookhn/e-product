package com.jiahui.search.datawrapper.api.entity;

public class DataRange {

    public DataRange() {

    }

    public DataRange(Long min, Long max) {
        this.min = min;
        this.max = max;
    }

    private Long min;
    private Long max;

    public Integer getIntMin(){
        return min.intValue();
    }

    public Integer getIntMax(){
        return max.intValue();
    }

    public Long getMin() {
        return min;
    }

    public void setMin(Long min) {
        this.min = min;
    }

    public Long getMax() {
        return max;
    }

    public void setMax(Long max) {
        this.max = max;
    }

    public void validateData() {
        if (min>max){
            long tmpTran = min;
            min = max;
            max = tmpTran;
        }
    }

    public Long getLength(){
        validateData();
        return max - min;
    }
}
