package com.jiahui.search.datawrapper.api;

import com.jiahui.search.common.enums.CodeEnum;
import com.jiahui.search.common.exception.BizException;
import com.jiahui.search.datawrapper.api.entity.WrapperResult;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;
import java.util.Map;
import java.util.Objects;

public abstract class DataWrapperHandler {

    private static Map<String, JdbcTemplate> jdbcTemplatesMap = null;

    /**
     * 获取IndexID
     *
     * @return
     */
    abstract public Long getIndexId();

    /**
     * 校验插件与配置是否匹配
     *
     * @param indexId
     */
    public void checkConfigIsok(Long indexId) {
        if (getIndexId() != indexId) {
            throw new BizException(CodeEnum.CODE_210002011);
        }
    }

    /**
     * 获取数据源对应jdbcTemplate
     *
     * @param dbName
     * @return
     */
    public JdbcTemplate getJdbcTemplateByDbName(String dbName) {
        return jdbcTemplatesMap.get(dbName);
    }

    /**
     * 初始化jdbcTemplate Map
     *
     * @param templateMap
     */
    public void initJdbcTemplate(Map<String, JdbcTemplate> templateMap) {
        if (Objects.nonNull(jdbcTemplatesMap)) {
            return;
        }
        jdbcTemplatesMap = templateMap;
    }

    /**
     * 全量数据封装
     *
     * @param value
     * @return
     */
    abstract public WrapperResult fullSyncDataWrap(Map<String, Object> value);

    /**
     * 全量数据封装
     *
     * @param values
     * @return
     */
    abstract public WrapperResult fullSyncDataWrap(List<Map<String, Object>> values);

    /**
     * 增量数据封装
     *
     * @param value
     * @return
     */
    abstract public WrapperResult incrementSyncDataWrap(Map<String, Object> value);
}
