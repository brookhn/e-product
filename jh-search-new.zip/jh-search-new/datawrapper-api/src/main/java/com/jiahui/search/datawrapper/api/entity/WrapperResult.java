package com.jiahui.search.datawrapper.api.entity;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * DataWrapper插件处理后数据
 */
public class WrapperResult {

    List<Map<String, Object>> datas;

    public WrapperResult(Map<String, Object> data)
    {
        if (null == data){
            return;
        }
        if (null == this.datas){
            this.datas = new ArrayList<>();
        }
        this.datas.add(data);
    }

    public WrapperResult(List<Map<String, Object>> datas){
        this.datas = datas;
    }

    public List<Map<String, Object>> getDatas() {
        return datas;
    }

    public void setDatas(List<Map<String, Object>> datas) {
        this.datas = datas;
    }
}
