//package com.jiahui.search.datawrapper.api;
//
//import com.jiahui.search.datawrapper.api.entity.WrapperResult;
//
//import java.util.Map;
//
//public class Test extends DataWrapperHandler {
//
//    public static void main(String[] args) {
//        Test test = new Test();
//
//    }
//
//    @Override
//    public Long getIndexId() {
//        return null;
//    }
//
//    @Override
//    public WrapperResult fullSyncDataWrap(Map<String, String> value) {
//        return null;
//    }
//
//    @Override
//    public WrapperResult incrementSyncDataWrap(Map<String, Object> value) {
//        return null;
//    }
//}
