package com.jiahui.search.datawrapper.entity;

import java.util.List;
import java.util.Map;

/**
 * 增量任务配置
 */
public class IncrementTaskConfig {

    /**
     * kafka consumer properties
     */
    private List<Map<String, String>> consumerProperties;

    public List<Map<String, String>> getConsumerProperties() {
        return consumerProperties;
    }

    public void setConsumerProperties(List<Map<String, String>> consumerProperties) {
        this.consumerProperties = consumerProperties;
    }
}
