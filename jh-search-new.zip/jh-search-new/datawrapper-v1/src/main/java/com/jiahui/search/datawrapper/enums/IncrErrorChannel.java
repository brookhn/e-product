package com.jiahui.search.datawrapper.enums;

public enum IncrErrorChannel {
    KAFKA(0, "kafka消费渠道"),
    XXL_JOB(1, "xxl-job补偿渠道");
    private int error;

    private String errorMsg;

    private IncrErrorChannel(int error, String errorMsg) {
        this.error = error;
        this.errorMsg = errorMsg;
    }

    public int getValue() {
        return error;
    }
}
