package com.jiahui.search.datawrapper.manager;

import cn.hutool.core.util.IdUtil;
import com.github.rholder.retry.RetryException;
import com.github.rholder.retry.Retryer;
import com.jiahui.framework.rpc.rest.ResultVO;
import com.jiahui.search.common.enums.CodeEnum;
import com.jiahui.search.common.exception.BizException;
import com.jiahui.search.common.utils.JsonUtil;
import com.jiahui.search.datawrapper.config.RetryBuilder;
import com.jiahui.search.entity.PluginConfig;
import com.jiahui.search.index.writer.rest.contract.IndexWriterRestClient;
import com.jiahui.search.index.writer.rest.contract.PrepareIndexResponse;
import com.jiahui.search.index.writer.rest.contract.ReadyFullIndexRequest;
import com.jiahui.search.indexer.contract.DocDto;
import com.jiahui.search.indexer.contract.IndexResponse;
import com.jiahui.search.indexer.contract.IndexWriterApiGrpc;
import com.jiahui.search.repository.dao.CompensateRecordMapper;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import net.devh.boot.grpc.client.inject.GrpcClient;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.ExecutionException;
import java.util.function.BiFunction;
import java.util.function.Function;


@Data
@Slf4j
@Service
public class GrpcClientManager {


    /**
     * 阻塞接口
     */
    @GrpcClient("indexer-service")
    private IndexWriterApiGrpc.IndexWriterApiBlockingStub indexWriterStub;

    @Resource
    private IndexWriterRestClient restClient;

    @Resource
    private CompensateRecordMapper compensateRecordMapper;

    @Autowired
    private RedissonClient redissonClient;


    public ResultVO<PrepareIndexResponse> prepareIndex(Long indexId, Function<Long, ResultVO<PrepareIndexResponse>> function) {
        ResultVO<PrepareIndexResponse> response;
        try {
            response = RetryBuilder.restRetry.call(() -> function.apply(indexId));
        } catch (ExecutionException e) {
            log.error(e.getMessage(), e);
            throw new BizException(CodeEnum.EXCEPTION.getCode(), e.getMessage());
        } catch (RetryException e) {
            log.error(e.getMessage(), e);
            throw new BizException(CodeEnum.EXCEPTION.getCode(), e.getMessage());
        }
        log.info("初始化索引返回结果, {}", JsonUtil.serialize(response));
        response = Optional.ofNullable(response).filter(p -> p.getCode() == CodeEnum.SUCCESS.getCode())
                .<BizException>orElseThrow(() -> {
                    throw new BizException(CodeEnum.EXCEPTION.getCode(), CodeEnum.EXCEPTION.getMsg());
                });
        return response;
    }

    /**
     * 增量 or 全量数据索引
     *
     * @param pluginConfig
     * @param docs
     * @param function
     * @return
     */
    public boolean doIndex(PluginConfig pluginConfig,
                           List<DocDto> docs,
                           BiFunction<List<DocDto>, Long, IndexResponse> function,
                           Retryer<IndexResponse> retry) {
        IndexResponse response;
        try {
            response = retry.call(() -> function.apply(docs, pluginConfig.getIndexId()));
            log.info("grpc doIndex response{}", response);
        } catch (ExecutionException e) {
            log.error(e.getMessage(), e);
            return false;
        } catch (RetryException e) {
            log.error(e.getMessage(), e);
            return false;
        }
        if (!Objects.isNull(response) && CodeEnum.SUCCESS.getCode() != response.getCode()) {
            return false;
        }
        return true;
    }

    public ResultVO<Boolean> doneIndex(Long indexId, String indexName, boolean isRunOk) {
        Function<Long, ResultVO<Boolean>> function = (iId) ->
                restClient.readyFullIndex(ReadyFullIndexRequest.builder()
                        .indexConfigId(indexId)
                        .indexName(indexName)
                        .done(isRunOk)
                        .token(IdUtil.objectId()).build());

        ResultVO<Boolean> response = null;
        try {
            response = RetryBuilder.restRetry.call(() -> function.apply(indexId));
        } catch (ExecutionException e) {
            log.error(e.getMessage(), e);
        } catch (RetryException e) {
            log.error(e.getMessage(), e);
        }
        log.info("grpc readyFullIndex response{}", response);
        return response;
    }


}
