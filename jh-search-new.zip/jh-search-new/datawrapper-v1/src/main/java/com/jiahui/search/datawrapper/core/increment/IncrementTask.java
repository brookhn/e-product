package com.jiahui.search.datawrapper.core.increment;

import com.jiahui.framework.rpc.rest.ResultVO;
import com.jiahui.search.common.config.DefaultThreadFactory;
import com.jiahui.search.common.utils.JsonUtil;
import com.jiahui.search.datawrapper.core.AbstractTask;
import com.jiahui.search.datawrapper.core.TaskFactory;
import com.jiahui.search.datawrapper.entity.IncrementTaskConfig;
import com.jiahui.search.datawrapper.util.IConstant;
import com.jiahui.search.index.writer.rest.contract.PrepareIndexRequest;
import com.jiahui.search.index.writer.rest.contract.PrepareIndexResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.assertj.core.util.Lists;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Function;

@Slf4j
public class IncrementTask extends AbstractTask {

    private IncrementTaskConfig taskConfig;

    private ExecutorService executor;

    private IncrementMonitor incrementMonitor;

    @Override
    public void init() {
        super.init();
        taskConfig = JsonUtil.parseObject(pluginConfig.getIncrSyncConfig(), IncrementTaskConfig.class);
        //初始化线程池
        DefaultThreadFactory threadFactory = new DefaultThreadFactory("incrTaskThreadPool-" + pluginConfig.getId());
        executor = Executors.newCachedThreadPool(threadFactory);

        //调用prepareIncrementIndex
        Function<Long, ResultVO<PrepareIndexResponse>> function = (iId) -> clientManager.getRestClient()
                .prepareIncrementIndex(PrepareIndexRequest.builder().indexConfigId(iId).build());
        clientManager.prepareIndex(pluginConfig.getIndexId(), function);
        //运行状态写入redis
        incrementMonitor = new IncrementMonitor(clientManager.getRedissonClient(), pluginConfig);
        incrementMonitor.addMonitor();
        log.info("indexId[{}]增量任务初始化成功", pluginConfig.getIndexId());
    }

    @Override
    public void doIndex() throws ExecutionException, InterruptedException {
        List<Map<String, String>> consumerProperties = taskConfig.getConsumerProperties();
        //监听多topic触发增量索引
        List<CompletableFuture> futureList = Lists.newArrayList();

        for (Map<String, String> config : consumerProperties) {
            if (!checkConfig(config)) {
                continue;
            }
            setDefaultConfig(config);

            Properties properties = new Properties();
            properties.putAll(config);
            IncrementTaskHandler taskHandler = new IncrementTaskHandler(properties, dataWrapperHandler, pluginConfig, clientManager);
            CompletableFuture<Void> completableFuture = CompletableFuture.runAsync(taskHandler, executor);
            futureList.add(completableFuture);
        }
        //多个任务都执行完，表示增量停止
        CompletableFuture<Object> allOfFuture = CompletableFuture.anyOf(futureList.toArray(new CompletableFuture[futureList.size()]));
        allOfFuture.get();
        log.info("indexId[{}]增量任务停止运行", pluginConfig.getIndexId());
    }

    /**
     * 校验 kafka consumer 必填项
     *
     * @param config
     * @return
     */
    public boolean checkConfig(Map<String, String> config) {
        if (StringUtils.isBlank(config.get("topic"))) {
            log.error("configId[{}]增量启动失败，topic非空", pluginConfig.getId());
            return false;
        }
        if (StringUtils.isBlank(config.get(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG))) {
            log.error("configId[{}]增量启动失败，bootstrap.servers非空", pluginConfig.getId());
            return false;
        }
        return true;
    }

    /**
     * 设置 kafka consumer 默认属性
     *
     * @param config
     */
    public void setDefaultConfig(Map<String, String> config) {
        if (StringUtils.isBlank(config.get(ConsumerConfig.GROUP_ID_CONFIG))) {
            config.put(ConsumerConfig.GROUP_ID_CONFIG, "increment-task-consumer-" + pluginConfig.getIndexId());
        }
        if (StringUtils.isBlank(config.get(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG))) {
            //默认3min
            config.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, "180000");
        }
        if (StringUtils.isBlank(config.get(ConsumerConfig.MAX_POLL_RECORDS_CONFIG))) {
            //默认poll 200条
            config.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, "200");
        }
        config.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");
        config.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        config.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        config.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
    }

    @Override
    public void indexDone() {
        super.indexDone();
        TaskFactory.unRegister(IConstant.TASKType.INCREMENT_TASKTYPE.type, pluginConfig.getIndexId());
        incrementMonitor.clearMonitor();
        executor.shutdownNow();
    }
}
