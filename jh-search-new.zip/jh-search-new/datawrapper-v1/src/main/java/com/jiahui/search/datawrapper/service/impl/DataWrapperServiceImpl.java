package com.jiahui.search.datawrapper.service.impl;

import com.jiahui.search.common.enums.CodeEnum;
import com.jiahui.search.common.exception.BizException;
import com.jiahui.search.common.utils.JsonUtil;
import com.jiahui.search.datawrapper.service.IDataWrapperService;
import com.jiahui.search.datawrapper.util.IConstant;
import com.jiahui.search.entity.PluginConfig;
import com.jiahui.search.repository.PluginConfigRepo;
import lombok.extern.slf4j.Slf4j;
import org.redisson.api.RMap;
import org.redisson.api.RedissonClient;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

import javax.annotation.Resource;
import java.util.Optional;
import java.util.Set;

@Slf4j
@Service
public class DataWrapperServiceImpl implements IDataWrapperService {

    @Resource
    private PluginConfigRepo pluginConfigRepo;

    @Resource
    private KafkaTemplate<String, String> template;

    @Resource
    private RedissonClient redissonClient;

    @Override
    public void startIncrementTask(Long indexId) {
        PluginConfig config = pluginConfigRepo.getByIndexConfigId(indexId);
        Optional.ofNullable(config).filter(conf -> 1 == conf.getStatus()).orElseThrow(() -> new BizException(CodeEnum.INDEX_CONFIG_NOT_EXISTS));
        ListenableFuture<SendResult<String, String>> future = template.send(IConstant.INCR_TASK_START, JsonUtil.serialize(config));
        future.addCallback(new ListenableFutureCallback<SendResult<String, String>>() {
            @Override
            public void onFailure(Throwable e) {
                log.error(e.getMessage(), e);
            }

            @Override
            public void onSuccess(SendResult<String, String> result) {

            }
        });
    }

    @Override
    public Set<String> getRunningInstance(Long indexId) {
        RMap<Long, Set<String>> rMap = redissonClient.getMap(IConstant.INCR_RUNNING);
        Set<String> ips = rMap.get(indexId);
        return ips;
    }


}
