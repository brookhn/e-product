package com.jiahui.search.datawrapper.core.full;


import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

/**
 * 查询数据库数据转换为Map<String, String>结构
 */
@Slf4j
public class DefaultRowMapper implements RowMapper<Map<String, Object>> {

    String format = "yyyy-MM-dd HH:mm:ss.SSS";

    @Override
    public Map<String, Object> mapRow(ResultSet rs, int rowNum) throws SQLException {
        Map<String, Object> objMap = new HashMap<>();
        ResultSetMetaData metaData = rs.getMetaData();
        int querySize = metaData.getColumnCount();
        if (querySize > 0) {
            for (int i = 0; i < querySize; i++) {
                String fieldName = metaData.getColumnName(i + 1);
//                int fieldType = metaData.getColumnType(i + 1);
//                objMap.put(fieldName, getValue(rs.getObject(i + 1), fieldType));
                objMap.put(fieldName, rs.getObject(i + 1));
            }
        }
        return objMap;
    }

//    private String getValue(Object fileValue, int sqlType) {
//        if (Objects.isNull(fileValue)) {
//            return null;
//        }
//        if (fileValue instanceof String) {
//            return String.valueOf(fileValue);
//        }
//        switch (sqlType) {
//            case Types.TIMESTAMP: {
//
//            }
//            case Types.DATE: {
//                if (fileValue instanceof LocalDateTime) {
//                    LocalDateTime dateTime = (LocalDateTime) fileValue;
//                    return dateTime.format(DateTimeFormatter.ofPattern(format));
//                } else if (fileValue instanceof LocalDate) {
//                    LocalDate date = (LocalDate) fileValue;
//                    return date.atTime(0, 0, 0).format(DateTimeFormatter.ofPattern(format));
//                } else {
//                    Date date = (Date) fileValue;
//                    return LocalDateTime.ofInstant(date.toInstant(), ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern(format));
//                }
//            }
//            case Types.BIT: {
//                if (Boolean.TRUE.equals(fileValue)) {
//                    return "1";
//                } else {
//                    return "0";
//                }
//            }
//            default:
//                return fileValue.toString();
//        }
//    }
}
