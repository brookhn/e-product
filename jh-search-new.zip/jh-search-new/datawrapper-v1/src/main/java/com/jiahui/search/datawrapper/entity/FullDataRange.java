package com.jiahui.search.datawrapper.entity;

import com.jiahui.search.datawrapper.api.entity.DataRange;
import lombok.Data;

@Data
public class FullDataRange {
    DataRange dataRange;
    int totalSize;
}
