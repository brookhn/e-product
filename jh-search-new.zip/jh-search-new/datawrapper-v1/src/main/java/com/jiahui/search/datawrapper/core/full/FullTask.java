package com.jiahui.search.datawrapper.core.full;

import com.jiahui.framework.rpc.rest.ResultVO;
import com.jiahui.search.common.enums.CodeEnum;
import com.jiahui.search.common.exception.BizException;
import com.jiahui.search.common.utils.JsonUtil;
import com.jiahui.search.datawrapper.core.AbstractTask;
import com.jiahui.search.datawrapper.core.TaskFactory;
import com.jiahui.search.datawrapper.entity.FullTaskEntity;
import com.jiahui.search.datawrapper.entity.FullTaskMoniter;
import com.jiahui.search.datawrapper.util.IConstant;
import com.jiahui.search.index.writer.rest.contract.PrepareIndexRequest;
import com.jiahui.search.index.writer.rest.contract.PrepareIndexResponse;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.jdbc.core.JdbcTemplate;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;

@Slf4j
/**
 * 全量同步线程
 */
public class FullTask extends AbstractTask {

    /**
     * 全量同步参数对象
     */
    FullTaskEntity fullTaskEntity = null;

    /**
     * 监控对象
     */
    @Getter
    FullTaskMoniter taskMoniter = null;

    /**
     * 全量抓取写es服务
     */
    AbstractFullIndexService fullIndexService = null;

    /**
     * 数据JDBCTemplate
     */
    JdbcTemplate jdbcTemplate = null;

    /**
     *
     */
    @Override
    public void init() {
        try {
            long start = System.currentTimeMillis();
            log.info("FullTask.init:开始，索引ID为{}，开始时间为：{}", pluginConfig.getIndexId(), start);
            super.init();
            taskMoniter = new FullTaskMoniter(this.getPluginConfig());

            taskMoniter.setRunStatus(IConstant.FullTaskStep.INIT_STEP.status);
            //初始化全量同步对象
            fullTaskEntity = new FullTaskEntity(getPluginConfig(), getPluginConfig().getIdFieldName());
            //调用Indexing开始创建索引
            jdbcTemplate = getDataSourceManager().getJdbcTemplate(getPluginConfig().getFullSyncDbName());
            fullIndexService = new DefaultFullIndexService(this);
            //创建全量索引
            Function<Long, ResultVO<PrepareIndexResponse>> function = (iId) ->
                    getClientManager().getRestClient().prepareFullIndex(PrepareIndexRequest.builder().indexConfigId(iId).build());
            ResultVO<PrepareIndexResponse> resultVO = getClientManager().prepareIndex(getDataWrapperHandler().getIndexId(),function);
            fullTaskEntity.setIndexName(resultVO.getData().getIndexName());
            taskMoniter.setIndexName(resultVO.getData().getIndexName());
            taskMoniter.setStatusTimeStamp(IConstant.FullTaskStep.INIT_STEP.code, System.currentTimeMillis() - start);
            log.info("FullTask.init:结束，索引ID为{}，消耗时长为：{}", pluginConfig.getIndexId(), System.currentTimeMillis() - start);
        } catch (Exception e) {
            log.error("FullTask.init::全量同步初始化异常", e);
            throw new BizException(CodeEnum.CODE_210002005.getCode(), CodeEnum.CODE_210002005.getMsg());
        }
    }

    /**
     * 开始写查数据写索引
     */
    @Override
    public void doIndex() {
        long startTime = System.currentTimeMillis();
        log.info("FullTask.doIndex:结束，索引ID为{}，开始时间为：{}", pluginConfig.getIndexId(), startTime);
        taskMoniter.setStatus(IConstant.FullTaskStep.FETCHDATA_STEP.status);
        fullIndexService.startDoIndex();
        taskMoniter.setStatusTimeStamp(IConstant.FullTaskStep.FETCHDATA_STEP.code, System.currentTimeMillis() - startTime);
        log.info("FullTask.doIndex:结束，索引ID为{}，消耗时长为：{}", pluginConfig.getIndexId(), System.currentTimeMillis() - startTime);
    }

    /**
     * 全量同步结束操作
     */
    @Override
    public void indexDone() {
        super.indexDone();
        long startTime = System.currentTimeMillis();
        log.info("FullTask.indexDone:开始，索引ID为{}，开始时间为：{}, 切换索引名称为：{}, 切换结果为：{}", pluginConfig.getIndexId(), startTime,
                ObjectUtils.isEmpty(fullTaskEntity)?"":fullTaskEntity.getIndexName(), taskMoniter.getFullTaskIsok());
        taskMoniter.setStatus(IConstant.FullTaskStep.DONE_STEP.status);
        //设置全量同步结束
        if (!ObjectUtils.isEmpty(fullIndexService)) {
            fullIndexService.stopService();
        }
        taskMoniter.setStatusTimeStamp(IConstant.FullTaskStep.DONE_STEP.code, System.currentTimeMillis() - startTime);
        log.info("FullTask.indexDone:结束，索引ID为{}，消耗时长为：{}, 切换索引名称为：{}, 切换结果为：{}", pluginConfig.getIndexId(), System.currentTimeMillis() - startTime,
                ObjectUtils.isEmpty(fullTaskEntity)?"":fullTaskEntity.getIndexName(), taskMoniter.getFullTaskIsok());
        //移除运行中状态
        TaskFactory.unRegister(IConstant.TASKType.FULL_TASKTYPE.type, getPluginConfig().getIndexId());
    }

}