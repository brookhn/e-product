package com.jiahui.search.datawrapper.core.increment;

import com.google.common.collect.Lists;
import com.jiahui.search.common.exception.BizException;
import com.jiahui.search.common.utils.JsonUtil;
import com.jiahui.search.datawrapper.api.DataWrapperHandler;
import com.jiahui.search.datawrapper.api.entity.WrapperResult;
import com.jiahui.search.datawrapper.config.RetryBuilder;
import com.jiahui.search.datawrapper.enums.IncrErrorChannel;
import com.jiahui.search.datawrapper.manager.GrpcClientManager;
import com.jiahui.search.datawrapper.util.IConstant;
import com.jiahui.search.datawrapper.util.KafkaConsumerHelper;
import com.jiahui.search.entity.CompensateRecord;
import com.jiahui.search.entity.PluginConfig;
import com.jiahui.search.indexer.contract.DocDto;
import com.jiahui.search.indexer.contract.IncrementIndexRequest;
import com.jiahui.search.indexer.contract.IndexResponse;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.errors.WakeupException;
import org.slf4j.MDC;
import org.springframework.util.CollectionUtils;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.*;
import java.util.function.BiFunction;

@Slf4j
@Data
public class IncrementTaskHandler implements Runnable {

    private Properties properties;

    private DataWrapperHandler dataWrapperHandler;

    private PluginConfig pluginConfig;

    private GrpcClientManager clientManager;

    private String topic;

    private Integer senderBatchSize = IConstant.DEFAULT_BATCH_INDEX_SIZE;

    private Long indexId;

    private KafkaConsumer<String, String> consumer;

    private IncrErrorChannel errorChannel = IncrErrorChannel.KAFKA;

    /**
     * kafka consumer 任务使用
     *
     * @param properties
     * @param dataWrapperHandler
     * @param pluginConfig
     * @param clientManager
     */
    public IncrementTaskHandler(Properties properties, DataWrapperHandler dataWrapperHandler,
                                PluginConfig pluginConfig, GrpcClientManager clientManager) {
        this.properties = properties;
        this.dataWrapperHandler = dataWrapperHandler;
        this.pluginConfig = pluginConfig;
        this.clientManager = clientManager;
    }

    /**
     * 补偿任务 使用
     *
     * @param dataWrapperHandler
     * @param pluginConfig
     * @param clientManager
     */
    public IncrementTaskHandler(DataWrapperHandler dataWrapperHandler, PluginConfig pluginConfig, GrpcClientManager clientManager) {
        this.dataWrapperHandler = dataWrapperHandler;
        this.pluginConfig = pluginConfig;
        this.clientManager = clientManager;
        this.errorChannel = IncrErrorChannel.XXL_JOB;
    }

    public void init() {
        topic = (String) properties.get(IConstant.TOPIC);
        indexId = pluginConfig.getIndexId();
        senderBatchSize = Objects.isNull(properties.get(IConstant.SENDER_BATCH_KEY)) ? IConstant.DEFAULT_BATCH_INDEX_SIZE :
                (Integer) properties.get(IConstant.SENDER_BATCH_KEY);
        MDC.put(IConstant.TOPIC, topic);
        consumer = new KafkaConsumer<>(properties);
    }

    @Override
    public void run() {
        init();
        consumer.subscribe(Lists.newArrayList(topic));
        //优雅停止kafka consumer
        KafkaConsumerHelper.addShutdownHook(consumer);
        try {
            while (true && !Thread.currentThread().isInterrupted()) {
                try {
                    ConsumerRecords<String, String> records = consumer.poll(Duration.ofMillis(100));
                    if (records.isEmpty()) {
                        continue;
                    }
                    List<Map<String, Object>> dataList = deleteRepeated(records);
                    doIndexer(dataList);
                } catch (WakeupException e) {
                    log.warn("WakeupErr", e);
                    break;
                } catch (Exception e) {
                    log.error("增量同步异常。。。", e);
                }
                consumer.commitSync();
            }
        } finally {
            consumer.close();
            MDC.remove(IConstant.TOPIC);
        }
    }

    public void doIndexer(List<Map<String, Object>> dataList) {
        // 执行DataWrapper
        List<Map<String, Object>> rowList = doDataWrapper(dataWrapperHandler, dataList);
        // 构造DocDto列表
        List<DocDto> docs = buildDocs(rowList);
        if (CollectionUtils.isEmpty(docs)) {
            log.info("docList为空不执行本次增量index");
            return;
        }

        BiFunction<List<DocDto>, Long, IndexResponse> biFunction = (subDocs, indexId) ->
                clientManager.getIndexWriterStub().incrementIndex(IncrementIndexRequest.newBuilder().
                        addAllDocs(subDocs).setIndexConfigId(indexId).build());
        // 分段插入
        long start = System.currentTimeMillis();
        Lists.partition(docs, senderBatchSize).forEach(subDocs ->
                clientManager.doIndex(pluginConfig, subDocs, biFunction, RetryBuilder.doIncrIndexRetry));
        long timeSpan = System.currentTimeMillis() - start;
        log.info("doIndex总数{} 总耗时{}ms 平均耗时{}", docs.size(), timeSpan, getAvgTime(docs.size(), timeSpan));
    }


    public List<Map<String, Object>> doDataWrapper(DataWrapperHandler dataWrapperHandler, List<Map<String, Object>> rows) {
        List<Map<String, Object>> newRows = Lists.newArrayList();
        if (Objects.isNull(dataWrapperHandler)) {
            return getRowData(rows);
        }
        long start = System.currentTimeMillis();
        for (Map<String, Object> row : rows) {
            try {
                WrapperResult wrapperResult = dataWrapperHandler.incrementSyncDataWrap(row);
                log.debug("incrementSyncDataWrap{}", wrapperResult);
                if (Objects.isNull(wrapperResult) || CollectionUtils.isEmpty(wrapperResult.getDatas())) {
                    continue;
                }
                wrapperResult.getDatas().forEach(data -> data.put(IConstant.OPT, row.get(IConstant.OPT)));
                newRows.addAll(wrapperResult.getDatas());
            } catch (Exception e) {
                log.error("doDataWrapper异常indexId[{}] topic[{}] rowData[{}]", indexId, topic, row, e);
                handleError(row);
                continue;
            }
        }
        long totalTime = System.currentTimeMillis() - start;
        log.info("doDataWrapper总数{} 返回总数{} 总耗时{}ms 平均耗时{}", rows.size(), newRows.size(), totalTime, getAvgTime(rows.size(), totalTime));
        return newRows;
    }

    /**
     * 无DataWrapper直接获取表数据
     *
     * @param rows
     * @return
     */
    public List<Map<String, Object>> getRowData(List<Map<String, Object>> rows) {
        List<Map<String, Object>> newRows = Lists.newArrayList();
        for (Map<String, Object> record : rows) {
            try {
                String dataKey = record.get(IConstant.OPT).equals(IConstant.DELETE) ? IConstant.OLD_ROW : IConstant.ROW;
                Map<String, Object> rowData = JsonUtil.parseStringObjectMap(JsonUtil.serialize(record.get(dataKey)));
                rowData.put(IConstant.OPT, record.get(IConstant.OPT));
                newRows.add(rowData);
            } catch (Exception e) {
                log.error("getRowData异常indexId[{}] topic[{}] rowData[{}]", indexId, topic, record, e);
                handleError(record);
            }
        }
        return newRows;
    }

    public BigDecimal getAvgTime(int count, Long timeSpan) {
        return BigDecimal.valueOf(timeSpan).divide(BigDecimal.valueOf(count), 2, RoundingMode.HALF_UP);
    }

    /**
     * 构造DocDto列表
     *
     * @param rowList
     * @return
     */
    public List<DocDto> buildDocs(List<Map<String, Object>> rowList) {
        List<DocDto> docs = new ArrayList<>();
        rowList.stream()
                //剔除无idFieldName数据
                .filter(row -> row.keySet().contains(getPluginConfig().getIdFieldName()))
                .forEach(row -> {
                    //添加Index或Delete标记
                    DocDto.OpEnum opEnum = IConstant.DELETE.equals(row.get(IConstant.OPT)) ? DocDto.OpEnum.Delete : DocDto.OpEnum.Index;
                    row.remove(IConstant.OPT);
                    DocDto docDto = DocDto.newBuilder().setData(JsonUtil.serialize(row)).setOp(opEnum).build();
                    docs.add(docDto);
                });
        log.info("过滤前总数{} 过滤后总数{}", rowList.size(), docs.size());
        return docs;
    }


    /**
     * 删除重复数据
     *
     * @param records
     * @return
     */
    public List<Map<String, Object>> deleteRepeated(ConsumerRecords<String, String> records) {
        Map<String, Map<String, Object>> distinctMap = new HashMap<>();
        records.forEach(record -> {
            Map<String, Object> recordMap = JsonUtil.parseObject(record.value(), Map.class);
            distinctMap.put(recordMap.get(IConstant.CANAL_PRIMARY_KEY).toString(), recordMap);
        });
        log.info("获取kafka总数{} 去重后总数{}", records.count(), distinctMap.values().size());
        return Lists.newArrayList(distinctMap.values().iterator());
    }

    /**
     * 消费异常保存补偿表
     *
     * @param rowData
     */
    public void handleError(Map<String, Object> rowData) {
        if (errorChannel.equals(IncrErrorChannel.XXL_JOB)) {
            throw new BizException();
        }
        try {
            CompensateRecord retryContent = CompensateRecord.builder()
                    .createTime(LocalDateTime.now())
                    .updateTime(LocalDateTime.now())
                    .retryTimes(0)
                    .pluginConfigId(pluginConfig.getId())
                    .indexId(indexId)
                    .retryContent(JsonUtil.serialize(rowData)).build();
            clientManager.getCompensateRecordMapper().insert(retryContent);
        } catch (Exception e) {
            log.error("保存消息异常", e);
        }
    }
}
