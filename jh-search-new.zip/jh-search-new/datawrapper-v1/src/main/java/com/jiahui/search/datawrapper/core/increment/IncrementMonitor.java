package com.jiahui.search.datawrapper.core.increment;

import cn.hutool.core.net.NetUtil;
import com.jiahui.search.datawrapper.util.IConstant;
import com.jiahui.search.entity.PluginConfig;
import lombok.extern.slf4j.Slf4j;
import org.redisson.api.RMap;
import org.redisson.api.RedissonClient;
import org.springframework.util.CollectionUtils;

import java.util.HashSet;
import java.util.Set;

@Slf4j
public class IncrementMonitor {

    private RedissonClient redissonClient;

    private PluginConfig pluginConfig;

    public IncrementMonitor(RedissonClient redissonClient, PluginConfig pluginConfig) {
        this.redissonClient = redissonClient;
        this.pluginConfig = pluginConfig;
    }

    public void addMonitor() {
        try {
            RMap<Long, Set<String>> rMap = redissonClient.getMap(IConstant.INCR_RUNNING);
            Set<String> ips = rMap.get(pluginConfig.getIndexId());
            if (CollectionUtils.isEmpty(ips)) {
                ips = new HashSet<>();
            }
            ips.add(NetUtil.getLocalhostStr());
            rMap.put(pluginConfig.getIndexId(), ips);
        } catch (Exception e) {
            log.error("增量任务monitor写入失败");
        }
    }

    public void clearMonitor() {
        try {
            RMap<Long, Set<String>> rMap = redissonClient.getMap(IConstant.INCR_RUNNING);
            Set<String> ips = rMap.get(pluginConfig.getIndexId());
            if (CollectionUtils.isEmpty(ips)) {
                return;
            }
            ips.remove(NetUtil.getLocalhostStr());
            rMap.put(pluginConfig.getIndexId(), ips);
        } catch (Exception e) {
            log.error("删除增量任务monitor失败");
        }
    }

}
