package com.jiahui.search.datawrapper.util;

public interface IConstant {

    /**
     * 默认抓取线程数量
     */
    public Integer DEFAULT_FULL_FETCH_THREAD_NUMBER = 3;

    /**
     * 最小抓取线程数量
     */
    public Integer MIN_FULL_FETCH_THREAD_NBUMBER = 1;

    /**
     * 最大抓取线程数量
     */
    public Integer MAX_FULL_FETCH_THREAD_NUMBER = 10;

    /**
     * 默认批量写索引数量
     */
    public Integer DEFAULT_BATCH_INDEX_SIZE = 200;

    public String SENDER_BATCH_KEY = "sender.batch.size";

    /**
     * 最小写索引的数量
     */
    public Integer MIN_BATCH_INDEX_SIZE = 50;

    /**
     * 最大批量写索引的数量
     */
    public Integer MAX_BATCH_INDEX_SIZE = 500;

    /**
     * 最大抓取数据数量
     */
    public Integer MAX_BATCH_FETCH_SIZE = 2000;

    /**
     * 最小抓取数据数量
     */
    public Integer MIN_BATCH_FETCH_SIZE = 50;

    /**
     * 若batchFetchSize该参数为设置value,则取该值，
     * 表示需要与batchIndexSize的value保持一致
     */
    public Integer SYNC_VALUE = -1;

    /**
     * 全量任务
     */
    public Integer FULL_TASK = 1;

    /**
     * 增量任务
     */
    public Integer INCREMENT_TASK = 2;

    /**
     * 全量推送状态初始化
     */
    public Integer FULL_PUSH_STATE_INIT = 0;

    /**
     * 全量推送状态已结束
     */
    public Integer FULL_PUSH_STATE_END = -1;

    /**
     * 全量推送状态发生异常
     */
    public Integer FULL_PUSH_STATE_EXCEPTION = -2;


    public String uuid = "_rt_uuid";

    public Integer MAX_RETRY = 10;

    public String INDEX_SYNC_TIME = "syncTime";

    String TOPIC = "topic";

    String INDEX_ID = "INDEX_ID";

    String CANAL_PRIMARY_KEY = "primaryKeyVal";

    String OPT = "opt";

    String ROW = "row";

    String OLD_ROW = "oldRow";

    String DELETE = "DELETE";

    String INCR_TASK_START="INCREMENT-TASK-START";

    String INCR_TASK_CONSUMER_GROUP="INCREMENT-TASK-START-CONSUMER";

    String INCR_RUNNING = "INCR_RUNNING";

    public enum FullTaskStep {
        NO_STEP(0, "NODE"),
        INIT_STEP(1, "INIT"),
        FETCHDATA_STEP(2, "FETCHDATA"),
        DONE_STEP(3, "DONE"),
        END_STEP(4, "END");

        public final Integer status;
        public final String code;

        FullTaskStep(Integer status, String code){
            this.status = status;
            this.code = code;
        }

        public static String getCode(Integer status) {
            if (NO_STEP.status == status){
              return NO_STEP.code;
            } else if (INIT_STEP.status == status) {
                return INIT_STEP.code;
            } else if (FETCHDATA_STEP.status == status) {
                return FETCHDATA_STEP.code;
            } else if (DONE_STEP.status == status){
                return DONE_STEP.code;
            }else if (END_STEP.status == status){
                return END_STEP.code;
            }
            return null;
        }
    }


    public enum TASKType {
        FULL_TASKTYPE(1, "FULL"), // 全量
        INCREMENT_TASKTYPE(2, "INCREMENT"); // 增量


        public final Integer type;
        public final String value;

        TASKType(Integer type, String value) {
            this.type = type;
            this.value = value;
        }

        public static String getValue(Integer type) {
            if (FULL_TASK == type) {
                return FULL_TASKTYPE.value;
            } else if (INCREMENT_TASK == type) {
                return INCREMENT_TASKTYPE.value;
            }
            return null;
        }
    }
}
