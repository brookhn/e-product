package com.jiahui.search.datawrapper.core;

import com.jiahui.search.common.enums.CodeEnum;
import com.jiahui.search.common.enums.PluginConfigStatus;
import com.jiahui.search.common.exception.BizException;
import com.jiahui.search.common.utils.JsonUtil;
import com.jiahui.search.datawrapper.entity.FullTaskMoniter;
import com.jiahui.search.datawrapper.manager.GrpcClientManager;
import com.jiahui.search.datawrapper.util.IConstant;
import com.jiahui.search.datawrapper.util.SpringUtil;
import com.jiahui.search.entity.PluginConfig;
import com.jiahui.search.repository.PluginConfigRepo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.annotation.PreDestroy;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicBoolean;

@Slf4j
@Component
public class DispatchCenter implements ApplicationListener<ApplicationReadyEvent> {

    /**
     * 防止datasource重复初始化
     **/
    private volatile AtomicBoolean initFlag = new AtomicBoolean(false);

    private static TaskFactory taskFactory;

    /**
     * 数据源管理
     */
    @Autowired
    private DataSourceManager dataSourceManager;

    /**
     * spring工具
     */
    @Autowired
    private SpringUtil springUtil;

    /**
     * plugin配置
     */
    @Autowired
    private PluginConfigRepo configRepo;

    @Autowired
    private GrpcClientManager clientManager;


    @Override
    public void onApplicationEvent(ApplicationReadyEvent event) {
        if (!initFlag.compareAndSet(false, true)) {
            return;
        }
        //传入spring对象给到Task
        taskFactory = new TaskFactory(springUtil, dataSourceManager, clientManager);
        this.startLoadExistsPlugin();
    }

    /**
     * 加载已经配置好的插件
     */
    private void startLoadExistsPlugin() {
        PluginConfig param = PluginConfig.builder().status(PluginConfigStatus.RUNNING.getCode()).build();
        List<PluginConfig> pluginConfigs = configRepo.queryList(param);
        if (CollectionUtils.isEmpty(pluginConfigs)) {
            log.info("startLoadExistsPlugin pluginConfig is null !");
            return;
        }

        for (PluginConfig pluginConfig : pluginConfigs) {
            try {
                taskFactory.startNewTask(IConstant.TASKType.INCREMENT_TASKTYPE.type, pluginConfig);
            } catch (Exception e) {
                log.error("startLoadExistsPlugin load plugin {} error", JsonUtil.serialize(pluginConfig), e);
            }
        }
    }

    public void registerTask(Long indexId,Integer taskType){
        PluginConfig param = PluginConfig.builder().status(PluginConfigStatus.RUNNING.getCode()).build();
        List<PluginConfig> pluginConfigs = configRepo.queryList(param);
        if (CollectionUtils.isEmpty(pluginConfigs)){
            throw new BizException(CodeEnum.CODE_210002002.getCode(), CodeEnum.CODE_210002002.getMsg());
        }
        PluginConfig config = pluginConfigs.stream().filter(cfg->cfg.getIndexId().equals(indexId)).findAny().orElse(null);
        if (Objects.isNull(config)){
            throw new BizException(CodeEnum.CODE_210002002.getCode(), CodeEnum.CODE_210002002.getMsg());
        }
        try {
            taskFactory.startNewTask(taskType, config);
        }catch (Exception e){
            log.info("DispatchCenter.registerTask:exception", e);
        }
    }

    /**
     * 获取所有监控对象
     * @return
     */
    public List<FullTaskMoniter> getAllMoniters(){
        List<FullTaskMoniter> taskMoniters = new ArrayList<>();
        return TaskFactory.getAllTaskMoniter();
    }

    public void unRegisterTask(Long indexId,Integer taskType) {
        try {
            taskFactory.stopTask(taskType, indexId);
        }catch (Exception ex){
            log.error("DispatchCenter.unRegisterTask:发生异常", ex);
            throw new BizException(CodeEnum.EXCEPTION.getCode(), CodeEnum.EXCEPTION.getMsg());
        }
    }

    @PreDestroy
    public void preDestory(){
        log.info("spring容器销毁，主动调用全量任务的doIndex操作！");
        taskFactory.stopAllTask();
    }

    public static TaskFactory getTaskFactory() {
        return taskFactory;
    }
}
