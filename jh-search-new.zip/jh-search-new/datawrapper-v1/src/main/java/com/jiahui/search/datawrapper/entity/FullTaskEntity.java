package com.jiahui.search.datawrapper.entity;

import com.jiahui.search.common.enums.CodeEnum;
import com.jiahui.search.common.exception.BizException;
import com.jiahui.search.common.utils.JsonUtil;
import com.jiahui.search.datawrapper.api.entity.DataRange;
import com.jiahui.search.datawrapper.core.full.FullTask;
import com.jiahui.search.datawrapper.util.IConstant;
import com.jiahui.search.entity.PluginConfig;
import io.grpc.netty.shaded.io.netty.util.internal.StringUtil;
import lombok.Getter;
import lombok.Setter;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.yaml.snakeyaml.events.Event;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * 全量对象
 */
public class FullTaskEntity {

    private String tableId;

    /**
     * 索引数据主键
     */
    private String idFieldName;

    @Setter
    @Getter
    private String indexName = "";

    /**
     * 全量抓取线程数
     */
    private Integer fetchThreadNumber;

    /**
     * 批量写入索引数量
     */
    private Integer batchIndexSize;

    /**
     * 批量sql抓取数量
     */
    private Integer batchFetchSize;

    public FullTaskEntity(PluginConfig pluginConfig, String idFieldName){
        String initJson = pluginConfig.getFullSyncConfig();
        if (StringUtil.isNullOrEmpty(pluginConfig.getFullSyncSql()) || StringUtil.isNullOrEmpty(pluginConfig.getFullSyncRangeSql())){
            throw  new BizException(CodeEnum.CODE_210002012);
        }
        if (StringUtil.isNullOrEmpty(initJson)){
            FullTaskEntity  fullTaskEntity =  JsonUtil.parseObject(initJson, FullTaskEntity.class);
            fullTaskEntity.syncBatchSize();
            this.fetchThreadNumber = fullTaskEntity.getFetchThreadNumber();
            this.batchFetchSize = fullTaskEntity.getBatchFetchSize();
            this.batchIndexSize = fullTaskEntity.getBatchIndexSize();
        }else{
            this.fetchThreadNumber = IConstant.DEFAULT_FULL_FETCH_THREAD_NUMBER;
            this.batchFetchSize = IConstant.DEFAULT_BATCH_INDEX_SIZE;
            this.batchIndexSize = IConstant.DEFAULT_BATCH_INDEX_SIZE;
        }
        this.setIdFieldName(idFieldName);
    }

    public Integer getFetchThreadNumber() {
        return fetchThreadNumber;
    }

    public String getIdTag(){
        if (Objects.isNull(tableId)) {
            return idFieldName;
        }
        return tableId;
    }

    public Long getIdValue(Map<String, Object> dataMap){
        if (CollectionUtils.isEmpty(dataMap)){
            throw new BizException(CodeEnum.CODE_210002009.getCode(), CodeEnum.CODE_210002009.getMsg());
        }
        if (dataMap.containsKey(getIdTag())){
            return Long.valueOf(dataMap.get(getIdTag()).toString());
        }
        throw new BizException(CodeEnum.CODE_210002009.getCode(), CodeEnum.CODE_210002009.getMsg());
    }

    /**
     * 抓取线程大小
     *
     * @param fetchThreadNumber
     */
    public void setFetchThreadNumber(Integer fetchThreadNumber) {
        if (null == fetchThreadNumber) {
            this.fetchThreadNumber = IConstant.DEFAULT_FULL_FETCH_THREAD_NUMBER;
        } else if (fetchThreadNumber <= IConstant.MIN_FULL_FETCH_THREAD_NBUMBER) {
            this.fetchThreadNumber = IConstant.MIN_FULL_FETCH_THREAD_NBUMBER;
        } else if (fetchThreadNumber >= IConstant.MAX_FULL_FETCH_THREAD_NUMBER) {
            this.fetchThreadNumber = IConstant.MAX_FULL_FETCH_THREAD_NUMBER;
        } else {
            this.fetchThreadNumber = fetchThreadNumber;
        }
    }

    public Integer getBatchIndexSize() {
        return batchIndexSize;
    }

    /**
     * 批量写入ES 大小
     *
     * @param batchIndexSize
     */
    public void setBatchIndexSize(Integer batchIndexSize) {
        if (null == batchIndexSize) {
            this.batchIndexSize = IConstant.DEFAULT_BATCH_INDEX_SIZE;
        } else if (batchIndexSize <= IConstant.MIN_BATCH_INDEX_SIZE) {
            this.batchIndexSize = IConstant.MIN_BATCH_INDEX_SIZE;
        } else if (batchIndexSize >= IConstant.MAX_BATCH_INDEX_SIZE) {
            this.batchIndexSize = IConstant.MAX_BATCH_INDEX_SIZE;
        } else {
            this.batchIndexSize = batchIndexSize;
        }
    }

    public Integer getBatchFetchSize() {
        return batchFetchSize;
    }

    /**
     * 批量抓取sql大小
     *
     * @param batchFetchSize
     */
    public void setBatchFetchSize(Integer batchFetchSize) {
        if (null == batchFetchSize) {
            this.batchFetchSize = IConstant.SYNC_VALUE;
        } else if (batchFetchSize <= IConstant.MIN_BATCH_FETCH_SIZE) {
            this.batchFetchSize = IConstant.MIN_BATCH_FETCH_SIZE;
        } else if (batchFetchSize >= IConstant.MAX_BATCH_FETCH_SIZE) {
            this.batchFetchSize = IConstant.MAX_BATCH_FETCH_SIZE;
        } else {
            this.batchFetchSize = batchIndexSize;
        }
    }

    /**
     * batchFetch
     */
    public void syncBatchSize() {
        if (IConstant.SYNC_VALUE == this.batchFetchSize) {
            this.batchFetchSize = this.batchIndexSize;
        }
    }

    /**
     * 根据线程数量划分拆分数据间隔
     *
     * @param dataLength
     * @return
     */
    public Long getFetchStepLen(Long dataLength) {
        Long stepLen = Long.valueOf(dataLength / fetchThreadNumber + 1);
        if (stepLen <= 0L) {
            stepLen = 1L;
        }
        return stepLen;
    }

    /**
     * @param originalRange
     * @return
     */
    public List<DataRange> getRealDataRange(DataRange originalRange) {
        List<DataRange> dataRanges = new ArrayList<>();
        Long stepLen = getFetchStepLen(originalRange.getLength());
        if (stepLen < this.getFetchThreadNumber()){
            dataRanges.add(originalRange);
            return dataRanges;
        }
        Long min = originalRange.getMin();
        for (int i = 0; i < getFetchThreadNumber(); ++i) {
            Long tempMin =min;
            long tempMax = tempMin + stepLen;
            if (tempMin > tempMax) {
                break;
            }
            if (tempMax > originalRange.getMax()) {
                tempMax = originalRange.getMax();
            }
            dataRanges.add(new DataRange(tempMin, tempMax));
            min = tempMax + 1;
        }
        return dataRanges;
    }

    public static void main(String[] args) {
//        FullTaskEntity taskEntity = new FullTaskEntity();
//        List<DataRange> splitRange = taskEntity.getRealDataRange(new DataRange(10L, 500L));
//        if (!CollectionUtils.isEmpty(splitRange)) {
//            splitRange.forEach(range -> {
//                System.out.println(range.getMin() + ":" + range.getMax());
//            });
//        }
    }

    public List<DataRange> getPushDataRange(int dataSize) {
        List<DataRange> dataRanges = new ArrayList<>();
        Long min = 0l;
        Long max = Long.valueOf(dataSize);
        if (dataSize <= batchIndexSize) {
            dataRanges.add(new DataRange(min, max));
            return dataRanges;
        }
        max = Long.valueOf(batchIndexSize) + min;
        while (min < Long.valueOf(dataSize)) {
            dataRanges.add(new DataRange(min, max));
            min = max;
            max = min + Long.valueOf(batchIndexSize);
            max = max > (dataSize) ? (dataSize) : max;
        }
        return dataRanges;
    }

    public boolean isNeedPush(int dataSize) {
        if (dataSize >= batchIndexSize) {
            return true;
        }
        return false;
    }

    public int getPushTimes(int dataSize) {
        if (dataSize <= batchIndexSize) {
            return 1;
        }
        return dataSize / batchIndexSize + 1;
    }

    public String getIdFieldName() {
        return idFieldName;
    }

    public void setIdFieldName(String idFieldName) {
        this.idFieldName = idFieldName;
    }

    public String getTableId() {
        return tableId;
    }

    public void setTableId(String tableId) {
        this.tableId = tableId;
    }


}
