package com.jiahui.search.datawrapper.core;

import com.jiahui.framework.datasource.config.JiaHuiDataSourceProperties;
import com.jiahui.framework.datasource.core.DynamicDataSource;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Log4j2
@Component
public class DataSourceManager {

    Map<String, JdbcTemplate> jdbcTemplatesMap = new ConcurrentHashMap<>();

    @Autowired
    private JiaHuiDataSourceProperties jiaHuiDataSourceProperties;

    /**
     * 新建dataSource根据List
     * @param dataSouceNames
     */
    public void createNewDataSource(List<String> dataSouceNames){
        if (!CollectionUtils.isEmpty(dataSouceNames)){
            for (String dataSourceName:dataSouceNames) {
                createNewDataSource(dataSourceName);
            }
        }
    }

    /**
     * 新建dataSource
     * @param dataSourceName
     */
    public void createNewDataSource(String dataSourceName) {
        if (!isExistsJdbcTemplate(dataSourceName)){
            if (null != dataSourceName){
                DynamicDataSource dynamicDataSource = new DynamicDataSource(dataSourceName, jiaHuiDataSourceProperties);
                jdbcTemplatesMap.put(dataSourceName, new JdbcTemplate(dynamicDataSource));
            }
        }
        log.info("DataSourceManager.createNewDataSource:{} 数据源已存在", dataSourceName);
    }

    /**
     * 判断是否存在JDBCTemplate
     * @param dataSourceName
     * @return
     */
    public boolean isExistsJdbcTemplate(String dataSourceName){
        if (jdbcTemplatesMap.containsKey(dataSourceName)) {
            return true;
        }
        return false;
    }

    /**
     * 根据数据源名称获取JDBCTemplate
     * @param dataSourceName jdbcTemplate
     * @return
     */
    public JdbcTemplate getJdbcTemplate(String dataSourceName) {
        if (CollectionUtils.isEmpty(jdbcTemplatesMap)){
            throw new RuntimeException("加载数据源【" + dataSourceName + "】错误");
        }
        return jdbcTemplatesMap.get(dataSourceName);
    }

}
