package com.jiahui.search.datawrapper.core.increment;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jiahui.search.common.utils.JsonUtil;
import com.jiahui.search.datawrapper.core.AbstractTask;
import com.jiahui.search.datawrapper.core.DispatchCenter;
import com.jiahui.search.datawrapper.core.TaskFactory;
import com.jiahui.search.datawrapper.manager.GrpcClientManager;
import com.jiahui.search.datawrapper.util.IConstant;
import com.jiahui.search.entity.CompensateRecord;
import com.jiahui.search.entity.PluginConfig;
import com.jiahui.search.repository.PluginConfigRepo;
import com.jiahui.search.repository.dao.CompensateRecordMapper;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.util.Lists;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;

@Slf4j
@Component
public class IncrementTaskJob {

    @Resource
    private CompensateRecordMapper compensateRecordMapper;

    @Resource
    private PluginConfigRepo pluginConfigRepo;

    @Resource
    private GrpcClientManager clientManager;


    /**
     * 增量任务失败补偿
     */
    @XxlJob("incrementTaskCompensate")
    public void doTask() {
        int current = 1, size = 10;
        List<Long> idList = Lists.newArrayList();
        while (true) {
            Page<CompensateRecord> page = new Page<>(current, size);
            Page<CompensateRecord> recordPage = compensateRecordMapper.selectPage(page, null);
            if (CollectionUtils.isEmpty(recordPage.getRecords())) {
                break;
            }
            TaskFactory taskFactory = DispatchCenter.getTaskFactory();
            for (CompensateRecord record : recordPage.getRecords()) {
                AbstractTask task = taskFactory.getTask(IConstant.TASKType.INCREMENT_TASKTYPE.type, record.getIndexId());
                if (Objects.isNull(task)) {
                    continue;
                }
                PluginConfig pluginConfig = pluginConfigRepo.selectCacheById(record.getPluginConfigId());
                if (Objects.isNull(pluginConfig)) {
                    continue;
                }
                try {
                    IncrementTaskHandler taskHandler = new IncrementTaskHandler(task.getDataWrapperHandler(), pluginConfig, clientManager);
                    taskHandler.doIndexer(Lists.newArrayList(JsonUtil.parseStringObjectMap(record.getRetryContent())));
                    idList.add(record.getId());
                } catch (Exception e) {
                    record.setRetryTimes(record.getRetryTimes() + 1);
                    compensateRecordMapper.updateById(record);
                }
            }
            if (!recordPage.hasNext()) {
                compensateRecordMapper.deleteBatchIds(idList);
                idList.clear();
                break;
            }
            current++;
            //批量删除、重置起始页
            if (idList.size() > 20) {
                compensateRecordMapper.deleteBatchIds(idList);
                idList.clear();
                current = 1;
            }
        }
    }

}
