package com.jiahui.search.datawrapper.service;

import com.jiahui.search.common.utils.JsonUtil;
import com.jiahui.search.datawrapper.core.DispatchCenter;
import com.jiahui.search.datawrapper.util.IConstant;
import com.jiahui.search.entity.PluginConfig;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Component
public class IncrementTaskStartConsumer {

    @Autowired
    private DispatchCenter dispatchCenter;

    /**
     * 监听增量任务启动
     * @param list
     * @param ack
     */
    @KafkaListener(topics = IConstant.INCR_TASK_START, containerFactory = "batchFactory")
    public void consume(List<ConsumerRecord<String, String>> list, Acknowledgment ack) {
        if (CollectionUtils.isEmpty(list)) {
            return;
        }
        try {
            List<PluginConfig> plugins = list.stream().map(record ->
                    JsonUtil.parseObject(record.value(), PluginConfig.class)).collect(Collectors.toList());
            plugins.forEach(config -> {
                dispatchCenter.registerTask(config.getIndexId(), IConstant.TASKType.INCREMENT_TASKTYPE.type);
            });
        } catch (Exception e) {
            log.error("增量任务启动消费异常", e);
        }
        ack.acknowledge();
    }

}
