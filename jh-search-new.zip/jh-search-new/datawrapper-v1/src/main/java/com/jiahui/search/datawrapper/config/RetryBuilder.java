package com.jiahui.search.datawrapper.config;

import com.github.rholder.retry.Retryer;
import com.github.rholder.retry.RetryerBuilder;
import com.github.rholder.retry.StopStrategies;
import com.github.rholder.retry.WaitStrategies;
import com.jiahui.framework.rpc.rest.ResultVO;
import com.jiahui.search.common.enums.CodeEnum;
import com.jiahui.search.datawrapper.util.IConstant;
import com.jiahui.search.indexer.contract.IndexResponse;

import java.util.Objects;
import java.util.concurrent.TimeUnit;

public class RetryBuilder {

    public static final Retryer<ResultVO> restRetry = RetryerBuilder.<ResultVO>newBuilder()
            //210004002重试code
            .retryIfResult(res -> Objects.isNull(res) || CodeEnum.RETRY.getCode() == res.getCode())
            //抛出异常重试
            .retryIfException()
            // 重试次数
            .withStopStrategy(StopStrategies.stopAfterAttempt(3))
            // 重试间隔
            .withWaitStrategy(WaitStrategies.fixedWait(500, TimeUnit.MILLISECONDS))
            .build();

    public static final Retryer<IndexResponse> doIndexRetry = RetryerBuilder.<IndexResponse>newBuilder()
            //210004002重试code
            .retryIfResult(res -> CodeEnum.RETRY.getCode() == res.getCode())
            //抛出异常重试
            .retryIfException()
            // 重试次数
            .withStopStrategy(StopStrategies.stopAfterAttempt(IConstant.MAX_RETRY))
            // 重试间隔
            .withWaitStrategy(WaitStrategies.fixedWait(500, TimeUnit.MILLISECONDS))
            .build();

    public static final Retryer<IndexResponse> doIncrIndexRetry = RetryerBuilder.<IndexResponse>newBuilder()
            //210004002重试code
            .retryIfResult(res -> CodeEnum.RETRY.getCode() == res.getCode())
            //抛出异常重试
            .retryIfException()
            // 重试次数
            .withStopStrategy(StopStrategies.neverStop())
            // 重试间隔
            .withWaitStrategy(WaitStrategies.fixedWait(500, TimeUnit.MILLISECONDS))
            .build();


}
