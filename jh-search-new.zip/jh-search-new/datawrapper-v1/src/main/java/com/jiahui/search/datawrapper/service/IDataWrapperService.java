package com.jiahui.search.datawrapper.service;

import java.util.Set;

public interface IDataWrapperService {
    /**
     * 手动启动增量任务
     *
     * @param indexId
     */
    void startIncrementTask(Long indexId);

    /**
     * 获取当前运行的节点列表
     *
     * @param indexId
     * @return
     */
    Set<String> getRunningInstance(Long indexId);

}
