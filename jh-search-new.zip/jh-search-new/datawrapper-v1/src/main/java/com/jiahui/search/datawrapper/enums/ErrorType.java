package com.jiahui.search.datawrapper.enums;

public enum ErrorType {
    OK(0, "成功"),
    MsgRecv(1, "消息接收"),
    MsgFormat(2, "消息格式化"),
    WrapException(3, "wrapper异常"),
    WrapEmpty(4, "wrapper返回空"),
    WrapFormat(5, "wrapper格式化异常"),
    MsgSend(6, "数据发送");

    private int error;

    private String errorMsg;

    private ErrorType(int error, String errorMsg) {
        this.error = error;
        this.errorMsg = errorMsg;
    }

    public int getValue() {
        return error;
    }
}