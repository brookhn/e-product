package com.jiahui.search.datawrapper.controller;

import cn.hutool.core.net.NetUtil;
import com.jiahui.framework.rpc.rest.ResultVO;
import com.jiahui.search.common.exception.BizException;
import com.jiahui.search.datawrapper.core.DispatchCenter;
import com.jiahui.search.datawrapper.entity.FullTaskMoniter;
import com.jiahui.search.datawrapper.service.IDataWrapperService;
import com.jiahui.search.datawrapper.util.IConstant;
import com.jiahui.search.index.writer.rest.contract.FullTaskMoniterResponse;
import com.jiahui.search.index.writer.rest.contract.SyncRequest;
import com.jiahui.search.index.writer.rest.contract.SyncResponse;
import com.jiahui.search.index.writer.rest.contract.WrapperTaskResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Set;

@Order(-1)
@RestController
@RequestMapping
public class DataWrapperController {

    @Autowired
    private DispatchCenter dispatchCenter;

    @Autowired
    private IDataWrapperService dataWrapperService;

    /**
     * 开启全量同步
     * @return
     */
    @PostMapping("/startFullTask")
    public ResultVO<SyncResponse> startFullTask(@RequestBody SyncRequest syncRequest){
        ResultVO<SyncResponse> resultVo = new ResultVO<>();
        try {
            SyncResponse syncResponse = new SyncResponse();
            syncResponse.setIndexId(syncRequest.getIndexId());
            syncResponse.setIpAddress(NetUtil.getLocalhostStr());
            resultVo.setData(syncResponse);
            dispatchCenter.registerTask(syncRequest.getIndexId(), IConstant.TASKType.FULL_TASKTYPE.type);
        } catch (BizException e){
            resultVo.setCode(e.getCode());
            resultVo.setMsg(e.getMsg());
            return resultVo;
        }
        return resultVo;
    }

    /**
     * 停止全量同步
     * @return
     */
    @PostMapping("/stopFullTask")
    public ResultVO<SyncResponse> stopFullTask(@RequestBody SyncRequest syncRequest){
        ResultVO<SyncResponse> resultVo = new ResultVO<>();
        try {
            SyncResponse syncResponse = new SyncResponse();
            syncResponse.setIndexId(syncRequest.getIndexId());
            resultVo.setData(syncResponse);
            dispatchCenter.unRegisterTask(syncRequest.getIndexId(), IConstant.TASKType.FULL_TASKTYPE.type);
        }catch (BizException e){
//            return JsonResult.failure(String.valueOf(e.getCode()), e.getMsg());
            resultVo.setCode(e.getCode());
            resultVo.setMsg(e.getMsg());
            return resultVo;
        }
        return resultVo;
    }

    /**
     * 获取系统监控
     * @return
     */
    @PostMapping("/getTaskActuator")
    public ResultVO<FullTaskMoniterResponse> getTaskRunActuator(){
        ResultVO<FullTaskMoniterResponse> resultVO = new ResultVO<>();
        List<FullTaskMoniter> taskMoniterList =  dispatchCenter.getAllMoniters();
        FullTaskMoniterResponse rpData = new FullTaskMoniterResponse();
        taskMoniterList.forEach(moniter->{
            rpData.addMoniterObject(moniter.getTaskName(),
                                moniter.getIndexName(),
                                moniter.getTotalCount().get(),
                                moniter.getTaskTotalCount().get(),
                                moniter.getThreadRumQtyMaps());
        });
        resultVO.setData(rpData);
        return resultVO;
    }

    /**
     * 手动启动增量
     ** @return
     */
    @PostMapping("/startIncrTask")
    public ResultVO<SyncResponse> startIncrTask(@RequestBody SyncRequest syncRequest) {
        ResultVO<SyncResponse> resultVo = new ResultVO<>();
        dataWrapperService.startIncrementTask(syncRequest.getIndexId());
        return resultVo;
    }

    /**
     * 查看正在运行的任务列表
     *
     * @return
     */
    @GetMapping("/getRunningMap")
    public ResultVO<WrapperTaskResponse> getRunningMap() {
        ResultVO<WrapperTaskResponse> resultVO = new ResultVO<>();
        WrapperTaskResponse wrapperTaskResponse = new WrapperTaskResponse();
        wrapperTaskResponse.setTasklist(DispatchCenter.getTaskFactory().getRunningTaskIndexIds());
        resultVO.setData(wrapperTaskResponse);
        return resultVO;
    }

    /**
     * 查看正在运行的任务列表
     *
     * @return
     */
    @GetMapping("/getIncrMonitor")
    public ResultVO<Set> getIncrMonitor(Long indexId) {
        ResultVO<Set> resultVO = new ResultVO<>();
        Set<String> ips = dataWrapperService.getRunningInstance(indexId);
        resultVO.setData(ips);
        return resultVO;
    }
}
