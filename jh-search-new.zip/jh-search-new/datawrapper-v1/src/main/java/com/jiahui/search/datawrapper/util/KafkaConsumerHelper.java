package com.jiahui.search.datawrapper.util;

import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class KafkaConsumerHelper {

    private static final Logger logger = LoggerFactory.getLogger(KafkaConsumerHelper.class);

    public static void addShutdownHook(KafkaConsumer consumer) {
        final Thread mainThread = Thread.currentThread();
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            logger.info("Starting exit...");
            consumer.wakeup();
            try {
                mainThread.join();
            } catch (InterruptedException e) {
                logger.error(e.getMessage(), e);
            }
        }));
    }
}
