package com.jiahui.search.datawrapper.core.full;

import com.google.common.collect.Lists;
import com.jiahui.search.common.enums.CodeEnum;
import com.jiahui.search.common.exception.BizException;
import com.jiahui.search.common.utils.JsonUtil;
import com.jiahui.search.datawrapper.api.entity.DataRange;
import com.jiahui.search.datawrapper.api.entity.WrapperResult;
import com.jiahui.search.datawrapper.config.RetryBuilder;
import com.jiahui.search.datawrapper.entity.FullDataRange;
import com.jiahui.search.datawrapper.util.IConstant;
import com.jiahui.search.indexer.contract.DocDto;
import com.jiahui.search.indexer.contract.FullIndexRequest;
import com.jiahui.search.indexer.contract.IncrementIndexRequest;
import com.jiahui.search.indexer.contract.IndexResponse;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang3.StringUtils;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.util.CollectionUtils;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.BiFunction;

/**
 * 默认全量数据推送服务
 */
@Log4j2
public class DefaultFullIndexService extends AbstractFullIndexService{

    public DefaultFullIndexService(FullTask fullTask) {
        super(fullTask);
    }


    /**
     * 获取数据范围
     * @return
     */
    @Override
    List<DataRange> getDataRange() {
        long st = System.currentTimeMillis();
        String rangeSql = this.fullTask.getPluginConfig().getFullSyncRangeSql();
        FullDataRange range = getFullTask().jdbcTemplate.queryForObject(rangeSql, new RowMapper<FullDataRange>() {
            public FullDataRange mapRow(ResultSet rs, int rowNum) throws SQLException {
                FullDataRange fullDataRange = new FullDataRange();
                DataRange range = new DataRange();
                range.setMin(rs.getLong(1));
                range.setMax(rs.getLong(2));
                fullDataRange.setDataRange(range);
                fullDataRange.setTotalSize(rs.getInt(3));
                return fullDataRange;
            }
        });
        range.getDataRange().validateData();
        fullTask.getTaskMoniter().setTaskTotalCount(range.getTotalSize());
        log.info("查询数据区间开始：cost:{}; SQL:{}; begin:{}; end:{}", new Object[] { System.currentTimeMillis() - st,
                rangeSql.replaceAll("\r|\n", "").replaceAll(" +|\t+", " "),
                range.getDataRange().getMin(), range.getDataRange().getMax() });
        return fullTask.fullTaskEntity.getRealDataRange(range.getDataRange());
    }

    List<Map<String, Object>> fetchDataDb(DataRange dataRange){
        if (putAllState == IConstant.FULL_PUSH_STATE_END || putAllState == IConstant.FULL_PUSH_STATE_EXCEPTION) {
            // 结束本次全量推送
            return null;
        }
        List<Map<String, Object>> queryList = getFullTask().jdbcTemplate.query(fullQuerySql,
                new Object[]{dataRange.getMin(), dataRange.getMax(), bathQuerySize}, defaultRowMapper);
        log.debug("查询子数据区间开始：cost:{}; SQL:{}; begin:{}; end:{}; batchSize:{}",
                new Object[] { System.currentTimeMillis() - startTime,
                fullQuerySql.replaceAll("\r|\n", "").replaceAll(" +|\t+", " "),
                        dataRange.getMin(), dataRange.getMax(), bathQuerySize });
        //若查询数据为Empty，则代表该操作已结束
        if (CollectionUtils.isEmpty(queryList)){
            return queryList;
        }
        log.debug("查询子数据区间结束：cost:{}; SQL:{}; begin:{}; end:{}; batchSize:{}",
                new Object[] { System.currentTimeMillis() - startTime,
                fullQuerySql.replaceAll("\r|\n", "").replaceAll(" +|\t+", " "),
                        dataRange.getMin(), dataRange.getMax(), bathQuerySize });
        //数据放入List中
        if (Objects.isNull(queryList.get(queryList.size()-1).get(getFullTask().fullTaskEntity.getIdFieldName()))){
            log.error("与配置文件中主键{}不一致", getFullTask().fullTaskEntity.getIdFieldName());
            throw new BizException(CodeEnum.CODE_210002007.getCode(), CodeEnum.CODE_210002007.getMsg());
        }
        //提交处理数据到
        return queryList;
    }

    /**
     * 转换数据
     * @param queryList
     * @return
     */
    List<Map<String, Object>> transformData(List<Map<String, Object>> queryList){
        if (CollectionUtils.isEmpty(queryList)){
            throw new BizException(CodeEnum.EXCEPTION.getCode(), CodeEnum.EXCEPTION.getMsg());
        }
        //空Plugin不需要
        if (!Objects.isNull(getFullTask().getDataWrapperHandler())) {
            return queryList;
        }
        WrapperResult wrapperResult = getFullTask().getDataWrapperHandler().fullSyncDataWrap(queryList);
        if (Objects.isNull(wrapperResult)) {
            return null;
        }
        return wrapperResult.getDatas();
    }

    /**
     * 写ES
     * @param indexDataList
     */
    void pushToIndex(List<Map<String, Object>> indexDataList) {
        if (CollectionUtils.isEmpty(indexDataList)){
            return;
        }
        BiFunction<List<DocDto>, Long, IndexResponse> biFunction = (docs, indexId) ->
                fullTask.getClientManager().getIndexWriterStub().fullIndex(FullIndexRequest.newBuilder().
                addAllDocs(docs).setIndexConfigId(getFullTask().getPluginConfig().getIndexId()).build());
        List<DocDto> docs = new ArrayList<>();
        indexDataList.forEach(map -> {
            DocDto docDto = DocDto.newBuilder().setData(JsonUtil.serialize(map)).build();
            docs.add(docDto);
        });
        List<List<DocDto>> subSets = Lists.partition(docs, fullTask.fullTaskEntity.getBatchIndexSize());
        if (CollectionUtils.isEmpty(subSets)) {
            return;
        }
       //索引写数据
       subSets.forEach(indexDatas->{
          boolean pushResult = fullTask.getClientManager().doIndex(fullTask.getPluginConfig(),
                                                   indexDatas,
                                                   biFunction,
                                                   RetryBuilder.doIndexRetry);
          if (!pushResult){
             getFullTask().taskMoniter.incrementFailCount(indexDataList.size());
             throw new BizException(CodeEnum.CODE_210002008.getCode(), CodeEnum.CODE_210002008.getMsg());
          }
       });

    }
}