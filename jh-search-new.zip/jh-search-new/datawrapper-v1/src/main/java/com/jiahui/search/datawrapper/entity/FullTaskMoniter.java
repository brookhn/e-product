package com.jiahui.search.datawrapper.entity;

import com.jiahui.search.datawrapper.util.IConstant;
import com.jiahui.search.entity.PluginConfig;
import lombok.Data;
import lombok.extern.log4j.Log4j2;
import org.checkerframework.checker.units.qual.A;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

@Data
@Log4j2
public class FullTaskMoniter {

    private String taskName;

    private String indexName;

    private AtomicLong totalCount = new AtomicLong(0l);
    private AtomicLong failCount = new AtomicLong(0l);


    /**
     * 任务数据大小
     */
    private AtomicLong taskTotalCount = new AtomicLong(0l);

    private PluginConfig pluginConfig;

    public FullTaskMoniter(PluginConfig config){
        this.pluginConfig = config;
        this.taskName = "全量同步任务,索引ID:["+config.getIndexId()+"]";
    }

    //全量任务，各个状态运行时间map
    Map<String, Long> runTimeSpace = new HashMap<>();

    /**
     * 每个线程运行数量
     */
    Map<String, AtomicLong> threadRumQtyMaps = new HashMap<>();

    public Integer runStatus = IConstant.FullTaskStep.NO_STEP.status;

    public void incrementFailCount(int incrementCount){
        failCount.addAndGet(incrementCount);
    }

    public void incrementTotalCount(int incrementCount){
        log.info("查询前数据量，{}, 增加数量 {}", totalCount.get(), incrementCount);
        totalCount.addAndGet(incrementCount);
        log.info("查询后数据量，{}", totalCount.get());
    }

    /**
     *
     * @param count
     */
    public void setTaskTotalCount(int count){
        taskTotalCount.addAndGet(count);
    }

    public void setStatus(int status){
        this.runStatus = status;
    }

    public void setStatusTimeStamp(String statusCode, long timeStamp){
        runTimeSpace.put(statusCode, timeStamp);
    }

    public void setThreadQty(String threadName, int qty){

        Long threadQty = 0l;
        if (threadRumQtyMaps.containsKey(threadName)){
            threadQty = threadRumQtyMaps.get(threadName).addAndGet(qty);
            log.info("线程{}，之前数量{}， 增加数量{}, 全量数量 {}", threadName, threadQty, qty, totalCount.get());
        }else{
            threadQty = Long.valueOf(qty);
        }
        log.info("线程{}，增加后数量{}, 全部数量 {}", threadName, threadQty, totalCount.get());
        threadRumQtyMaps.put(threadName, new AtomicLong(threadQty));
    }

    //
    public boolean getFullTaskIsok(){
        if (totalCount.get() == 0){
            return false;
        }
        if (totalCount.get() == taskTotalCount.get()){
            return true;
        }
        return false;
    }
}
