package com.jiahui.search.datawrapper.core;

import com.jiahui.search.common.enums.CodeEnum;
import com.jiahui.search.common.exception.BizException;
import com.jiahui.search.datawrapper.api.DataWrapperHandler;
import com.jiahui.search.datawrapper.core.full.FullTask;
import com.jiahui.search.datawrapper.core.increment.IncrementTask;
import com.jiahui.search.datawrapper.entity.FullTaskMoniter;
import com.jiahui.search.datawrapper.manager.GrpcClientManager;
import com.jiahui.search.datawrapper.util.ClassLoaderUtil;
import com.jiahui.search.datawrapper.util.IConstant;
import com.jiahui.search.datawrapper.util.SpringUtil;
import com.jiahui.search.entity.PluginConfig;
import lombok.extern.log4j.Log4j2;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.BiConsumer;


/**
 * 任务管理工厂，负责任务相关处理
 */
@Log4j2
public class TaskFactory {

    /**
     * 运行中任务管理列表
     **/
    private static Map<String, AbstractTask> runningTaskMap = new ConcurrentHashMap<>();

    /**
     * 插件列表
     **/
    private Map<Long, DataWrapperHandler> dataWrapperHandlerMap = new HashMap<>();

    private SpringUtil springUtil;

    private DataSourceManager dataSourceManager;

    private GrpcClientManager clientManager;

    public TaskFactory(SpringUtil springUtil, DataSourceManager dataSourceManager, GrpcClientManager clientManager) {
        this.springUtil = springUtil;
        this.dataSourceManager = dataSourceManager;
        this.clientManager = clientManager;
    }

    public static Set<String> getRunningTaskIndexIds() {
        return runningTaskMap.keySet();
    }

    /**
     * 加载并获取插件wrapperHandler 实例
     *
     * @param config
     * @return
     */
    private DataWrapperHandler getDataWrapperHandler(PluginConfig config) {
        try {
            if (dataWrapperHandlerMap.containsKey(config.getIndexId())) {
                return dataWrapperHandlerMap.get(config.getIndexId());
            }
            ClassLoader classLoader = ClassLoaderUtil.getClassLoader(config.getWrapperJarUrl());
            Class<?> clazz = classLoader.loadClass(config.getWrapperClass());
            springUtil.registerBean(clazz.getName(), clazz);
            DataWrapperHandler dataWrapperHandler = (DataWrapperHandler) springUtil.getBean(config.getWrapperClass());
            dataWrapperHandlerMap.put(config.getIndexId(), dataWrapperHandler);
            return dataWrapperHandler;
        } catch (ClassNotFoundException e) {
            log.error("TaskFactory.getDataWrapperHandler::加载plugin异常", e);
            throw new BizException(CodeEnum.CODE_210002004.getCode(), CodeEnum.CODE_210002004.getMsg());
        }
    }


    /**
     * 开启任务
     *
     * @param taskType
     * @return
     */
    public void startNewTask(Integer taskType, PluginConfig config) {
        DataWrapperHandler dataWrapperHandler = getDataWrapperHandler(config);
        String indexMapKey = getMapKey(taskType, dataWrapperHandler.getIndexId());
        String indexId = String.valueOf(config.getIndexId());
        //防止手动触发增量导致的单节点任务重复提交
        synchronized (indexId.intern()) {
            if (isExistsTask(taskType, dataWrapperHandler.getIndexId())) {
                log.info("TaskFactory.startNewTask::{} 索引任务已经存在", dataWrapperHandler.getIndexId());
                throw new BizException(CodeEnum.CODE_210002001.getCode(), CodeEnum.CODE_210002001.getMsg());
            }
            AbstractTask task = createNewTask(taskType);
            task.setDataSourceManager(dataSourceManager);
            task.setDataWrapperHandler(dataWrapperHandler);
            task.setClientManager(clientManager);
            task.setPluginConfig(config);
            runningTaskMap.put(indexMapKey, task);
            new Thread(task).start();
        }

    }

    /**
     * 创建新的任务
     *
     * @param taskType
     * @return
     */
    public AbstractTask createNewTask(Integer taskType) {
        AbstractTask task = null;
        if (IConstant.FULL_TASK == taskType) {
            task = new FullTask();
        } else if (IConstant.INCREMENT_TASK == taskType) {
            task = new IncrementTask();
        }
        return task;
    }

    /**
     * 停止任务
     *
     * @param taskType
     * @param indexId
     */
    public void stopTask(Integer taskType, Long indexId) {
        String indexMapKey = getMapKey(taskType, indexId);
        if (!isExistsTask(taskType, indexId)) {
            log.error("TaskFactory.stopTask::{} index sync task not eixists exists", indexId);
            throw new BizException(CodeEnum.CODE_210002001.getCode(), CodeEnum.CODE_210002001.getMsg());
        }
        runningTaskMap.get(indexMapKey).indexDone();
        unRegister(taskType, indexId);
    }

    public void stopAllTask(){
        runningTaskMap.forEach((key, value)->{
            if (value instanceof  FullTask){
                value.indexDone();
            }
        });
    }

    /***
     * 根据任务类型及IndexId生产map的key
     * @param taskType
     * @param indexId
     * @return
     */
    public static String getMapKey(Integer taskType, Long indexId) {
        StringBuilder mapKey = new StringBuilder();
        mapKey.append(indexId);
        mapKey.append("_");
        mapKey.append(IConstant.TASKType.getValue(taskType));
        return mapKey.toString();
    }

    /**
     * @param taskType
     * @param indexId
     */
    public static void unRegister(Integer taskType, Long indexId) {
        log.info("移除运行列表中的任务:indexId[{}]:taskType[{}]", indexId, IConstant.TASKType.getValue(taskType));
        runningTaskMap.remove(getMapKey(taskType, indexId));
    }

    public static List<FullTaskMoniter> getAllTaskMoniter(){
        List<FullTaskMoniter> taskMoniters = new ArrayList<>();
        runningTaskMap.forEach(new BiConsumer<String, AbstractTask>() {
            @Override
            public void accept(String s, AbstractTask abstractTask) {
                if (abstractTask instanceof FullTask){
                    FullTask fullTask = (FullTask)abstractTask;
                    taskMoniters.add(fullTask.getTaskMoniter());
                }
            }
        });
        return taskMoniters;
    }

    /**
     * 获取当前正在运行任务
     *
     * @param taskType
     * @param indexId
     * @return
     */
    public AbstractTask getTask(Integer taskType, Long indexId) {
        String indexMapKey = getMapKey(taskType, indexId);
        return runningTaskMap.get(indexMapKey);
    }

    /**
     * 判断当前任务中是否已经存在对应任务
     *
     * @param taskType
     * @param indexId
     * @return
     */
    public boolean isExistsTask(Integer taskType, Long indexId) {
        AbstractTask task = getTask(taskType, indexId);
        if (null != task) {
            return true;
        }
        return false;
    }
}
