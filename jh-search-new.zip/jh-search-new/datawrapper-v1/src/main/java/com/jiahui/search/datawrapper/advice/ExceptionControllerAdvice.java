package com.jiahui.search.datawrapper.advice;


import com.jiahui.framework.rpc.enums.ResultCodeEnum;
import com.jiahui.framework.rpc.rest.ResultVO;
import com.jiahui.search.common.exception.BizException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * @author zzc
 * 全局异常处理
 */
@RestControllerAdvice
public class ExceptionControllerAdvice {

    private static final Logger logger = LoggerFactory.getLogger(ExceptionControllerAdvice.class);

    @ExceptionHandler(Exception.class)
    public Object errorHandler(Exception ex) {
        logger.error(ex.getMessage(), ex);
        return new ResultVO<>(ResultCodeEnum.ERROR.getCode(), ResultCodeEnum.ERROR.getMsg());
    }

    @ExceptionHandler(BizException.class)
    public Object errorHandler(BizException ex) {
//        logger.error(ex.getMessage(), ex);
        return new ResultVO<>(ex.getCode(), ex.getMessage());
    }
}
