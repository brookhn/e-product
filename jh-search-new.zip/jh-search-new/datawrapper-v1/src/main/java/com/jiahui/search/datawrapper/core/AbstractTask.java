package com.jiahui.search.datawrapper.core;

import cn.hutool.core.text.StrSplitter;
import com.jiahui.search.common.enums.CodeEnum;
import com.jiahui.search.common.exception.BizException;
import com.jiahui.search.datawrapper.api.DataWrapperHandler;
import com.jiahui.search.datawrapper.manager.GrpcClientManager;
import com.jiahui.search.datawrapper.util.IConstant;
import com.jiahui.search.entity.PluginConfig;
import lombok.Data;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

/**
 * 同步任务类，增量、全量同步任务父类
 */
@Data
@Log4j2
public abstract class AbstractTask implements Runnable {

    /**
     * 数据封装方法
     */
    protected DataWrapperHandler dataWrapperHandler;

    /**
     * 任务配置参数
     */
    protected PluginConfig pluginConfig;

    /**
     * 数据源
     */
    protected DataSourceManager dataSourceManager;

    /**
     * index操作RPC
     */
    protected GrpcClientManager clientManager;

    private boolean fetchDataDone = false;


    /**
     * 初始化参数等动作
     */
    public void init() {
        MDC.put(IConstant.INDEX_ID, pluginConfig.getIndexId() + "");
        List<String> dbSourceList = new ArrayList<>();
        if (null == getPluginConfig()){
            throw new BizException(CodeEnum.CODE_210002002);
        }
        //初始化数据源,全量增量数据源同时
        if (StringUtils.isNoneBlank(getPluginConfig().getFullSyncDbName())) {
            dbSourceList.add(getPluginConfig().getFullSyncDbName());
        }
        if (StringUtils.isNoneBlank(getPluginConfig().getIncrSyncDbNames())) {
            List<String> incrementDbList = StrSplitter.split(getPluginConfig().getIncrSyncDbNames(), ",", 0, false, true);
            if (!CollectionUtils.isEmpty(incrementDbList)) {
                dbSourceList.addAll(incrementDbList);
            }
        }
        dataSourceManager.createNewDataSource(dbSourceList);
        dataWrapperHandler.initJdbcTemplate(dataSourceManager.jdbcTemplatesMap);
    }

    /**
     * 开启同步任务
     */
    public abstract void doIndex() throws ExecutionException, InterruptedException;

    /**
     * 停止同步任务
     */
    public void indexDone() {
        MDC.remove(IConstant.INDEX_ID);
    }

    @Override
    public void run() {
        try {
            this.init();
            this.doIndex();
        } catch (Exception e) {
            log.error("AbstractTask.run:任务异常，索引ID：{}", pluginConfig.getIndexId(),  e);
        } finally {
            this.indexDone();
            try {
                Thread.sleep(10 * 1000); //延时10秒注销,以便"获取全量重推任务的实时状态信息"接口取相关的状态信息
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
