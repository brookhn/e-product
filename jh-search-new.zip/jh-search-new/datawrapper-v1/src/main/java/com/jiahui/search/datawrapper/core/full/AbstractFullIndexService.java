package com.jiahui.search.datawrapper.core.full;

import com.jiahui.search.common.enums.CodeEnum;
import com.jiahui.search.common.exception.BizException;
import com.jiahui.search.datawrapper.api.entity.DataRange;
import com.jiahui.search.datawrapper.util.IConstant;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.log4j.Log4j2;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;

@Slf4j
public abstract class AbstractFullIndexService {
    @Setter
    @Getter
    FullTask fullTask;

    CountDownLatch downLatch;

    String fullQuerySql;

    long bathQuerySize;

    DefaultRowMapper defaultRowMapper;

    long startTime = 0;

    List<FetchDataThread> fetchDataThreads = null;

    public AbstractFullIndexService(FullTask fullTask) {
        this.fullTask = fullTask;
        this.fullQuerySql = fullTask.getPluginConfig().getFullSyncSql();
        this.bathQuerySize = fullTask.fullTaskEntity.getBatchFetchSize();
        this.defaultRowMapper = new DefaultRowMapper();
        fetchDataThreads = new ArrayList<>();
    }

    /**
     * 全量同步状态：0 初始化
     *             -1 已结束
     */
    public int putAllState = IConstant.FULL_PUSH_STATE_INIT;

    /**
     * 拆分查询数据
     * @return
     */
    abstract List<DataRange> getDataRange();


    /**
     * 抓取数据
     * @param dataRange
     * @return
     */
    abstract List<Map<String, Object>> fetchDataDb(DataRange dataRange);

    /**
     * 封装数据
     * @param queryList
     * @return
     */
    abstract  List<Map<String, Object>> transformData(List<Map<String, Object>> queryList);

    /**
     * 写ES
     * @param indexDataList
     */
    abstract void pushToIndex(List<Map<String, Object>> indexDataList);

    public void stopService(){
        //设置全量抓取数据结束
        this.putAllState = IConstant.FULL_PUSH_STATE_END;
        fetchDataThreads.forEach(fetchT->{
            while (!fetchT.isDone){
                try {
                    Thread.sleep(10000);
                } catch (InterruptedException e) {
                    log.error("FullTask.indexDone:全量同步停止service异常", e);
                }
            }
        });
        //通知indexing全量完成
        fullTask.getClientManager().doneIndex(fullTask.getPluginConfig().getIndexId(), fullTask.fullTaskEntity.getIndexName(), fullTask.taskMoniter.getFullTaskIsok());
    }

    /**
     *开启全量抓取线程
     */
    public void startDoIndex() {
        try {
            //获取当前数据范围
            List<DataRange> dataRanges = this.getDataRange();
            if (CollectionUtils.isEmpty(dataRanges)) {
                return;
            }
            // 开启多线程，抓取数据进行全量同步
            downLatch = new CountDownLatch(dataRanges.size());
            for (int i = 0; i < dataRanges.size(); i++) {
                FetchDataThread thread = new FetchDataThread(dataRanges.get(i), i);
                thread.start();
                fetchDataThreads.add(thread);
            }
            //全量抓取任务完成
            downLatch.await();
        }catch (Exception e){
            this.putAllState = IConstant.FULL_PUSH_STATE_EXCEPTION;
            log.error("AbstractFullIndexService.run:全量同步失败", e);
            throw new BizException(CodeEnum.CODE_210002005.getCode(), CodeEnum.CODE_210002005.getMsg());
        }
    }

    /**
     * 抓取数据及添加索引
     */
    class FetchDataThread extends Thread {
        private DataRange dataRange;
        boolean isDone = false;

        public FetchDataThread(DataRange dataRange, int index) {
            this.setName("FetchThread-" + getFullTask().getPluginConfig().getIndexId() + "_" + index);
            this.dataRange = dataRange;
            log.info("FetchDataThread.FetchDataThread:开启全量同步线程，区间为{}，{}", dataRange.getIntMin(), dataRange.getMax());
        }

        @Override
        public void run() {
            List<Map<String, Object>> indexDataList = new ArrayList<>();
            try {
                long currentId = dataRange.getMin() -1;
                startTime = System.currentTimeMillis();
                while(!isDone){
                    //抓取数据
                    List<Map<String, Object>> queryList = fetchDataDb(new DataRange(currentId, dataRange.getMax()));
                    //若数据已经处理完，则该线程正常退出循环
                    if (CollectionUtils.isEmpty(queryList)){
                        break;
                    }
                    //获取下次数据
                    currentId = fullTask.fullTaskEntity.getIdValue(queryList.get(queryList.size() - 1));
                    //转换数据
                    List<Map<String, Object>> wrapperResults = transformData(queryList);
                    if (!CollectionUtils.isEmpty(wrapperResults)){
                        fullTask.taskMoniter.incrementTotalCount(queryList.size());
                        fullTask.taskMoniter.setThreadQty(getName(), queryList.size());
                        indexDataList.addAll(wrapperResults);
                    }
                    //推送数据
                    if (fullTask.fullTaskEntity.isNeedPush(indexDataList.size())) {
                        pushToIndex(indexDataList);
                        indexDataList.clear();
                    }
                }
                //剩余未处理的数据写到ES
                pushToIndex(indexDataList);
            } catch (Exception e) {
                //抓取数据异常，则设置PUSH_STATE 为-2， 停止全量抓取操作
                putAllState = IConstant.FULL_PUSH_STATE_EXCEPTION;
                log.error("FetchDataThread.run::处理全量索引异常！{}", e);
                throw new BizException(CodeEnum.CODE_210002005.getCode(), CodeEnum.CODE_210002005.getMsg());
            } finally {
                isDone = true;
                log.info("线程结束：thread:{}; begin:{}; end:{}",
                        new Object[] { this.getName(), dataRange.getMin(), dataRange.getMax()});
                try {
                    downLatch.countDown();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

}

