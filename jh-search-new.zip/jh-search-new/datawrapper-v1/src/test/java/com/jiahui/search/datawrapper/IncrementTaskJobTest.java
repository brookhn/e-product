//package com.jiahui.search.datawrapper;
//
//import com.jiahui.search.DataWrapperApp;
//import com.jiahui.search.datawrapper.core.increment.IncrementTaskJob;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.test.context.junit4.SpringRunner;
//
//@RunWith(SpringRunner.class)
//@SpringBootTest(classes = {DataWrapperApp.class})
//public class IncrementTaskJobTest {
//
//    @Autowired
//    private IncrementTaskJob incrementTaskJob;
//
//    @Test
//    public void testDoTask() {
//        incrementTaskJob.doTask();
//    }
//
//
//}
