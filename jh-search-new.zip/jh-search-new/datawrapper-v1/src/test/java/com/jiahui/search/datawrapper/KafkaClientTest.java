//package com.jiahui.search.datawrapper;
//
//import cn.hutool.core.date.DateUtil;
//import org.apache.kafka.clients.consumer.ConsumerRecord;
//import org.apache.kafka.clients.consumer.ConsumerRecords;
//import org.apache.kafka.clients.consumer.KafkaConsumer;
//import org.apache.kafka.clients.producer.KafkaProducer;
//import org.apache.kafka.clients.producer.ProducerRecord;
//import org.apache.kafka.common.serialization.StringDeserializer;
//
//import java.text.SimpleDateFormat;
//import java.time.LocalDateTime;
//import java.util.ArrayList;
//import java.util.Date;
//import java.util.List;
//import java.util.Properties;
//import java.util.concurrent.ExecutionException;
//import java.util.logging.SimpleFormatter;
//
//public class KafkaClientTest {
//
//
//    public static void main(String[] args) {
////        List<String> topic = new ArrayList<>();
////        topic.add("order_info");
////        Properties props = new Properties();
////        props.put("bootstrap.servers", "jih-kafka01-test.jihint.com:9092,jih-kafka02-test.jihint.com:9092,jih-kafka03-test.jihint.com:9092");
////        props.put("group.id", "canal-consumer1");
////        props.put("enable.auto.commit", "true");
////        props.put("auto.commit.interval.ms", "1000");
////        props.put("session.timeout.ms", "30000");
////        props.put("max.poll.records", 1000);
////        props.put("auto.offset.reset", "latest");
////        props.put("key.deserializer", StringDeserializer.class.getName());
////        props.put("value.deserializer", StringDeserializer.class.getName());
////        KafkaConsumer<String, String> consumer = new KafkaConsumer<String, String>(props);
////        consumer.subscribe(topic);
////
////        KafkaProducer<String, String> producer = new KafkaProducer<String, String>(props);
////        ProducerRecord<String, String> record = new ProducerRecord<>("", "");
////        try {
////            producer.send(record).get();
////        } catch (InterruptedException e) {
////            e.printStackTrace();
////        } catch (ExecutionException e) {
////            e.printStackTrace();
////        }
//
//        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
//
//        Date date = DateUtil.parse(formatter.format(new Date()));
//        System.out.println(date.getTime());
//
//
//
////        while (true) {
////            ConsumerRecords<String, String> msgList = consumer.poll(1000);
////            List<Map> list = Lists.newArrayList();
////            for (ConsumerRecord<String, String> record : msgList) {
////                Map<String, Object> map = JsonUtil.parseMap(record.value());
////                list.add(map);
////            }
////
////            List<Map> myList = list.stream().distinct().collect(Collectors.toList());
////            System.out.println(myList);
////
////        }
//    }
//}
