package com.jiahui.search.searcher.api.module;


import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;
import java.util.Map;

/**
 * 查询结果
 *
 */
public class QueryResponse extends AbstractQueryResponse {

    public QueryResponse() {
    }

    @JsonProperty("hits")
    @ApiModelProperty(value = "result data")
    private List<HitItem> hits;

    @JsonProperty("aggs")
    @ApiModelProperty(value = "aggs result data")
    private Map<String, Object> aggs;

    public List<HitItem> getHits() {
        return hits;
    }

    public void setHits(List<HitItem> hits) {
        this.hits = hits;
    }

    public Map<String, Object> getAggs() {
        return aggs;
    }

    public void setAggs(Map<String, Object> aggs) {
        this.aggs = aggs;
    }
}
