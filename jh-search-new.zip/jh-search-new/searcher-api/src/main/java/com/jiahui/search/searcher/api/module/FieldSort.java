package com.jiahui.search.searcher.api.module;

import org.elasticsearch.search.sort.SortOrder;

public class FieldSort {

    private String field;

    private SortOrder sortOrder;

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public SortOrder getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(SortOrder sortOrder) {
        this.sortOrder = sortOrder;
    }
}
