package com.jiahui.search.searcher.api.module;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.Objects;

/**
 * 请求
 *
 * @author ivy.wang
 */
public abstract class AbstractQueryRequest {

    @JsonIgnore
    protected SearchSourceBuilder sourceBuilder;

    protected String sourceBuilderStr;

    @NotBlank
    @JsonProperty("appKey")
    @ApiModelProperty(value = "Appkey can't be null")
    private String appKey;

    @NotBlank
    @JsonProperty("indexName")
    @ApiModelProperty(value = "IndexName can't be null")
    private String indexName;

    @JsonIgnore
    @JsonProperty("queryBuilder")
    @ApiModelProperty(value = "QueryBuilder")
    private BoolQueryBuilder boolQueryBuilder;

    @NotNull
    @JsonProperty("start")
    @Range(min = 0, max = 10000)
    @ApiModelProperty(value = "Start can't be null")
    private Integer start;

    @NotNull
    @JsonProperty("limit")
    @Range(min = 1, max = 10000)
    @ApiModelProperty(value = "Limit can't be null")
    private Integer limit;

    @JsonProperty("sortFields")
    @ApiModelProperty(value = "if sortFields is null,result will sort by _score")
    private List<FieldSort> sortFields;

    @JsonProperty("returnFields")
    @ApiModelProperty(value = "if returnFields is null,result will reutrn all source fields")
    private List<String> returnFields;

    @JsonProperty("highLightFields")
    @ApiModelProperty(value = "High light fields")
    private List<String> highLightFields;

    public List<String> getHighLightFields() {
        return highLightFields;
    }

    public void setHighLightFields(List<String> highLightFields) {
        this.highLightFields = highLightFields;
    }

    public String getAppKey() {
        return appKey;
    }

    public String getIndexName() {
        return indexName;
    }

    protected BoolQueryBuilder getBoolQueryBuilder() {
        return boolQueryBuilder;
    }

    public Integer getStart() {
        return start;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setAppKey(String appKey) {
        this.appKey = appKey;
    }

    public void setIndexName(String indexName) {
        this.indexName = indexName;
    }

    public void setBoolQueryBuilder(BoolQueryBuilder boolQueryBuilder) {
        if(Objects.nonNull(boolQueryBuilder)) {
           sourceBuilder.query(boolQueryBuilder);
        }
        this.boolQueryBuilder = boolQueryBuilder;
    }

    public void setStart(Integer start) {
        this.start = start;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public List<FieldSort> getSortFields() {
        return sortFields;
    }

    public void setSortFields(List<FieldSort> sortFields) {
        this.sortFields = sortFields;
    }

    public List<String> getReturnFields() {
        return returnFields;
    }

    public void setReturnFields(List<String> returnFields) {
        this.returnFields = returnFields;
    }

    public AbstractQueryRequest(){
        sourceBuilder = new SearchSourceBuilder();
    }

    public String getSourceBuilderStr() {
        if(StringUtils.isEmpty(sourceBuilderStr)) {
            return sourceBuilder.toString();
        }
        return sourceBuilderStr;
    }

}
