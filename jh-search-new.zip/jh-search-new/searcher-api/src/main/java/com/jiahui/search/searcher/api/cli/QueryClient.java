package com.jiahui.search.searcher.api.cli;

import com.jiahui.search.common.rest.JsonResult;
import com.jiahui.search.searcher.api.module.QueryRequest;
import com.jiahui.search.searcher.api.module.QueryResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 *  查询
 *
 * @author ivy.jingjingwang
 */
@FeignClient( value = "searcher-service", url = "${feign.url.searcher:#{searcher-service}}")
public interface QueryClient {

  @PostMapping(path = "/searcher/search", headers = {"Content-Type=application/json;charset=UTF-8"})
  JsonResult<QueryResponse> search(@RequestBody QueryRequest body);

}