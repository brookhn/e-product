package com.jiahui.search.searcher.api.module;


import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;

import java.util.Map;

/**
 * 查询结果
 *
 */
public class HitItem  {

    public HitItem() {
    }

    @JsonProperty("id")
    @ApiModelProperty(value = "index id")
    private String id;

    @JsonProperty("params")
    @ApiModelProperty(value = "result map")
    private Map<String, Object> params;

    @JsonProperty("highlights")
    @ApiModelProperty(value = "highlights param")
    private Map<String, String> highlights;

    public HitItem(String id, Map<String, Object> sourceAsMap) {
        this.id = id;
        this.params = sourceAsMap;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Map<String, Object> getParams() {
        return params;
    }

    public void setParams(Map<String, Object> params) {
        this.params = params;
    }

    public Map<String, String> getHighlights() {
        return highlights;
    }

    public void setHighlights(Map<String, String> highlights) {
        this.highlights = highlights;
    }
}
