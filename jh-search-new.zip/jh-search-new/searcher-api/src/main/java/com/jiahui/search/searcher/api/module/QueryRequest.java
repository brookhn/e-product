package com.jiahui.search.searcher.api.module;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import org.elasticsearch.search.aggregations.AbstractAggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.terms.TermsAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.AvgAggregationBuilder;

import javax.validation.constraints.NotNull;
import java.util.Objects;

/**
 * @Description 聚合请求参数
 * @Author Garen
 * @Date 2022/2/9 10:58
 */
public class QueryRequest extends AbstractQueryRequest {

    @JsonIgnore
    @JsonProperty("aggregationBuilder")
    @ApiModelProperty(value = "Available aggregation methods：TermsAggregationBuilder/SumAggregationBuilder/MaxAggregationBuilder/MinAggregationBuilder")
    private AggregationBuilder aggregationBuilder;

    protected AggregationBuilder getAggregationBuilder() {
        return aggregationBuilder;
    }

    public void setAggregationBuilder(AggregationBuilder aggregationBuilder) {
        if(Objects.nonNull(aggregationBuilder)) {
            sourceBuilder.aggregation(aggregationBuilder);
        }
        this.aggregationBuilder = aggregationBuilder;
    }
}
