package com.jh.wrappertest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DataWrapperTestApp {


    public static void main(String[] args) {
        SpringApplication.run(DataWrapperTestApp.class, args);
    }
}
