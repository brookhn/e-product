package com.jh.wrappertest.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;

@Service
public class BatchInserServiceImpl implements IBathInserService {


    String insertSql = "insert into fullsync_info (`product_id`,`product_name`, `product_num`,`user_id`, `create_time`, `update_time`) VALUES ('345', 'test', 123, 123, now(), now())," +
            "('456', 'test', 123, 123, now(), now()), ('789', 'test', 123, 123, now(), now())," +
            " ('1012', 'test', 123, 123, now(), now()), ('10523', 'test', 123, 123, now(), now()), " +
            " ('10524', 'test', 123, 123, now(), now()), ('10526', 'test', 123, 123, now(), now())," +
            " ('105289', 'test', 123, 123, now(), now()), ('134289', 'test', 123, 123, now(), now()), " +
            "('135689', 'test', 123, 123, now(), now()), ('135689', 'test', 123, 123, now(), now()), " +
            "('456510', 'test', 123, 123, now(), now()),('4565789', 'test', 123, 123, now(), now()), " +
            "('456565', 'test', 123, 123, now(), now()), ('456566', 'test', 123, 123, now(), now()), " +
            "('456567', 'test', 123, 123, now(), now())" +
            ",('456568', 'test', 123, 123, now(), now()) , ('456569', 'test', 123, 123, now(), now())" +
            ",('4554646', 'test', 123, 123, now(), now()) , ('56423467', 'test', 123, 123, now(), now())"+
            ",('34567', 'test', 123, 123, now(), now()) , ('34568', 'test', 123, 123, now(), now())," +
            "('34569', 'test', 123, 123, now(), now()) , ('345610', 'test', 123, 123, now(), now())"+
            ",('345614', 'test', 123, 123, now(), now()) , ('345613', 'test', 123, 123, now(), now())," +
            "('345612', 'test', 123, 123, now(), now()) , ('345611', 'test', 123, 123, now(), now()),"+
            "('456565', 'test', 123, 123, now(), now()), ('456566', 'test', 123, 123, now(), now())," +
            " ('456567', 'test', 123, 123, now(), now())" +
            ",('8954456', 'test', 123, 123, now(), now()) , ('895467', 'test', 123, 123, now(), now())," +
            "('89547', 'test', 123, 123, now(), now()) , ('89544', 'test', 123, 123, now(), now())"+
            ",('89544545', 'test', 123, 123, now(), now()) , ('895445445', 'test', 123, 123, now(), now())," +
            "('89544345', 'test', 123, 123, now(), now()) , ('89544879', 'test', 123, 123, now(), now())"+
            ",('89544544450', 'test', 123, 123, now(), now()) , ('895445453789', 'test', 123, 123, now(), now())," +
            "('43456789', 'test', 123, 123, now(), now()) , ('3459897611', 'test', 123, 123, now(), now())";

    String updateSql = "update fullsync_info ";

    @Autowired
    DataSource dataSource;

    boolean isStop = false;

    private static JdbcTemplate jdbcTemplate = null;

    public  JdbcTemplate getJdbcTemplate(){
        synchronized (this){
            if (null == jdbcTemplate){
                return new JdbcTemplate(dataSource);
            }
            return jdbcTemplate;
        }
    }

    @Override
    public void stopBatch() {
        this.isStop = true;
    }

    @Override
    public void batchInsert() throws InterruptedException {
        long totalSize = 20000000;
        long incrementTimes  = 0;
        long lastBatchInsertTime = 0;
        long beginS = System.currentTimeMillis();
        while (true) {
            if (isStop){
                return;
            }
            getJdbcTemplate().batchUpdate(insertSql);
            totalSize-=10;
            if (totalSize < 0){
                System.out.println("data write ok!");
            }
            System.out.println("dataWriteSize: " + incrementTimes++ +" time: "+ (System.currentTimeMillis() - beginS) +" executeTimeSpan: "
                    + (System.currentTimeMillis() - lastBatchInsertTime));
            lastBatchInsertTime = System.currentTimeMillis();
            Thread.sleep(5);
        }
    }

    @Override
    public void switchInsertAndUpdate() {

    }
}
