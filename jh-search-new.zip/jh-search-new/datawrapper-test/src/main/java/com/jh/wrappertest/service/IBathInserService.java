package com.jh.wrappertest.service;

public interface IBathInserService {

    public void stopBatch();

    public void batchInsert() throws InterruptedException;

    public void switchInsertAndUpdate();
}
