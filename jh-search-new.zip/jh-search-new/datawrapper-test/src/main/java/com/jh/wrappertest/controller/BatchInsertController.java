package com.jh.wrappertest.controller;

import com.jh.wrappertest.service.IBathInserService;
import com.jiahui.search.common.enums.CodeEnum;
import com.jiahui.search.common.exception.BizException;
import com.jiahui.search.common.rest.JsonResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@Order(-1)
@RestController
public class BatchInsertController {

    @Autowired
    private IBathInserService bathInserService;

    /**
     * 开启全量同步
     * @param indexId
     * @return
     */
    @GetMapping("/fullSyncStart")
    public JsonResult startFullTask(String indexId){
        try {
            bathInserService.batchInsert();
        } catch (Exception e){
            e.printStackTrace();
        }
        return JsonResult.successWithCode(CodeEnum.SUCCESS);
    }

    public JsonResult stopFullTask(){
        bathInserService.stopBatch();
        return JsonResult.successWithCode(CodeEnum.SUCCESS);
    }
}
