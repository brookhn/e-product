package com.jiahui.search.datawrapper.plugin;

import com.jiahui.search.datawrapper.api.DataWrapperHandler;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.util.CollectionUtils;
import com.jiahui.search.datawrapper.api.entity.*;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class AccountInfoDataWrapper extends DataWrapperHandler {

    private String userInfo_sql = "select id,email,name from user_info where id= ? ";

    private String accountInfo_sql = "select id_number from account_info where id = ? ";

    @Override
    public Long getIndexId() {
        return 3L;
    }

    @Override
    public WrapperResult fullSyncDataWrap(Map<String, Object> value) {
        return new WrapperResult(value);
    }

    @Override
    public WrapperResult fullSyncDataWrap(List<Map<String, Object>> values) {
        return new WrapperResult(values);
    }

    /**
     * 多表关联一个索引测试
     *
     * @param record
     * @return
     */
    @Override
    public WrapperResult incrementSyncDataWrap(Map<String, Object> record) {
        String dataKey = record.get("opt").equals("DELETE") ? "oldRow" : "row";
        Map<String, Object> rowData = JsonUtil.parseObject(JsonUtil.serialize(record.get(dataKey)), Map.class);
        String tableName = (String) record.get("tableName");

        JdbcTemplate jdbcTemplate = getJdbcTemplateByDbName("canal_test");
        if (tableName.equals("user_info")) {
            if (Objects.nonNull(rowData.get("account_id"))) {
                Long accountId = Long.parseLong(rowData.get("account_id").toString());
                List<Account> accounts = jdbcTemplate.query(accountInfo_sql, new BeanPropertyRowMapper<>(Account.class), new Object[]{accountId});
                if (!CollectionUtils.isEmpty(accounts)) {
                    Account account = accounts.get(0);
                    rowData.remove("create_time");
                    rowData.remove("account_id");
                    rowData.put("id_number", account.getId_number());
                }
            }
        } else if (tableName.equals("account_info")) {
            Long userId = Long.parseLong(rowData.get("user_id").toString());
            List<User> users = jdbcTemplate.query(userInfo_sql, new BeanPropertyRowMapper<>(User.class), new Object[]{userId});
            if (!CollectionUtils.isEmpty(users)) {
                User user = users.get(0);
                rowData.remove("create_time");
                rowData.remove("update_time");
                rowData.remove("id");
                rowData.remove("password");
                rowData.remove("user_id");

                rowData.put("id", user.getId());
                rowData.put("email", user.getEmail());
                rowData.put("name", user.getName());
            }
        }
        return new WrapperResult(rowData);
    }
}
