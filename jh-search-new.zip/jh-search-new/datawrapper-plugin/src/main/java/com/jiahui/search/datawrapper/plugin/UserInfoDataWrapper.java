package com.jiahui.search.datawrapper.plugin;

import com.jiahui.search.datawrapper.api.DataWrapperHandler;
import com.jiahui.search.datawrapper.api.entity.*;

import java.util.List;
import java.util.Map;

public class UserInfoDataWrapper extends DataWrapperHandler {


    @Override
    public Long getIndexId() {
        return 2L;
    }

    @Override
    public WrapperResult fullSyncDataWrap(Map<String, Object> value) {
        return new WrapperResult(value);
    }

    @Override
    public WrapperResult fullSyncDataWrap(List<Map<String, Object>> values) {
        return new WrapperResult(values);
    }

    private String sql = "select account,name,identification,mail,phone,dingTalk from tb_user where id= ? ";

    @Override
    public WrapperResult incrementSyncDataWrap(Map<String, Object> record) {

        String dataKey = record.get("opt").equals("DELETE") ? "old_row" : "row";
        Map<String, Object> rowData = JsonUtil.parseObject(JsonUtil.serialize(record.get(dataKey)), Map.class);
//        rowData.put("user_name", rowData.get("name"));
//        rowData.remove("name");

//        Long userId = Long.parseLong(rowData.get("id").toString());
//        JdbcTemplate jdbcTemplate = getJdbcTemplateByDbName("alarm");
//        List<User> list = jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(User.class), new Object[]{userId});
//        if (!CollectionUtils.isEmpty(list)) {
//            rowData.put("account", list.get(0).getAccount());
//            rowData.put("name", list.get(0).getName());
//            rowData.put("mail", list.get(0).getMail());
//            rowData.put("phone", list.get(0).getPhone());
//            rowData.put("dingTalk", list.get(0).getDingTalk());
//        }
        return new WrapperResult(rowData);
    }
}
