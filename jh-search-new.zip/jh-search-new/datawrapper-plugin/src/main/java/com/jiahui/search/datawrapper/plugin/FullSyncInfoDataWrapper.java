package com.jiahui.search.datawrapper.plugin;

import com.jiahui.search.datawrapper.api.DataWrapperHandler;
import com.jiahui.search.datawrapper.api.entity.WrapperResult;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;
import java.util.Map;

public class FullSyncInfoDataWrapper extends DataWrapperHandler {

    @Override
    public Long getIndexId() {
        return 9L;
    }

    @Override
    public WrapperResult fullSyncDataWrap(Map<String, Object> value) {
        return new WrapperResult(value);
    }

    @Override
    public WrapperResult fullSyncDataWrap(List<Map<String, Object>> values) {
        return new WrapperResult(values);
    }


    @Override
    public WrapperResult incrementSyncDataWrap(Map<String, Object> record) {
        String dataKey = record.get("opt").equals("DELETE") ? "oldRow" : "row";
        Map<String, Object> rowData = JsonUtil.parseObject(JsonUtil.serialize(record.get(dataKey)), Map.class);
        if (record.get("opt").equals("DELETE")) {
            return new WrapperResult(rowData);
        }
        JdbcTemplate jdbcTemplate = getJdbcTemplateByDbName("canal_test");
        String sql = "select id,product_id,product_name,product_num,user_id,create_time,update_time from fullsync_info where id= ? ";
        Map<String, Object> user = jdbcTemplate.queryForMap(sql, new Object[]{rowData.get("id")});
        return new WrapperResult(user);
    }
}
