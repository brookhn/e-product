package com.jiahui.search.datawrapper.plugin;

import com.jiahui.search.datawrapper.api.DataWrapperHandler;
import com.jiahui.search.datawrapper.api.entity.*;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;
import java.util.Map;

public class TestDataWrapper extends DataWrapperHandler {
    @Override
    public Long getIndexId() {
        return 1L;
    }

    @Override
    public WrapperResult fullSyncDataWrap(Map<String, Object> value) {
        return new WrapperResult(value);
    }

    @Override
    public WrapperResult fullSyncDataWrap(List<Map<String, Object>> values) {
        return new WrapperResult(values);
    }

    String sql = "select id,account_id,email,name,create_time from user_info where id=?";

    @Override
    public WrapperResult incrementSyncDataWrap(Map<String, Object> record) {
        String dataKey = record.get("opt").equals("DELETE") ? "oldRow" : "row";
        Map<String, Object> rowData = JsonUtil.parseObject(JsonUtil.serialize(record.get(dataKey)), Map.class);

        if (record.get("opt").equals("DELETE")) {
            return new WrapperResult(rowData);
        }
        JdbcTemplate jdbcTemplate = getJdbcTemplateByDbName("canal_test");
        Map<String, Object> user = jdbcTemplate.queryForMap(sql, new Object[]{rowData.get("id")});
//        String id = (String) rowData.get("id");
//        //模拟datawrapper异常
//        if (Long.valueOf(id) % 5 == 0) throw new BizException();
        return new WrapperResult(user);
    }
}
