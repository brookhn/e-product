package com.jiahui.adminconsole.vo.in;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @description 索引字段配置
 * @author peng.wang
 * @date 2022-02-28
 */
@Data
@ApiModel("索引字段配置查询参数")
@EqualsAndHashCode(callSuper=false)
public class IndexFieldConfigIn extends BaseParam {


    /**
    * index_config_id
    */
    @ApiModelProperty("index_config_id")
    private Long indexConfigId;

    /**
    * 字段名称
    */
    @ApiModelProperty("字段名称")
    private String fieldName;

    /**
    * 字段类型
    */
    @ApiModelProperty("字段类型")
    private String fieldType;

    /**
    * index_analyzer
    */
    @ApiModelProperty("index_analyzer")
    private String indexAnalyzer;

    /**
    * 分片数量
    */
    @ApiModelProperty("分片数量")
    private String searchAnalyzer;

    /**
    * 分片副本数
    */
    @ApiModelProperty("分片副本数")
    private int norms;

    /**
    * 默认值
    */
    @ApiModelProperty("默认值")
    private String nullValue;

    /**
    * 0，1
    */
    @ApiModelProperty("0，1")
    private int bizStatus;


    /**
    * 创建人
    */
    @ApiModelProperty("创建人")
    private String createUser;


    /**
    * 更新人
    */
    @ApiModelProperty("更新人")
    private String updateUser;

    public IndexFieldConfigIn() {}
}