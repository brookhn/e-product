package com.jiahui.adminconsole.controller;

import com.alibaba.fastjson.JSON;
import com.jiahui.adminconsole.po.IndexConfig;
import com.jiahui.adminconsole.dto.Result;
import com.jiahui.adminconsole.service.IndexConfigService;
import com.jiahui.adminconsole.util.ResultUtils;
import com.jiahui.adminconsole.vo.in.IndexConfigIn;
import com.jiahui.adminconsole.vo.in.OptionIndexIn;
import com.jiahui.framework.rpc.rest.ResultVO;
import com.jiahui.search.index.manager.contract.*;
import com.jiahui.search.index.writer.rest.contract.FullTaskMoniterResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
* @description index_config控制器
* @author peng.wang
* @date 2022-02-24
*/
@Log4j2
@RestController
@RequestMapping("/indexConfig")
@Api(tags = "索引配置相关接口")
public class IndexConfigController {

    @Autowired
    private IndexConfigService indexConfigService;


      /**
     * 新增
     */
    @PostMapping("/add")
    @ApiOperation("新增索引基础配置")
    public Result add(@RequestBody @Valid IndexConfig indexConfig){
        log.info("add:"+ JSON.toJSONString(indexConfig));
        Result result= (Result)indexConfigService.add(indexConfig);
        return result;
    }
      /**
     * 同步到es
     */
    @PostMapping("/syn2Es")
    @ApiOperation("将索引同步到es")
    public Result syn2Es(@RequestBody @Valid OptionIndexIn in){
        log.info("syn2Es:"+ JSON.toJSONString(in));
        Result result= indexConfigService.syn2Es(in);
        return result;
    }

    @PostMapping(path = "/closeIndex")
    @ApiOperation("关闭索引")
    Result closeIndex(@RequestBody OptionIndexIn in) {
        log.info("syn2Es:"+ JSON.toJSONString(in));
        Result result= indexConfigService.closeIndex(in);
        return result;
    }

    @PostMapping(path = "/deleteIndex")
    @ApiOperation("删除索引")
    Result deleteIndex(@RequestBody OptionIndexIn in) {
        log.info("syn2Es:"+ JSON.toJSONString(in));
        Result result= indexConfigService.deleteIndex(in);
        return result;
    }

    @PostMapping(path = "/openIndex")
    @ApiOperation("打开索引")
    Result openIndex(@RequestBody OptionIndexIn in){
        log.info("syn2Es:"+ JSON.toJSONString(in));
        Result result= indexConfigService.openIndex(in);
        return result;
        
    }

    @PostMapping(path = "/putMapping")
    @ApiOperation("修改索引索引mapping")
    Result putMapping(@RequestBody OptionIndexIn in) {
        log.info("syn2Es:"+ JSON.toJSONString(in));
        Result result= indexConfigService.putMapping(in);
        return result;
    }

    @PostMapping(path = "/startFullTask")
    @ApiOperation("开始全量数据同步任务")
    ResultVO startFullTask(@RequestBody OptionIndexIn in) {
        log.info("startFullTask:"+ JSON.toJSONString(in));
        ResultVO result= indexConfigService.startFullTask(in);
        return result;
    }
    @PostMapping(path = "/stopFullTask")
    @ApiOperation("停止全量同步任务")
    ResultVO stopFullTask(@RequestBody OptionIndexIn in) {
        log.info("停止全量同步任务:"+ JSON.toJSONString(in));
        ResultVO result= indexConfigService.stopFullTask(in);
        return result;
    }
    @PostMapping(path = "/startIncrTask")
    @ApiOperation("开始增量数据任务同步")
    ResultVO startIncrTask(@RequestBody OptionIndexIn in) {
        log.info("开始增量数据任务同步:"+ JSON.toJSONString(in));
        ResultVO result= indexConfigService.startIncrTask(in);
        return result;
    }
    @GetMapping(path = "/getRunningMap")
    @ApiOperation("查看正在运行的任务列表")
    ResultVO getRunningMap() {
        log.info("查看正在运行的任务列表:");
        ResultVO result= indexConfigService.getRunningMap();
        return result;
    }
    @GetMapping(path = "/getTaskRunActuator")
    @ApiOperation("查看任务监控开始")
    ResultVO<FullTaskMoniterResponse> getTaskRunActuator(){
        log.info("查看任务监控开始");
        ResultVO result= indexConfigService.getTaskRunActuator();
        return result;
    };

     @PostMapping("/edit")
     @ApiOperation("编辑索引配置")
     public Result edit(@RequestBody @Valid IndexConfig indexConfig){

         Result result= (Result)indexConfigService.edit(indexConfig);
        return result;
        }

    /**
    * 删除
    */
     @RequestMapping(value = "/delete/{id}", method = RequestMethod.GET)
    @ApiOperation("删除")
    public Result delete(@PathVariable("id") int id){
            indexConfigService.deleteById(id);
            return ResultUtils.success("删除成功");
    }

    /**
    * 查询详情
    */
   @RequestMapping(value = "detail/{id}", method = RequestMethod.GET)
   @ApiOperation("查询索引配置详情")
    public Result selectOne(@PathVariable("id") int id){
    Result info = indexConfigService.selectOne(id);
            return info;
    }

    /**
    * 自动分页查询
    */
    @PostMapping("/pagelist")
    @ApiOperation("分页查询索引配置")
    public Result pageList(@RequestBody IndexConfigIn param) {
        log.info("分页查询开始:"+ JSON.toJSONString(param));

        Object pageList = indexConfigService.pageList(param);
        //返回结果
        return ResultUtils.success(pageList);
    }

    /**
    * 根据条件查询列表
    */
    @PostMapping("/list")
    @ApiOperation("根据条件查询索引配置列表")
    public Result list(@RequestBody  IndexConfigIn param) {
        log.info("index_config 列表查询"+ JSON.toJSONString(param));

        Object pageList = indexConfigService.list(param);
        //返回结果
        return ResultUtils.success(pageList);
    }

}