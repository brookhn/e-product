package com.jiahui.adminconsole.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.jiahui.adminconsole.dto.Result;
import com.jiahui.adminconsole.po.IndexFieldConfig;
import com.jiahui.adminconsole.vo.in.IndexFieldConfigIn;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @description 索引字段配置服务层
 * @author peng.wang
 * @date 2022-02-28
 */
@Service
public interface IndexFieldConfigService  {

 /**
    * 新增
    */
    public Result add(IndexFieldConfig indexFieldConfig);


    /**
    * 删除
    */
    public Result deleteById(int id);



    /**
    * 编辑
    */
    public Result edit(IndexFieldConfig  indexFieldConfig);


    /**
    * 查询详情
    */
    public Result selectOne(int id);

    /**
    * 自动分页查询
    */
    public IPage pageList(IndexFieldConfigIn param);
    /**
    * 条件列表查询
    */
    public List list(IndexFieldConfigIn param);





}