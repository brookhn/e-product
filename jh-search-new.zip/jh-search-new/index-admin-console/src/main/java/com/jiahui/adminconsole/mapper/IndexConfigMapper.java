package com.jiahui.adminconsole.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiahui.adminconsole.po.IndexConfig;
import org.apache.ibatis.annotations.Mapper;

/**
 * @description index_configMapper
 * @author peng.wang
 * @date 2022-02-24
 */
@Mapper
public interface IndexConfigMapper extends BaseMapper<IndexConfig> {



}