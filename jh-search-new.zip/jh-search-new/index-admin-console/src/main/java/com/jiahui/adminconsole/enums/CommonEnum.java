package com.jiahui.adminconsole.enums;

/**

@version 1.0.0
@description 公共枚举接口
*/
public interface CommonEnum {
Number getCode();
String getMessage();
}