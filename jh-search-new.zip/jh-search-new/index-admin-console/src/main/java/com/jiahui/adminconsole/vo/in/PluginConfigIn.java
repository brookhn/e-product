package com.jiahui.adminconsole.vo.in;

import com.alibaba.excel.annotation.ExcelProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.util.Date;

/**
 * @description plugin_config
 * @author peng.wang
 * @date 2022-03-03
 */
@Data
@ApiModel("插件配置")
@EqualsAndHashCode(callSuper=false)
public class PluginConfigIn extends BaseParam {

    private static final long serialVersionUID = 1L;


    /**
    * 索引id
    */
    @ApiModelProperty("索引id")
    @ExcelProperty(value="索引id" )
    private Long indexId;

    /**
    * 全量同步sql
    */
    @ApiModelProperty("全量同步sql")
    @ExcelProperty(value="全量同步sql" )
    private String fullSyncSql;

    /**
    * 全量同步range sql
    */
    @ApiModelProperty("全量同步range sql")
    @ExcelProperty(value="全量同步range sql" )
    private String fullSyncRangeSql;

    /**
    * 全量同步配置
    */
    @ApiModelProperty("全量同步配置")
    @ExcelProperty(value="全量同步配置" )
    private String fullSyncConfig;

    /**
    * 全量查询数据源名称
    */
    @ApiModelProperty("全量查询数据源名称")
    @ExcelProperty(value="全量查询数据源名称" )
    private String fullSyncDbName;

    /**
    * 增量同步配置
    */
    @ApiModelProperty("增量同步配置")
    @ExcelProperty(value="增量同步配置" )
    private String incrSyncConfig;

    /**
    * 增量datawrapper需使用的数据源名称
    */
    @ApiModelProperty("增量datawrapper需使用的数据源名称")
    @ExcelProperty(value="增量datawrapper需使用的数据源名称" )
    private String incrSyncDbNames;

    /**
    * 增量同步类型 1-kafka
    */
    @ApiModelProperty("增量同步类型 1-kafka")
    @ExcelProperty(value="增量同步类型 1-kafka" )
    private int incrSyncType;

    /**
    * 同步任务主键
    */
    @ApiModelProperty("同步任务主键")
    @ExcelProperty(value="同步任务主键" )
    private String idFieldName;

    /**
    * wrapper jar 地址
    */
    @ApiModelProperty("wrapper jar 地址")
    @ExcelProperty(value="wrapper jar 地址" )
    private String wrapperJarUrl;

    /**
    * wrapper 类全限定名
    */
    @ApiModelProperty("wrapper 类全限定名")
    @ExcelProperty(value="wrapper 类全限定名" )
    private String wrapperClass;

    /**
    * 状态 1：启用 0：停用
    */
    @ApiModelProperty("状态 1：启用 0：停用")
    @ExcelProperty(value="状态 1：启用 0：停用" )
    private int status;

    /**
    * 创建时间
    */
    @ApiModelProperty("创建时间")
    @ExcelProperty(value="创建时间" )
    private Date createTime;

    /**
    * 创建人
    */
    @ApiModelProperty("创建人")
    @ExcelProperty(value="创建人" )
    private String createUser;

    /**
    * 更新时间
    */
    @ApiModelProperty("更新时间")
    @ExcelProperty(value="更新时间" )
    private Date updateTime;

    /**
    * 更新人
    */
    @ApiModelProperty("更新人")
    @ExcelProperty(value="更新人" )
    private String updateUser;

    public PluginConfigIn() {}
}