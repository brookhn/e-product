package com.jiahui.adminconsole.service.impl;

import cn.hutool.core.util.ObjectUtil;
import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jiahui.adminconsole.po.IndexConfig;
import com.jiahui.adminconsole.dto.Result;
import com.jiahui.adminconsole.mapper.IndexConfigMapper;
import com.jiahui.adminconsole.service.IndexConfigService;
import com.jiahui.adminconsole.util.LongIdUtils;
import com.jiahui.adminconsole.util.ResultUtils;
import com.jiahui.adminconsole.vo.in.IndexConfigIn;
import com.jiahui.adminconsole.vo.in.OptionIndexIn;
import com.jiahui.framework.rpc.rest.ResultVO;
import com.jiahui.search.index.manager.contract.*;
import com.jiahui.search.index.manager.contract.client.IndexManagerClient;
import com.jiahui.search.index.writer.rest.contract.*;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.util.List;

/**
 * @description index_config服务层
 * @author peng.wang
 * @date 2022-02-24
 */
@Service
@Log4j2
public class IndexConfigServiceImpl implements IndexConfigService {


    @Autowired
    private IndexConfigMapper indexConfigMapper;

    @Autowired
    private IndexManagerClient indexManagerClient;
    @Autowired
    private com.jiahui.search.index.writer.rest.contract.DataWrapperRestClient dataWrapperRestClient;

    /**
    * 新增
    */
    @Override
    public Result add(IndexConfig indexConfig){

   log.info("indexConfig:"+ JSON.toJSONString(indexConfig));
   QueryWrapper queryWrapper= new QueryWrapper();
    //数据重复校验逻辑
   queryWrapper.eq("index_name",indexConfig.getIndexName());
     List<IndexConfig> oldInfos = indexConfigMapper.selectList(queryWrapper);
    if(CollectionUtils.isNotEmpty(oldInfos)){
    return ResultUtils.error("索引名称重复");
    }else {
        Long cid=LongIdUtils.elfHash(indexConfig.getIndexName());
        if(indexConfig.getId()==null){
            indexConfig.setId(cid);
        }
        //本地落库
         indexConfigMapper.insert(indexConfig);
        log.info("新增索引完成.....~");
    }
    return ResultUtils.success("保存成功");
    }


    @Override
    public Result syn2Es(OptionIndexIn in) {
        IndexConfig indexConfig = indexConfigMapper.selectById(in.getId());
        if(ObjectUtil.isNull(indexConfig)){
            return  ResultUtils.error("要同步的索引不存在!");
        }
        CreateIndexRequestType requestType=new CreateIndexRequestType();
        requestType.setIndexConfigId(in.getId());
        System.out.println("获取的索引ID为:"+requestType.getIndexConfigId());
        ResultVO<CreateIndexResponseType> index = indexManagerClient.createIndex(requestType);
        return ResultUtils.success("同步索引成功!");
    }

    @Override
    public Result closeIndex(OptionIndexIn in) {
        CloseIndexRequestType requestType=new CloseIndexRequestType();
        requestType.setIndexConfigId(in.getId());
        ResultVO<CloseIndexResponseType> index = indexManagerClient.closeIndex(requestType);
        return ResultUtils.success("关闭成功");
    }

    @Override
    public Result deleteIndex(OptionIndexIn in) {

        IndexConfig indexConfig=new IndexConfig();
        indexConfig.setId(in.getId());
        indexConfig.setBizStatus(0);
        //逻辑删除
        indexConfigMapper.updateById(indexConfig);
        DeleteIndexRequestType requestType=new DeleteIndexRequestType();
        requestType.setIndexConfigId(in.getId());
        ResultVO<DeleteIndexResponseType> index = indexManagerClient.deleteIndex(requestType);
        return ResultUtils.success("删除成功");
    }

    @Override
    public Result openIndex(OptionIndexIn in) {
        OpenIndexRequestType requestType=new OpenIndexRequestType();
        requestType.setIndexConfigId(in.getId());
        ResultVO<OpenIndexResponseType> index = indexManagerClient.openIndex(requestType);
        return ResultUtils.success("打开成功");
    }

    @Override
    public Result putMapping(OptionIndexIn in) {
        PutMappingRequestType requestType=new PutMappingRequestType();
        requestType.setIndexConfigId(in.getId());
//        indexManagerClient.createIndex(new URI(""));
        ResultVO<PutMappingResponseType> index = indexManagerClient.putMapping(requestType);
        return ResultUtils.success("修改成功");
    }

    @Override
    public ResultVO startFullTask(OptionIndexIn in) {
        SyncRequest request=new SyncRequest();
        request.setIndexId(in.getId());
        ResultVO<SyncResponse> syncResponseResultVO = dataWrapperRestClient.startFullTask(request);
        return syncResponseResultVO;
    }

    @Override
    public ResultVO stopFullTask(OptionIndexIn in) {
        SyncRequest request=new SyncRequest();
        request.setIndexId(in.getId());
        ResultVO<SyncResponse> syncResponseResultVO = dataWrapperRestClient.stopFullTask(request);
        return syncResponseResultVO;
    }

    @Override
    public ResultVO startIncrTask(OptionIndexIn in) {
        SyncRequest request=new SyncRequest();
        request.setIndexId(in.getId());
        ResultVO<SyncResponse> syncResponseResultVO = dataWrapperRestClient.startIncrementTask(request);
        return syncResponseResultVO;
    }

    @Override
    public ResultVO getRunningMap() {
        ResultVO<WrapperTaskResponse> syncResponseResultVO = dataWrapperRestClient.getRunningMap();
        return syncResponseResultVO;
    }

    @Override
    public ResultVO getTaskRunActuator() {

        ResultVO<FullTaskMoniterResponse> getTaskRunActuator = dataWrapperRestClient.getTaskRunActuator();
        return getTaskRunActuator;
    }

    /**
    * 编辑
    */
    @Override
    public Object edit(IndexConfig indexConfig){

    QueryWrapper queryWrapper= new QueryWrapper();
    //数据重复校验逻辑
   //queryWrapper.eq("indexConfig_name",indexConfig.getindexConfigName());
     List<IndexConfig> oldindexConfigs = indexConfigMapper.selectList(queryWrapper);
    oldindexConfigs.removeIf(e->e.getIndexAlias().equals(indexConfig.getIndexName()));
    if(CollectionUtils.isNotEmpty(oldindexConfigs)){
    return ResultUtils.error("名称重复");
    }else{
    indexConfigMapper.updateById(indexConfig);
    }
    return ResultUtils.success("保存成功");
    }

    /**
    * 删除
    */
    @Override
    public Object deleteById(int id){
       return indexConfigMapper.deleteById(id);
    }

    /**
    * 查询详情
    */
    @Override
    public Result selectOne(int id){
        IndexConfig indexConfig = indexConfigMapper.selectById(id);
                if(indexConfig!=null){
                    return ResultUtils.success(indexConfig);
                }else{
                    return ResultUtils.error("没有找到该对象");
                }
    }


    /**
    * 自动分页查询
    */
    public IPage pageList(IndexConfigIn param) {
        log.info("pageparam:"+ JSON.toJSONString(param));
        //分页构造器
        Page<IndexConfig> buildPage = new Page<IndexConfig>(param.getPageNum(),param.getPageSize());
        //条件构造器
        QueryWrapper<IndexConfig> queryWrapper = new QueryWrapper<IndexConfig>();
        if(null!=param ) {
        IndexConfig info=new IndexConfig();
        BeanUtils.copyProperties(param,info);
        queryWrapper.setEntity(info);
        }
        //执行分页
        IPage<IndexConfig> pageList = indexConfigMapper.selectPage(buildPage, queryWrapper);
        //返回结果
        return pageList;
    }

    /**
     * 条件列表查询
     */
    public List list(IndexConfigIn param) {
            //条件构造器
         QueryWrapper<IndexConfig> queryWrapper = new QueryWrapper<IndexConfig>();
        if(null!=param ) {
        IndexConfig info=new IndexConfig();
        BeanUtils.copyProperties(param,info);
        queryWrapper.setEntity(info);
        }
        //列表查询
        List<IndexConfig> list = indexConfigMapper.selectList(queryWrapper);
            //返回结果
            return list;
            }



}