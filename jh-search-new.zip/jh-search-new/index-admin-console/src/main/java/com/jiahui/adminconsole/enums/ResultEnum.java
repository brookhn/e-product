package com.jiahui.adminconsole.enums;

public enum ResultEnum implements CommonEnum {
SUCCESS(200, "成功"),//成功
UNAUTH_POST(3012, "失败"),
INVALID_TOKEN(401, "登录已过期或者权限发生变更,请重新登录!"),
EXPIRE_TOKEN(4001, "token已过期"),
FAIL_TOKEN(4002, "获取token失败"),
CODE_NULL(4008, "code不存在"),
UNIONID_FAILD(40078, "登录失败,请重新登录!"),
MIS_PASSWORD(4009, "账号或者密码不正确"),
PARAMS_BLANK(4027, "参数不完整"),
NETWORK_EXCEPTION(2004, "网络异常，请稍后重试"),
JSON_ERROR(2005, "external json解析异常"),
SERVICE_EXCEPTION(2006, "ops~系统开小差了，请联系管理员!"),
UN_AUTH(2008, "无此操作权限!") ;
    private Integer code;

private String message;

ResultEnum(Integer code, String message) {
    this.code = code;
    this.message = message;
}


@Override
public Integer getCode() {
    return code;
}


@Override
public String getMessage() {
    return message;
}

}
