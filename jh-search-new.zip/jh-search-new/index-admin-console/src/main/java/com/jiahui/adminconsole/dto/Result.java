package com.jiahui.adminconsole.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel(description = "响应对象")
public class Result<T> {
    @ApiModelProperty(value = "业务码", example = "200", required = true)
    private Integer code;
    @ApiModelProperty(value = "业务码描述", example = "成功", required = true)
    private String msg;
    private String errMsg;
    @ApiModelProperty(value = "业务数据", example = "{}", required = true)
    private T data;
}