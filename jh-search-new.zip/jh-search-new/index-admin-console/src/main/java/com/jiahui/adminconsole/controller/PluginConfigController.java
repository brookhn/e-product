package com.jiahui.adminconsole.controller;

import cn.hutool.core.util.ObjectUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.jiahui.adminconsole.dto.Result;
import com.jiahui.adminconsole.po.PluginConfig;
import com.jiahui.adminconsole.service.PluginConfigService;
import com.jiahui.adminconsole.util.ResultUtils;
import com.jiahui.adminconsole.vo.in.PluginConfigIn;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.log4j.Log4j2;
import org.apache.poi.util.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
* @description 插件配置控制器
* @author peng.wang
* @date 2022-03-03
*/
@Log4j2
@RestController
@RequestMapping("/pluginConfig")
@Api(tags = "插件配置相关接口")
public class PluginConfigController {

    @Autowired
    private PluginConfigService pluginConfigService;


      /**
     * 新增
     */
    @PostMapping("/add")
    @ApiOperation("新增插件配置")
    public Object add(@RequestBody @Valid PluginConfig pluginConfig){
        log.info("add:"+ JSON.toJSONString(pluginConfig));
        Result result= (Result)pluginConfigService.add(pluginConfig);
        return result;
    }

     @PostMapping("/edit")
     @ApiOperation("编辑插件配置")
     public Object edit(@RequestBody @Valid PluginConfig pluginConfig){

         Result result= (Result)pluginConfigService.edit(pluginConfig);
        return result;
        }

    /**
    * 删除
    */
     @RequestMapping(value = "/delete/{id}", method = RequestMethod.GET)
    @ApiOperation("删除")
    public Object delete(@PathVariable("id") int id){
            pluginConfigService.deleteById(id);
            return ResultUtils.success("删除成功");
    }

    /**
    * 查询详情
    */
   @RequestMapping(value = "detail/{id}", method = RequestMethod.GET)
   @ApiOperation("查询插件配置详情")
    public Object selectOne(@PathVariable("id") int id){
    Result info = pluginConfigService.selectOne(id);
            return info;
    }

    /**
    * 自动分页查询
    */
    @PostMapping("/pagelist")
    @ApiOperation("分页查询插件配置")
    public Object pageList(@RequestBody PluginConfigIn param) {
        log.info("分页查询开始:"+ JSON.toJSONString(param));

        Object pageList = pluginConfigService.pageList(param);
        //返回结果
        return ResultUtils.success(pageList);
    }

    /**
    * 根据条件查询列表
    */
    @PostMapping("/list")
    @ApiOperation("根据条件查询插件配置列表")
    public Object list(@RequestBody  PluginConfigIn param) {
        log.info("插件配置 列表查询"+ JSON.toJSONString(param));

        Object pageList = pluginConfigService.list(param);
        //返回结果
        return ResultUtils.success(pageList);
    }

    /**
     * 文件下载（失败了会返回一个有部分数据的Excel）
     * <p>
     * 1. 创建excel对应的实体对象 参照{@link PluginConfig}
     * <p>
     * 2. 设置返回的 参数
     * <p>
     */
    @GetMapping("exporttemplate")
    @ApiOperation(value = "插件配置导出")
    public void exporttemplete(HttpServletResponse response) throws IOException {
        InputStream inputStream = null;
        ServletOutputStream servletOutputStream = null;
        try {
            Resource resource = new DefaultResourceLoader().getResource("classpath:templates/plugintemplate.xlsx");
            response.setContentType("application/force-download");
            response.setHeader("Content-Disposition", "attachment;fileName=" + new String("plugintemplate".getBytes(), StandardCharsets.UTF_8)
                    + ".xlsx");
            inputStream = resource.getInputStream();
            servletOutputStream = response.getOutputStream();
            IOUtils.copy(inputStream, servletOutputStream);
            response.flushBuffer();
        } catch (Exception e) {
//            response.setContentType("");
//            response.setHeader("", "");
            log.error("导出插件配置模板错误", e);
        } finally {
            try {
                if (servletOutputStream != null) {
                    servletOutputStream.close();
                }
                if (inputStream != null) {
                    inputStream.close();
                }
            } catch (Exception e) {
                log.error("导出插件配置模板错误", e);
            }
        }
    }

    /**
     * 导入
     */
    @PostMapping("/import")
    @ApiOperation(value = "插件配置导入")
    public Object importPlugin(MultipartFile file) throws IOException {
        log.info("插件配置导入开始:"+".......~");
        if(ObjectUtil.isNull(file)){
            return  ResultUtils.error("导入excel不能为空");
        }
        return  pluginConfigService.importPlugin(file);

    }

    /**
     * 文件下载（失败了会返回一个有部分数据的Excel）
     * <p>
     * 1. 创建excel对应的实体对象 参照{@link PluginConfigIn}
     * <p>
     * 2. 设置返回的 参数
     * <p>
     */
    @GetMapping("export")
    @ApiOperation(value = "单模版导出")
    public void download(HttpServletResponse response) throws IOException {
        List<PluginConfigIn> records = new ArrayList<>();
        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        response.setCharacterEncoding("utf-8");
        String fileName = URLEncoder.encode("插件配置", "UTF-8").replaceAll("\\+", "%20");
        response.setHeader("Content-disposition", "attachment;filename*=utf-8''" + fileName + ".xlsx");
        EasyExcel.write(response.getOutputStream(), PluginConfigIn.class).sheet("sheet1").doWrite(records);
    }




}