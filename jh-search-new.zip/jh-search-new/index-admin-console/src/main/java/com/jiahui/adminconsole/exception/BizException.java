package com.jiahui.adminconsole.exception;

import com.jiahui.adminconsole.enums.ResultEnum;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.HashMap;

/**
 * @author SQL
 * 业务异常定义
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class BizException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    private Integer code;
    private String msg;
    private String errMsg;
    private Object data;


    public BizException(Integer code, String msg, Object data) {
        this.setCode(code);
        this.setMsg(msg);
        this.setData(data);
    }

    public BizException(Integer code, String msg) {
        this.setCode(code);
        this.setMsg(msg);
        this.setData(new HashMap<>(1));
    }

    public BizException(ResultEnum resultEnum) {
        this.setCode(resultEnum.getCode());
        this.setMsg(resultEnum.getMessage());

    }

    public BizException(ResultEnum resultEnum, String errMsg) {
        this.setCode(resultEnum.getCode());
        this.setMsg(resultEnum.getMessage());
        this.setErrMsg(errMsg);
    }


    public BizException() {
        this.setCode(3002);
        this.setMsg("业务报错!");
    }


}
