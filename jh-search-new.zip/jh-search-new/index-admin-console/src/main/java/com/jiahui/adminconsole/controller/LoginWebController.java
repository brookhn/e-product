package com.jiahui.adminconsole.controller;

import cn.dev33.satoken.secure.SaSecureUtil;
import cn.dev33.satoken.stp.StpUtil;
import com.jiahui.adminconsole.dto.Result;
import com.jiahui.adminconsole.dto.UserInfo;
import com.jiahui.adminconsole.enums.ResultEnum;
import com.jiahui.adminconsole.service.UserInfoService;
import com.jiahui.adminconsole.util.ResultUtils;
import com.jiahui.adminconsole.vo.in.UserIn;
import com.jiahui.adminconsole.vo.out.UserOut;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * Created by peng.wang
 *
 */
@RestController
@Api(tags = "登录相关接口")
@Slf4j
public class LoginWebController {


    @Autowired
    private UserInfoService userInfoService;

    @PostMapping("oauth/login")
    @ApiOperation("登录")
    public Result login(@RequestBody UserIn user){
        String username =user.getUserName();
        String password=user.getPassword();
        if(null==user||StringUtils.isEmpty(user.getUserName())
                ||StringUtils.isEmpty(user.getPassword())){
            return ResultUtils.error(ResultEnum.PARAMS_BLANK);
        }
        UserInfo userInfo=userInfoService.getUserByUserName(username);
        if(null==userInfo){
            return  ResultUtils.error(ResultEnum.MIS_PASSWORD);
        }
        try {
            if(userInfo.getPassword().equals(SaSecureUtil.md5(password)) && userInfo.getUserName().equals(username)) {
                StpUtil.setLoginId(userInfo.getUserId());
                StpUtil.getTokenSession().setAttribute("userName", userInfo.getUserName());
                UserOut out= new UserOut();
                BeanUtils.copyProperties(userInfo,out);
                out.setBaseToken(StpUtil.getTokenValue());
//				sstpInterfaceImpl.getPermissionList(userInfo.getUserId(),null);
                return ResultUtils.success(out);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResultUtils.error(ResultEnum.MIS_PASSWORD);
        }
        return ResultUtils.error(ResultEnum.MIS_PASSWORD);
    }

    @PostMapping("oauth/mnlogin")
    @ApiOperation("模拟登录")
    public Result mnlogin(@RequestParam(required = false) String userId){
        if(StringUtils.isEmpty(userId)){
            userId="peng.wang";
        }
        StpUtil.setLoginId(userId);

        String tokenValue = StpUtil.getTokenValue();
        log.info("*****这里是模拟登录********");
        UserOut out= new UserOut();
        out.setUserName("somebody");
        StpUtil.getTokenSession().setAttribute("userName", out.getUserName());
        out.setUserId(userId);
        out.setBaseToken(tokenValue);
        return ResultUtils.success(out);
    }

}
