package com.jiahui.adminconsole.handler;


import cn.dev33.satoken.exception.NotLoginException;
import com.jiahui.adminconsole.dto.Result;
import com.jiahui.adminconsole.enums.ResultEnum;
import com.jiahui.adminconsole.exception.BizException;
import com.jiahui.adminconsole.util.ResultUtils;
import lombok.extern.log4j.Log4j2;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.NoHandlerFoundException;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import java.util.stream.Collectors;


/**
 * @author peng.wang
 * 全局异常处理
 *
 */
@RestControllerAdvice
@Log4j2
public class RestExceptionHandler {
    @ExceptionHandler(BindException.class)
    public Result methodArgumentNotValidException(BindException e) {

        String message = e.getBindingResult().getAllErrors().stream().map(DefaultMessageSourceResolvable::getDefaultMessage).collect(Collectors.joining());
        return ResultUtils.error(message);
    }

    /**
     * 处理请求参数格式错误 @RequestParam上validate失败后抛出的异常是javax.validation.ConstraintViolationException
     */
    @ExceptionHandler(ConstraintViolationException.class)
    @ResponseBody
    public Result constraintViolationExceptionHandler(ConstraintViolationException e) {
        log.error("@RequestParam 请求参数校验不通过!");
        String message = e.getConstraintViolations().stream().map(ConstraintViolation::getMessage).collect(Collectors.joining("|"));
        return ResultUtils.error(message);
    }

    /**
     * 处理请求参数格式错误 @RequestBody上validate失败后抛出的异常是MethodArgumentNotValidException异常。
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseBody
    public Result methodArgumentNotValidExceptionHandler(MethodArgumentNotValidException e) {
        log.error("@RequestBody 请求参数校验不通过!:{}",e);
        String message = e.getBindingResult().getAllErrors().stream().map(DefaultMessageSourceResolvable::getDefaultMessage).collect(Collectors.joining("|"));
        return ResultUtils.error(message);
    }

    @ExceptionHandler(BizException.class)
    public Result findBizException(BizException ex) {
        log.error("业务异常：{}" + ex);
        return ResultUtils.error(ex.getCode(), ex.getMsg(),ex.getErrMsg());
    }
    @ExceptionHandler(NotLoginException.class)
    public Result findNotLoginException(NotLoginException ex) {
        log.error("登录异常：{}" + ex);
        return ResultUtils.error(ResultEnum.INVALID_TOKEN);
    }

    @ExceptionHandler(NoHandlerFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public Result resultmyhandleNoHandlerFoundException(NoHandlerFoundException ex) {
        log.error("url错误,无对应方法:" + ex.getMessage());
        return ResultUtils.error(ResultEnum.SERVICE_EXCEPTION);
    }
    @ExceptionHandler(MissingServletRequestParameterException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public Result missingServletRequestParameterException(MissingServletRequestParameterException ex) {
        log.error("参数为空校验不通过:" + ex.getMessage());
        return ResultUtils.error(ResultEnum.PARAMS_BLANK);
    }


    @ExceptionHandler(value = {Exception.class})
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public Result unknownException(Exception e) {
        log.error("未知异常：{}" ,e);
        //log.error("未知异常：" + getStackMsg(ex));
        return ResultUtils.error(ResultEnum.SERVICE_EXCEPTION);
    }

    private static String getStackMsg(Exception e) {
        StringBuffer sb = new StringBuffer();
        sb.append(e + "\n");
        StackTraceElement[] stackArray = e.getStackTrace();
        int len = stackArray.length;
        if (len > 2) {
            len = 10;
        }
        for (int i = 0; i < len; i++) {
            StackTraceElement element = stackArray[i];
            sb.append(element.toString() + "\n...");
        }
        return sb.toString();
    }

}

