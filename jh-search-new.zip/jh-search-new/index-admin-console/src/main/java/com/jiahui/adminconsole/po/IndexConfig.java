package com.jiahui.adminconsole.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @description index_config
 * @author peng.wang
 * @date 2022-02-24
 */
@Data
@ApiModel("索引配置")
@TableName("index_config")
public class IndexConfig implements Serializable {

    private static final long serialVersionUID = 1L;
    //如果主键字段不是id 需在主键上加上@TableId
    //Date类型 @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")  @TableField(exist = false)  @JsonIgnore 等可酌情添加

    /**
    * id
    */
    @ApiModelProperty("id")
    @TableId(value = "id",type = IdType.INPUT)
    private Long id;
    /**
    * 索引名称
    */
    @ApiModelProperty("索引名称")
    private String indexName;

    /**
    * 索引别名
    */
    @ApiModelProperty("索引别名")
    private String indexAlias;

    /**
    * refresh_interval
    */
    @ApiModelProperty("refresh_interval")
    private String refreshInterval;

    /**
    * 分片数量
    */
    @ApiModelProperty("分片数量")
    private Integer numberOfShards;

    /**
    * 分片副本数
    */
    @ApiModelProperty("分片副本数")
    private Integer numberOfReplicas;

    /**
    * 索引分片key
    */
    @ApiModelProperty("索引分片key")
    private String indexRouteKeys;

    /**
    * 审核状态 0：待审核 1：审核通过 -1：审核拒绝
    */
    @ApiModelProperty("审核状态 0：待审核 1：审核通过 -1：审核拒绝")
    private int auditStatus;

    /**
    * 审核时间
    */
    @ApiModelProperty("审核时间")
    private Date auditTime;

    /**
    * 同步状态 0-停止 1-开始
    */
    @ApiModelProperty("同步状态 0-停止 1-开始")
    private int bizStatus;


    /**
    * 创建人
    */
    @ApiModelProperty("创建人")
    private String createUser;

    /**
    * 更新时间
    */
    @ApiModelProperty("更新时间")
    private Date updateTime;

    /**
    * 更新人
    */
    @ApiModelProperty("更新人")
    private String updateUser;

    public IndexConfig() {}
}