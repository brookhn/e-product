package com.jiahui.adminconsole.vo.in;

import lombok.Data;

@Data
public class BaseParam {

    public   int pageSize;
    public   int pageNum;
}