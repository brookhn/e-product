package com.jiahui.adminconsole.vo.in;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;

/**
 * @description 应用信息
 * @author peng.wang
 * @date 2022-02-28
 */
@Data
@ApiModel("应用信息查询参数")
@EqualsAndHashCode(callSuper=false)
public class ApplicationIn extends BaseParam {


    /**
     * 应用名
     */
    @ApiModelProperty("应用名")
    private String appName;



    public ApplicationIn() {}
}
