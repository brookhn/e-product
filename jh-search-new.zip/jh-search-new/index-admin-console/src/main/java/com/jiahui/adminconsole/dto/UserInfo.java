package com.jiahui.adminconsole.dto;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @description user_info
 * @author peng.wang
 * @date 2022-02-23
 */
@Data
@TableName("user_info")
public class UserInfo implements Serializable {

    private static final long serialVersionUID = 1L;
    //如果主键字段不是id 需在主键上加上@TableId
    //Date类型 @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")  @TableField(exist = false)  @JsonIgnore 等可酌情添加

    /**
    * 用户id     primary key
    */
    private String userId;

    /**
    * 用户名
    */
    private String userName;

    /**
    * 英文名
    */
    private String enName;

    /**
    * 状态:1正常 0禁用
    */
    private Integer state;

    /**
    * 邮箱
    */
    private String mail;

    /**
    * 密码
    */
    private String password;

    /**
    * 创建时间
    */
    private Date createTime;

    /**
    * update_time
    */
    private Date updateTime;

    public UserInfo() {}
}