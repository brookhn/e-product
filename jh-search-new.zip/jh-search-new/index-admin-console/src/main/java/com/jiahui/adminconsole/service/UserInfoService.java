package com.jiahui.adminconsole.service;

import com.jiahui.adminconsole.dto.UserInfo;
import org.springframework.stereotype.Service;

/**
 * @description user_info服务层
 * @author peng.wang
 * @date 2022-02-23
 */
@Service
public interface UserInfoService  {

 /**
    * 新增
    */
   UserInfo getUserByUserName(String username);

}