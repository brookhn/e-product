package com.jiahui.adminconsole.service.impl;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jiahui.adminconsole.dto.Result;
import com.jiahui.adminconsole.mapper.IndexFieldConfigMapper;
import com.jiahui.adminconsole.po.IndexFieldConfig;
import com.jiahui.adminconsole.service.IndexFieldConfigService;
import com.jiahui.adminconsole.util.ResultUtils;
import com.jiahui.adminconsole.vo.in.IndexFieldConfigIn;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @description 索引字段配置服务层
 * @author peng.wang
 * @date 2022-02-28
 */
@Service
@Log4j2
public class IndexFieldConfigServiceImpl implements IndexFieldConfigService {


    @Autowired
    private IndexFieldConfigMapper indexFieldConfigMapper;

    /**
    * 新增
    */
    @Override
    public Result add( IndexFieldConfig indexFieldConfig){
     log.info("indexFieldConfig:"+ JSON.toJSONString(indexFieldConfig));
   QueryWrapper queryWrapper= new QueryWrapper();
    //数据重复校验逻辑
   queryWrapper.eq("field_name",indexFieldConfig.getFieldName());
   queryWrapper.eq("index_config_id",indexFieldConfig.getIndexConfigId());
     List<IndexFieldConfig> oldInfos = indexFieldConfigMapper.selectList(queryWrapper);
    if(CollectionUtils.isNotEmpty(oldInfos)){
    return ResultUtils.error("名称重复");
    }else {
    indexFieldConfigMapper.insert(indexFieldConfig);
    }
    return ResultUtils.success("保存成功");
    }


     /**
    * 编辑
    */
     @Override
    public Result edit(IndexFieldConfig indexFieldConfig){

    QueryWrapper queryWrapper= new QueryWrapper();
    //数据重复校验逻辑
   //queryWrapper.eq("indexFieldConfig_name",indexFieldConfig.getindexFieldConfigName());
     List<IndexFieldConfig> oldindexFieldConfigs = indexFieldConfigMapper.selectList(queryWrapper);
    oldindexFieldConfigs.removeIf(e->e.getId().equals(indexFieldConfig.getId()));
    if(CollectionUtils.isNotEmpty(oldindexFieldConfigs)){
    return ResultUtils.error("名称重复");
    }else{
    indexFieldConfigMapper.updateById(indexFieldConfig);
    }
    return ResultUtils.success("保存成功");
    }

    /**
    * 删除
    */
    @Override
    public Result deleteById(int id){
        indexFieldConfigMapper.deleteById(id);
       return ResultUtils.success("删除成功!");
    }

    /**
    * 查询详情
    */
    @Override
    public Result selectOne(int id){
        IndexFieldConfig indexFieldConfig = indexFieldConfigMapper.selectById(id);
                if(indexFieldConfig!=null){
                    return ResultUtils.success(indexFieldConfig);
                }else{
                    return ResultUtils.error("没有找到该对象");
                }
    }

    /**
    * 自动分页查询
    */
    @Override
    public IPage pageList(IndexFieldConfigIn param) {
        log.info("pageparam:"+ JSON.toJSONString(param));
        //分页构造器
        Page<IndexFieldConfig> buildPage = new Page<IndexFieldConfig>(param.getPageNum(),param.getPageSize());
        //条件构造器
        QueryWrapper<IndexFieldConfig> queryWrapper = new QueryWrapper<IndexFieldConfig>();
        if(null!=param ) {
        IndexFieldConfig info=new IndexFieldConfig();
        BeanUtils.copyProperties(param,info);
        queryWrapper.setEntity(info);
        }
        //执行分页
        IPage<IndexFieldConfig> pageList = indexFieldConfigMapper.selectPage(buildPage, queryWrapper);
        //返回结果
        return pageList;
    }

    /**
     * 条件列表查询
     */
    @Override
    public List list(IndexFieldConfigIn param) {
            //条件构造器
         QueryWrapper<IndexFieldConfig> queryWrapper = new QueryWrapper<IndexFieldConfig>();
        if(null!=param ) {
        IndexFieldConfig info=new IndexFieldConfig();
        BeanUtils.copyProperties(param,info);
        queryWrapper.setEntity(info);
        }
        //列表查询
        List<IndexFieldConfig> list = indexFieldConfigMapper.selectList(queryWrapper);
            //返回结果
            return list;
            }

}