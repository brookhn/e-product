package com.jiahui.adminconsole.controller;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.jiahui.adminconsole.dto.Result;
import com.jiahui.adminconsole.po.ApplicationInfo;
import com.jiahui.adminconsole.service.ApplicationService;
import com.jiahui.adminconsole.util.ResultUtils;
import com.jiahui.adminconsole.vo.in.ApplicationAddIn;
import com.jiahui.adminconsole.vo.in.ApplicationEditIn;
import com.jiahui.adminconsole.vo.in.ApplicationIn;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

/**
* @description 应用信息控制器
* @author peng.wang
* @date 2022-02-28
*/
@Log4j2
@RestController
@RequestMapping("/application")
@Api(tags = "应用信息相关接口")
public class ApplicationController {

    @Autowired
    private ApplicationService applicationService;


      /**
     * 新增
     */
    @PostMapping("/add")
    @ApiOperation("新增应用信息")
    public Result add(@RequestBody @Valid ApplicationAddIn in){
        log.info("add:"+ JSON.toJSONString(in));
        ApplicationInfo applicationInfo=new ApplicationInfo();
        BeanUtils.copyProperties(in,applicationInfo);
        Result result= (Result)applicationService.add(applicationInfo);
        return result;
    }

     @PostMapping("/edit")
     @ApiOperation("编辑应用信息")
     public Result edit(@RequestBody @Valid ApplicationEditIn in){

         ApplicationInfo applicationInfo=new ApplicationInfo();
         BeanUtils.copyProperties(in,applicationInfo);
         Result result= (Result)applicationService.edit(applicationInfo);
        return result;
        }

    /**
    * 删除
    */
     @RequestMapping(value = "/delete/{id}", method = RequestMethod.GET)
    @ApiOperation("停用")
    public Result delete(@PathVariable("id") int id){
            applicationService.deleteById(id);
            return ResultUtils.success("停用成功");
    }

//    /**
//    * 查询详情
//    */
//   @RequestMapping(value = "detail/{id}", method = RequestMethod.GET)
//   @ApiOperation("查询应用信息详情")
//    public Result selectOne(@PathVariable("id") int id){
//    Result info = applicationService.selectOne(id);
//            return info;
//    }

    /**
    * 自动分页查询
    */
    @PostMapping("/pagelist")
    @ApiOperation("分页查询应用信息")
    public Result pageList(@RequestBody ApplicationIn param) {
        log.info("分页查询开始:"+ JSON.toJSONString(param));

        IPage pageList = applicationService.pageList(param);
        //返回结果
        return ResultUtils.success(pageList);
    }

//    /**
//    * 根据条件查询列表
//    */
//    @PostMapping("/list")
//    @ApiOperation("根据条件查询应用信息列表")
//    public Result list(@RequestBody  ApplicationIn param) {
//        log.info("应用信息 列表查询"+ JSON.toJSONString(param));
//
//        List pageList = applicationService.list(param);
//        //返回结果
//        return ResultUtils.success(pageList);
//    }





}