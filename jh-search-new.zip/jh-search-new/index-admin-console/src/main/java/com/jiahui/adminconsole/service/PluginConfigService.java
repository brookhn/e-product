package com.jiahui.adminconsole.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.jiahui.adminconsole.dto.Result;
import com.jiahui.adminconsole.po.PluginConfig;
import com.jiahui.adminconsole.vo.in.PluginConfigIn;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * @description plugin_config服务层
 * @author peng.wang
 * @date 2022-03-03
 */
@Service
public interface PluginConfigService  {

 /**
    * 新增
    */
    public Object add(PluginConfig  pluginConfig);


    /**
    * 删除
    */
    public Object deleteById(int id);



    /**
    * 编辑
    */
    public Object edit(PluginConfig pluginConfig);


    /**
    * 查询详情
    */
    public Result selectOne(int id);

    /**
    * 自动分页查询
    */
    public IPage pageList(PluginConfigIn param);
    /**
    * 条件列表查询
    */
    public List list(PluginConfigIn param);


    Result importPlugin(MultipartFile plugins);
}