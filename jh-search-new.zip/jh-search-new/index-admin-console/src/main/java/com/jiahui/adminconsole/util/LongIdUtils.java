package com.jiahui.adminconsole.util;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.util.Base64;
import java.util.Random;

/**
 * Created @2020/2/11 3:29 PM
 *
 * @author peng.wang
 * @version 1.0
 */
public class LongIdUtils {

    public static long elfHash(String str) {
        long hash = 0;
        long x=0;
        for(int i=0;i<str.length();i++)
        {
            hash = (hash<<4)+str.charAt(i);
            if((x=hash & 0xF0000000L) != 0)
            {
                hash^=(x>>24);
                hash &=~x;
            }
        }
        return (hash & 0x7FFFFFFF);
    }

}