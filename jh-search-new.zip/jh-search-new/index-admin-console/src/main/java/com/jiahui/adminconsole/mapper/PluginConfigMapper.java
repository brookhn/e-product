package com.jiahui.adminconsole.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiahui.adminconsole.po.PluginConfig;
import com.jiahui.adminconsole.vo.in.PluginConfigIn;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @description plugin_configMapper
 * @author peng.wang
 * @date 2022-03-03
 */
@Mapper
public interface PluginConfigMapper extends BaseMapper<PluginConfig> {


    void batchInsert(@Param("list") List<PluginConfigIn> list);
}