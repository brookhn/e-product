
package com.jiahui.adminconsole.constant;

import java.util.HashMap;
import java.util.Map;

/**
 * FileName: Constant
 * Author:   peng.wang
 * Date:     2021/04/20
 * Description: 公共常量类
 */
public class Constant {

    /**
     * 数据字典
     *
     */
    public static interface DataDict{

    }

    /**
     * 通用
     */
    public static interface Common {
        public final static String APPPREFIX ="JIH-" ;
    }


}
