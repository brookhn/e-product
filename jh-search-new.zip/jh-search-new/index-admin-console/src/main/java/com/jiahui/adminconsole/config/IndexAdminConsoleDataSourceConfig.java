package com.jiahui.adminconsole.config;


import com.jiahui.framework.datasource.config.JiaHuiDataSourceProperties;
import com.jiahui.framework.datasource.core.DynamicDataSource;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import javax.sql.DataSource;

@Configuration
public class IndexAdminConsoleDataSourceConfig {


    /**
     * productlib需替换为邮件申请中的{dbname}
     * @param dbProp
     * @return
     */
    @Bean("indexAdminConsole")
    @Primary
    public DataSource getDataSource(JiaHuiDataSourceProperties dbProp) {
        DynamicDataSource dataSource = new DynamicDataSource("indexAdminConsole", dbProp);
        return dataSource;
    }



//    @Bean("indexAdminConsoleSqlSessionFactory")
//    public SqlSessionFactory getSqlSessionFactory(@Qualifier("indexAdminConsole") DataSource dataSource) throws Exception {
//        SqlSessionFactoryBean bean = new SqlSessionFactoryBean();
//        bean.setDataSource(dataSource);
//        bean.setMapperLocations(new PathMatchingResourcePatternResolver().getResources("classpath*:mapper/xxx/*.xml"));
//        return bean.getObject();
//    }
//
//    @Bean("indexAdminConsoleSqlSessionTemplate")
//    public SqlSessionTemplate getSqlSessionTemplate(@Qualifier("indexAdminConsoleSqlSessionFactory") SqlSessionFactory sqlSessionFactory) {
//        return new SqlSessionTemplate(sqlSessionFactory);
//    }
//
//    @Bean(name = "indexAdminConsoleTransactionManager")
//    public DataSourceTransactionManager getTransactionManager(@Qualifier("indexAdminConsole") DataSource dataSource) {
//        return new DataSourceTransactionManager(dataSource);
//    }

}