package com.jiahui.adminconsole.controller;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.jiahui.adminconsole.dto.Result;
import com.jiahui.adminconsole.po.ApplicationInfo;
import com.jiahui.adminconsole.po.IndexFieldConfig;
import com.jiahui.adminconsole.service.IndexFieldConfigService;
import com.jiahui.adminconsole.util.ResultUtils;
import com.jiahui.adminconsole.vo.in.IndexFieldConfigIn;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

/**
* @description 索引字段配置控制器
* @author peng.wang
* @date 2022-02-28
*/
@Log4j2
@RestController
@RequestMapping("/indexFieldConfig")
@Api(tags = "索引字段配置相关接口")
public class IndexFieldConfigController {

    @Autowired
    private IndexFieldConfigService indexFieldConfigService;


      /**
     * 新增
     */
    @PostMapping("/add")
    @ApiOperation("新增索引字段配置")
    public Result add(@RequestBody @Valid IndexFieldConfigIn in){
        log.info("add:"+ JSON.toJSONString(in));
        IndexFieldConfig info=new IndexFieldConfig();
        BeanUtils.copyProperties(in,info);
        Result result= indexFieldConfigService.add(info);
        return result;
    }

     @PostMapping("/edit")
     @ApiOperation("编辑索引字段配置")
     public Result edit(@RequestBody @Valid IndexFieldConfig indexFieldConfig){

         Result result= indexFieldConfigService.edit(indexFieldConfig);
        return result;
        }

    /**
    * 删除
    */
     @RequestMapping(value = "/delete/{id}", method = RequestMethod.GET)
    @ApiOperation("删除")
    public Result delete(@PathVariable("id") int id){
            indexFieldConfigService.deleteById(id);
            return ResultUtils.success("删除成功");
    }

    /**
    * 查询详情
    */
   @RequestMapping(value = "detail/{id}", method = RequestMethod.GET)
   @ApiOperation("查询索引字段配置详情")
    public Result selectOne(@PathVariable("id") int id){
    Result info = indexFieldConfigService.selectOne(id);
            return info;
    }

    /**
    * 自动分页查询
    */
    @PostMapping("/pagelist")
    @ApiOperation("分页查询索引字段配置")
    public Result pageList(@RequestBody IndexFieldConfigIn param) {
        log.info("分页查询开始:"+ JSON.toJSONString(param));

        IPage pageList = indexFieldConfigService.pageList(param);
        //返回结果
        return ResultUtils.success(pageList);
    }

    /**
    * 根据条件查询列表
    */
    @PostMapping("/list")
    @ApiOperation("根据条件查询索引字段配置列表")
    public Result list(@RequestBody IndexFieldConfigIn param) {
        log.info("索引字段配置 列表查询"+ JSON.toJSONString(param));

        List pageList = indexFieldConfigService.list(param);
        //返回结果
        return ResultUtils.success(pageList);
    }

}