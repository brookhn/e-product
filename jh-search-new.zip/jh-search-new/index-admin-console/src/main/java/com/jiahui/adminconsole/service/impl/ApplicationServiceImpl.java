package com.jiahui.adminconsole.service.impl;

import cn.dev33.satoken.stp.StpUtil;
import cn.hutool.core.date.DateUtil;
import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jiahui.adminconsole.common.JihPage;
import com.jiahui.adminconsole.constant.Constant;
import com.jiahui.adminconsole.dto.Result;
import com.jiahui.adminconsole.mapper.ApplicationMapper;
import com.jiahui.adminconsole.po.ApplicationInfo;
import com.jiahui.adminconsole.service.ApplicationService;
import com.jiahui.adminconsole.util.ResultUtils;
import com.jiahui.adminconsole.vo.in.ApplicationIn;
import com.jiahui.adminconsole.vo.out.ApplicationOut;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

/**
 * @description 应用信息服务层
 * @author peng.wang
 * @date 2022-02-28
 */
@Service
@Log4j2
public class ApplicationServiceImpl implements ApplicationService {


    @Autowired
    private ApplicationMapper applicationMapper;

    /**
    * 新增
    */
    @Override
    public Result add( ApplicationInfo application){
        application.setAuditTime(DateUtil.date());
        application.setCreateUser((String) StpUtil.getTokenSession().getAttribute("userName"));
        application.setAppKey(Constant.Common.APPPREFIX+application.getAppName()+System.currentTimeMillis());
     log.info("application:"+ JSON.toJSONString(application));
   QueryWrapper queryWrapper= new QueryWrapper();
    //数据重复校验逻辑
   queryWrapper.eq("app_name",application.getAppName());
     List<ApplicationInfo> oldInfos = applicationMapper.selectList(queryWrapper);
    if(CollectionUtils.isNotEmpty(oldInfos)){
    return ResultUtils.error("名称重复");
    }else {
    applicationMapper.insert(application);
    }
    return ResultUtils.success("保存成功");
    }


     /**
    * 编辑
    */
     @Override
    public Object edit(ApplicationInfo application){

    QueryWrapper queryWrapper= new QueryWrapper();
    //数据重复校验逻辑
   //queryWrapper.eq("application_name",application.getapplicationName());
     List<ApplicationInfo> oldapplications = applicationMapper.selectList(queryWrapper);
    oldapplications.removeIf(e->e.getId().equals(application.getId()));
    if(CollectionUtils.isNotEmpty(oldapplications)){
    return ResultUtils.error("名称重复");
    }else{
    applicationMapper.updateById(application);
    }
    return ResultUtils.success("保存成功");
    }

    /**
    * 删除
    */
    @Override
    public Object deleteById(int id){
        ApplicationInfo info=new ApplicationInfo();
        info.setId(id);
        info.setEnabled("0");
       return applicationMapper.updateById(info);
    }

    /**
    * 查询详情
    */
    @Override
    public Result selectOne(int id){
        ApplicationInfo application = applicationMapper.selectById(id);
                if(application!=null){
                    return ResultUtils.success(application);
                }else{
                    return ResultUtils.error("没有找到该对象");
                }
    }

    /**
    * 自动分页查询
    */
    @Override
    public IPage pageList(ApplicationIn param) {
        log.info("pageparam:"+ JSON.toJSONString(param));
        //分页构造器
        Page<ApplicationInfo> buildPage = new Page<ApplicationInfo>(param.getPageNum(),param.getPageSize());
        //条件构造器
        QueryWrapper<ApplicationInfo> queryWrapper = new QueryWrapper<ApplicationInfo>();
        if(null!=param ) {
            ApplicationInfo info=new ApplicationInfo();
        BeanUtils.copyProperties(param,info);
        queryWrapper.setEntity(info);
        }
        //执行分页
        Page<ApplicationInfo> pageList = applicationMapper.selectPage(buildPage, queryWrapper);
        //返回结果
        return pageList;
    }

    /**
     * 条件列表查询
     */
    @Override
    public List list(ApplicationIn param) {
            //条件构造器
         QueryWrapper<ApplicationInfo> queryWrapper = new QueryWrapper<ApplicationInfo>();
        if(null!=param ) {
            ApplicationInfo info=new ApplicationInfo();
        BeanUtils.copyProperties(param,info);
        queryWrapper.setEntity(info);
        }
        //列表查询
        List<ApplicationInfo> list = applicationMapper.selectList(queryWrapper);
            //返回结果
            return list;
            }

}