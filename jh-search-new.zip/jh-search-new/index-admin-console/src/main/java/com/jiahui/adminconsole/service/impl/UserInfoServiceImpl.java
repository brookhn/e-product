package com.jiahui.adminconsole.service.impl;

import com.jiahui.adminconsole.dto.UserInfo;
import com.jiahui.adminconsole.service.UserInfoService;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;

/**
 * @description user_info服务层
 * @author peng.wang
 * @date 2022-02-23
 */
@Service
@Log4j2
public class UserInfoServiceImpl implements UserInfoService {

    @Override
    public UserInfo getUserByUserName(String username) {
        return null;
    }
}
