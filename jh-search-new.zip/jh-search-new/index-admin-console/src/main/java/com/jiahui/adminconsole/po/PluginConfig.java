package com.jiahui.adminconsole.po;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @description plugin_config
 * @author peng.wang
 * @date 2022-03-03
 */
@Data
@TableName("plugin_config")
public class PluginConfig implements Serializable {

    private static final long serialVersionUID = 1L;
    //如果主键字段不是id 需在主键上加上@TableId
    //Date类型 @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")  @TableField(exist = false)  @JsonIgnore 等可酌情添加

    /**
    * id
    */
    private Long id;
    /**
    * 索引id
    */
    private Long indexId;

    /**
    * 全量同步sql
    */
    private String fullSyncSql;

    /**
    * 全量同步range sql
    */
    private String fullSyncRangeSql;

    /**
    * 全量同步配置
    */
    private String fullSyncConfig;

    /**
    * 全量查询数据源名称
    */
    private String fullSyncDbName;

    /**
    * 增量同步配置
    */
    private String incrSyncConfig;

    /**
    * 增量datawrapper需使用的数据源名称
    */
    private String incrSyncDbNames;

    /**
    * 增量同步类型 1-kafka
    */
    private int incrSyncType;

    /**
    * 同步任务主键
    */
    private String idFieldName;

    /**
    * wrapper jar 地址
    */
    private String wrapperJarUrl;

    /**
    * wrapper 类全限定名
    */
    private String wrapperClass;

    /**
    * 状态 1：启用 0：停用
    */
    private int status;

    /**
    * 创建时间
    */
    private Date createTime;

    /**
    * 创建人
    */
    private String createUser;

    /**
    * 更新时间
    */
    private Date updateTime;

    /**
    * 更新人
    */
    private String updateUser;

    public PluginConfig() {}
}