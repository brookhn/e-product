package com.jiahui.adminconsole.po;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;

/**
 * @description 索引字段配置
 * @author peng.wang
 * @date 2022-02-28
 */
@Data
@TableName("index_field_config")
public class IndexFieldConfig implements Serializable {

    private static final long serialVersionUID = 1L;
    //如果主键字段不是id 需在主键上加上@TableId
    //Date类型 @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")  @TableField(exist = false)  @JsonIgnore 等可酌情添加

    /**
    * id
    */
    private Integer id;
    /**
    * index_config_id
    */
    private Long indexConfigId;

    /**
    * 字段名称
    */
    private String fieldName;

    /**
    * 字段类型
    */
    private String fieldType;

    /**
    * index_analyzer
    */
    private String indexAnalyzer;

    /**
    * 分片数量
    */
    private String searchAnalyzer;

    /**
    * 分片副本数
    */
    private int norms;

    /**
    * 默认值
    */
    private String nullValue;

    /**
    * 0，1
    */
    private int bizStatus;


    /**
    * 创建人
    */
    private String createUser;


    /**
    * 更新人
    */
    private String updateUser;

    public IndexFieldConfig() {}
}