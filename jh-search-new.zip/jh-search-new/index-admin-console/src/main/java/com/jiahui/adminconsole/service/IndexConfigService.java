package com.jiahui.adminconsole.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.jiahui.adminconsole.po.IndexConfig;
import com.jiahui.adminconsole.dto.Result;
import com.jiahui.adminconsole.vo.in.IndexConfigIn;
import com.jiahui.adminconsole.vo.in.OptionIndexIn;
import com.jiahui.framework.rpc.rest.ResultVO;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @description index_config服务层
 * @author peng.wang
 * @date 2022-02-24
 */
@Service
public interface IndexConfigService  {

 /**
    * 新增
    */
    public Object add(IndexConfig indexConfig);


    /**
    * 删除
    */
    public Object deleteById(int id);



    /**
    * 编辑
    */
    public Object edit(IndexConfig  indexConfig);


    /**
    * 查询详情
    */
    public Result selectOne(int id);

    /**
    * 自动分页查询
    */
    public IPage pageList(IndexConfigIn param);

    /**
    * 条件列表查询
    */
    public List list(IndexConfigIn param);

   Result syn2Es(OptionIndexIn indexConfig);

    Result closeIndex(OptionIndexIn in);

    Result deleteIndex(OptionIndexIn in);

    Result openIndex(OptionIndexIn in);

    Result putMapping(OptionIndexIn in);

    ResultVO startFullTask(OptionIndexIn in);

    ResultVO stopFullTask(OptionIndexIn in);

    ResultVO startIncrTask(OptionIndexIn in);

    ResultVO getRunningMap();

    ResultVO getTaskRunActuator();

}