package com.jiahui.adminconsole.vo.in;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@ApiModel("登录用户入参")
@Data
public class UserIn {


    /**
     * 用户名
     */
    @ApiModelProperty("用户名")
    private String userName;


    /**
     * 密码
     */
    @ApiModelProperty("密码")
    private String password;
}
