package com.jiahui.adminconsole.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiahui.adminconsole.po.ApplicationInfo;
import com.jiahui.adminconsole.vo.in.ApplicationIn;
import org.apache.ibatis.annotations.Mapper;

/**
 * @description 应用信息Mapper
 * @author peng.wang
 * @date 2022-02-28
 */
@Mapper
public interface ApplicationMapper extends BaseMapper<ApplicationInfo> {



}