package com.jiahui.adminconsole.po;

import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @description 应用信息
 * @author peng.wang
 * @date 2022-02-28
 */
@Data
@TableName("application")
public class ApplicationInfo implements Serializable {

    private static final long serialVersionUID = 1L;
    //如果主键字段不是id 需在主键上加上@TableId
    //Date类型 @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")  @TableField(exist = false)  @JsonIgnore 等可酌情添加

    /**
    * id
    */
    private Integer id;
    /**
    * 应用名
    */
    private String appName;
    /**
     * 备注
     */
    @ApiModelProperty("备注")
    private String remark;
    /**
    * 应用key
    */
    private String appKey;

    /**
    * 审核状态 0：待审核 1：审核通过 -1：审核拒绝
    */
    private String auditStatus;

    /**
    * 审核时间
    */
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date auditTime;

    /**
    * 可用状态 0-停用 1-启用
    */
    private String enabled;

    /**
    * 创建时间
    */
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date createTime;

    /**
    * 创建人
    */
    private String createUser;


    public ApplicationInfo() {}
}