package com.jiahui.adminconsole.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.jiahui.adminconsole.dto.Result;
import com.jiahui.adminconsole.po.ApplicationInfo;
import com.jiahui.adminconsole.vo.in.ApplicationIn;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @description 应用信息服务层
 * @author peng.wang
 * @date 2022-02-28
 */
@Service
public interface ApplicationService  {

 /**
    * 新增
    */
    public Object add(ApplicationInfo applicationInfo);


    /**
    * 删除
    */
    public Object deleteById(int id);



    /**
    * 编辑
    */
    public Object edit(ApplicationInfo applicationInfo);


    /**
    * 查询详情
    */
    public Result selectOne(int id);

    /**
    * 自动分页查询
    */
    public IPage pageList(ApplicationIn param);
    /**
    * 条件列表查询
    */
    public List list(ApplicationIn param);





}