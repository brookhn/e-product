package com.jiahui.adminconsole.vo.in;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class OptionIndexIn {


    /**
     * 索引id
     */
    @ApiModelProperty("id")
    private Long id;

}
