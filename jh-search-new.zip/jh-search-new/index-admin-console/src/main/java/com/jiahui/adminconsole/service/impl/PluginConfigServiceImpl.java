package com.jiahui.adminconsole.service.impl;

import com.alibaba.excel.EasyExcel;
import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jiahui.adminconsole.dto.Result;
import com.jiahui.adminconsole.listener.PluginConfigInListener;
import com.jiahui.adminconsole.mapper.PluginConfigMapper;
import com.jiahui.adminconsole.po.PluginConfig;
import com.jiahui.adminconsole.service.PluginConfigService;
import com.jiahui.adminconsole.util.ResultUtils;
import com.jiahui.adminconsole.vo.in.PluginConfigIn;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

/**
 * @description plugin_config服务层
 * @author peng.wang
 * @date 2022-03-03
 */
@Service
@Log4j2
public class PluginConfigServiceImpl implements PluginConfigService {


    @Autowired
    private PluginConfigMapper pluginConfigMapper;

    /**
    * 新增
    */
    @Override
    public Object add( PluginConfig pluginConfig){
     log.info("pluginConfig:"+ JSON.toJSONString(pluginConfig));
   QueryWrapper queryWrapper= new QueryWrapper();
    //数据重复校验逻辑
   //queryWrapper.eq("pluginConfig_name",pluginConfig.getpluginConfigName());
     List<PluginConfig> oldInfos = pluginConfigMapper.selectList(queryWrapper);
    if(CollectionUtils.isNotEmpty(oldInfos)){
    return ResultUtils.error("名称重复");
    }else {
    pluginConfigMapper.insert(pluginConfig);
    }
    return ResultUtils.success("保存成功");
    }


     /**
    * 编辑
    */
     @Override
    public Object edit(PluginConfig pluginConfig){

    QueryWrapper queryWrapper= new QueryWrapper();
    //数据重复校验逻辑
   //queryWrapper.eq("pluginConfig_name",pluginConfig.getpluginConfigName());
     List<PluginConfig> oldpluginConfigs = pluginConfigMapper.selectList(queryWrapper);
    oldpluginConfigs.removeIf(e->e.getId().equals(pluginConfig.getId()));
    if(CollectionUtils.isNotEmpty(oldpluginConfigs)){
    return ResultUtils.error("名称重复");
    }else{
    pluginConfigMapper.updateById(pluginConfig);
    }
    return ResultUtils.success("保存成功");
    }

    /**
    * 删除
    */
    @Override
    public Object deleteById(int id){
       return pluginConfigMapper.deleteById(id);
    }

    /**
    * 查询详情
    */
    @Override
    public Result selectOne(int id){
        PluginConfig pluginConfig = pluginConfigMapper.selectById(id);
                if(pluginConfig!=null){
                    return ResultUtils.success(pluginConfig);
                }else{
                    return ResultUtils.error("没有找到该对象");
                }
    }

    /**
    * 自动分页查询
    */
    @Override
    public IPage pageList(PluginConfigIn param) {
        log.info("pageparam:"+ JSON.toJSONString(param));
        //分页构造器
        Page<PluginConfig> buildPage = new Page<PluginConfig>(param.getPageNum(),param.getPageSize());
        //条件构造器
        QueryWrapper<PluginConfig> queryWrapper = new QueryWrapper<PluginConfig>();
        if(null!=param ) {
        PluginConfig info=new PluginConfig();
        BeanUtils.copyProperties(param,info);
        queryWrapper.setEntity(info);
        }
        //执行分页
        IPage<PluginConfig> pageList = pluginConfigMapper.selectPage(buildPage, queryWrapper);
        //返回结果
        return pageList;
    }

    /**
     * 条件列表查询
     */
    @Override
    public List list(PluginConfigIn param) {
            //条件构造器
         QueryWrapper<PluginConfig> queryWrapper = new QueryWrapper<PluginConfig>();
        if(null!=param ) {
        PluginConfig info=new PluginConfig();
        BeanUtils.copyProperties(param,info);
        queryWrapper.setEntity(info);
        }
        //列表查询
        List<PluginConfig> list = pluginConfigMapper.selectList(queryWrapper);
            //返回结果
            return list;
            }

    @Override
    public Result importPlugin(MultipartFile file) {
        try {
            EasyExcel.read(file.getInputStream(), PluginConfigIn.class, new PluginConfigInListener(pluginConfigMapper)).sheet().doRead();
            return  ResultUtils.success("导入成功!");
        } catch (IOException e) {
            log.error("导入失败:{}",e);
            return ResultUtils.error("导入失败!");
        }
    }

}