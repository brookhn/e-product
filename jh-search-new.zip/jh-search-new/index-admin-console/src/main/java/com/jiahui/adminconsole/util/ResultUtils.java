package com.jiahui.adminconsole.util;


import com.jiahui.adminconsole.dto.Result;
import com.jiahui.adminconsole.enums.ResultEnum;

public class ResultUtils {
    public static Result success(Object obj) {
        return getResult(ResultEnum.SUCCESS, obj);
    }

    public static Result success(String msg, Object obj) {
        return getResult(ResultEnum.SUCCESS.getCode(), msg, obj);
    }

    public static Result success() {
        return getResult(ResultEnum.SUCCESS, null);
    }


    public static Result getResult(ResultEnum re) {
        return getResult(re, null);
    }

    public static Result getResult(ResultEnum re, Object obj) {
        return getResult(re.getCode(), re.getMessage(), obj);
    }

    public static Result error(ResultEnum re, Object obj) {
        return getResult(re.getCode(), re.getMessage(), obj);
    }

    public static Result error(Integer code, String msg) {
        return getResult(code, msg, null);
    }

    public static Result error(Integer code, String msg, String errMsg) {
        return getResult(code, msg, errMsg, null);
    }

    public static Result error(ResultEnum re) {
        return getResult(re.getCode(), re.getMessage());
    }

    public static Result error(String mesg) {
        return getResult(402, mesg);
    }

    public static Result getResult(Integer code, String msg) {
        return getResult(code, msg, null);
    }


    public static Result getResult(Integer code, String msg, Object obj) {
        Result result = new Result();
        result.setCode(code);
        result.setMsg(msg);
        result.setData(obj);
        return result;
    }

    public static Result getResult(Integer code, String msg, String errMsg, Object obj) {
        Result result = new Result();
        result.setCode(code);
        result.setMsg(msg);
        result.setErrMsg(errMsg);
        result.setData(obj);
        return result;
    }

}
