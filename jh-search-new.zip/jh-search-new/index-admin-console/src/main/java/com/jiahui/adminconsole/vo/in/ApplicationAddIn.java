package com.jiahui.adminconsole.vo.in;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @description 应用信息
 * @author peng.wang
 * @date 2022-02-28
 */
@Data
@ApiModel("新增应用入参")
public class ApplicationAddIn {


    /**
     * 应用名
     */
    @ApiModelProperty("应用")
    private String appName;
    /**
     * 备注
     */
    @ApiModelProperty("备注")
    private String remark;

    public ApplicationAddIn() {}
}
