package com.jiahui.adminconsole.vo.in;

import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

@Data
public class ApplicationEditIn {

    /**
     * 应用名
     */
    private String appName;
    /**
     * 备注
     */
    @ApiModelProperty("备注")
    private String remark;

    /**
     * 审核状态 0：待审核 1：审核通过 -1：审核拒绝
     */
    private String auditStatus;

    /**
     * 可用状态 0-停用 1-启用
     */
    private String enabled;

}
