package com.jiahui.adminconsole.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiahui.adminconsole.po.IndexFieldConfig;
import org.apache.ibatis.annotations.Mapper;

/**
 * @description 索引字段配置Mapper
 * @author peng.wang
 * @date 2022-02-28
 */
@Mapper
public interface IndexFieldConfigMapper extends BaseMapper<IndexFieldConfig> {



}