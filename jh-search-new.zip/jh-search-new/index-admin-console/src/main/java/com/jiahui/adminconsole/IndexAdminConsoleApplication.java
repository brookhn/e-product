package com.jiahui.adminconsole;


import cn.dev33.satoken.filter.SaServletFilter;
import lombok.extern.log4j.Log4j2;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.core.annotation.Order;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

import javax.annotation.PostConstruct;

/**
 * springboot 入口
 *
 * @author SQL
 * @date 2021/03/25
 */
@Log4j2
@SpringBootApplication(scanBasePackages = {"com.jiahui.*"},exclude = {
        DataSourceAutoConfiguration.class,
        DataSourceTransactionManagerAutoConfiguration.class,
        HibernateJpaAutoConfiguration.class})
@EnableFeignClients(basePackages = {"com.jiahui.search.index.manager.contract.client","com.jiahui.search.index.writer.rest.contract"})
public class IndexAdminConsoleApplication {

    @Value("${server.port}")
    private String serverPort;


    /**
     * springboot 入口函数
     * @param args
     */
    public static void main(String[] args) {
        SpringApplication.run(IndexAdminConsoleApplication.class, args);
    }

    @PostConstruct
    void postInit() {
        System.out.println("index-admin-console@" + serverPort + " Started ......");
    }

    @Bean
    @Order(1)
    public FilterRegistrationBean corsFilter() {
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowCredentials(true);
        config.addAllowedOriginPattern("*");
        config.addAllowedHeader("*");
        config.addAllowedMethod("*");
        source.registerCorsConfiguration("/**", config);
        FilterRegistrationBean bean = new FilterRegistrationBean(new CorsFilter(source));
        bean.setOrder(1);
        return bean;
    }


    @Bean
    @Order(2)
    public FilterRegistrationBean registrationAuthorizeAttribute(SaServletFilter filter) {
        FilterRegistrationBean registration = new FilterRegistrationBean(filter);
        registration.addUrlPatterns("/*");
        registration.setOrder(2);
        return registration;
    }


}
