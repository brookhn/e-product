package com.jiahui.adminconsole;

import com.github.benmanes.caffeine.cache.Caffeine;
import com.github.benmanes.caffeine.cache.LoadingCache;

import java.util.concurrent.TimeUnit;

public class MainTest {


    public static void main(String[] args) {

        LoadingCache<String, DataObject> cache = Caffeine.newBuilder()
                .maximumSize(100)
                .expireAfterWrite(1, TimeUnit.MINUTES)
                .build(k -> DataObject.get("Data for " + k));
        for (int i = 0; i < 3; i++) {
            System.out.println("round:"+i);
            DataObject dataObject = cache.get("1");
            System.out.println(dataObject);
        }
//        assertNotNull(dataObject);
//        assertEquals("Data for " + key, dataObject.getData());
    }

    public static long ELFHash(String strUri) {
        long hash = 0;
        long x=0;
        for(int i=0;i<strUri.length();i++)
        {
            hash = (hash<<4)+strUri.charAt(i);
            if((x=hash & 0xF0000000L) != 0)
            {
                hash^=(x>>24);
                hash &=~x;
            }
        }
        return (hash & 0x7FFFFFFF);
    }


}
