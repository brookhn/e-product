package com.jiahui.adminconsole;

public class DataObject {
    private final String data;

    private static int objectCounter = 0;

    public DataObject(String data) {
        this.data = data;
    }
    // standard constructors/getters

    public static DataObject get(String data) {
        System.out.println("start**************************");
        objectCounter++;
        return new DataObject(data);
    }
}