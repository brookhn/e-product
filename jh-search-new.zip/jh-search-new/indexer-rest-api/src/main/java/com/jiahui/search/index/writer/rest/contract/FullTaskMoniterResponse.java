package com.jiahui.search.index.writer.rest.contract;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

public class FullTaskMoniterResponse {

    List<TaskMoniterObject> taskMoniterObjectList = new ArrayList<>();

    public List<TaskMoniterObject> getTaskMoniterObjectList() {
        return taskMoniterObjectList;
    }

    public void setTaskMoniterObjectList(List<TaskMoniterObject> taskMoniterObjectList) {
        this.taskMoniterObjectList = taskMoniterObjectList;
    }

    public void addMoniterObject(String taskName,
                                 String indexName,
                                 Long totalCount,
                                 Long taskTotalCount,
                                 Map<String, AtomicLong> taskMap){
        TaskMoniterObject taskMoniterObject = new TaskMoniterObject();
        taskMoniterObject.setTaskName(taskName);
        taskMoniterObject.setIndexName(indexName);
        taskMoniterObject.setTotalCount(totalCount);
        taskMoniterObject.setTaskTotalCount(taskTotalCount);
        taskMoniterObject.setRunTaskMap(taskMap);
        taskMoniterObjectList.add(taskMoniterObject);
    }


    public class TaskMoniterObject{
        String taskName;
        String indexName;
        Long  totalCount;
        Long taskTotalCount;

        Map<String, AtomicLong> runTaskMap = new HashMap<>();

        public Map<String, AtomicLong> getRunTaskMap() {
            return runTaskMap;
        }

        public void setRunTaskMap(Map<String, AtomicLong> runTaskMap) {
            this.runTaskMap = runTaskMap;
        }

        public String getTaskName() {
            return taskName;
        }

        public void setTaskName(String taskName) {
            this.taskName = taskName;
        }

        public String getIndexName() {
            return indexName;
        }

        public void setIndexName(String indexName) {
            this.indexName = indexName;
        }

        public Long getTotalCount() {
            return totalCount;
        }

        public void setTotalCount(Long totalCount) {
            this.totalCount = totalCount;
        }

        public Long getTaskTotalCount() {
            return taskTotalCount;
        }

        public void setTaskTotalCount(Long taskTotalCount) {
            this.taskTotalCount = taskTotalCount;
        }

        @Override
        public String toString() {
            return "TaskMoniterObject{" +
                    "taskName='" + taskName + '\'' +
                    ", indexName='" + indexName + '\'' +
                    ", totalCount=" + totalCount +
                    ", taskTotalCount=" + taskTotalCount +
                    '}';
        }
    }
}
