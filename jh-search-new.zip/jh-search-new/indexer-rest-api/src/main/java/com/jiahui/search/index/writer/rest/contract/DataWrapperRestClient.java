package com.jiahui.search.index.writer.rest.contract;

import com.jiahui.framework.rpc.rest.ResultVO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@FeignClient(value = "jhs-data-wrapper")
public interface DataWrapperRestClient {

    @PostMapping(path = "/startFullTask", headers = {"Content-Type=application/json;charset=UTF-8"})
    ResultVO<SyncResponse> startFullTask(SyncRequest fullIndexSyncRequest);

    @PostMapping(path = "/stopFullTask", headers = {"Content-Type=application/json;charset=UTF-8"})
    ResultVO<SyncResponse> stopFullTask(SyncRequest fullIndexSyncRequest);

    @PostMapping(path = "/startIncrTask", headers = {"Content-Type=application/json;charset=UTF-8"})
    ResultVO<SyncResponse> startIncrementTask(SyncRequest syncRequest);

    @GetMapping(path = "/getRunningMap", headers = {"Content-Type=application/json;charset=UTF-8"})
    ResultVO<WrapperTaskResponse> getRunningMap();

    /**
     * 获取系统监控
     * @return
     */
    @PostMapping(path ="/getTaskActuator", headers = {"Content-Type=application/json;charset=UTF-8"})
    ResultVO<FullTaskMoniterResponse> getTaskRunActuator();


}
