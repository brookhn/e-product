package com.jiahui.search.index.writer.rest.contract;

import com.jiahui.framework.rpc.rest.ResultVO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(value = "indexer-service")
public interface IndexWriterRestClient {
    @PostMapping(path = "/prepareFullIndex", headers = {"Content-Type=application/json;charset=UTF-8"})
    ResultVO<PrepareIndexResponse> prepareFullIndex(@RequestBody PrepareIndexRequest request);

    @PostMapping(path = "/prepareIncrementIndex", headers = {"Content-Type=application/json;charset=UTF-8"})
    ResultVO<PrepareIndexResponse> prepareIncrementIndex(@RequestBody PrepareIndexRequest request);

    @PostMapping(path = "/readyFullIndex", headers = {"Content-Type=application/json;charset=UTF-8"})
    ResultVO<Boolean> readyFullIndex(@RequestBody ReadyFullIndexRequest request);
}
