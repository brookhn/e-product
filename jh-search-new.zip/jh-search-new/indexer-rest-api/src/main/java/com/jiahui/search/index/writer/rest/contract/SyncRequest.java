package com.jiahui.search.index.writer.rest.contract;

public class SyncRequest {
    private Long indexId;

    public Long getIndexId() {
        return indexId;
    }

    public void setIndexId(Long indexId) {
        this.indexId = indexId;
    }
}
