package com.jiahui.search.index.writer.rest.contract;

import java.util.Set;

public class WrapperTaskResponse {
    Set<String> tasklist;

    public Set<String> getTasklist() {
        return tasklist;
    }

    public void setTasklist(Set<String> tasklist) {
        this.tasklist = tasklist;
    }
}
