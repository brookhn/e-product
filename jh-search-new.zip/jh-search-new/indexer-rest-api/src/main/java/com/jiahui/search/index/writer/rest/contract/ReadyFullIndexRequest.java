package com.jiahui.search.index.writer.rest.contract;

import lombok.*;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode(callSuper = false)
public class ReadyFullIndexRequest {
    private boolean done;
    private String indexName;
    private Long indexConfigId;
    private String token;

    public boolean isDone() {
        return done;
    }

    public void setDone(boolean done) {
        this.done = done;
    }

    public String getIndexName() {
        return indexName;
    }

    public void setIndexName(String indexName) {
        this.indexName = indexName;
    }

    public Long getIndexConfigId() {
        return indexConfigId;
    }

    public void setIndexConfigId(Long indexConfigId) {
        this.indexConfigId = indexConfigId;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
