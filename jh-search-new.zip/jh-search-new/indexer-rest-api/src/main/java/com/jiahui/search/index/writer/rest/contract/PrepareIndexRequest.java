package com.jiahui.search.index.writer.rest.contract;

import lombok.*;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode(callSuper = false)
public class PrepareIndexRequest {
    private Long indexConfigId;

    public Long getIndexConfigId() {
        return indexConfigId;
    }

    public void setIndexConfigId(Long indexConfigId) {
        this.indexConfigId = indexConfigId;
    }
}
