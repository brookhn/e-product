package com.jiahui.search.searcher.config;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * @author ivy.wang
 */
@Configuration
public class CorsConfig implements WebMvcConfigurer {

@Override
public void addCorsMappings(CorsRegistry registry) {
    registry.addMapping(MvcConstants.URL_PATTERN_ALL_MATCH)
            .allowedOriginPatterns(MvcConstants.PATTERN_ALL_MATCH)
            .allowedMethods(MvcConstants.ALLOW_METHODS)
            .allowedHeaders(MvcConstants.ALLOW_HEADERS)
            .exposedHeaders(MvcConstants.HEADER_COOKIE)
            .allowCredentials(true);
}

    /**
     * http://localhost:port/xxxxxx/doc.html#/
     * @param registry
     */
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler(MvcConstants.SWAGGER_UI_URI)
                .addResourceLocations(MvcConstants.SWAGGER_RESOURCE_LOCATION);

        if (!registry.hasMappingForPattern(MvcConstants.URL_PATTERN_WEBJARS)) {
            registry.addResourceHandler(MvcConstants.URL_PATTERN_WEBJARS)
                    .addResourceLocations(MvcConstants.WEBJARS_RESOURCE_LOCATION);
        }
        if (!registry.hasMappingForPattern(MvcConstants.URL_PATTERN_ALL_MATCH)) {
            registry.addResourceHandler(MvcConstants.URL_PATTERN_ALL_MATCH)
                    .addResourceLocations(MvcConstants.RESOURCE_LOCATIONS);
        }

    }

    @Bean
    public CommonsMultipartResolver multipartResolver() {
        CommonsMultipartResolver multipartResolver = new CommonsMultipartResolver();
        return multipartResolver;
    }
} 