package com.jiahui.search.searcher.service.impl;

import com.jiahui.search.entity.Application;
import com.jiahui.search.repository.ApplicationRepo;
import com.jiahui.search.searcher.service.AppService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AppServiceImpl implements AppService {

    @Autowired
    private ApplicationRepo applicationRepo;

    @Override
    public Application getByAppKey(String appKey){
        return applicationRepo.getFromCacheByAppKey(appKey);
    }
}
