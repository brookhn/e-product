package com.jiahui.search.searcher.service;

import com.jiahui.search.searcher.api.module.QueryRequest;
import com.jiahui.search.searcher.api.module.QueryResponse;

/**
 *  查询application信息
 */
public interface SearchService {


    QueryResponse search(QueryRequest request) ;
}
