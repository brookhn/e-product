package com.jiahui.search.searcher.service;

import com.jiahui.search.entity.Application;

/**
 *  查询application信息
 */
public interface AppService {

    Application getByAppKey(String appKey);

}
