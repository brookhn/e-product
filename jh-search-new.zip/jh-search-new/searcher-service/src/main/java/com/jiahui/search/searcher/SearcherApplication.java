package com.jiahui.search.searcher;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;


@EnableFeignClients(value = "com.jiahui.search.searcher.api")
@EnableDiscoveryClient
@SpringBootApplication(scanBasePackages = {"com.jiahui.search.searcher", "com.jiahui.search.repository"})
public class SearcherApplication {

    public static void main(String[] args) {
       SpringApplication.run(SearcherApplication.class, args);
    }


}
