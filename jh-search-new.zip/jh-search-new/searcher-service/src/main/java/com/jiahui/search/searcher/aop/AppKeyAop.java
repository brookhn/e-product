package com.jiahui.search.searcher.aop;


import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.jiahui.search.common.exception.BizException;
import com.jiahui.search.common.enums.CodeEnum;
import com.jiahui.search.searcher.service.AppService;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.support.StandardMultipartHttpServletRequest;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Slf4j
@Aspect
@Component
public class AppKeyAop {

    @Autowired
    private AppService appService;

    /**
     *  直接对RestController进行拦截
     */
    @Pointcut("@within(org.springframework.stereotype.Controller) || @within(org.springframework.web.bind.annotation.RestController)")
    public void controllerPointCut() {
    }

    @Before("controllerPointCut()")
    public void doBefore(JoinPoint joinPoint) {

        Object[] args = joinPoint.getArgs();
        List<Object> list = new ArrayList<>();
        for (int i = 0; i < args.length; i++) {
            if (args[i] instanceof HttpServletRequest || args[i] instanceof HttpServletResponse || args[i] instanceof StandardMultipartHttpServletRequest || args[i] instanceof MultipartFile) {
                log.warn("过滤不能解析参数");
            } else {
                list.add(args[i]);
            }
        }
        if(CollectionUtil.isNotEmpty(list)) {
            Object arg = list.get(0);
            JSONObject jsonObject = JSONUtil.parseObj(arg);
            String appKey = jsonObject.get("appKey", String.class);
            if(Objects.nonNull(appKey)) {
                checkAppKey(appKey);
            }
        }
    }

    private void checkAppKey(String appKey)  {
        if(Objects.isNull(appService.getByAppKey(appKey))) {
            throw new BizException(CodeEnum.APP_KEY_NOT_EXISTS);
        }
    }
}
