package com.jiahui.search.searcher.handler;

import com.alibaba.csp.sentinel.slots.block.authority.AuthorityException;
import com.alibaba.csp.sentinel.slots.block.degrade.DegradeException;
import com.alibaba.csp.sentinel.slots.block.flow.FlowException;
import com.alibaba.csp.sentinel.slots.block.flow.param.ParamFlowException;
import com.alibaba.csp.sentinel.slots.system.SystemBlockException;
import com.jiahui.search.common.enums.CodeEnum;
import com.jiahui.search.common.exception.BizException;
import com.jiahui.search.common.rest.ApiError;
import lombok.extern.log4j.Log4j2;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.NoHandlerFoundException;

import javax.validation.ConstraintViolationException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.UndeclaredThrowableException;

import static org.springframework.http.HttpStatus.BAD_REQUEST;


/**
 * @author SQL
 * 全局异常处理
 */
@Order(Ordered.HIGHEST_PRECEDENCE)
@RestControllerAdvice
@Log4j2
public class ApiExceptionHandler {

    /**
     * Handle Exception, handle generic Exception.class
     *
     * @param ex the Exception
     * @return the ApiError object
     */
    @ExceptionHandler({MethodArgumentNotValidException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<Object> methodArgumentNotValidException(MethodArgumentNotValidException ex) {
        log.error(ex);
       ApiError apiError = new ApiError(HttpStatus.BAD_REQUEST, HttpStatus.BAD_REQUEST.value());
       apiError.setMsg("参数校验异常,请检查请求参数:" + ex.getBindingResult().getFieldError().getField() + ", " + ex.getBindingResult().getFieldError().getDefaultMessage());
       return buildResponseEntity(apiError);
    }

    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    protected ResponseEntity<Object> handleMethodArgumentTypeMismatch(MethodArgumentTypeMismatchException ex,
                                                                      WebRequest request) {
        log.error(ex);
       ApiError apiError = new ApiError(BAD_REQUEST, BAD_REQUEST.value());
       apiError.setMsg(String.format("The parameter '%s' of value '%s' could not be converted to type '%s'", ex.getName(), ex.getValue(), ex.getRequiredType().getSimpleName()));
       return buildResponseEntity(apiError);
    }

    @ExceptionHandler({HttpRequestMethodNotSupportedException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<Object> methodNotSupportedException(HttpRequestMethodNotSupportedException ex) {
        log.error(ex);
        ApiError apiError = new ApiError(CodeEnum.BAD_REQUEST.getCode(), CodeEnum.BAD_REQUEST.getMsg());
        return buildResponseEntity(apiError);
    }

    @ExceptionHandler({MissingServletRequestParameterException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<Object> methodNotSupportedException(MissingServletRequestParameterException ex) {
        log.error(ex);
        ApiError apiError = new ApiError(CodeEnum.BAD_REQUEST.getCode(), CodeEnum.BAD_REQUEST.getMsg());
        return buildResponseEntity(apiError);
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<Object> handleHttpMessageNotReadableException(HttpMessageNotReadableException e){
        log.error(e);
        ApiError apiError = new ApiError(HttpStatus.BAD_REQUEST, HttpStatus.BAD_REQUEST.value());
        if (e.getMessage().indexOf("JSON parse error: Cannot deserialize value of type `java.lang.Integer`") != -1) {
            apiError.setMsg("参数错误,有参数必须为数字但是输入了字符串或者输入了较大的数字");
        }
        if ((e.getMessage().indexOf("out of range of int") != -1)){
            apiError.setMsg("参数错误,有参数必须为数字但是输入了字符串或者输入了较大的数字");
        }
        else {
            apiError.setMsg("请求的参数格式有误！！");
        }
        return buildResponseEntity(apiError);
    }

//    @ExceptionHandler(ElasticsearchStatusException.class)
//    protected ResponseEntity<Object> findEsException(ElasticsearchStatusException ex,
//                                                     WebRequest request) {
//        ApiError apiError = new ApiError(HttpStatus.INTERNAL_SERVER_ERROR, INTERNAL_SERVER_ERROR.value());
//        apiError.setMsg("elasticsearch操作出错:" + ex.getMessage());
//        return buildResponseEntity(apiError);
//    }

    @ExceptionHandler(value = {NullPointerException.class})
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseEntity<Object> nullPointerException(NullPointerException ex) {
        log.error(ex.getMessage(), ex);
        return buildResponseEntity(new ApiError(HttpStatus.INTERNAL_SERVER_ERROR, CodeEnum.EXCEPTION.getCode()));
    }

    @ExceptionHandler(value = {RuntimeException.class})
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseEntity<Object> runtimeException(RuntimeException ex) {
        log.error(ex.getMessage(),ex);
        return buildResponseEntity(new ApiError(HttpStatus.INTERNAL_SERVER_ERROR, CodeEnum.EXCEPTION.getCode()));
    }

//    @ExceptionHandler(value = {RedisConnectionFailureException.class})
//    public ResponseEntity<Object> jedisException(IllegalArgumentException ex) {
//        return buildResponseEntity(new ApiError(HttpStatus.INTERNAL_SERVER_ERROR, ApiErrorCode.INTERNAL_SERVER_ERROR.getCode(), ex.getMessage()));
//    }

    @ExceptionHandler(UndeclaredThrowableException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<Object> undeclaredThrowableException(UndeclaredThrowableException ex) {
        log.error(ex);
        ApiError apiError = new ApiError(HttpStatus.BAD_REQUEST, HttpStatus.BAD_REQUEST.value());
        apiError.setMsg("请求参数异常!");
        Throwable exception = ex.getUndeclaredThrowable();
        if(exception instanceof FlowException) {
            apiError = new ApiError(HttpStatus.BAD_REQUEST,CodeEnum.SENTINEL_FLOW_BLOCK.getCode());
            apiError.setMsg(CodeEnum.SENTINEL_FLOW_BLOCK.getMsg());
        } else if(exception instanceof DegradeException) {
            apiError = new ApiError(HttpStatus.BAD_REQUEST,CodeEnum.SENTINEL_DEGRADE_BLOCK.getCode());
            apiError.setMsg(CodeEnum.SENTINEL_DEGRADE_BLOCK.getMsg());
        } else if(exception instanceof ParamFlowException) {
            apiError = new ApiError(HttpStatus.BAD_REQUEST,CodeEnum.SENTINEL_PARAM_FLOW_BLOCK.getCode());
            apiError.setMsg(CodeEnum.SENTINEL_PARAM_FLOW_BLOCK.getMsg());
        } else if(exception instanceof SystemBlockException) {
            apiError = new ApiError(HttpStatus.BAD_REQUEST,CodeEnum.SENTINEL_SYSTEM_BLOCK.getCode());
            apiError.setMsg(CodeEnum.SENTINEL_SYSTEM_BLOCK.getMsg());
        } else if(exception instanceof AuthorityException) {
            apiError = new ApiError(HttpStatus.BAD_REQUEST,CodeEnum.SENTINEL_AUTHORITY_BLOCK.getCode());
            apiError.setMsg(CodeEnum.SENTINEL_AUTHORITY_BLOCK.getMsg());
        }

        return buildResponseEntity(apiError);
    }

    @ExceptionHandler(NoHandlerFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ResponseEntity<Object> myhandleNoHandlerFoundException(NoHandlerFoundException ex) {
        ApiError apiError = new ApiError(HttpStatus.NOT_FOUND, HttpStatus.NOT_FOUND.value());
        apiError.setMsg("url错误,无对应方法:" + ex.getMessage());
        return buildResponseEntity(apiError);
    }

    @ExceptionHandler(value = {ConstraintViolationException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<Object> constraintViolationException(ConstraintViolationException ex) {
        return buildResponseEntity(new ApiError(HttpStatus.BAD_REQUEST, CodeEnum.BAD_REQUEST.getCode()));
    }

    @ExceptionHandler(value = {IllegalArgumentException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<Object> illegalArgumentException(IllegalArgumentException ex) {
        log.error(getStackMsg(ex));
        return buildResponseEntity(new ApiError(HttpStatus.BAD_REQUEST, CodeEnum.BAD_REQUEST.getCode()));
    }

    @ExceptionHandler(value = {Exception.class})
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseEntity<Object> unknownException(Exception ex) {
        log.error(ex);
        return buildResponseEntity(new ApiError(HttpStatus.INTERNAL_SERVER_ERROR, CodeEnum.EXCEPTION.getCode()));
    }


    @ExceptionHandler( value = {BizException.class} )
    public ResponseEntity<Object> findEsException( BizException ex) {
        //ThreadLocal<Set<String>> key = SmsTemplateServiceImpl.getCache();
        //Set<String> set = key.get();
        //if(CollectionUtil.isNotEmpty(set)) {
        //    //TODO:
        //}

       ApiError apiError = new ApiError(HttpStatus.OK, ex.getCode(), ex.getMsg());
        return buildResponseEntity(apiError);
    }

    private ResponseEntity<Object> buildResponseEntity( ApiError apiError) {
        //假如是业务异常，warn.否则 error
        if (apiError.getCode() > 100000000) {
            log.warn(apiError);
        } else {
            log.error(apiError);
        }
        return new ResponseEntity<>(apiError, apiError.getStatus());
    }

    private static String getStackMsg(Exception e) {
        StringBuffer sb = new StringBuffer();
        sb.append(e + "\n");
        StackTraceElement[] stackArray = e.getStackTrace();
        int len = stackArray.length;
        if (len > 2) {
            len = 2;
        }
        for (int i = 0; i < len; i++) {
            StackTraceElement element = stackArray[i];
            sb.append(element.toString() + "\n...");
        }
        return sb.toString();
    }
    public static String getStackTraceInfo(Exception e) {

        StringWriter sw = null;
        PrintWriter pw = null;

        try {
            sw = new StringWriter();
            pw = new PrintWriter(sw);
            e.printStackTrace(pw);
            pw.flush();
            sw.flush();

            return sw.toString();
        } catch (Exception ex) {
            log.warn("error happened when resolving stack trace of exception ", ex);
            return "error happend";
        } finally {
            if (sw != null) {
                try {
                    sw.close();
                } catch (IOException e1) {
                    log.warn("error happened when closing string writer", e1);
                }
            }
            if (pw != null) {
                pw.close();
            }
        }

    }
}

