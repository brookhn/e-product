package com.jiahui.search.searcher.util;

import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.xcontent.LoggingDeprecationHandler;
import org.elasticsearch.common.xcontent.NamedXContentRegistry;
import org.elasticsearch.common.xcontent.XContentParser;
import org.elasticsearch.common.xcontent.XContentType;
import org.elasticsearch.search.SearchModule;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Collections;

@Component
public class EsSerializeUtil {

    private static final NamedXContentRegistry xContentRegistry;

    static {
        SearchModule searchModule =
                new SearchModule(Settings.EMPTY, false, Collections.emptyList());
        xContentRegistry =
                new NamedXContentRegistry(searchModule.getNamedXContents());
    }


    public static SearchSourceBuilder parse(String s) throws IOException {
        XContentParser parser =
                XContentType.JSON.xContent().createParser(xContentRegistry,
                        LoggingDeprecationHandler.INSTANCE,
                        s);

        return SearchSourceBuilder.fromXContent(parser);
    }

    public static SearchResponse parseSearchResponse(String s) throws IOException {
        XContentParser parser =
                XContentType.JSON.xContent().createParser(xContentRegistry,
                        LoggingDeprecationHandler.INSTANCE,
                        s);

        return SearchResponse.fromXContent(parser);
    }


}
