package com.jiahui.search.searcher.service.impl;

import cn.hutool.core.collection.CollectionUtil;
import com.jiahui.search.common.enums.CodeEnum;
import com.jiahui.search.common.exception.BizException;
import com.jiahui.search.searcher.api.module.*;
import com.jiahui.search.searcher.service.SearchService;
import com.jiahui.search.searcher.util.EsObjectUtils;
import com.jiahui.search.searcher.util.EsSerializeUtil;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.client.*;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.elasticsearch.search.fetch.subphase.highlight.HighlightBuilder;
import org.elasticsearch.search.fetch.subphase.highlight.HighlightField;
import org.elasticsearch.search.sort.SortBuilder;
import org.elasticsearch.search.sort.SortBuilders;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.*;

@Slf4j
@Service
public class SearchServiceImpl implements SearchService {


    @Autowired
    private RestHighLevelClient client;

    @Override
    public QueryResponse search(QueryRequest body) {
        org.elasticsearch.action.search.SearchRequest esRequest = new SearchRequest(body.getIndexName());
        org.elasticsearch.action.search.SearchResponse esResponse = null;

        SearchSourceBuilder sourceBuilder = null;
        try {
            sourceBuilder = buildSourceBuilder(body);
        } catch (IOException e) {
            log.error("SearchSourceBuilder deserialization failed.", e);
            throw new BizException(CodeEnum.DESERIALIZATION_FAILED);
        }

        try {
            esRequest.source(sourceBuilder);
            esResponse = client.search(esRequest, RequestOptions.DEFAULT);
        } catch (IOException e) {
            log.error("Search from es failed.", e);
            throw new BizException(CodeEnum.EXCEPTION_ES_SEARCH);
        }
        QueryResponse response = new QueryResponse();
        SearchHits searchHits = esResponse.getHits();

        if(searchHits.getHits().length > 0) {
            response.setTotal(searchHits.getHits().length);
            SearchHit[] hits = searchHits.getHits();
            List<HitItem> datas = EsObjectUtils.transHits(hits);
            response.setHits(datas);
        }

        if(Objects.isNull(esResponse.getAggregations()) || CollectionUtil.isEmpty(esResponse.getAggregations().getAsMap())) {
            return response;
        }

        Aggregations aggregations = esResponse.getAggregations();
        Map<String, Object> aggs = null;
       try{
           aggs = EsObjectUtils.transAggregation(aggregations.getAsMap());
       } catch (Exception e) {
           log.error("trans Aggregations failed", e);
           throw new BizException(CodeEnum.TRANS_AGG_FAILED);
       }
        response.setAggs(aggs);
        return response;
    }

    private SearchSourceBuilder buildSourceBuilder(QueryRequest body) throws IOException {
        SearchSourceBuilder sourceBuilder = EsSerializeUtil.parse(body.getSourceBuilderStr());
        sourceBuilder.from(body.getStart());
        sourceBuilder.size(body.getLimit());
        //设置返回字段
        if(CollectionUtil.isNotEmpty(body.getReturnFields())) {
            sourceBuilder.fetchSource(body.getReturnFields().toArray(new String[0]), null);
        }

        //设置高亮
        if(CollectionUtil.isNotEmpty(body.getHighLightFields())) {
            HighlightBuilder highlightBuilder = sourceBuilder.highlight();
            for(String high: body.getHighLightFields()) {
                highlightBuilder.field(high);
            }
            sourceBuilder.highlighter(highlightBuilder);
        }
        //设置排序
        if(CollectionUtil.isNotEmpty(body.getSortFields())) {
            List<SortBuilder<?>> sortBuilders = new ArrayList<>();
            for(FieldSort fieldSort: body.getSortFields()) {
                SortBuilder builder = SortBuilders.fieldSort(fieldSort.getField()).order(fieldSort.getSortOrder());
                sortBuilders.add(builder);
            }
            sourceBuilder.sort(sortBuilders);
        }
        return sourceBuilder;
    }


}
