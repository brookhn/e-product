package com.jiahui.search.searcher.util;

import cn.hutool.core.collection.CollectionUtil;
import com.jiahui.search.searcher.api.module.HitItem;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.aggregations.Aggregation;
import org.elasticsearch.search.aggregations.ParsedMultiBucketAggregation;
import org.elasticsearch.search.aggregations.bucket.histogram.Histogram;
import org.elasticsearch.search.aggregations.bucket.terms.ParsedStringTerms;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.metrics.ParsedSingleValueNumericMetricsAggregation;
import org.elasticsearch.search.aggregations.metrics.ParsedStats;
import org.elasticsearch.search.fetch.subphase.highlight.HighlightField;

import java.util.*;

/**
 * 数据转换
 *
 * @author ivy.wang
 */
public class EsObjectUtils {

    public static Map<String, Object> transAggregation(Map<String, Aggregation> aggregationMap) {
        if (aggregationMap == null) {
            return Collections.EMPTY_MAP;
        }
        Map<String, Object> result = new HashMap<>();
        aggregationMap.forEach((k, v) -> {
            List<Map> bucketList = new ArrayList<>();

            if (v instanceof ParsedStringTerms) {
                List<? extends Terms.Bucket> buckets = ((ParsedStringTerms) v).getBuckets();
                for (Terms.Bucket bucket : buckets) {
                    Map<String, Object> agg = new HashMap<>();
                    agg.put("key", bucket.getKeyAsString());
                    agg.put("docCount", bucket.getDocCount());
                    if (Objects.nonNull(bucket.getAggregations())) {
                        Map<String, Object> rs = transAggregation(bucket.getAggregations().getAsMap());
                        agg.putAll(rs);
                    }
                    bucketList.add(agg);
                }
            } else if (v instanceof ParsedSingleValueNumericMetricsAggregation) {
                result.put(v.getName(), ((ParsedSingleValueNumericMetricsAggregation) v).value());
                return;
            } else if(v instanceof ParsedStats) {
                Map<String, Object> extendedStats = new HashMap<>();
                for(String name: ((ParsedStats) v).valueNames()) {
                    extendedStats.put(name, ((ParsedStats) v).value(name));
                }
                result.put(k, extendedStats);
                return;
            } else if(v instanceof ParsedMultiBucketAggregation) {
                List<? extends Histogram.Bucket> buckets = (List<? extends Histogram.Bucket>) ((ParsedMultiBucketAggregation) v).getBuckets();
                for (Histogram.Bucket bucket : buckets) {
                    Map<String, Object> agg = new HashMap<>();
                    agg.put("key", bucket.getKeyAsString());
                    agg.put("docCount", bucket.getDocCount());
                    if (Objects.nonNull(bucket.getAggregations())) {
                        Map<String, Object> rs = transAggregation(bucket.getAggregations().getAsMap());
                        agg.putAll(rs);
                    }
                    bucketList.add(agg);
                }
            }

            result.put(k, bucketList);
        });
        return result;
    }

    public static List<HitItem> transHits( SearchHit[] hits ) {
        if(hits.length == 0) {
            return Collections.EMPTY_LIST;
        }
        List<HitItem> datas = new ArrayList<HitItem>(hits.length);
        for(SearchHit hit: hits) {
            HitItem data = new HitItem(hit.getId(), hit.getSourceAsMap());
            Map<String, HighlightField> highlightFieldMap = hit.getHighlightFields();
            if(CollectionUtil.isNotEmpty(highlightFieldMap)) {
                Map<String, String> highlights = new HashMap<>();
                for(String key: highlightFieldMap.keySet()) {
                    highlights.put(key, highlightFieldMap.get(key).fragments()[0].string());
                }
                data.setHighlights(highlights);
            }
            datas.add(data);
        }
        return datas;
    }
}
