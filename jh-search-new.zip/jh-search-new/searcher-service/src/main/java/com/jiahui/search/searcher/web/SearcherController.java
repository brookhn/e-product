package com.jiahui.search.searcher.web;

import com.alibaba.csp.sentinel.slots.block.flow.FlowRuleManager;
import com.jiahui.search.common.rest.JsonResult;
import com.jiahui.search.searcher.api.module.*;
import com.jiahui.search.searcher.service.AppService;
import com.jiahui.search.searcher.service.SearchService;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Api( tags = "查询")
@RestController
@RequestMapping("/searcher")
public class SearcherController {

    @Autowired
    AppService appService;

    @Autowired
    SearchService searchService;

    @PostMapping("/search")
    public JsonResult<QueryResponse> search(@RequestBody QueryRequest request){

        QueryResponse response = searchService.search(request);
        return JsonResult.success(response);
    }

    @GetMapping("/test")
    public JsonResult test( ){

        System.out.println( FlowRuleManager.getRules());
        return JsonResult.success();
    }
}
