package com.jiahui.search.searcher.web;

import cn.hutool.json.JSONUtil;
import com.jiahui.search.searcher.SearcherApplication;
import com.jiahui.search.searcher.api.module.QueryResponse;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.search.aggregations.Aggregation;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.ParsedMultiBucketAggregation;
import org.elasticsearch.search.aggregations.bucket.histogram.*;
import org.elasticsearch.search.aggregations.bucket.terms.ParsedStringTerms;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.TermsAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.*;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.elasticsearch.search.sort.SortOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.io.IOException;
import java.util.*;



@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = SearcherApplication.class)
public class SearcherControllerTest {

    @Autowired
    RestHighLevelClient client;


    @Test
    public void testAggs2() {

        SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
        sourceBuilder.from(1);
        sourceBuilder.size(0);

        TermsAggregationBuilder a1 = AggregationBuilders.terms("popular_color").field("color");

        ExtendedStatsAggregationBuilder extendedStatsAggregationBuilder = AggregationBuilders.extendedStats("stats").field("price");
        a1.subAggregation(extendedStatsAggregationBuilder);


        TermsAggregationBuilder sub1 = AggregationBuilders.terms("make").field("make");
        sub1.subAggregation(AggregationBuilders.min("min_price").field("price"));
        sub1.subAggregation(AggregationBuilders.max("max_price").field("price"));
        a1.subAggregation(sub1);


        sourceBuilder.aggregation(a1);

        org.elasticsearch.action.search.SearchRequest searchRequest = new SearchRequest("cars");
        searchRequest.source(sourceBuilder);
        System.out.println(searchRequest);
        System.out.println("=============================================================");
        SearchResponse esReaponse = null;
        try {
            esReaponse = client.search(searchRequest, RequestOptions.DEFAULT);
            System.out.println(esReaponse);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        QueryResponse response = new QueryResponse();

        Aggregations aggregations = esReaponse.getAggregations();
        Map<String, Object> aggs = getAggregation3(aggregations.getAsMap());
        System.out.println(JSONUtil.toJsonPrettyStr(aggs));
    }

    @Test
    public void testAggs3() {

        SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
        sourceBuilder.size(0);
        HistogramAggregationBuilder h1 = AggregationBuilders.histogram("price_data").field("price").interval(20000);

        SumAggregationBuilder sumAggregationBuilder =AggregationBuilders.sum("revenue").field("price");
        h1.subAggregation(sumAggregationBuilder);
        sourceBuilder.aggregation(h1);
        sourceBuilder.sort("price", SortOrder.ASC);

//        DateHistogramAggregationBuilder dateHistogramAggregationBuilder =AggregationBuilders
//                .dateHistogram("sales")
//                .field("sold")
//                .calendarInterval(DateHistogramInterval.MONTH)
//                .format("yyyy-MM-dd")
//                .minDocCount(0) //in_doc_count 非常容易理解：它强制返回所有 buckets，即使 buckets 可能为空。
//                .extendedBounds(new LongBounds("2014-01-01", "2014-12-01"));//
//
//        sourceBuilder.aggregation(dateHistogramAggregationBuilder);

        org.elasticsearch.action.search.SearchRequest searchRequest = new SearchRequest("cars");
        searchRequest.source(sourceBuilder);
        System.out.println(searchRequest);
        System.out.println("=============================================================");
        SearchResponse esReaponse = null;
        try {
            esReaponse = client.search(searchRequest, RequestOptions.DEFAULT);
            System.out.println(esReaponse);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        QueryResponse response = new QueryResponse();

        Aggregations aggregations = esReaponse.getAggregations();
        Map<String, Object> aggs = getAggregation3(aggregations.getAsMap());
        System.out.println(JSONUtil.toJsonPrettyStr(aggs));
    }

    private Map<String, Object> getAggregation3(Map<String, Aggregation> aggregationMap) {
        if (aggregationMap == null) {
            return Collections.EMPTY_MAP;
        }
        Map<String, Object> result = new HashMap<>();
        aggregationMap.forEach((k, v) -> {
            List<Map> bucketList = new ArrayList<>();

            if (v instanceof ParsedStringTerms) {
                List<? extends Terms.Bucket> buckets = ((ParsedStringTerms) v).getBuckets();
                for (Terms.Bucket bucket : buckets) {
                    Map<String, Object> agg = new HashMap<>();
                    agg.put("key", bucket.getKeyAsString());
                    agg.put("docCount", bucket.getDocCount());
                    if (Objects.nonNull(bucket.getAggregations())) {
                        Map<String, Object> rs = getAggregation3(bucket.getAggregations().getAsMap());

                        agg.putAll(rs);
                    }
                    bucketList.add(agg);
                }
            } else if (v instanceof ParsedSingleValueNumericMetricsAggregation) {
                result.put(v.getName(), ((ParsedSingleValueNumericMetricsAggregation) v).value());
                return;
            } else if(v instanceof ParsedStats) {
                Map<String, Object> extendedStats = new HashMap<>();
                for(String name: ((ParsedStats) v).valueNames()) {
                    extendedStats.put(name, ((ParsedStats) v).value(name));
                }
                result.put(k, extendedStats);
                return;
            } else if(v instanceof ParsedMultiBucketAggregation) {
                List<? extends Histogram.Bucket> buckets = (List<? extends Histogram.Bucket>) ((ParsedMultiBucketAggregation) v).getBuckets();
                for (Histogram.Bucket bucket : buckets) {
                    Map<String, Object> agg = new HashMap<>();
                    agg.put("key", bucket.getKeyAsString());
                    agg.put("docCount", bucket.getDocCount());
                    if (Objects.nonNull(bucket.getAggregations())) {
                        Map<String, Object> rs = getAggregation3(bucket.getAggregations().getAsMap());

                        agg.putAll(rs);
                    }
                    bucketList.add(agg);
                }
            }

            result.put(k, bucketList);
        });
        return result;
    }

    /**
     *
     */
    @Test
    public void testAggs1() {

        SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
        sourceBuilder.from(1);
        sourceBuilder.size(0);

        TermsAggregationBuilder a1 = AggregationBuilders.terms("popular_color").field("color");
        AvgAggregationBuilder avg1 = AggregationBuilders.avg("avg_price").field("price");
        a1.subAggregation(avg1);

        TermsAggregationBuilder sub1 = AggregationBuilders.terms("make").field("make");
        sub1.subAggregation(AggregationBuilders.min("min_price").field("price"));
        sub1.subAggregation(AggregationBuilders.max("max_price").field("price"));
        a1.subAggregation(sub1);


        sourceBuilder.aggregation(a1);

        org.elasticsearch.action.search.SearchRequest searchRequest = new SearchRequest("cars");
        searchRequest.source(sourceBuilder);
        System.out.println(searchRequest);
        System.out.println("=============================================================");
        SearchResponse esReaponse = null;
        try {
            esReaponse = client.search(searchRequest, RequestOptions.DEFAULT);
            System.out.println(esReaponse);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        QueryResponse response = new QueryResponse();

        Aggregations aggregations = esReaponse.getAggregations();
        Map<String, Object> aggs = getAggregation2(aggregations.getAsMap());
        System.out.println(JSONUtil.toJsonPrettyStr(aggs));
    }

    private Map<String, Object> getAggregation(Map<String, Aggregation> aggregationMap) {
        if (aggregationMap == null) {
            return Collections.EMPTY_MAP;
        }
        Map<String, Object> result = new HashMap<>();
        aggregationMap.forEach((k, v) -> {
            List<Map> bucketList = new ArrayList<>();

            if (v instanceof ParsedStringTerms) {
                List<? extends Terms.Bucket> buckets = ((ParsedStringTerms) v).getBuckets();
                for (Terms.Bucket bucket : buckets) {
                    Map<String, Object> agg = new HashMap<>();
                    agg.put(bucket.getKeyAsString(), bucket.getDocCount());
                    if (Objects.nonNull(bucket.getAggregations())) {
                        Map<String, Object> rs = getAggregation(bucket.getAggregations().getAsMap());

                        agg.putAll(rs);
                    }
                    bucketList.add(agg);
                }
            } else if (v instanceof ParsedSingleValueNumericMetricsAggregation) {
                result.put(v.getName(), ((ParsedSingleValueNumericMetricsAggregation) v).value());
                return;
            }

            result.put(k, bucketList);
        });
        return result;
    }

    private Map<String, Object> getAggregation2(Map<String, Aggregation> aggregationMap) {
        if (aggregationMap == null) {
            return Collections.EMPTY_MAP;
        }
        Map<String, Object> result = new HashMap<>();
        aggregationMap.forEach((k, v) -> {
            List<Map> bucketList = new ArrayList<>();

            if (v instanceof ParsedStringTerms) {
                List<? extends Terms.Bucket> buckets = ((ParsedStringTerms) v).getBuckets();
                for (Terms.Bucket bucket : buckets) {
                    Map<String, Object> agg = new HashMap<>();
                    agg.put("key", bucket.getKeyAsString());
                    agg.put("doc_count", bucket.getDocCount());
//                    agg.put(bucket.getKeyAsString(), bucket.getDocCount());
                    if (Objects.nonNull(bucket.getAggregations())) {
                        Map<String, Object> rs = getAggregation2(bucket.getAggregations().getAsMap());

                        agg.putAll(rs);
                    }
                    bucketList.add(agg);
                }
            } else if (v instanceof ParsedSingleValueNumericMetricsAggregation) {
                result.put(v.getName(), ((ParsedSingleValueNumericMetricsAggregation) v).value());
                return;
            }

            result.put(k, bucketList);
        });
        return result;
    }
}