package com.jiahui.search.searcher.api;

import cn.hutool.json.JSONUtil;
import com.jiahui.search.searcher.SearcherApplication;
import com.jiahui.search.searcher.api.module.QueryRequest;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.MultiMatchQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.terms.TermsAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.AvgAggregationBuilder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.io.IOException;
import java.util.*;


@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = SearcherApplication.class)
public class SearcherApiTest {

    /**
     *
     */
    @Test
    public void testAggs1() throws IOException {
        QueryRequest queryRequest = new QueryRequest();

        MultiMatchQueryBuilder matchQueryBuilder4 = QueryBuilders.multiMatchQuery("brown dog", "*title", "body");
        BoolQueryBuilder boolBuilder = QueryBuilders.boolQuery();
        boolBuilder.should(matchQueryBuilder4);
        queryRequest.setBoolQueryBuilder(boolBuilder);

        TermsAggregationBuilder a1 = AggregationBuilders.terms("popular_color").field("color");
        AvgAggregationBuilder avg1 = AggregationBuilders.avg("avg_price").field("price");
        a1.subAggregation(avg1);

        TermsAggregationBuilder sub1 = AggregationBuilders.terms("make").field("make");
        sub1.subAggregation(AggregationBuilders.min("min_price").field("price"));
        sub1.subAggregation(AggregationBuilders.max("max_price").field("price"));
        a1.subAggregation(sub1);

        queryRequest.setAggregationBuilder(a1);

        String s = JSONUtil.toJsonPrettyStr(queryRequest);
        System.out.println(s);

        QueryRequest qq = JSONUtil.toBean(s, QueryRequest.class);
        System.out.println(qq.getSourceBuilderStr());


    }

}