package com.jiahui.oss.contract.vo.in;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.http.entity.ContentType;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @Description
 * @Author Garen
 * @Date 2021年03月24日 13:14
 */
//@Data
@ApiModel(value = "UploadBasedResourceStringInVO", description = "基于String上传资源")
public class UploadBasedResourceStringInVO implements Serializable {

    /**
     * 资源String
     */
    @NotBlank
    @ApiModelProperty(value = "String类型资源", required = true)
    private String resourceString;

    /**
     * 是否需要校验参数
     */
    @NotNull
    @ApiModelProperty(value = "是否需要校验参数 true 需要 false 不需要", required = true)
    private Boolean validatedRequired;

    /**
     * 校验令牌 - 非对称算法
     */
    @ApiModelProperty(value = "校验参数token")
    private String validatedToken;

    /**
     * 资源桶名称
     */
    @NotBlank
    @ApiModelProperty(value = "桶名称", required = true)
    private String bucket;

//    @NotBlank
    @ApiModelProperty(value = "上传文件名称")
    private String fileName;

    @ApiModelProperty(value = "上传资源类型")
    private String contentType = ContentType.APPLICATION_OCTET_STREAM.getMimeType();

    /**
     * 文件路径名称--计算生成
     */
//    private String fileName;


    public String getResourceString() {
        return resourceString;
    }

    public void setResourceString(String resourceString) {
        this.resourceString = resourceString;
    }

    public Boolean getValidatedRequired() {
        return validatedRequired;
    }

    public void setValidatedRequired(Boolean validatedRequired) {
        this.validatedRequired = validatedRequired;
    }

    public String getValidatedToken() {
        return validatedToken;
    }

    public void setValidatedToken(String validatedToken) {
        this.validatedToken = validatedToken;
    }

    public String getBucket() {
        return bucket;
    }

    public void setBucket(String bucket) {
        this.bucket = bucket;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
}
