package com.jiahui.oss.contract.vo.in;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotNull;

@ApiModel(value = "GetUploadParamInVO", description = "获取临时访问oss参数")
public class GetAccessResouceInVO {

    @NotNull
    @ApiModelProperty(value = "桶名称", required = true)
    private String bucketName;

    @ApiModelProperty(value = "过期时间")
    @NotNull
    private Integer expireTime;

    public String getBucketName() {
        return bucketName;
    }

    public void setBucketName(String bucketName) {
        this.bucketName = bucketName;
    }

    public Integer getExpireTime() {
        return expireTime;
    }

    public void setExpireTime(Integer expireTime) {
        this.expireTime = expireTime;
    }

    @Override
    public String toString() {
        return "GetAccessResouceInVO{" +
                "bucketName='" + bucketName + '\'' +
                ", expireTime=" + expireTime +
                '}';
    }
}
