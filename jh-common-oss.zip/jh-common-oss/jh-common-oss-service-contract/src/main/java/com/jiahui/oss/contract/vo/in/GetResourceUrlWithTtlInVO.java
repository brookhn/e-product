package com.jiahui.oss.contract.vo.in;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @Description
 * @Author Garen
 * @Date 2021年03月23日 13:13
 */
//@Data
//@NoArgsConstructor
//@AllArgsConstructor
@ApiModel(value = "GetResourceUrlWithTtlInVO", description = "获取访问bucket资源URL")
public class GetResourceUrlWithTtlInVO implements Serializable {

    public GetResourceUrlWithTtlInVO(@NotBlank String bucketName, @NotBlank String objectName, @NotNull @Range(min = 0, max = 604800) Integer expires) {
        this.bucketName = bucketName;
        this.objectName = objectName;
        this.expires = expires;
    }

    public GetResourceUrlWithTtlInVO(@NotBlank String bucketName, @NotBlank String objectName, @NotNull @Range(min = 0, max = 604800) Integer expires, String picOption) {
        this.bucketName = bucketName;
        this.objectName = objectName;
        this.expires = expires;
        this.picOption = picOption;
    }

    public GetResourceUrlWithTtlInVO() {
    }

    /**
     * bucket名称
     */
    @NotBlank
    @ApiModelProperty(value = "桶名称", required = true)
    private String bucketName;

    /**
     * 文件路径
     */
    @NotBlank
    @ApiModelProperty(value = "文件名称", required = true)
    private String objectName;

    /**
     * url有效期 s级时间戳
     */
    @NotNull
    @Range(min = 0, max = 604800)
    @ApiModelProperty(value = "url有效期 单位为秒 范围 0-604800", required = true)
    private Integer expires;

    @ApiModelProperty(value = "图片的缩放操作 取值说明:0x0,200x,x0.15,100x150,100,150,fit,100,r90,cw100,ch100", notes = "")
    private String picOption;


    public String getBucketName() {
        return bucketName;
    }

    public void setBucketName(String bucketName) {
        this.bucketName = bucketName;
    }

    public String getObjectName() {
        return objectName;
    }

    public void setObjectName(String objectName) {
        this.objectName = objectName;
    }

    public Integer getExpires() {
        return expires;
    }

    public void setExpires(Integer expires) {
        this.expires = expires;
    }

    public String getPicOption() {
        return picOption;
    }

    public void setPicOption(String picOption) {
        this.picOption = picOption;
    }
}
