package com.jiahui.oss.contract.vo.in;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @Description
 * @Author Garen
 * @Date 2021年03月23日 13:56
 */
//@Data
@ApiModel(value = "GetUploadParamInVO", description = "获取桶访问资源参数")
public class GetUploadParamInVO implements Serializable {

    @NotBlank
    @ApiModelProperty(value = "资源类型", required = true)
    private Integer bizType;

    public Integer getBizType() {
        return bizType;
    }

    public void setBizType(Integer bizType) {
        this.bizType = bizType;
    }
}