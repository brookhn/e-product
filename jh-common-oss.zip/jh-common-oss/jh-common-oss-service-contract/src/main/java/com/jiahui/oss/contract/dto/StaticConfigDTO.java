package com.jiahui.oss.contract.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * js 端minio访问参数
 */

public class StaticConfigDTO implements Serializable {

    //minio访问端点
    private String endPoint;
    //minio访问接口
    private Integer port;
    //minio访问key
    private String accessKey;
    //minio访问密钥
    private String secretKey;
    //minio访问token
    private String sesionToken;
    //minio访问token到期时间
    private Long expireTimeStamp;


    public String getEndPoint() {
        return endPoint;
    }

    public void setEndPoint(String endPoint) {
        this.endPoint = endPoint;
    }

    public Integer getPort() {
        return port;
    }

    public void setPort(Integer port) {
        this.port = port;
    }

    public String getAccessKey() {
        return accessKey;
    }

    public void setAccessKey(String accessKey) {
        this.accessKey = accessKey;
    }

    public String getSecretKey() {
        return secretKey;
    }

    public void setSecretKey(String secretKey) {
        this.secretKey = secretKey;
    }

    public String getSesionToken() {
        return sesionToken;
    }

    public void setSesionToken(String sesionToken) {
        this.sesionToken = sesionToken;
    }

    public Long getExpireTimeStamp() {
        return expireTimeStamp;
    }

    public void setExpireTimeStamp(Long expireTimeStamp) {
        this.expireTimeStamp = expireTimeStamp;
    }
}
