package com.jiahui.oss.contract;

import com.jiahui.oss.contract.config.FeignSupportConfig;
import com.jiahui.oss.contract.vo.in.*;
import com.jiahui.oss.contract.vo.out.*;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@Component
@FeignClient(value = "jh-common-oss", configuration = FeignSupportConfig.class)
public interface OssClientService {

    @PostMapping(path = "/jh-common-oss/v1/oss/getUploadParam",headers = {"Content-Type=application/json;charset=UTF-8"})
    JsonOut<GetUploadParamOutVO> getUploadParam(@RequestBody @Validated GetUploadParamInVO inVO);

    @PostMapping(path = "/jh-common-oss/v1/oss/removeStaticResource",headers = {"Content-Type=application/json;charset=UTF-8"})
    JsonOut<GetRemoveResouceOutVO> removeResouce(@RequestBody @Validated GetRemoveResouceInVO removeResouceInVO);

    /**
     * 客户端获取上传参数 accesskey, accessAccount, url 等
     * @param inVO
     * @return
     */
    @PostMapping(path = "/jh-common-oss/v1/oss/getAccessResource",headers = {"Content-Type=application/json;charset=UTF-8"})
    JsonOut<EphemeralAccessResourceOutVo> getAccessResource(@RequestBody @Validated GetAccessResouceInVO inVO);

    /**
     * 获取资源路径URL--TTL
     * @param inVO
     * @return
     */
    @PostMapping(path = "/jh-common-oss/v1/oss/getResourceUrlWithTtl",headers = {"Content-Type=application/json;charset=UTF-8"})
    JsonOut<GetResourceUrlOutVO> getResourceUrlWithTtl(@RequestBody @Validated GetResourceUrlWithTtlInVO inVO);

    /**
     * 获取资源路径URL--TTL
     * @param inVO
     * @return
     */
    @PostMapping(path = "/jh-common-oss/v1/oss/getResourceUrlWithTtlAndPicHandle",headers = {"Content-Type=application/json;charset=UTF-8"})
    JsonOut<GetResourceUrlOutVO> getResourceUrlWithTtlAndPicHandler(@RequestBody @Validated GetResourceUrlWithTtlInVO inVO);

    /**
     * 基于资源String(Base64)上传资源
     * @param inVO
     * @return
     */
    @PostMapping(path = "/jh-common-oss/v1/oss/uploadBasedResourceString",headers = {"Content-Type=application/json;charset=UTF-8"})
    JsonOut<UploadResourceOutVO> uploadBasedResourceString(@RequestBody @Validated UploadBasedResourceStringInVO inVO);

    /**
     * 基于MultipartFile上传资源
     * @param inVO
     * @return
     */
    @PostMapping(path = "/jh-common-oss/v1/oss/uploadBasedResourceMultiPartFile",
            headers= {"Content-Type=multipart/form-data"},
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    JsonOut<UploadResourceOutVO> uploadBaseResourceMultiPartFile(@Validated UploadBasedResourceMultiPartInVO inVO);

}
