package com.jiahui.oss.contract.vo.in;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @Description
 * @Author Garen
 * @Date 2021年03月29日 13:16
 */
@NoArgsConstructor
@AllArgsConstructor
public class GetResourceUrlBasedKeyInVO {

    @NotBlank
    private String bucketName;

    @NotBlank
    private String resourceKey;

    /**
     * url有效期 s级时间戳
     */
    @NotNull
    @Range(min = 0, max = 604800)
    private Integer expires;

    public String getBucketName() {
        return bucketName;
    }

    public void setBucketName(String bucketName) {
        this.bucketName = bucketName;
    }

    public String getResourceKey() {
        return resourceKey;
    }

    public void setResourceKey(String resourceKey) {
        this.resourceKey = resourceKey;
    }

    public Integer getExpires() {
        return expires;
    }

    public void setExpires(Integer expires) {
        this.expires = expires;
    }

    @Override
    public String toString() {
        return "GetResourceUrlBasedKeyInVO{" +
                "bucketName='" + bucketName + '\'' +
                ", resourceKey='" + resourceKey + '\'' +
                ", expires=" + expires +
                '}';
    }
}
