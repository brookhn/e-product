package com.jiahui.oss.contract.vo.in;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @Description
 * @Author Garen
 * @Date 2021年03月23日 13:13
 */
//@Data
//@NoArgsConstructor
//@AllArgsConstructor
@ApiModel(value = "GetRemoveResouceInVO", description = "删除资源")
public class GetRemoveResouceInVO implements Serializable {


    /**
     * bucket名称
     */
    @NotBlank
    @ApiModelProperty(value = "桶名称", required = true)
    private String bucketName;

    /**
     * 文件路径
     */
    @NotBlank
    @ApiModelProperty(value = "文件名称", required = true)
    private String objectName;


    public String getBucketName() {
        return bucketName;
    }

    public void setBucketName(String bucketName) {
        this.bucketName = bucketName;
    }

    public String getObjectName() {
        return objectName;
    }

    public void setObjectName(String objectName) {
        this.objectName = objectName;
    }

    @Override
    public String toString() {
        return "GetRemoveResouceInVO{" +
                "bucketName='" + bucketName + '\'' +
                ", objectName='" + objectName + '\'' +
                '}';
    }
}
