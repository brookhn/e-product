package com.jiahui.oss.contract.vo.in;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.http.entity.ContentType;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

/**
 * @Description
 * @Author Garen
 * @Date 2021年03月24日 13:14
 */
//@Data
@ApiModel(value = "UploadBasedResourceMultiPartInVO", description = "获取桶访问资源参数")
public class UploadBasedResourceMultiPartInVO implements Serializable {

    @NotBlank
    @ApiModelProperty(value = "上传文件资源", required = true)
    private MultipartFile multipartFile;

    /**
     * 资源桶名称
     */
    @NotBlank
    @ApiModelProperty(value = "桶名称", required = true)
    private String bucket;


    @NotBlank
    @ApiModelProperty(value = "文件名称", required = true)
    private String fileName;

    @ApiModelProperty(value = "文件类型")
    private String contentType = ContentType.APPLICATION_OCTET_STREAM.getMimeType();

    public MultipartFile getMultipartFile() {
        return multipartFile;
    }

    public void setMultipartFile(MultipartFile multipartFile) {
        this.multipartFile = multipartFile;
    }

    public String getBucket() {
        return bucket;
    }

    public void setBucket(String bucket) {
        this.bucket = bucket;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }
}
