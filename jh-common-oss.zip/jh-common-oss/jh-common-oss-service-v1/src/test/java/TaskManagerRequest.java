public class TaskManagerRequest {
    private final String type;

    private final long ts;

    public TaskManagerRequest(String type, long ts){
        this.type = type;
        this.ts = ts;
    }

    public String getType(){
        return type;
    }

    public long getTs(){
        return ts;
    }
}
