public class InitRequest {
    private final int taskManager;

    public InitRequest(int taskManager){
        this.taskManager = taskManager;
    }

    public int getTaskManager(){
        return taskManager;
    }
}
