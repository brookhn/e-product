import com.alibaba.ttl.threadpool.TtlExecutors;

import java.util.concurrent.*;

public class ClientThread {

//    static ExecutorService executorService = Executors.newFixedThreadPool(1);
//    static ExecutorService asynchExecutorService = Executors.newFixedThreadPool(1);
//    static ExecutorService ttlExecutorService;
//    static CountDownLatch downLatch = new CountDownLatch(1);
//    static {
//        new Thread(()->{
//            asynchExecutorService.execute(()->{
//                System.out.println("init thread pool");
//            });
//            ttlExecutorService = TtlExecutors.getTtlExecutorService(asynchExecutorService);
//            ttlExecutorService.execute(()->{
//                System.out.println("----------------");
//            });
//            downLatch.countDown();
//        }).start();
//    }


   volatile   int x = 10;

    public static void main(String[] args) {
        ClientThread clientThread = new ClientThread();
        int y = 100;


        FutureTask task = new FutureTask(()->{
           clientThread.x = 100;
           System.out.println(clientThread.x+" client THread 1 xxx");
            return clientThread.x;
        });

        FutureTask task2 = new FutureTask(()->{
            clientThread.x = 300;
            System.out.println(clientThread.x+" client THread 2 xxx");
            return clientThread.x;
        });

       new Thread(task).start();
       new Thread(task2).start();
        try {
            task.get();
            task2.get();
            System.out.println(clientThread.x +"  main thread x");
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }


//        try {
//            downLatch.wait();
//        } catch (InterruptedException e) {
//
//        }
    }
}
