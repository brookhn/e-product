import akka.actor.AbstractActor;
import akka.actor.Props;

public class TaskManager extends AbstractActor {
    static Props props(){
        return Props.create(JobManager.class, JobManager::new);
    }

    @Override
    public Receive createReceive() {
        return receiveBuilder().match(InitRequest.class, message->{
            System.out.println("init begin....");
            for (int i =0; i< message.getTaskManager();i++){
                getContext().actorOf(TaskManager.props(), "taskManager-"+i);
            }
        }).build();
    }
}
