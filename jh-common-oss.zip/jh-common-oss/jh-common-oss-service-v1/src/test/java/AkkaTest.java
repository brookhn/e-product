//import akka.actor.ActorRef;
//import akka.actor.ActorSystem;
//
//public class AkkaTest {
//    public static void main(String[] args) {
//        ActorSystem actorSystem = ActorSystem.create();
//        ActorRef jobManager = actorSystem.actorOf(JobManager.props(), "jobManager");
//        System.out.println(jobManager);
//        jobManager.tell("init", ActorRef.noSender());
//    }
//}
