import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

public class FutureTest {

    public static int[] getNext(String ps){
        char[] chars = ps.toCharArray();
        int[] next = new int[chars.length];
        next[0] = -1;
        int k = -1;
        int j = 0;
        while (j< chars.length-1) {
            if (k == -1 || chars[k] == chars[j]) {
                j++;
                k++;
                next[j] = k;
            } else {
                k = next[k];
            }
        }
        return next;
    }


    public static int Fibonacci(int n) {
        if (n<=2){
            return 1;
        }
        Map<Integer, Integer> tempMap = new HashMap<>();
        tempMap.put(1, 1);
        tempMap.put(2, 1);
        for (int i= 3; i<= n ; i++){
            int tmpValue = tempMap.get(i-1)+ tempMap.get(i-2);
            if (n == i){
                return tmpValue;
            }
            tempMap.put(i, tmpValue);
        }
        return -1;
    }

    private int[] d= {0};
    private int[] conins = {1, 3, 5};

    public  void coin(int i, int target){
        if (i == 0){
            d[0] = 0;
            coin(i+1 , target);
        }else {
            AtomicInteger min = new AtomicInteger(99999);
            Arrays.stream(conins).forEach(con -> {
                if (i >= con && d[i - con] + 1 <= min.get()) {
                    min.set(d[i - con] + 1);
                }
            });
            d[i] = min.get();
            if (i < target) {
                coin(i + 1, target);
            }
        }
    }

    private int m = 10;
    private int n = 10;
    private int[][] chessCoins = new int[m][n];



    public static Integer getPriceLevel1() throws InterruptedException {
        Thread.sleep(1000);
        return 10;
    }

    public static Integer getPriceLevel2(){
        return 20;
    }

    public static ConcurrentHashMap<String, Integer> map = new ConcurrentHashMap();

    public static void save(String key, Integer value){
        map.put(key, value);
        System.out.println("key:"+ key+" value:"+ value);
    }


    public static void main(String[] args) throws ExecutionException, InterruptedException {
        ThreadLocal<Integer> threadLocal = new ThreadLocal<>();
//        Object obj = new Object();
//        System.out.println(ClassLayout.parseInstance(obj).toPrintable());
//        System.gc();
//        System.out.println(ClassLayout.parseInstance(obj).toPrintable());
//---------------------------------------------------------------------------
//        coin
//        FutureTest futureTest = new FutureTest();
//        int sum = 10;
//        futureTest.d = new int[sum+3];
//        futureTest.coin(0, sum);
//        AtomicInteger integer = new AtomicInteger(-1);
//        Arrays.stream(futureTest.d).forEach(value->{
//            System.out.println(value+"-----"+ integer.incrementAndGet());
//        });
//---------------------------------------------------------------------------
//          List<String> list = Arrays.asList("abc", "cbd", "efg");
//          long size = list.stream().filter(String::isEmpty).count();
//          System.out.println(size);
//        TransactionAspectSupport transactionAspectSupport;
//---------------------------------------------------------------------------
//        Runnable runnable = ()->{System.out.println("---------");};
//        CompletableFuture.runAsync(runnable);
//        CompletableFuture<String> future = CompletableFuture.supplyAsync(()->{
//
//            return "Hello World";
//        });
//        String result = future.get();
//        System.out.println(result+"------");
//        CompletableFuture<String> aCompletableFuture = CompletableFuture.supplyAsync(()->{
//            try {
//                Thread.sleep(10);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//            if (new Random().nextInt()%2 == 0){
//               int i = 12/0;
//           }
//           System.out.println("execution game over");
//           return "helloworld";
//        });
//        aCompletableFuture.whenComplete(new BiConsumer<String, Throwable>() {
//            @Override
//            public void accept(String s, Throwable throwable) {
//                System.out.println(s+" execution ok!");
//            }
//        });
//        aCompletableFuture.exceptionally(new Function<Throwable, String>() {
//            @Override
//            public String apply(Throwable throwable) {
//                System.out.println(" execution failure " + throwable.getMessage());
//                return "exception occurence";
//            }
//        });
//        aCompletableFuture.get();

//        String nextChar = "abcdefdabefsabee";
//        StringBuilder nextArray = new StringBuilder();
//        AtomicInteger integer = new AtomicInteger(0);
//        Arrays.stream(FutureTest.getNext(nextChar)).forEach(intConsumer->{
//            nextArray.append(intConsumer).append("-").append(nextChar.toCharArray()[integer.get()]).append(",");
//            integer.incrementAndGet();
//        });
//        System.out.println(nextArray.toString());
//
//        FutureTask task = new FutureTask(new Callable() {
//            @Override
//            public Object call() throws Exception {
//                System.out.println("run with callable way");
//                Thread.sleep(3000);
//                return null;
//            }
//        });
//        new Thread(task).start();
//        ExecutorService executorService = Executors.newFixedThreadPool(2);
//        Future<Integer> f1 = executorService.submit(()->getPriceLevel1());
//        Future<Integer> f2 = executorService.submit(()->getPriceLevel2());
//
//        executorService.execute(()-> {
//            try {
//                save("f1", f1.get());
//                System.out.println("execute f2 operation "+ f1.get());
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            } catch (ExecutionException e) {
//                e.printStackTrace();
//            }
//        });
//
//        executorService.execute(()-> {
//            try {
//                System.out.println("execute f2 operation "+ f2.get());
//                save("f2", f2.get());
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            } catch (ExecutionException e) {
//                e.printStackTrace();
//            }
//        });
//        map.forEach((key, val)->{
//            System.out.println("key:"+ key+ " value:"+val);
//        });

//        BiConsumer<String, String> greet =(k, v)->{System.out.println(k+" "+ v);};
//        greet.accept("map-key", "map-value");
// ---------------------------------------------------------------
//        ExecutorService excutor = Executors.newFixedThreadPool(2);
//        CompletionService<Integer> cs = new ExecutorCompletionService<>(excutor);
//        cs.submit(()->getPriceLevel1());
//        cs.submit(()->getPriceLevel2());
//        for (int i = 0; i< 2; i++){
//            Integer value = cs.take().get();
//            excutor.execute(()->save("i", value));
// ---------------------------------------------------------------
//            int resultF = Fibonacci(4);
//            System.out.println(resultF);
//            resultF = Fibonacci(13);
//        System.out.println(13+"==="+resultF);
//        resultF = Fibonacci(14);
//        System.out.println(14+"==="+resultF);
//        resultF = Fibonacci(15);
//        System.out.println(15+"==="+resultF);
//        resultF = Fibonacci(16);
//        System.out.println(16+"==="+resultF);
//        Thread thread = new Thread(()->{System.out.println("test");});
//        }
    }
}
