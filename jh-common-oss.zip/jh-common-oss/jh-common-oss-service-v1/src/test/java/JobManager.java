import akka.actor.AbstractActor;
import akka.actor.ActorRef;
import akka.actor.Props;

import java.util.Enumeration;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

public class JobManager extends AbstractActor {
    static Props props(){
        return Props.create(JobManager.class, JobManager::new);
    }

    private ConcurrentHashMap<ActorRef, Long> heartBeat;

    private volatile boolean isRunning = false;

    @Override
    public void preStart() throws Exception {
        heartBeat = new ConcurrentHashMap<>();
        new Thread(()->{
            while (true) {
                if (!isRunning) checkHearbeat();
                try {
                    TimeUnit.SECONDS.sleep(10);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    private void checkHearbeat(){
        long currentTimes = System.currentTimeMillis();
        Enumeration<ActorRef> keys = heartBeat.keys();
        while (keys.hasMoreElements()){
            ActorRef ref = keys.nextElement();
            if (currentTimes - 5000> heartBeat.get(ref)){
                System.out.println(ref+" shutdown , try close it....");
                getContext().stop(ref);
            }
        }
    }

    @Override
    public Receive createReceive() {
        //return receiveBuilder().build();
        return receiveBuilder().matchEquals("init", message->
                System.out.printf("hello %s, iam %s %n", sender().path().name(),
                self().path().name())).build();
    }
}
