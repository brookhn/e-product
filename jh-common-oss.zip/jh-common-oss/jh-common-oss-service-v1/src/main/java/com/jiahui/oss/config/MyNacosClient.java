//package com.jiahui.oss.config;
//
//import com.alibaba.nacos.api.NacosFactory;
//import com.alibaba.nacos.api.config.ConfigService;
//import com.alibaba.nacos.api.exception.NacosException;
//import org.springframework.beans.factory.annotation.Autowired;
//
//import java.util.Properties;
//
//public class MyNacosClient {
//    private volatile ConfigService configService;
//
//    private static final MyNacosClient instance = new MyNacosClient();
//
//    @Autowired
//    private ListenerConfig listenerConfig;
//
//    private ConfigService getConfigService(){
//        if (null == configService){
//            synchronized (this){
//                if (null == configService){
//                    Properties properties = new Properties();
//                    properties.put("serverAddr", "jih-nacos01-config-test.jihint.com:8848,jih-nacos02-config-test.jihint.com:8848,jih-nacos03-config-test.jihint.com:8848");
//                    properties.put("username", "common-oss");
//                    properties.put("password", "888888");
//                    properties.put("namespace", "dev");
//                    try {
//                        configService = NacosFactory.createConfigService(properties);
//                    } catch (NacosException e) {
//                        e.printStackTrace();
//                    }
//                }
//            }
//        }
//        return configService;
//    }
//
//
//    public static ConfigService staticGetConfigService(){
//        return instance.getConfigService();
//    }
//}
