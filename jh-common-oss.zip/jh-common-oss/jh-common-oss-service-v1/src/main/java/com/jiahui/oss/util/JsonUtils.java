package com.jiahui.oss.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jiahui.oss.common.CodeMsg;
import com.jiahui.oss.common.exceptionHandler.BizException;
import com.jiahui.oss.contract.vo.out.JsonOut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * @author SQL
 * @date 2021年3月22日
 */
@Component
public class JsonUtils {

    private static Logger log = LoggerFactory.getLogger(JsonUtils.class);

    private static ObjectMapper objectMapper;

    @Autowired
    private void setObjectMapper(ObjectMapper objectMapper) {
        JsonUtils.objectMapper = objectMapper;
    }

    public static JsonOut fromJson(String jsonStr, Object clazz) {
        JsonOut out = new JsonOut();
        try {
            JsonNode root = objectMapper.readTree(jsonStr);
            int code = root.get("code").intValue();
            String msg = root.get("msg").asText();
            out.setCode(code);
            out.setMsg(msg);
            if (code != 200) {
                return out;
            }
            String dataStr = null;
            JsonNode dataNode = root.get("data");
            if (dataNode != null) {
                dataStr = dataNode.toString();
            }
            if (dataStr == null || dataStr.length() < 3) {
                return out;
            }
            clazz = objectMapper.readValue(dataStr, clazz.getClass());
            if (clazz == null) {
//                throw new BizException(CodeMsg.CODE_210005000.code(), CodeMsg.CODE_210005000.msg() + clazz);
            }
            out.setData(clazz);
        } catch (JsonProcessingException e) {
            log.error("外部接口StringToJson异常" + e);
            throw new BizException(CodeMsg.CODE_210005000.code(), CodeMsg.CODE_210005000.msg() + e);
        } catch (Exception e) {
            log.error("外部接口StringToJson异常" + e);
            throw new BizException(CodeMsg.CODE_210005000.code(), CodeMsg.CODE_210005000.msg() + e);
        }
        return out;
    }

    public static String toJsonString(Object obj) {
        try {
            return objectMapper.writeValueAsString(obj);
        } catch (JsonProcessingException ex) {
            log.error("serialize json error: " + ex.getMessage());
        }
        return null;
    }

    /**
     * 解析json数组
     *
     * @param mapper
     * @param json   这个样式的[{},{}]
     * @param clazz  {}对应的object
     * @param <T>    范性
     * @return
     */
    public static <T> List<T> parseArray(ObjectMapper mapper, String json, Class<T> clazz) {
        List<T> result = new ArrayList<>();
        try {
            JsonNode root = mapper.readTree(json);
            if (root.size() < 1) {
                return result;
            }
            for (JsonNode node : root) {
                T obj = mapper.readValue(String.valueOf(node), clazz);
                result.add(obj);
            }
        } catch (IOException e) {
            log.error("parse json error: " + e.getMessage() + " => " + json);
        }
        return result;
    }

    public static String toJsonString(ObjectMapper mapper, Object obj) {
        try {
            return mapper.writeValueAsString(obj);
        } catch (JsonProcessingException ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public static <T> T toObject(String json, TypeReference<T> clazz) {
        JsonOut out = new JsonOut();
        try {
            JsonNode root = objectMapper.readTree(json);
            int code = root.get("code").intValue();
            String msg = root.get("msg").asText();
            out.setCode(code);
            out.setMsg(msg);
            String dataStr = null;
            JsonNode dataNode = root.get("data");
            if (dataNode != null) {
                dataStr = dataNode.toString();
            }
            if (dataStr == null || dataStr.length() < 3) {
                return (T) out;
            }
            return objectMapper.readValue(json, clazz);
        } catch (IOException ex) {
            log.error("parse json error: " + ex.getMessage() + " => " + json);
            throw new BizException(CodeMsg.CODE_210005000.code(), CodeMsg.CODE_210005000.msg() + ex);
        }
    }

    public static <T> T toObjectClearly(String json, TypeReference<T> clazz) {
        JsonOut out = new JsonOut();
        try {
            JsonNode root = objectMapper.readTree(json);
            String dataStr = null;
            if (root != null) {
                dataStr = root.toString();
            }
            if (dataStr == null || dataStr.length() < 3) {
                return (T) out;
            }
            return objectMapper.readValue(json, clazz);
        } catch (IOException ex) {
            log.error("parse json error: " + ex.getMessage() + " => " + json);
            throw new BizException(CodeMsg.CODE_210005000.code(), CodeMsg.CODE_210005000.msg() + ex);
        }
    }

    public static <T> T toObjectFromInputStream(InputStream inputStream, TypeReference<T> clazz) {
        try {
            return objectMapper.readValue(inputStream, clazz);
        } catch (IOException ex) {
            log.error("parse json from inputStream error: " + ex.getMessage());
            throw new BizException(CodeMsg.CODE_210005000.code(), CodeMsg.CODE_210005000.msg() + ex);
        }
    }

    /**
     * 将json字符串转换成对象,added by SQL in 2018-05-08
     *
     * @param json
     * @param clazz
     * @return
     */
    public static <T> T json2Object(String json, Class<T> clazz) {
        try {
            return objectMapper.readValue(json, clazz);
        } catch (IOException ex) {
            log.error("parse jsonStr error: " + ex.getMessage() + " => " + json);
            throw new BizException(CodeMsg.CODE_210005000.code(), CodeMsg.CODE_210005000.msg() + ex);
        }
    }

}
