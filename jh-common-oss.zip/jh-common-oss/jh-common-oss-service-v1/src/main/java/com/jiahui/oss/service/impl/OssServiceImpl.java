package com.jiahui.oss.service.impl;

import com.jiahui.oss.common.BizVar;
import com.jiahui.oss.common.CodeMsg;
import com.jiahui.oss.common.exceptionHandler.BizException;
import com.jiahui.oss.config.BucketMappingConfig;
import com.jiahui.oss.config.MinIOConfig;
import com.jiahui.oss.config.OldMinIOConfig;
import com.jiahui.oss.config.StaticRecordRouteEnum;
import com.jiahui.oss.contract.dto.StaticConfigDTO;
import com.jiahui.oss.contract.vo.in.UploadBasedResourceMultiPartInVO;
import com.jiahui.oss.contract.vo.in.UploadBasedResourceStringInVO;
import com.jiahui.oss.contract.vo.out.*;
import com.jiahui.oss.entity.commonoss.EphemeralCredentialEntity;
import com.jiahui.oss.entity.commonoss.StaticRecordEntity;
import com.jiahui.oss.handler.MinioPlatformHandler;
import com.jiahui.oss.handler.OldMinioPlatformHandler;
import com.jiahui.oss.mapper.StaticRecordMapper;
import com.jiahui.oss.service.OssService;
import com.jiahui.oss.util.MD5Util;
import com.jiahui.oss.util.SnakeFlow;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Base64;
import java.util.Objects;

/**
 * @Description minio接口服务实现类
 * @Author it-framework
 * @Date 2021年03月23日 10:53
 */
@Service
@Log4j2
public class OssServiceImpl implements OssService {

    @Autowired
    private MinioPlatformHandler minIOPlatformHandler;

    @Autowired
    private MinIOConfig minIOConfig;


    @Autowired

    private StaticRecordMapper staticRecordMapper;

    @Autowired
    private OldMinIOConfig oldMinIOConfig;

    @Autowired
    private OldMinioPlatformHandler oldMinioPlatformHandler;

    @Autowired
    private BucketMappingConfig mappingConfig;


    @Override
    public GetUploadParamOutVO getUploadParam(String bizParam) {
        GetUploadParamOutVO outVO = new GetUploadParamOutVO();
        if (!minIOConfig.getBucketMap().containsKey(bizParam)) {
            log.error("StaticResourceServiceImpl.getUploadParam::获取文件bucket异常!", bizParam);
            throw new BizException(CodeMsg.CODE_210002003.getCode(), CodeMsg.CODE_210002003.getMsg());
        }
        try {
            outVO.setBucketName(minIOConfig.getBucketMap().get(bizParam));
            return outVO;
        }catch (Exception e){
            log.error("StaticResourceServiceImpl.getUploadParam::获取参数异常!", e);
            throw new BizException(CodeMsg.CODE_210002002.getCode(), CodeMsg.CODE_210002002.getMsg());
        }

    }

    @Override
    public GetRemoveResouceOutVO removeBucketObject(String bucketName, String obejctName) {
        try {
           return minIOPlatformHandler.removeObjectUrl(bucketName, obejctName);
        }catch (Exception ex){
            log.error("StaticResourceServiceImpl.removeBucketObject::移除对象异常!", ex);
            throw new BizException(CodeMsg.CODE_210002006.getCode(), CodeMsg.CODE_210002006.getMsg());
        }
    }

    /**
     *
     * @param bucketName
     * @return
     */
    @Override
    public EphemeralAccessResourceOutVo getUploadParamOutVO(String bucketName, Integer expire) {
        try {
            EphemeralCredentialEntity ephemeralCredentialEntity = minIOPlatformHandler.
                                                                    getEphemeralCredentialEntity(expire, bucketName);
            if (Objects.isNull(ephemeralCredentialEntity)) {
                return new EphemeralAccessResourceOutVo();
            }
            StaticConfigDTO staticConfigDTO = new StaticConfigDTO();
            staticConfigDTO.setEndPoint(minIOConfig.getEndpoint());
            staticConfigDTO.setPort(minIOConfig.getPort());
            staticConfigDTO.setAccessKey(ephemeralCredentialEntity.getAccesskey());
            staticConfigDTO.setSecretKey(ephemeralCredentialEntity.getSecretKey());
            staticConfigDTO.setSesionToken(ephemeralCredentialEntity.getSessionToken());
            staticConfigDTO.setExpireTimeStamp(ephemeralCredentialEntity.getTimestamp());
            return new EphemeralAccessResourceOutVo(1, staticConfigDTO, bucketName);
        }catch (Exception e){
            log.error("StaticResourceServiceImpl.getUploadParam::获取上传参数异常!", e);
            throw new BizException(CodeMsg.CODE_210002002.getCode(), CodeMsg.CODE_210002002.getMsg());
        }
    }

    @Override
    public GetResourceUrlOutVO getResourceUrlWithTtl(String bucketName, String objectName, Integer expires) {
        String resourceUrl = null;
        try{
            resourceUrl = minIOPlatformHandler.presignedGetObject(getBucketName(bucketName), objectName, expires);
            if (StringUtils.isBlank(resourceUrl)){
                throw new RuntimeException("file not exists");
            }
        }catch (Exception e){
            log.error("OssServiceImpl.getResourceUrlWithTtl::获取资源URL异常!BucketName:{};ObjectName:{};Exception:{}", bucketName, objectName, e);
//            try {
//                resourceUrl = oldMinioPlatformHandler.presignedGetObject(bucketName, objectName, expires);
//                return new GetResourceUrlOutVO(resourceUrl);
//            }catch (Exception ex){
//                return new GetResourceUrlOutVO(resourceUrl);
//            }
            try {
                resourceUrl = minIOPlatformHandler.presignedGetObject(bucketName, objectName, expires);
                return new GetResourceUrlOutVO(resourceUrl);
            }catch (Exception ex){
                return new GetResourceUrlOutVO(resourceUrl);
            }
        }
        return new GetResourceUrlOutVO(resourceUrl);
    }

    @Override
    public GetResourceUrlOutVO getResourceUrlWithTtlAndPicHandler(String bucketName, String objectName, Integer expires, String picOption) {
        String resourceUrl = null;
        StringBuilder resourceBuilder = new StringBuilder();
        try{
            resourceUrl = minIOPlatformHandler.presignedGetObject(getBucketName(bucketName), objectName, expires);
            if (StringUtils.isBlank(resourceBuilder)){
                throw new RuntimeException("file not exists");
            }
            if (!StringUtils.isBlank(picOption)){
                resourceBuilder.append(minIOConfig.getPicPrefixUrl());
                resourceBuilder.append(picOption).append(picOption.contains("/")?"":"/");
                resourceBuilder.append(resourceUrl);
                resourceUrl = resourceBuilder.toString();
            }
        }catch (Exception e){
            log.error("OssServiceImpl.getResourceUrlWithTtl::获取资源URL异常!BucketName:{};ObjectName:{};Exception:{}", bucketName, objectName, e);
            try {
                resourceUrl = minIOPlatformHandler.presignedGetObject(bucketName, objectName, expires);
                return new GetResourceUrlOutVO(resourceUrl);
            }catch (Exception ex){
                return new GetResourceUrlOutVO(resourceUrl);
            }
        }
        return new GetResourceUrlOutVO(resourceUrl);
    }

    private String getFileName(String objName){
        if (StringUtils.isBlank(objName)){
            return MD5Util.encrypt(String.valueOf(SnakeFlow.snowflake()));
        }
        if (objName.contains("/")){
            return  objName.substring(objName.indexOf("/"));
        }
        return objName;
    }

    /**
     * @param bucketName
     * @return
     */
    public String getBucketName(String bucketName){
        if (mappingConfig.getConfigMap().containsKey(bucketName)){
            return mappingConfig.getConfigMap().get(bucketName);
        }
        return bucketName;
    }

    @Override
    public UploadResourceOutVO uploadBasedResourceString(UploadBasedResourceStringInVO inVO) {
        String virtualBucket = inVO.getBucket();
        String token = MD5Util.encrypt(inVO.getResourceString());
        inVO.setBucket(getBucketName(inVO.getBucket()));
        if (inVO.getValidatedRequired()){
            if (!token.equals(inVO.getValidatedToken())){
                throw new BizException(CodeMsg.PARAMS_ERROR.getCode(), CodeMsg.PARAMS_ERROR.getMsg());
            }
        }
        byte[] resourceBytes = Base64.getDecoder().decode(inVO.getResourceString());
        InputStream inputStream = new ByteArrayInputStream(resourceBytes);
        String fileName = getFileName(inVO.getFileName());
        String filePath = virtualBucket + "/" + fileName;
//        String virtualPath = virtualBucket + "/" + fileName;
        try {
            minIOPlatformHandler.putObject(inVO.getBucket(), filePath, inputStream, inVO.getContentType());
        } catch (Exception e) {
            log.error("StaticResourceServiceImpl.uploadBasedResourceString::上传文件资源异常!", e);
            throw new BizException(CodeMsg.CODE_210002001.getCode(), CodeMsg.CODE_210002001.getMsg());
        }

        //持久化DB
        StaticRecordEntity staticRecordEntity = new StaticRecordEntity();
        staticRecordEntity.setPlatformType(BizVar.STATIC_RESOURCE_PLATFORM_MINIO);
        staticRecordEntity.setFileKey(token);
        staticRecordEntity.setFilePath(filePath);
        staticRecordEntity.setBucket(inVO.getBucket());

        try {
            staticRecordMapper.insertStaticRecord(getRouteTable(virtualBucket, token), staticRecordEntity);
        } catch (Exception e) {
            log.error("StaticResourceServiceImpl.uploadBasedResourceString::静态资源持久化至DB异常!", e);
            throw new BizException(CodeMsg.CODE_210002001.getCode(), CodeMsg.CODE_210002001.getMsg());
        }

        //返回上传路径
        UploadResourceOutVO outVO = new UploadResourceOutVO();
        outVO.setBucketName(virtualBucket);
        outVO.setResourceKey(token);
        outVO.setResourcePath(filePath);
        outVO.setObjectName(filePath);
        return outVO;
    }

    private String getResourceUrl(UploadBasedResourceMultiPartInVO inVO, String filePath){
        StringBuilder urlBuilder = new StringBuilder();
        urlBuilder.append(minIOConfig.getRedefineUrl()).append("/");
        urlBuilder.append(inVO.getBucket()).append("/");
        urlBuilder.append(filePath);
        return urlBuilder.toString();
    }

    @Override
    public UploadResourceOutVO updateResourceMultipart(UploadBasedResourceMultiPartInVO inVO){
        String virtualBucket = inVO.getBucket();
        inVO.setBucket(getBucketName(inVO.getBucket()));
        String filePath = this.getFileName(inVO.getFileName());
        String token = MD5Util.encrypt(filePath);
        try{
            minIOPlatformHandler.putObject(inVO.getBucket(), filePath, inVO.getMultipartFile().getInputStream(), inVO.getContentType());
        }catch (Exception e){
            log.error("StaticResourceServiceImpl.updateResourceMultipart::上传文件资源异常!", e);
            throw new BizException(CodeMsg.CODE_210002001.getCode(), CodeMsg.CODE_210002001.getMsg());
        }finally {
            try {
                if (null != inVO.getMultipartFile().getInputStream()) {
                    inVO.getMultipartFile().getInputStream().close();
                }
            } catch (IOException e) {
                log.error("StaticResourceServiceImpl.updateResourceMultipart::关闭资源流异常!", e);
                throw new BizException(CodeMsg.CODE_210002001.getCode(), CodeMsg.CODE_210002001.getMsg());
            }
        }

        //持久化DB
        StaticRecordEntity staticRecordEntity = new StaticRecordEntity();
        staticRecordEntity.setPlatformType(BizVar.STATIC_RESOURCE_PLATFORM_MINIO);
        staticRecordEntity.setFileKey(token);
        staticRecordEntity.setFilePath(filePath);
        staticRecordEntity.setBucket(inVO.getBucket());

        try {
            staticRecordMapper.insertStaticRecord(getRouteTable(virtualBucket, token), staticRecordEntity);
        } catch (Exception e) {
            log.error("StaticResourceServiceImpl.uploadBasedResourceString::静态资源持久化至DB异常!", e);
            throw new BizException(CodeMsg.CODE_210002001.getCode(), CodeMsg.CODE_210002001.getMsg());
        }


        //返回上传路径
        UploadResourceOutVO outVO = new UploadResourceOutVO();
        outVO.setBucketName(virtualBucket);
        outVO.setResourceKey(token);
        outVO.setObjectName(filePath);
        inVO.setBucket(virtualBucket);
        outVO.setResourcePath(getResourceUrl(inVO, filePath));
        return outVO;
    }

    /**
     * 平台化控制  TODO
     * @param platformType
     * @return
     */
    protected MinioPlatformHandler getStaticResourceHandler(int platformType){
        MinioPlatformHandler minioPlatformHandler = null;
        switch (platformType){
            case BizVar.STATIC_RESOURCE_PLATFORM_MINIO:
                minioPlatformHandler = minIOPlatformHandler;
                break;
            default:
                break;
        }
        return minioPlatformHandler;
    }


    /**
     * 获取上传记录路由表
     * @return
     */
    protected String getRouteTable(String bucketName, String key){
        String perfix = BizVar.STATIC_RECORD_TABLE_PERFIX;
        //路由规则
        int routeNum = Math.abs(key.hashCode() % BizVar.SATATIC_RECORD_TABLE_SEPATE_NUM) + 1;
        String routeBucket = StaticRecordRouteEnum.getRouteString(bucketName).replace("-", "_");
        log.info("StaticResourceServiceImpl.getRouteTable bucketName:{} key:{} routeNum:{} route_baucket:{}",
                bucketName, key, routeNum, routeBucket);
        return perfix + routeBucket + "_" + routeNum;
    }


    @Override
    public GetResourceUrlOutVO getResourceUrlBasedKey(String bucketName, String resourceKey, Integer expires) {
        String tableName = getRouteTable(bucketName, resourceKey);
        StaticRecordEntity entity = staticRecordMapper.getStaticRecordByFileKey(tableName, resourceKey);
        MinioPlatformHandler handler = getStaticResourceHandler(BizVar.STATIC_RESOURCE_PLATFORM_MINIO);
        if (Objects.isNull(handler)){
            log.warn("StaticResourceServiceImpl.getResourceUrlBasedKey::获取资源URL异常,Handler处理类为空!BucketName:{};ResourceKey:{}", bucketName, resourceKey);
            throw new BizException(CodeMsg.CODE_210002004.getCode(), CodeMsg.CODE_210002004.getMsg());
        }
        String resourceUrl = null;
        try {
            resourceUrl = handler.presignedGetObject(entity.getBucket(), entity.getFilePath(), expires);
        } catch (Exception e) {
            log.error("StaticResourceServiceImpl.getResourceUrlWithTtl::获取资源URL异常!BucketName:{};ResourceKey:{}", bucketName, resourceKey);
            throw new BizException(CodeMsg.CODE_210002004.getCode(), CodeMsg.CODE_210002004.getMsg());
        }
        return new GetResourceUrlOutVO(resourceUrl);
    }
}
