//package com.jiahui.oss.dto;
//
//import lombok.Data;
//
///**
// * js 端minio访问参数
// */
//@Data
//public class StaticConfigDTO {
//
//    //minio访问端点
//    private String endPoint;
//    //minio访问接口
//    private Integer port;
//    //minio访问key
//    private String accessKey;
//    //minio访问密钥
//    private String secretKey;
//    //minio访问token
//    private String sesionToken;
//    //minio访问token到期时间
//    private Long expireTimeStamp;
//}
