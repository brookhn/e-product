//package com.jiahui.oss.config;
//
//import com.alibaba.nacos.api.config.ConfigService;
//import com.alibaba.nacos.api.config.listener.Listener;
//import com.alibaba.nacos.api.exception.NacosException;
//import lombok.extern.log4j.Log4j2;
//import org.springframework.beans.BeansException;
//import org.springframework.boot.context.event.ApplicationReadyEvent;
//import org.springframework.context.ApplicationContext;
//import org.springframework.context.ApplicationContextAware;
//import org.springframework.context.ApplicationListener;
//import org.springframework.stereotype.Component;
//
//import java.util.concurrent.Executor;
//import java.util.concurrent.atomic.AtomicBoolean;
//
//@Component
//@Log4j2
//public class MyConfigListener implements ApplicationListener<ApplicationReadyEvent>, ApplicationContextAware {
//
//    private volatile AtomicBoolean initFlag = new AtomicBoolean(false);
//
//    private ApplicationContext context;
//
//    @Override
//    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
//        this.context = applicationContext;
//    }
//
//    @Override
//    public void onApplicationEvent(ApplicationReadyEvent event) {
//        log.info("DataSourceChangeEventListener start...");
//        //防止重复触发
//        if (!initFlag.compareAndSet(false, true)) {
//            return;
//        }
//        ConfigService configService = MyNacosClient.staticGetConfigService();
//        try {
//            configService.addListener("jh-common-oss.properties", "jh-common-oss", new Listener() {
//                @Override
//                public Executor getExecutor() {
//                    return null;
//                }
//
//                @Override
//                public void receiveConfigInfo(String configInfo) {
//                    System.out.println(System.currentTimeMillis()+" receive message: " + configInfo);
//                }
//            });
//        } catch (NacosException e) {
//            e.printStackTrace();
//        }
//
//    }
//}
