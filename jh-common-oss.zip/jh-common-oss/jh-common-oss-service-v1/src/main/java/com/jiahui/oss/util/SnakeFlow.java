package com.jiahui.oss.util;

import cn.hutool.core.lang.Snowflake;
import cn.hutool.core.util.IdUtil;
import cn.hutool.core.util.RandomUtil;
import org.apache.commons.lang3.StringUtils;

public class SnakeFlow {
    public static String snowflake(){
        StringBuilder snowFlake = new StringBuilder();
        Snowflake snowflake = IdUtil.getSnowflake(3, 3);
        long id = snowflake.nextId();
        String randomNum = RandomUtil.randomNumbers(5);
        snowFlake.append(randomNum).append(id);
        return snowFlake.toString();
    }

    public static void main(String[] args) {
//        long id = snowflake();
        for (int i=0;  i<100; i++) {
//            long id = snowflake();
           String snk =  MD5Util.encrypt(String.valueOf(SnakeFlow.snowflake()));
            System.out.println(snk);
        }

    }
}
