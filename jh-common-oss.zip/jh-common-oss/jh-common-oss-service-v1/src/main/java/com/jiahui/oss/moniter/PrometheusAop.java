//package com.jiahui.oss.moniter;
//
//import com.jiahui.framework.web.invoke.log.constants.CommonConst;
//import com.jiahui.framework.web.invoke.log.constants.LogConst;
//import lombok.extern.log4j.Log4j2;
//import org.aspectj.lang.JoinPoint;
//import org.aspectj.lang.annotation.Aspect;
//import org.aspectj.lang.annotation.Before;
//import org.aspectj.lang.annotation.Pointcut;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.multipart.MultipartFile;
//import org.springframework.web.multipart.support.StandardMultipartHttpServletRequest;
//
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//import java.util.ArrayList;
//import java.util.List;
//
//@Aspect
//@Log4j2
//public class PrometheusAop {
//
//    @Autowired
//    private HttpServletRequest request;
//
//    @Autowired
//    private PrometheusCustomerMoniter moniter;
//
//    /**
//     * TODO 直接对RestController进行拦截
//     */
//    @Pointcut("@within(org.springframework.stereotype.Controller) || @within(org.springframework.web.bind.annotation.RestController)")
//    public void controllerPointCut() {
//    }
//
//    @Before("controllerPointCut()")
//    public void doBefore(JoinPoint joinPoint) {
//        //http get请求
//        if (CommonConst.HTTP_METHOD_GET.equalsIgnoreCase(request.getMethod())) {
//            return;
//        }
//        Object[] args = joinPoint.getArgs();
//        moniter.getCounter().increment();
//        for (int i = 0; i < args.length; i++) {
//            log.info(args[i]);
//        }
//    }
//}
