package com.jiahui.oss.entity.commonoss;

import lombok.Data;

import java.sql.Timestamp;

@Data
public class StaticRecordEntity {
    private Long id;

    private Integer platformType;

    private String fileKey;

    private String bucket;

    private String filePath;

    private Integer delType;

    private Timestamp createTime;

    private Timestamp updateTime;


    //迁移数据记录
    private String transferDb;

    private String transferTable;

    private String transferId;
}
