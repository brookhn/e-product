package com.jiahui.oss.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * @note 日期时间工具类
 * @author SQL
 * @since 2021-03-10
 */
public class DateUtil {

    /**
     * 获取指定日期的开始时间戳(s)
     * @param year
     * @param month
     * @param day
     * @return
     */
    public static long getDesignatedDayStartTime(int year, int month, int day){
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.YEAR, year);
        cal.set(Calendar.MONTH, month-1);
        cal.set(Calendar.DAY_OF_MONTH,day);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTime().getTime()/1000;
    }

    /**
     * 获取指定年,月最后时刻的时间戳(s)
     * @param year
     * @param month
     * @return
     */
    public static long getLastDayEndTimeOfMonth(int year, int month) {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.YEAR, year);
        cal.set(Calendar.MONTH, month-1);
        cal.set(Calendar.DAY_OF_MONTH,cal.getActualMaximum(Calendar.DATE));
        cal.set(Calendar.HOUR_OF_DAY, cal.getActualMaximum(Calendar.HOUR_OF_DAY));
        cal.set(Calendar.MINUTE, cal.getActualMaximum(Calendar.MINUTE));
        cal.set(Calendar.SECOND, cal.getActualMaximum(Calendar.SECOND));
        cal.set(Calendar.MILLISECOND, cal.getActualMaximum(Calendar.MILLISECOND));
        return cal.getTime().getTime()/1000;
    }

    /**
     * 获取指定年,月第一天的开始时间戳(s)
     * @param year
     * @param month
     * @return
     */
    public static long getFirstDayStartTimeOfMonth(int year, int month) {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.YEAR, year);
        cal.set(Calendar.MONTH, month-1);
        cal.set(Calendar.DAY_OF_MONTH,cal.getMinimum(Calendar.DATE));
        cal.set(Calendar.HOUR_OF_DAY, cal.getMinimum(Calendar.HOUR_OF_DAY));
        cal.set(Calendar.MINUTE, cal.getMinimum(Calendar.MINUTE));
        cal.set(Calendar.SECOND, cal.getMinimum(Calendar.SECOND));
        cal.set(Calendar.MILLISECOND, cal.getMinimum(Calendar.MILLISECOND));
        return cal.getTime().getTime()/1000;
    }

    /**
     * 获取当天的开始时刻的时间戳(s)
     * @return
     */
    public static long getCurrentDayStartTime(){
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTime().getTime()/1000;
    }

    /**
     * 获取下个月的年月表达式
     * @return
     */
    public static String getNextMonthDes(){
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM");
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.MONTH, 1);
        String dateStr = sdf.format(cal.getTime());
        return dateStr;
    }

    public static long getCurrentTimeAddTimes(int timeSeconds) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        cal.add(Calendar.SECOND, timeSeconds);
        return cal.getTime().getTime();
    }

    public static void main(String[] args) {
        long timeStamp = DateUtil.getCurrentTimeAddTimes(3600);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = new Date(timeStamp);
        String formatDate = simpleDateFormat.format(date);
        System.out.println("-------------------------------"+ formatDate);
    }
}
