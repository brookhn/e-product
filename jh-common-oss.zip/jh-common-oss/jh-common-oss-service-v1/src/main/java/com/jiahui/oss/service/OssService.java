package com.jiahui.oss.service;

import com.jiahui.oss.contract.vo.in.UploadBasedResourceMultiPartInVO;
import com.jiahui.oss.contract.vo.in.UploadBasedResourceStringInVO;
import com.jiahui.oss.contract.vo.out.*;

import java.io.IOException;


/**
 * @Description minio接口服务接口
 * @Author it-framework
 * @Date 2021年03月23日 10:53
 */
public interface OssService {

    /**
     * 获取文件上传参数
     * @param bucketName
     * @return
     */
    public EphemeralAccessResourceOutVo getUploadParamOutVO(String bucketName, Integer expire);


    /**
     * removeObject
     * @param bucketName
     * @param obejctName
     * @return
     */
    public GetRemoveResouceOutVO removeBucketObject(String bucketName, String obejctName);

    /**
     * 获取Bucket
     * @return
     */
    public GetUploadParamOutVO getUploadParam(String bizParam);
    /**
     * 获取静态资源URL-TTL
     * @param bucketName
     * @param objectName
     * @param expires
     * @return
     */
    public GetResourceUrlOutVO getResourceUrlWithTtl(String bucketName, String objectName, Integer expires);

    /**
     *
     * @return
     */
    public GetResourceUrlOutVO getResourceUrlWithTtlAndPicHandler(String bucketName, String objectName, Integer expires, String picOption);

    /**
     * Base64编码格式上传
     * @param inVO
     */
    public UploadResourceOutVO uploadBasedResourceString(UploadBasedResourceStringInVO inVO);

    /**
     * MultipartFile 上传文件
     * @param inVO
     * @return
     */
    public UploadResourceOutVO updateResourceMultipart(UploadBasedResourceMultiPartInVO inVO);

    /**
     *
     * @param bucketName
     * @param resourceKey
     * @param expires
     * @return
     */
    public GetResourceUrlOutVO getResourceUrlBasedKey(String bucketName, String resourceKey, Integer expires);

}
