package com.jiahui.oss.config;

import com.jiahui.framework.datasource.config.JiaHuiDataSourceProperties;
import com.jiahui.framework.datasource.core.DynamicDataSource;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import javax.sql.DataSource;

@Configuration
@MapperScan(basePackages = "com.jiahui.oss.mapper", sqlSessionFactoryRef = "commstaticSqlSessionFactory",sqlSessionTemplateRef = "commstaticSqlSessionTemplate" )
public class OssDataSourceConfig {
    /**
     * ${dbname}需替换为邮件申请中的{dbname}
     * @param dbProp
     * @return
     */
    @Bean("commstatic")
    public DataSource getDataSource(JiaHuiDataSourceProperties dbProp) {
        DynamicDataSource dataSource = new DynamicDataSource("commstatic", dbProp);
        return dataSource;
    }

    @Bean("commstaticSqlSessionFactory")
    public SqlSessionFactory getSqlSessionFactory(@Qualifier("commstatic") DataSource dataSource) throws Exception {
        SqlSessionFactoryBean bean = new SqlSessionFactoryBean();
        bean.setDataSource(dataSource);
        bean.setMapperLocations(new PathMatchingResourcePatternResolver().getResources("classpath:mybatis/*.xml"));
        return bean.getObject();
    }

    @Bean("commstaticSqlSessionTemplate")
    public SqlSessionTemplate getSqlSessionTemplate(@Qualifier("commstaticSqlSessionFactory") SqlSessionFactory sqlSessionFactory) {
        return new SqlSessionTemplate(sqlSessionFactory);
    }

    @Bean(name = "commstaticTransactionManager")
    public DataSourceTransactionManager getTransactionManager(@Qualifier("commstatic") DataSource dataSource) {
        return new DataSourceTransactionManager(dataSource);
    }
}
