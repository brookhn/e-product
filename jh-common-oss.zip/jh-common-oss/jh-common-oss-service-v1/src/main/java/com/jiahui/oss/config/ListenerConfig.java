//package com.jiahui.oss.config;
//
//
//import lombok.Data;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.stereotype.Component;
//
//@Component
//@Configuration
//@Data
//public class ListenerConfig {
//
//    @Value("${nacos.serveraddr}")
//    private String serverAddr;
//
//    @Value("${nacos.username}")
//    private String userName;
//
//    @Value("${nacos.password}")
//    private String password;
//
//    @Value("${nacos.namespace}")
//    private String namespace;
//}
