package com.jiahui.oss.config;

//import com.jiahui.oss.moniter.PrometheusAop;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class WebLogConfig {

//    @Bean
//    public PrometheusAop prometheusAop()
//    {
//        return new PrometheusAop();
//    }
}
