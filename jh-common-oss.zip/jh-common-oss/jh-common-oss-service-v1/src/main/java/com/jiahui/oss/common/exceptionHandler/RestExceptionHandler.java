package com.jiahui.oss.common.exceptionHandler;

import com.jiahui.oss.common.GlobalVar;
import lombok.extern.log4j.Log4j2;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.NoHandlerFoundException;
import javax.validation.ConstraintViolationException;

import static org.springframework.http.HttpStatus.BAD_REQUEST;


/**
 * @author SQL
 * 全局异常处理
 */
@Order(Ordered.HIGHEST_PRECEDENCE)
//@RestControllerAdvice
@ControllerAdvice
@Log4j2
public class RestExceptionHandler {
    /**
     * Handle Exception, handle generic Exception.class
     *
     * @param ex the Exception
     * @return the ApiError object
     */

    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<Object> methodArgumentNotValidException(MethodArgumentNotValidException ex) {
        ApiError apiError = new ApiError(HttpStatus.BAD_REQUEST, HttpStatus.BAD_REQUEST.value());
//        apiError.setMsg("参数校验异常,请检查请求参数:"+ex.getLocalizedMessage());
        apiError.setMsg("参数校验异常,请检查请求参数:" + ex.getBindingResult().getFieldError().getField() + ", " + ex.getBindingResult().getFieldError().getDefaultMessage());
        return buildResponseEntity(apiError);
    }

    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    protected ResponseEntity<Object> handleMethodArgumentTypeMismatch(MethodArgumentTypeMismatchException ex,
                                                                      WebRequest request) {
        ApiError apiError = new ApiError(BAD_REQUEST, BAD_REQUEST.value());
        apiError.setMsg(String.format("The parameter '%s' of value '%s' could not be converted to type '%s'", ex.getName(), ex.getValue(), ex.getRequiredType().getSimpleName()));
        return buildResponseEntity(apiError);
    }

//    @ExceptionHandler(ElasticsearchStatusException.class)
//    protected ResponseEntity<Object> findEsException(ElasticsearchStatusException ex,
//                                                     WebRequest request) {
//        ApiError apiError = new ApiError(HttpStatus.INTERNAL_SERVER_ERROR, INTERNAL_SERVER_ERROR.value());
//        apiError.setMsg("elasticsearch操作出错:" + ex.getMessage());
//        return buildResponseEntity(apiError);
//    }

    //    @ExceptionHandler(NullPointerException.class)
    @ExceptionHandler(value = {RuntimeException.class})
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
//    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<Object> runtimeException(RuntimeException ex) {
        return buildResponseEntity(new ApiError(HttpStatus.INTERNAL_SERVER_ERROR, GlobalVar.Status_ServerErr, getStackMsg(ex)));
//        return buildResponseEntity(new ApiError(HttpStatus.INTERNAL_SERVER_ERROR, GlobalVar.Status_ServerErr, ex.getMessage()));
    }

//    @ExceptionHandler(value = {RedisConnectionFailureException.class})
//    public ResponseEntity<Object> jedisException(IllegalArgumentException ex) {
//        return buildResponseEntity(new ApiError(HttpStatus.INTERNAL_SERVER_ERROR, GlobalVar.Status_ServerErr, ex.getMessage()));
//    }

//    @ExceptionHandler(UndeclaredThrowableException.class)
//    @ResponseStatus(HttpStatus.BAD_REQUEST)
//    public ResponseEntity<Object> undeclaredThrowableException(UndeclaredThrowableException ex) {
//        ApiError apiError = new ApiError(HttpStatus.BAD_REQUEST, HttpStatus.BAD_REQUEST.value());
//        apiError.setMsg("请求参数异常!");
//        return buildResponseEntity(apiError);
//    }

    @ExceptionHandler(NoHandlerFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ResponseEntity<Object> myhandleNoHandlerFoundException(NoHandlerFoundException ex) {
        ApiError apiError = new ApiError(HttpStatus.NOT_FOUND, HttpStatus.NOT_FOUND.value());
//        apiError.setMsg("url错误,无对应方法:" + ex.getMessage());
        apiError.setMsg("url错误，无对应方法:"+ ex.getRequestURL());
        return buildResponseEntity(apiError);
    }


    @ExceptionHandler(value = {ConstraintViolationException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<Object> constraintViolationException(ConstraintViolationException ex) {
        return buildResponseEntity(new ApiError(HttpStatus.BAD_REQUEST, GlobalVar.Status_BadRequest, ex.getMessage()));
    }

    @ExceptionHandler(value = {IllegalArgumentException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<Object> illegalArgumentException(IllegalArgumentException ex) {
        return buildResponseEntity(new ApiError(HttpStatus.BAD_REQUEST, GlobalVar.Status_BadRequest, ex.getMessage()));
    }

    @ExceptionHandler(value = {Exception.class})
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseEntity<Object> unknownException(Exception ex) {
        return buildResponseEntity(new ApiError(HttpStatus.INTERNAL_SERVER_ERROR, GlobalVar.Status_ServerErr, getStackMsg(ex)));
//        return buildResponseEntity(new ApiError(HttpStatus.INTERNAL_SERVER_ERROR, GlobalVar.Status_ServerErr, ex.getStackTrace().toString()));
    }


    @ExceptionHandler(BizException.class)
    public ResponseEntity<Object> findEsException(BizException ex) {
        ApiError apiError = new ApiError(HttpStatus.OK, ex.getCode(), ex.getMsg());
        return buildResponseEntity(apiError);
    }

//    @ExceptionHandler(ExpiredJwtException.class)


    private ResponseEntity<Object> buildResponseEntity(ApiError apiError) {
        //假如是业务异常，warn.否则 error
        if (apiError.getCode() > 100000000) {
            log.warn(apiError);
        } else {
            log.error(apiError);
        }
        return new ResponseEntity<>(apiError, apiError.getStatus());
    }

    private static String getStackMsg(Exception e) {
        StringBuffer sb = new StringBuffer();
        sb.append(e + "\n");
        StackTraceElement[] stackArray = e.getStackTrace();
        int len = stackArray.length;
        if (len > 2) {
            len = 2;
        }
        for (int i = 0; i < len; i++) {
            StackTraceElement element = stackArray[i];
            sb.append(element.toString() + "\n...");
        }
        return sb.toString();
    }

}

