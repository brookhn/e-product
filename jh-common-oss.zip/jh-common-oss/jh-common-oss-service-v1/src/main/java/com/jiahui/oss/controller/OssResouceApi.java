package com.jiahui.oss.controller;

import com.jiahui.oss.common.CodeMsg;
import com.jiahui.oss.common.exceptionHandler.BizException;
import com.jiahui.oss.contract.vo.in.*;
import com.jiahui.oss.contract.vo.out.*;
import com.jiahui.oss.service.OssService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@Api(tags = "访问OSSweb接口")
@RestController
@RequestMapping("/v1/oss")
public class OssResouceApi {

    @Autowired
    private OssService ossService;

    /**
     * 获取上传参数-FOR H5
     * @param inVO
     * @return
     */
    @PostMapping("/getUploadParam")
    public JsonOut<GetUploadParamOutVO> getUploadParam(@RequestBody @Validated GetUploadParamInVO inVO){
        JsonOut<GetUploadParamOutVO> jsonOut = new JsonOut<>(CodeMsg.CODE_200.code(), CodeMsg.CODE_200.getMsg());
        try {
            jsonOut.setData(ossService.getUploadParam(String.valueOf(inVO.getBizType())));
        } catch (BizException e) {
            jsonOut.setCode(e.getCode());
            jsonOut.setMsg(e.getMsg());
        }
        return jsonOut;
    }

    /**
     * 获取上传参数-FOR H5
     * @param removeResouceInVO
     * @return
     */
    @PostMapping("/removeStaticResource")
    public JsonOut<GetRemoveResouceOutVO> removeResouce(@RequestBody @Validated GetRemoveResouceInVO removeResouceInVO)
    {
        JsonOut<GetRemoveResouceOutVO> jsonOut = new JsonOut<>(CodeMsg.CODE_200.code(), CodeMsg.CODE_200.getMsg());
        try {
            jsonOut.setData(ossService.removeBucketObject(removeResouceInVO.getBucketName(), removeResouceInVO.getObjectName()));
        } catch (BizException e) {
            jsonOut.setCode(e.getCode());
            jsonOut.setMsg(e.getMsg());
        }
        return jsonOut;
    }

    /**
     *
     * 客户端获取上传参数
     * @param inVO
     * @return
     */
    @ApiOperation(value="获取临时访问minio", notes="获取临时访问minio accessToken等", produces="application/json")
//    @ApiImplicitParam(name = "inVO", value = "访问资源参数 bucketName：桶名称，expireTime：过期时间（单位为妙默认为3600秒）", paramType = "GetAccessResouceInVO", required = true, dataType = "String")
    @ApiParam(name = "inVo.bucketName", value = "访问资源参数 bucketName：桶名称")
    @PostMapping("/getAccessResource")
    public JsonOut<EphemeralAccessResourceOutVo> getAccessResource(@RequestBody @Validated GetAccessResouceInVO inVO) {
        JsonOut<EphemeralAccessResourceOutVo> jsonOut = new JsonOut<>(CodeMsg.CODE_200.code(), CodeMsg.CODE_200.getMsg());
        try {
            jsonOut.setData(ossService.getUploadParamOutVO(inVO.getBucketName(), 0));
        } catch (BizException e) {
            jsonOut.setCode(e.getCode());
            jsonOut.setMsg(e.getMsg());
        }
        return jsonOut;
    }


    /**
     * 获取资源路径URL--TTL
     * @param inVO
     * @return
     */
    @ApiOperation(value="临时访问资源URL", notes="临时访问资源URL", produces="application/json")
    @PostMapping("/getResourceUrlWithTtl")
    public JsonOut<GetResourceUrlOutVO> getResourceUrlWithTtl(@RequestBody @Validated GetResourceUrlWithTtlInVO inVO){
        JsonOut<GetResourceUrlOutVO> jsonOut = new JsonOut<>(CodeMsg.CODE_200.code(), CodeMsg.CODE_200.getMsg());
        try {
            jsonOut.setData(ossService.getResourceUrlWithTtl(inVO.getBucketName(), inVO.getObjectName(), inVO.getExpires()));
        } catch (BizException e) {
            jsonOut.setCode(e.getCode());
            jsonOut.setMsg(e.getMsg());
        }
        return jsonOut;
    }

    @ApiOperation(value="临时访问资源URL，带缩放，旋转功能", notes="临时访问资源URL，带缩放，旋转功能", produces="application/json")
    @PostMapping("/getResourceUrlWithTtlAndPicHandle")
    public JsonOut<GetResourceUrlOutVO> getResourceUrlWithTtlAndPicHandler(@RequestBody @Validated GetResourceUrlWithTtlInVO inVO){
        JsonOut<GetResourceUrlOutVO> jsonOut = new JsonOut<>(CodeMsg.CODE_200.code(), CodeMsg.CODE_200.getMsg());
        try {
            jsonOut.setData(ossService.getResourceUrlWithTtlAndPicHandler(inVO.getBucketName(), inVO.getObjectName(), inVO.getExpires(), inVO.getPicOption()));
        } catch (BizException e) {
            jsonOut.setCode(e.getCode());
            jsonOut.setMsg(e.getMsg());
        }
        return jsonOut;
    }


    /**
     * 基于资源String(Base64)上传资源
     * @return
     */
    @ApiOperation(value="上传资源，基于Base64", notes="上传资源，基于Base64", produces="application/json")
    @PostMapping("/uploadBasedResourceString")
    public JsonOut<UploadResourceOutVO> uploadBasedResourceString(@RequestBody @Validated UploadBasedResourceStringInVO inVO){
        JsonOut<UploadResourceOutVO> jsonOut = new JsonOut<>(CodeMsg.CODE_200.code(), CodeMsg.CODE_200.getMsg());
        try {
            jsonOut.setData(ossService.uploadBasedResourceString(inVO));
        } catch (BizException e) {
            jsonOut.setCode(e.getCode());
            jsonOut.setMsg(e.getMsg());
        }
        return jsonOut;
    }



    /**
     * 基于multipartFile上传资源
     * @return
     */
    @ApiOperation(value="上传资源，基于MultipartFile", notes="上传资源，基于MultipartFile")
    @PostMapping("/uploadBasedResourceMultiPartFile")
    public JsonOut<UploadResourceOutVO> uploadBaseResourceMultiPartFile(@Validated UploadBasedResourceMultiPartInVO inVO) {
        JsonOut<UploadResourceOutVO> jsonOut = new JsonOut<>(CodeMsg.CODE_200.code(), CodeMsg.CODE_200.getMsg());
        try{
//            moniter.getUploadTotalSize().set(moniter.getUploadTotalSize().floatValue() + inVO.getMultipartFile().getSize());
            jsonOut.setData(ossService.updateResourceMultipart(inVO));
        }catch (BizException e){
            jsonOut.setCode(e.getCode());
            jsonOut.setMsg(e.getMsg());
        }
        return jsonOut;
    }


    /**
     * 基于资源key获取资源URL -- TTL
     * @param inVO
     * @return
     */
    @PostMapping("/getResourceUrlBasedKey")
    public JsonOut<GetResourceUrlOutVO> getResourceUrlBasedKey(@RequestBody @Validated GetResourceUrlBasedKeyInVO inVO){
        JsonOut<GetResourceUrlOutVO> jsonOut = new JsonOut<>(CodeMsg.CODE_200.code(), CodeMsg.CODE_200.getMsg());
        try {
            jsonOut.setData(ossService.getResourceUrlBasedKey(inVO.getBucketName(), inVO.getResourceKey(), inVO.getExpires()));
        } catch (BizException e) {
            jsonOut.setCode(e.getCode());
            jsonOut.setMsg(e.getMsg());
        }
        return jsonOut;
    }
}
