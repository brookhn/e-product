package com.jiahui.oss.common;

public class BizVar {

    /**
     * 静态资源URL默认过期时间
     */
    public static final int DEFAULT_RRSOURCE_URL_EXPIRY_TIME = 7 * 24 * 3600;

    /**
     * minIO静态资源平台类型
     */
    public static final int STATIC_RESOURCE_PLATFORM_MINIO = 1;

    /**
     * 静态资源记录表前缀
     */
    public static final String STATIC_RECORD_TABLE_PERFIX = "static_record_";
    public static final int SATATIC_RECORD_TABLE_SEPATE_NUM = 5;


}
