package com.jiahui.oss.mapper;

import com.jiahui.oss.entity.commonoss.StaticRecordEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface StaticRecordMapper {

    public StaticRecordEntity getStaticRecordByFileKey(@Param("tableName") String tableName, @Param("fileKey") String fileKey);

    public void insertStaticRecord(@Param("tableName") String tableName, @Param("staticRecordEntity") StaticRecordEntity staticRecordEntity);

    public void insertStaticRecordClean(@Param("tableName") String tableName, @Param("staticRecordEntity") StaticRecordEntity staticRecordEntity);

    public void batchInsertStaticRecord(@Param("tableName") String tableName, @Param("staticRecordList") List<StaticRecordEntity> staticRecordList);
}
