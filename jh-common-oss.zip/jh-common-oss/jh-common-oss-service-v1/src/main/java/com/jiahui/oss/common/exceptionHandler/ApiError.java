package com.jiahui.oss.common.exceptionHandler;

import lombok.Setter;
import lombok.ToString;
import org.springframework.http.HttpStatus;

import java.util.HashMap;
import java.util.Map;


@Setter
@ToString
public class ApiError {

    private HttpStatus status;
    //    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy hh:mm:ss")
    private String msg = "";
    private int code = 200;
    private Map data;

    public ApiError() {
    }

    public ApiError(HttpStatus status, int code) {
        this.status = status;
        this.code = code;
    }

    public ApiError(HttpStatus status, int code, String msg) {
        this.status = status;
        this.code = code;
        this.msg = msg;
    }

    public ApiError(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public HttpStatus getStatus() {
        return status;
    }

    public String getMsg() {
        return msg;
    }

    public int getCode() {
        return code;
    }

    public Map getData() {
        if (data == null) {
            return new HashMap<>(1);
        }
        return data;
    }

}


