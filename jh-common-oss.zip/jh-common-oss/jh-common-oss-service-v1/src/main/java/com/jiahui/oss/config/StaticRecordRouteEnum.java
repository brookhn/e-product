package com.jiahui.oss.config;

import org.apache.commons.lang3.StringUtils;

import java.util.Objects;

/**
 * @Author: Garen
 * @Date: 2021-03-26
 * @Description: 静态资源记录路由枚举
 */
public enum StaticRecordRouteEnum {


    DEFAULT(0, "default"),
    NIS_NAS_RECORDS(1, "nis-nas-records"),
    MDC_LOC_CA(2, "mdc-loc-ca"),
    PTM_PATIENT_PIC(3, "ptm-patient-pic"),
    MET_CHK_CALOG(4, "met-chk-calog");

    private Integer bucketType;

    private String bucketName;

    StaticRecordRouteEnum(Integer bucketType, String bucketName){
        this.bucketType = bucketType;
        this.bucketName = bucketName;
    }

    public void setBucketType(Integer bucketType) {
        this.bucketType = bucketType;
    }

    public void setBucketName(String bucketName) {
        this.bucketName = bucketName;
    }

    public Integer getBucketType() {
        return bucketType;
    }

    public String getBucketName() {
        return bucketName;
    }

    /**
     * 基于bucket名称获取routeString,如果无匹配的bucket;default是默认路由
     * @param bucketName
     * @return
     */
    public static String getRouteString(String bucketName){
        if (StringUtils.isBlank(bucketName)){
            return DEFAULT.getBucketName();
        }
        String routeString = null;
        StaticRecordRouteEnum[] staticRecordRouteEnums = values();
        for (StaticRecordRouteEnum enumInfo : staticRecordRouteEnums) {
            if (enumInfo.getBucketName().equals(bucketName)){
                routeString = bucketName;
                break;
            }
        }
        if (Objects.isNull(routeString)){
            routeString = DEFAULT.getBucketName();
        }
        return routeString;
    }
}
