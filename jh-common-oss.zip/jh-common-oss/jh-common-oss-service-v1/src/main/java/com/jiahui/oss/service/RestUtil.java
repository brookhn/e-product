package com.jiahui.oss.service;

import cn.hutool.core.map.MapUtil;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jiahui.oss.common.CodeMsg;
import com.jiahui.oss.common.exceptionHandler.BizException;
import com.jiahui.oss.util.JsonUtils;
import org.slf4j.Logger;
import com.alibaba.fastjson.JSON;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.Map;
import java.util.Optional;

@Component
public class RestUtil {
    private static Logger log = LoggerFactory.getLogger(RestUtil.class);

    private static final long MAX_REQUEST_WAIT_TIME = 4000L;

    private static RestTemplate restTemplate;

    private static ObjectMapper objectMapper;


    @Autowired
    private void setRestTemplate(RestTemplate restTemplate) {
        RestUtil.restTemplate = restTemplate;
    }

    @Autowired
    private void setObjectMapper(ObjectMapper objectMapper) {
        RestUtil.objectMapper = objectMapper;
    }


    /**
     * post请求携带表单数据
     *
     * @param url
     * @param paramMap
     * @param headerMap
     * @param typeReference
     * @param <T>
     * @return
     */
    public static <T> T doFormPost(String url, MultiValueMap<String, Object> paramMap, Map<String, String> headerMap, ParameterizedTypeReference<T> typeReference) {
        try {
            //设置请求头
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
            if (MapUtil.isNotEmpty(headerMap)) {
                headerMap.forEach((k, v) -> headers.add(k, v));
            }

            long beginTime = System.currentTimeMillis();
            paramMap = Optional.ofNullable(paramMap).orElse(new LinkedMultiValueMap<>());
            HttpEntity<MultiValueMap> httpEntity = new HttpEntity<>(paramMap, headers);
            ResponseEntity<T> rss = restTemplate.exchange(url, HttpMethod.POST, httpEntity, typeReference);
            long spendtime = System.currentTimeMillis() - beginTime;
            String payload = JSON.toJSONString(paramMap);
            String result = String.format("RestHelper.doFormPost::request:%s,cost:%dms,payload:%s,reponse:%s", url, spendtime, payload, rss.getBody());
            if (spendtime > MAX_REQUEST_WAIT_TIME) {
                log.warn(result);
            } else {
                log.info(result);
            }
            if (rss.getStatusCode().equals(HttpStatus.OK)) {
                return rss.getBody();
            } else {
                log.error("RestHelper.doFormPost::failed to request:{},param:{},httpstatus:{},repsBody:{}", url, payload, rss.getStatusCode(), rss.getBody());
                throw new BizException(CodeMsg.NETWORK_EXCEPTION.getCode(), CodeMsg.NETWORK_EXCEPTION.getMsg());
            }
        } catch (HttpStatusCodeException e) {
            // 4xx和5xx的错误打印状态码
            log.error("RestHelper.doFormPost::failed to request:{},param:{},httpstatus:{},repsBody:{}", url, paramMap, e.getStatusCode().value(), e.getResponseBodyAsString(), e);
            throw new BizException(CodeMsg.NETWORK_EXCEPTION.getCode(), CodeMsg.NETWORK_EXCEPTION.getMsg());
        } catch (Exception e) {
            log.error("RestHelper.doFormPost::failed to request:{},param:{}", url, paramMap, e);
            throw new BizException(CodeMsg.NETWORK_EXCEPTION.getCode(), CodeMsg.NETWORK_EXCEPTION.getMsg());
        }
    }

    /**
     * post请求
     *
     * @param url
     * @param payload
     * @param headerMap
     * @return
     */
    public static String doPost(String url, String payload, Map<String, String> headerMap) {
        try {
            //设置请求头
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            if (MapUtil.isNotEmpty(headerMap)) {
                headerMap.forEach((k, v) -> headers.add(k, v));
            }

            long beginTime = System.currentTimeMillis();
            HttpEntity<String> httpEntity = new HttpEntity<>(payload, headers);
            ResponseEntity<String> rss = restTemplate.exchange(url, HttpMethod.POST, httpEntity, String.class);
            long spendtime = System.currentTimeMillis() - beginTime;
            String result = String.format("RestHelper.doPost::request:%s,cost:%dms,payload:%s,reponse:%s", url, spendtime, payload, rss.getBody());
            if (spendtime > MAX_REQUEST_WAIT_TIME) {
                log.warn(result);
            } else {
                log.info(result);
            }
            if (rss.getStatusCode().equals(HttpStatus.OK)) {
                return rss.getBody();
            } else {
                log.error("RestHelper.doPost::failed to request:{},param:{},httpstatus:{},repsBody:{}", url, payload, rss.getStatusCode(), rss.getBody());
                throw new BizException(CodeMsg.NETWORK_EXCEPTION.getCode(), CodeMsg.NETWORK_EXCEPTION.getMsg());
            }
        } catch (HttpStatusCodeException e) {
            // 4xx和5xx的错误打印状态码
            log.error("RestHelper.doPost::failed to request:{},param:{},httpstatus:{},repsBody:{}", url, payload, e.getStatusCode().value(), e.getResponseBodyAsString(), e);
            throw new BizException(CodeMsg.NETWORK_EXCEPTION.getCode(), CodeMsg.NETWORK_EXCEPTION.getMsg());
        } catch (Exception e) {
            log.error("RestHelper.doPost::failed to request:{},param:{}", url, payload, e);
            throw new BizException(CodeMsg.NETWORK_EXCEPTION.getCode(), CodeMsg.NETWORK_EXCEPTION.getMsg());
        }
    }

    /**
     * 适用出/入参遵循Java api数据结构规范的接口
     *
     * @param url
     * @param payload
     * @param headerMap
     * @param typeReference
     * @param <T>
     * @return
     */
    public static <T> T doPost(String url, String payload, Map<String, String> headerMap, TypeReference<T> typeReference) {
        String body = doPost(url, payload, headerMap);
        try {
            return objectMapper.readValue(body, typeReference);
        } catch (IOException e) {
            log.error("parse json error", e);
        }
        return null;
    }

    public static <T> T doPost(String url, String payload, Map<String, String> headerMap, Class<T> clazz) {
        String body = doPost(url, payload, headerMap);
        try {
            return objectMapper.readValue(body, clazz);
        } catch (IOException e) {
            log.error("parse json error", e);
        }
        return null;
    }

    public static String doPost(String url, Object paramObject, Map<String, String> headerMap) {
        String payload = JsonUtils.toJsonString(paramObject);
        return doPost(url, payload, headerMap);
    }

    public static <T> T doPost(String url, Object paramObject, Map<String, String> headerMap, TypeReference<T> typeReference) {
        String payload = JsonUtils.toJsonString(paramObject);
        return doPost(url, payload, headerMap, typeReference);
    }

    public static <T> T doPost(String url, Object paramObject, Map<String, String> headerMap, Class<T> clazz) {
        String payload = JsonUtils.toJsonString(paramObject);
        return doPost(url, payload, headerMap, clazz);
    }
}
