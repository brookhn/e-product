package com.jiahui.oss.service;

import io.minio.messages.Bucket;

import java.util.List;

public interface OssManagerService {

    List<Bucket> listBucket();
}
