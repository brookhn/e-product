package com.jiahui.oss.controller;

import com.jiahui.oss.common.CodeMsg;
import com.jiahui.oss.common.exceptionHandler.BizException;
import com.jiahui.oss.contract.vo.out.JsonOut;
import com.jiahui.oss.service.OssManagerService;
import io.minio.messages.Bucket;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(tags = "访问OSSweb接口")
@RestController
@RequestMapping("/v1/oss/manager")
public class OssManagerApi {

    @Autowired
    private OssManagerService managerService;

    @GetMapping("/listBucket")
    public JsonOut<List<Bucket>> getUploadParam(){
        JsonOut<List<Bucket>> jsonOut = new JsonOut<>(CodeMsg.CODE_200.code(), CodeMsg.CODE_200.getMsg());
        try {
            jsonOut.setData(managerService.listBucket());
        } catch (BizException e) {
            jsonOut.setCode(e.getCode());
            jsonOut.setMsg(e.getMsg());
        }
        return jsonOut;
    }
}
