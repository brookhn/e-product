package com.jiahui.oss.entity.commonoss;

import lombok.Data;

@Data
public class EphemeralCredentialEntity {

    public EphemeralCredentialEntity(String accesskey, String secretKey, String sessionToken, long timestamp){
        this.accesskey = accesskey;
        this.secretKey = secretKey;
        this.sessionToken = sessionToken;
        this.timestamp = timestamp;
    }

    private String sessionToken;
    private String accesskey;
    private String secretKey;
    private long timestamp;
    private boolean isExpired;
}
