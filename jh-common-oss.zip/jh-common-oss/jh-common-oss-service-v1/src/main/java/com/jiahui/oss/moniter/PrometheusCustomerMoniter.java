//package com.jiahui.oss.moniter;
//
//import com.google.common.util.concurrent.AtomicDouble;
//import io.micrometer.core.instrument.Counter;
//import io.micrometer.prometheus.PrometheusMeterRegistry;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
//
//import javax.annotation.PostConstruct;
//import java.util.concurrent.atomic.AtomicInteger;
//
//@Component
//public class PrometheusCustomerMoniter {
//
//    private Counter counter;
//
//    private AtomicDouble uploadTotalSize;
//
//    @Autowired
//    private PrometheusMeterRegistry registry;
//
//    @PostConstruct
//    private void init(){
//        counter = registry.counter("test_counter", "request_url", "request_url");
//        uploadTotalSize = registry.gauge("test_gauge", new AtomicDouble(0));
//    }
//
//    public Counter getCounter() {
//        return counter;
//    }
//
//    public AtomicDouble getUploadTotalSize() {
//        return uploadTotalSize;
//    }
//}
