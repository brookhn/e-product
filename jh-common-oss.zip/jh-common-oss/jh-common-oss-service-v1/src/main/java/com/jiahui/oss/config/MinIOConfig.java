package com.jiahui.oss.config;

import com.jiahui.oss.common.GlobalVar;
import io.minio.MinioClient;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;


@Data
@Component
@ConfigurationProperties(prefix = "minio")
@RefreshScope
public class MinIOConfig {

    private String endpoint;

    private Integer port;

    private String accessKey;

    private String secretKey;

    private Boolean secure;

    private String region;

    private String picPrefixUrl;

    private String roleArn;

    private String ephmeralPolicy;

    private String buckets;

    private Map<String, String> bucketMap;


    public String getRedefineUrl() {
        StringBuilder redefineUrl = new StringBuilder();
//        redefineUrl.append("http://").append(endpoint).append(":").append(port);
//        redefineUrl.append("http://").append(endpoint);
        redefineUrl.append(endpoint);
        return redefineUrl.toString();
    }

    private void handleBucketMap(){
        try {
            bucketMap = new HashMap<>();
            String[] bkArray = buckets.split("\\|");
            if (null != bkArray && bkArray.length > 0) {
                for (String bkStr : bkArray) {
                    if (!StringUtils.isBlank(bkStr)) {
                        String[] realBucket = bkStr.split("\\:");
                        if (null != realBucket && realBucket.length >= 2) {
                            bucketMap.put(realBucket[0], realBucket[1]);
                        }
                    }
                }
            }
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }


    @Bean(name = "nwminio")
    public MinioClient getMinioClient() {
        handleBucketMap();
        MinioClient minioClient =
                MinioClient.builder()
                        .endpoint(getRedefineUrl())
                        .credentials(accessKey, secretKey)
                        .build();
        return minioClient;
    }


}