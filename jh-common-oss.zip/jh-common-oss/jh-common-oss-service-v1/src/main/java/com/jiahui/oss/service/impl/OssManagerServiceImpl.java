package com.jiahui.oss.service.impl;

import com.jiahui.oss.handler.MinioPlatformHandler;
import com.jiahui.oss.service.OssManagerService;
import io.minio.messages.Bucket;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OssManagerServiceImpl implements OssManagerService {

    @Autowired
    private MinioPlatformHandler minIOPlatformHandler;

    @Override
    public List<Bucket> listBucket() {
        return minIOPlatformHandler.listBuckets();
    }
}
