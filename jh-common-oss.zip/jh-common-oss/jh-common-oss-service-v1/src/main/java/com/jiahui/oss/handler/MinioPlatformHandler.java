package com.jiahui.oss.handler;

import com.jiahui.oss.common.BizVar;
import com.jiahui.oss.common.GlobalVar;
import com.jiahui.oss.config.MinIOConfig;
import com.jiahui.oss.contract.vo.out.GetRemoveResouceOutVO;
import com.jiahui.oss.entity.commonoss.EphemeralCredentialEntity;
import com.jiahui.oss.util.DateUtil;
import io.minio.*;
import io.minio.credentials.AssumeRoleProvider;
import io.minio.http.Method;
import io.minio.messages.Bucket;
import lombok.SneakyThrows;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * @Description MinIO平台处理类
 * @Author it-framework
 * @Date 2021年03月22日 17:43
 */
@Log4j2
@Component
public class MinioPlatformHandler {

    @Autowired
    @Qualifier(value="nwminio")
    private MinioClient minioClient;

    @Autowired
    private MinIOConfig minIOConfig;


    public static final String POLICY_GET_AND_PUT = "{\n" +
            "    \"Version\": \"2012-10-17\",\n" +
            "    \"Statement\": [\n" +
            "        {\n" +
            "            \"Effect\": \"Allow\",\n" +
            "            \"Action\": [\n" +
            "                \"s3:GetBucketLocation\",\n" +
            "                \"s3:ListBucket\",\n" +
            "                \"s3:PutObject\",\n" +
            "                \"s3:GetBucketLocation\"\n" +
            "            ],\n" +
            "            \"Resource\": [\n" +
            "                \"arn:aws:s3:::*\"\n" +
            "            ]\n" +
            "        }\n" +
            "    ]\n" +
            "}";

    /**
     * 生产JS使用的临时key及seesion
     *
     * @return
     */
    @SneakyThrows
    public EphemeralCredentialEntity getEphemeralCredentialEntity(Integer durationSeconds, String sessionName) {

//        durationSeconds = durationSeconds < GlobalVar.MINIO_EPHEMERAL_TTL? GlobalVar.MINIO_EPHEMERAL_TTL:durationSeconds;
        AssumeRoleProvider provider =  new AssumeRoleProvider(
                minIOConfig.getRedefineUrl(),
                minIOConfig.getAccessKey(),
                minIOConfig.getSecretKey(),
                GlobalVar.MINIO_EPHEMERAL_TTL,//token失效周期为1天
                POLICY_GET_AND_PUT,
                minIOConfig.getRegion(),
                minIOConfig.getRoleArn(),
                sessionName,
                null,
                null);
        if (null != provider) {
            long timeStamp = DateUtil.getCurrentTimeAddTimes(durationSeconds);
            return  new EphemeralCredentialEntity(provider.fetch().accessKey(),
                                                  provider.fetch().secretKey(),
                                                  provider.fetch().sessionToken(),
                                                  timeStamp);
        }
        return null;
    }


    /**
     * 通过InputStream上传文件
     * @param bucketName
     * @param objectName
     * @param stream
     * @param contentType
     */
    @SneakyThrows
    public boolean putObject(String bucketName, String objectName, InputStream stream, String contentType) {
        boolean flag = bucketExists(bucketName);
        if (flag) {
            minioClient.putObject(
                    PutObjectArgs.builder().bucket(bucketName).object(objectName).stream(
                            stream, stream.available(), -1)
                            .contentType(contentType)
                            .build());
            StatObjectResponse status = statObject(bucketName, objectName);
            if (status != null && status.size() > 0){
                return true;
            }

        }
        return false;
    }

    /**
     * 基于媒体文件上传
     * @param bucketName
     * @param multipartFile
     * @param fileName
     */
    @SneakyThrows
    public boolean putObject(String bucketName, MultipartFile multipartFile, String fileName) {
        boolean flag = bucketExists(bucketName);
        if (flag) {
            minioClient.putObject(
                    PutObjectArgs.builder().bucket(bucketName).object(fileName).stream(
                            multipartFile.getInputStream(), multipartFile.getSize(), ObjectWriteArgs.MIN_MULTIPART_SIZE)
                            .contentType(multipartFile.getContentType())
                            .build());
            StatObjectResponse status = statObject(bucketName, fileName);
            if (status != null && status.size() > 0){
                return true;
            }
        }
        return false;
    }

    /**
     *
     * 
     * @param bucketName
     * @param objectName
     * @param expires
     * @return
     */
    @SneakyThrows
    public String presignedGetObject(String bucketName, String objectName, Integer expires) {
        boolean flag = bucketExists(bucketName);
        String url = "";
        if (flag) {
//            if (expires < 1 || expires > BizVar.DEFAULT_RRSOURCE_URL_EXPIRY_TIME) {
//                throw  new IllegalArgumentException("expires must be in range of 1 to " + BizVar.DEFAULT_RRSOURCE_URL_EXPIRY_TIME);
//            }
            if (null == expires ||expires > BizVar.DEFAULT_RRSOURCE_URL_EXPIRY_TIME || expires < 1 ){
                expires = BizVar.DEFAULT_RRSOURCE_URL_EXPIRY_TIME;
            }
            StatObjectResponse objectStat =
                    minioClient.statObject(
                            StatObjectArgs.builder().bucket(bucketName).object(objectName).build());
            System.out.println(objectStat.etag());

            url = minioClient.getPresignedObjectUrl(GetPresignedObjectUrlArgs.builder()
                                            .method(Method.GET)
                                            .bucket(bucketName)
                                            .object(objectName)
                                            .expiry(expires, TimeUnit.SECONDS)
                                            .build());
        }
        return url;
    }

    /**
     *
     * @param bucketName
     * @param objectName
     * @return
     */
    @SneakyThrows
    public String getObjectUrl(String bucketName, String objectName) {
        boolean flag = bucketExists(bucketName);
        String URL = StringUtils.EMPTY;
        if (flag) {
            URL = presignedGetObject(bucketName, objectName, BizVar.DEFAULT_RRSOURCE_URL_EXPIRY_TIME);
        }
        return URL;
    }


    @SneakyThrows
    public GetRemoveResouceOutVO removeObjectUrl(String bucketName, String objectName){
        GetRemoveResouceOutVO removeResouceOutVO = new GetRemoveResouceOutVO();
        removeResouceOutVO.setBucketName(bucketName);
        removeResouceOutVO.setObjectName(objectName);
        boolean flag = bucketExists(bucketName);
        String URL = StringUtils.EMPTY;
        removeResouceOutVO.setRemoveResult(false);
        if (flag) {
            minioClient.removeObject(RemoveObjectArgs.builder().bucket(bucketName).object(objectName).build());
           removeResouceOutVO.setRemoveResult(true);
        }
        return removeResouceOutVO;
    }

    /**
     * 检查存储桶是否存在
     * @param bucketName
     * @return
     */
    @SneakyThrows
    public boolean bucketExists(String bucketName) {
        boolean isExistsFlag = false;
        isExistsFlag =  minioClient.bucketExists(BucketExistsArgs.builder()
                                                .bucket(bucketName).build());
        if (isExistsFlag) {
            return true;
        }
        return false;
    }

    /**
     * 获取对像的元数据信息
     * @param bucketName
     * @param obejctName
     * @return
     */
    @SneakyThrows
    public StatObjectResponse statObject(String bucketName, String obejctName) {
        boolean flag = bucketExists(bucketName);
        if (flag){
            StatObjectResponse stat =
                    minioClient.statObject(
                            StatObjectArgs.builder().bucket(bucketName).object(obejctName).build());
            return stat;
        }
        return null;
    }

    /**
     * 获取存储桶列表
     * @return
     */
    @SneakyThrows
    public List<Bucket> listBuckets() {
        return  minioClient.listBuckets();
    }
}
