package com.jiahui.oss.common;

/**
 * @author sql
 * 全局变量类
 */
public class GlobalVar {
    //redis 过期时间 单位/小时
    public static final int Timeout_Default = 24;

    //status 状态码
    public static final int Status_Ok = 200;
    public static final int Status_BadRequest = 404;
    public static final int Status_BadRequestParam = 400;
    public static final int Status_ServerErr = 500;

    //jwt 配置
    public static final String SRC = "Src";
    public static final String IP = "Ip";
    public static final String USERID = "UserId";
    public static final String USERTYPE = "UserType";
    public static final String ROLE = "role";
    public static final String TTLS = "ttls";
    public static final int TTLS_VALUE = 86400;// 24小时

    public static final int MINIO_EPHEMERAL_TTL = 86400; //3600秒
}