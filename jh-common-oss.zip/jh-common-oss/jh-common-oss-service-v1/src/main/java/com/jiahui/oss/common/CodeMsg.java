package com.jiahui.oss.common;

/**
 * @author SQL
 * @date 2017-12-13
 */
public enum CodeMsg {
    /**
     * 参数异常
     */
    PARAMS_EMPTY(210001000, "参数为空"),
    PARAMS_ERROR(210001001, "参数错误"),
    /**
     * 业务异常
     */
    EXCEPTION(21000000, "业务异常"),
    CODE_210002001(210002001, "文件上传异常"),
    CODE_210002002(210002002, "获取上传参数异常"),
    CODE_210002003(210002003, "获取资源bucket异常"),
    CODE_210002004(210002004, "获取资源URL异常"),
    NETWORK_EXCEPTION(220002011, "网络异常，请稍后重试"),
    CODE_210002005(210002005, "获取bucket列表异常"),
    CODE_210002006(210002006, "异常对象异常"),


    CODE_210005000(210005000, "external json解析异常:"),

    CODE_200(200, "成功");


    private Integer code;
    private String msg;

    CodeMsg(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer code() {
        return code;
    }

    public String msg() {
        return msg;
    }

    public Integer getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }

}
