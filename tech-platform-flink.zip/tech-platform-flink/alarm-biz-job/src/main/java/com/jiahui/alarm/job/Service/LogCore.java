package com.jiahui.alarm.job.Service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Component
public class LogCore {

    @Value("${spring.profiles.active}")
    private String onProfile;

    @Value("${kibana.url}")
    private String kibanaUrl;

    @Value("${aliyun.kibana.url}")
    private String aliyunKibanaUrl;

    public String getInvokeLogIndex(String group) {
        String index;
        boolean isAliyun = "frontend-server".equals(group) ? true : false;
        if (isAliyun) {
            index = "invoking-log-" + group + "-" + onProfile + "-" + DateTimeFormatter.ofPattern("yyyyMMdd").format(LocalDate.now());
        } else {
            index = "invoking-log-" + group + "-" + DateTimeFormatter.ofPattern("yyyyMM").format(LocalDate.now());
        }
        return index;
    }

    public String getKibanaUrl(String group) {
        return "frontend-server".equals(group) ? aliyunKibanaUrl : kibanaUrl;
    }

}
