package com.jiahui.alarm.job.Service;

import com.jiahui.alarm.job.ESClientProxy;
import com.jiahui.alarm.job.client.proxy.AlarmClient;
import com.jiahui.alarm.job.dto.AlarmRequest;
import com.xxl.job.core.handler.annotation.XxlJob;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.RangeQueryBuilder;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.redisson.api.RBucket;
import org.redisson.api.RedissonClient;
import org.redisson.client.codec.StringCodec;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

@Service
public class OracleLogAlertService {
    private static Logger logger = LoggerFactory.getLogger(ProgramLogAlertService.class);
    private static DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS+08:00");
    @Autowired
    private ESClientProxy clientProxy;
    @Autowired
    private AlarmClient alarmClient;

    @Autowired
    private RedissonClient redissonClient;

    @Value("${kibana.url}")
    private String kibanaUrl;

    @XxlJob("oracleLogAlert")
    public boolean oracleLogAlert() {
        String index = "oracle-log-" + DateTimeFormatter.ofPattern("yyyyMM").format(LocalDate.now());
        boolean exists = clientProxy.exists(index, false);
        if (!exists) {
            return false;
        }
        RBucket<String> rBucket = redissonClient.getBucket("V2:OracleLogWarning:LastTime", new StringCodec());
        ZonedDateTime lastTime;
        ZonedDateTime now = ZonedDateTime.now();
        String lastTimeStr = rBucket.getAndSet(now.format(dateTimeFormatter), 1, TimeUnit.HOURS);
        if (StringUtils.isNotBlank(lastTimeStr)) {
            lastTime = ZonedDateTime.parse(lastTimeStr);
        } else {
            lastTime = now.plusDays(-3);
        }
        BoolQueryBuilder queryBuilder = QueryBuilders.boolQuery();
        queryBuilder.must(QueryBuilders.matchQuery("message", "ora"));
        queryBuilder.must(QueryBuilders.matchQuery("message", "00600"));
        RangeQueryBuilder rangequerybuilder = QueryBuilders
                .rangeQuery("@timestamp")
                .from(lastTime).to(now).includeUpper(false);
        queryBuilder.must(rangequerybuilder);
        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        searchSourceBuilder.size(0);
        searchSourceBuilder.query(queryBuilder);
        SearchRequest searchRequest = new SearchRequest(index);
        searchRequest.source(searchSourceBuilder);

        SearchResponse response;
        try {
            logger.info("index:{},{}", index, searchSourceBuilder);
            response = clientProxy.search(searchRequest, false);
            //获取聚合的结果
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return false;
        }
        long totalCount = Optional.ofNullable(response).map(p -> p.getHits().getTotalHits().value).orElse(0l);
        if (totalCount <= 0) {
            return false;
        }

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        DateTimeFormatter dtFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        StringBuilder sb = new StringBuilder();
        sb.append("  \n  ");
        sb.append("- **发生时间段**：").append(lastTime.format(formatter)).append("至").append(now.format(formatter))
                .append("  \n  ");
        StringBuilder linkUrl = new StringBuilder();
        linkUrl.append(kibanaUrl);
        linkUrl.append("?_g=(filters:!(),refreshInterval:(pause:!t,value:0),time:(from:'")
                .append(lastTime.withZoneSameInstant(ZoneId.of("UTC")).format(dtFormatter))
                .append("',to:now))&_a=(columns:!(),filters:!(),index:'0b4afa30-c22e-11ec-9723-93b381b04266',interval:auto,query:(language:kuery,query:'message%20:%20\"ora\"%20and%20message%20:%20\"00600\"'),sort:!(!('@timestamp',desc)))");
        sb.append("- 错误数：").append(response.getHits().getTotalHits().value).append("(").append(linkUrl).append(")").append("  \n  ");
        String alarmContent = sb.toString();
        logger.info("OracleLogAlert:{}", alarmContent);
        AlarmRequest alarmRequest = new AlarmRequest();
        alarmRequest.setCode("2022042401");
        alarmRequest.setContent(alarmContent);
        alarmRequest.setLevel("ERROR");
        try {
            alarmClient.alarm(alarmRequest);
        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
        }
        return true;
    }
}
