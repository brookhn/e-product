//package com.jiahui.alarm.job.consumer;
//
//import com.jiahui.alarm.job.constants.TopicConstant;
//import com.jiahui.alarm.job.dao.influxdb.ProgramLogRepository;
//import com.jiahui.alarm.job.model.ProgramLogAlarm;
//import com.jiahui.alarm.job.util.JacksonUtils;
//import lombok.extern.slf4j.Slf4j;
//import org.apache.kafka.clients.consumer.ConsumerRecord;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.kafka.annotation.KafkaListener;
//import org.springframework.kafka.support.Acknowledgment;
//import org.springframework.stereotype.Service;
//import org.springframework.util.CollectionUtils;
//
//import java.util.List;
//import java.util.Objects;
//
///**
// * 消费flink 统计的program log窗口数据写入influxdb（grafana Program Log看板信息）
// */
//@Slf4j
//@Service
//@Deprecated
//public class FlinkProgramLogConsumer {
//
//    @Autowired
//    private ProgramLogRepository programLogRepository;
//
//
//    @KafkaListener(topics = TopicConstant.FLINK_LOGGING_ERROR_COUNT, groupId = "flinkConsumer", containerFactory = "batchFactory")
//    public void listenProgramLog(List<ConsumerRecord<String, String>> list, Acknowledgment ack) {
//        if (CollectionUtils.isEmpty(list)) {
//            return;
//        }
//        for (ConsumerRecord<String, String> record : list) {
//            try {
//                String value = record.value();
//                ProgramLogAlarm alarm = JacksonUtils.json2pojo(value, ProgramLogAlarm.class);
//                if (Objects.nonNull(alarm)) {
//                    programLogRepository.insert(alarm.getAppName(), alarm.getWindowStart(), alarm.getErrNum());
//                }
//            } catch (Exception e) {
//                log.error("write to influxdb error key[{}] value[{}]", record.key(), record.value(), e);
//            }
//        }
//        ack.acknowledge();
//    }
//}
