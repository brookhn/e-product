package com.jiahui.alarm.job.client.proxy;

import com.jiahui.alarm.job.dto.kafka.GetConsumerResponse;
import com.jiahui.alarm.job.dto.kafka.GetLagResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Component
@FeignClient(name = "burrow", url = "${burrow.host}", configuration = AlarmClientConfig.class)
public interface BurrowLogClient {
    @GetMapping(path = "/{cluster}/consumer")
    GetConsumerResponse consumer(@PathVariable("cluster") String cluster);

    @GetMapping(path = "/{cluster}/consumer/{groupId}/lag")
    GetLagResponse lag(@PathVariable("groupId") String groupId,@PathVariable("cluster") String cluster);
}
