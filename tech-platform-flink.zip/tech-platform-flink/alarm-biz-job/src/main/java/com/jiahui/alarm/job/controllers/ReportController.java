package com.jiahui.alarm.job.controllers;

import com.alibaba.excel.EasyExcel;
import com.jiahui.alarm.job.Service.InvokeLogMetricService;
import com.jiahui.alarm.job.domain.model.ApiTPStatEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@RestController
public class ReportController {

    @Autowired
    private InvokeLogMetricService logMetricService;

    @Value("#{'${index.groups}'.split(',')}")
    private Set<String> indexGroups;


    @GetMapping("/apiTP9095Report")
    public void apiTP9095Report(HttpServletResponse response) throws IOException {
        List<ApiTPStatEntity> results = new ArrayList<>();
        for (String group : indexGroups) {
            List<ApiTPStatEntity> list = logMetricService.apiTPStatCore(group);
            results.addAll(list);
        }
        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        response.setCharacterEncoding("utf-8");
        // 这里URLEncoder.encode可以防止中文乱码 当然和easyexcel没有关系
        String fileName = URLEncoder.encode("TP9095", "UTF-8").replaceAll("\\+", "%20");
        response.setHeader("Content-disposition", "attachment;filename*=utf-8''" + fileName + ".xlsx");
        EasyExcel.write(response.getOutputStream(), ApiTPStatEntity.class).sheet("模板").doWrite(results);
        response.flushBuffer();
    }
}
