package com.jiahui.alarm.job.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
public class InvokeLogDTO implements Serializable {

    @JsonProperty("traceid")
    private String traceId;

    @JsonProperty("appversion")
    private String appVersion;

    @JsonProperty("appname")
    private String appName;

    @JsonProperty("appenv")
    private String appEnv;

    @JsonProperty("current_time")
    private Date currentTime;

    @JsonProperty("response_time")
    private Date responseTime;

    @JsonProperty("http_status")
    private String httpStatus;

    @JsonProperty("uri")
    private String uri;

    @JsonProperty("user_agent")
    private String userAgent;

    @JsonProperty("http_method")
    private String httpMethod;

    @JsonProperty("spend_time")
    private Long spendTime;

    @JsonProperty("server_ip")
    private String serverIp;

    @JsonProperty("ip")
    private String ip;

    @JsonProperty("src")
    private String src;

    @JsonProperty("userid")
    private String userid;

    @JsonProperty("request_param")
    private String requestParam;

    @JsonProperty("code")
    private String code;

    @JsonProperty("response_body")
    private String responseBody;
}
