package com.jiahui.alarm.job.domain.model;

import java.util.HashMap;
import java.util.Map;

public class InvokeLogAlertEntity {
    private String appName;
    private Map<String, Long> errorCodeStatMap;
    private Map<String, Long> httpStatusMap;

    public InvokeLogAlertEntity() {
        this.errorCodeStatMap = new HashMap<>();
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public Map<String, Long> getErrorCodeStatMap() {
        return errorCodeStatMap;
    }

    public void setErrorCodeStatMap(Map<String, Long> errorCodeStatMap) {
        this.errorCodeStatMap = errorCodeStatMap;
    }

    public Map<String, Long> getHttpStatusMap() {
        return httpStatusMap;
    }

    public void setHttpStatusMap(Map<String, Long> httpStatusMap) {
        this.httpStatusMap = httpStatusMap;
    }
}
