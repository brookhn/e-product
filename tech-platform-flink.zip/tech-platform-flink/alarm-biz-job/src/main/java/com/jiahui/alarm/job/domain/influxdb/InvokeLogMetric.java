package com.jiahui.alarm.job.domain.influxdb;

import com.influxdb.annotations.Column;
import com.influxdb.annotations.Measurement;
import lombok.Builder;
import lombok.Data;

import java.time.Instant;

@Data
@Builder
@Measurement(name = "invoke_log_metric")
public class InvokeLogMetric {

    @Column(tag = true)
    String appName;

    @Column(tag = true)
    String uri;

    @Column(tag = true)
    private Double percent;

    @Column
    private Double elapsed_time;

    @Column
    private Long request_count;

    @Column(timestamp = true)
    Instant date;


}