package com.jiahui.alarm.job.Service;

import com.google.common.collect.ImmutableMap;
import com.jiahui.alarm.job.ESClientProxy;
import com.jiahui.alarm.job.client.proxy.AlarmClient;
import com.jiahui.alarm.job.domain.model.ProgramLogAlertEntity;
import com.jiahui.alarm.job.dto.AlarmRequest;
import com.xxl.job.core.handler.annotation.XxlJob;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.RangeQueryBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.TermsAggregationBuilder;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.redisson.api.RBucket;
import org.redisson.api.RedissonClient;
import org.redisson.client.codec.StringCodec;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

@RefreshScope
@Service
public class ProgramLogAlertService {

    private static Logger logger = LoggerFactory.getLogger(ProgramLogAlertService.class);
    private static DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS+08:00");
    @Autowired
    private ESClientProxy clientProxy;
    @Autowired
    private AlarmClient alarmClient;

    @Resource(name = "coreThreadPool")
    private ExecutorService threadPool;

    @Autowired
    private RedissonClient redissonClient;

    @Value("${spring.profiles.active}")
    private String onProfile;

    private final Map<String, Integer> groupMap = new ImmutableMap.Builder<String, Integer>()
            .put("ehr", 2022010401)
            .put("billing", 2022010402)
            .put("tech-platform", 2022010403)
            .put("frontend-server", 2022010404)
            .build();

    @Value("#{${program.log.pattern.map}}")
    private Map<String, String> indexPatternIdMap;
    @Autowired
    private LogCore logCore;

    @XxlJob("programLogAlert")
    public void programLogAlert() {
        List<CompletableFuture<Boolean>> futures = new ArrayList<>();
        for (Map.Entry<String, Integer> entry : groupMap.entrySet()) {
            CompletableFuture<Boolean> f = CompletableFuture.supplyAsync(() -> programLogAlertCore(entry.getKey()), threadPool);
            futures.add(f);
        }
        CompletableFuture.allOf(futures.toArray(new CompletableFuture[futures.size()])).join();
    }

    public boolean programLogAlertCore(String group) {
        String index;
        boolean isAliyun = "frontend-server".equals(group) ? true : false;
        if (isAliyun) {
            index = group + "-program-log-" + onProfile + "-" + DateTimeFormatter.ofPattern("yyyyMMdd").format(LocalDate.now());
        } else {
            index = group + "-program-log-" + DateTimeFormatter.ofPattern("yyyyMM").format(LocalDate.now());
        }
        boolean exists = clientProxy.exists(index, isAliyun);
        if (!exists) {
            return false;
        }
        RBucket<String> rBucket = redissonClient.getBucket(String.format("V2:%s:ProgramLogWarning:LastTime", group), new StringCodec());
        ZonedDateTime lastTime;
        ZonedDateTime now = ZonedDateTime.now();
        String lastTimeStr = rBucket.getAndSet(now.format(dateTimeFormatter), 1, TimeUnit.HOURS);
        if (StringUtils.isNotBlank(lastTimeStr)) {
            lastTime = ZonedDateTime.parse(lastTimeStr);
        } else {
            lastTime = now.plusMinutes(-3);
        }
        BoolQueryBuilder queryBuilder = QueryBuilders.boolQuery();
        queryBuilder.must(QueryBuilders.termQuery("level", "error"));
        queryBuilder.must(QueryBuilders.termQuery("appenv", onProfile));
        RangeQueryBuilder rangequerybuilder = QueryBuilders
                .rangeQuery("current_time")
                .from(lastTime).to(now).includeUpper(false);
        queryBuilder.must(rangequerybuilder);
        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        searchSourceBuilder.size(0);
        searchSourceBuilder.query(queryBuilder);
        TermsAggregationBuilder agg
                = AggregationBuilders.terms("app_name").field("appname");
        if ("tech-platform".equals(group) || "ehr".equals(group)) {
            agg.subAggregation(AggregationBuilders.terms("exception_class").field("exception_class"));
        }
        searchSourceBuilder.aggregation(agg);
        SearchRequest searchRequest = new SearchRequest(index);
        searchRequest.source(searchSourceBuilder);

        List<ProgramLogAlertEntity> list = new ArrayList<>();
        SearchResponse response;
        try {
            logger.info("index:{},{}", index, searchSourceBuilder);
            response = clientProxy.search(searchRequest, isAliyun);
            //获取聚合的结果
            Terms termsAgg = response.getAggregations().get("app_name");
            if (CollectionUtils.isEmpty(termsAgg.getBuckets())) {
                return false;
            }

            for (Terms.Bucket bucket : termsAgg.getBuckets()) {
                ProgramLogAlertEntity entity = new ProgramLogAlertEntity();
                entity.setAppName(bucket.getKey().toString());
                entity.setErrorCount(bucket.getDocCount());
                if ("tech-platform".equals(group) || "ehr".equals(group)) {
                    Terms terms = bucket.getAggregations().get("exception_class");
                    if (terms != null && !CollectionUtils.isEmpty(terms.getBuckets())) {
                        LinkedHashMap<String, Long> statMap = terms.getBuckets().stream()
                                .sorted(Comparator.comparing((Terms.Bucket p) -> p.getDocCount()).reversed()).limit(10)
                                .collect(Collectors.toMap(p -> p.getKey().toString(), p -> p.getDocCount(), (p1, p2) -> p1, LinkedHashMap<String, Long>::new));
                        entity.setExceptionStatMap(statMap);
                    }
                }
                list.add(entity);
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return false;
        }

        if (CollectionUtils.isEmpty(list)) {
            return false;
        }

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        DateTimeFormatter dtFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        StringBuilder sb = new StringBuilder();
        sb.append("  \n  ");
        sb.append("- **发生时间段**：").append(lastTime.format(formatter)).append("至").append(now.format(formatter))
                .append("（点击应用名查看详情）  \n  ");
        for (ProgramLogAlertEntity entity : list) {
            StringBuilder linkUrl = new StringBuilder();
            linkUrl.append(logCore.getKibanaUrl(group));
            linkUrl.append("?_a=(columns:!(_source),index:'").append(indexPatternIdMap.get(group))
                    .append("',interval:auto,query:(language:kuery,query:'appname%20:%20%22").append(entity.getAppName())
                    .append("%22%20and%20level%20:%20%22error%22%20'),sort:!(!(current_time,desc)))&_g=(filters:!(),refreshInterval:(pause:!t,value:0),time:(from:'")
                    .append(lastTime.withZoneSameInstant(ZoneId.of("UTC")).format(dtFormatter))
                    .append("',to:'").append(now.withZoneSameInstant(ZoneId.of("UTC")).format(dtFormatter)).append("'))");
            sb.append("- [").append(entity.getAppName()).append("]")
                    .append("(").append(linkUrl).append(")")
                    .append("  错误数：").append(entity.getErrorCount()).append("  \n  ");
            if (!CollectionUtils.isEmpty(entity.getExceptionStatMap())) {
                for (Map.Entry<String, Long> entry : entity.getExceptionStatMap().entrySet()) {
                    sb.append(" - ").append(entry.getKey()).append("(").append(entry.getValue()).append(")  \n  ");
                }
            }
        }
        String alarmContent = sb.toString();
        logger.info("ProgramLogAlert:{}", alarmContent);
        AlarmRequest alarmRequest = new AlarmRequest();
        alarmRequest.setCode(groupMap.get(group).toString());
        alarmRequest.setContent(alarmContent);
        alarmRequest.setLevel("ERROR");
        try {
            alarmClient.alarm(alarmRequest);
        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
        }
        return true;
    }
}
