//package com.jiahui.alarm.job.core;
//
//import com.alibaba.fastjson.JSON;
//import com.jiahui.alarm.job.dto.ConsumerDetail;
//import org.apache.kafka.clients.CommonClientConfigs;
//import org.apache.kafka.clients.admin.*;
//import org.apache.kafka.clients.consumer.ConsumerConfig;
//import org.apache.kafka.clients.consumer.KafkaConsumer;
//import org.apache.kafka.clients.consumer.OffsetAndMetadata;
//import org.apache.kafka.common.ConsumerGroupState;
//import org.apache.kafka.common.TopicPartition;
//import org.apache.kafka.common.serialization.StringDeserializer;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.util.CollectionUtils;
//
//import java.util.*;
//import java.util.stream.Collectors;
//
//public class KafkaLagMonitorService {
//
//    private static final Logger logger = LoggerFactory.getLogger(KafkaLagMonitorService.class);
//
//    /**
//     * Get kafka group consumer all topics lags.
//     */
//    public long getKafkaLag(String clusterAlias, String group, String ketopic) {
////        long lag = 0L;
//
//        Properties prop = new Properties();
//        prop.put(CommonClientConfigs.BOOTSTRAP_SERVERS_CONFIG, "jih-kafka01-test.jihint.com:9092,jih-kafka02-test.jihint.com:9092,jih-kafka03-test.jihint.com:9092");
//
//        AdminClient adminClient = null;
////        List<ConsumerDetail> consumerDetails = new ArrayList<>();
//        Set<String> stableGroupIds = new HashSet<>();
//        try {
//            adminClient = AdminClient.create(prop);
//
//            ListConsumerGroupsResult groupResult = adminClient.listConsumerGroups(new ListConsumerGroupsOptions());
//            List<String> groupIds = groupResult.valid().get().stream().map(ConsumerGroupListing::groupId).distinct().collect(Collectors.toList());
////            List<String> groupIds = new ArrayList<>();
////            groupIds.add("programLogConsumer");
//            DescribeConsumerGroupsResult consumerGroupsResult = adminClient.describeConsumerGroups(groupIds);
//            Map<String, ConsumerGroupDescription> consumerGroupDescriptionMap = consumerGroupsResult.all().get();
//            for (Map.Entry<String, ConsumerGroupDescription> entry : consumerGroupDescriptionMap.entrySet()) {
//                ConsumerGroupDescription consumerGroupDescription = entry.getValue();
//                if (consumerGroupDescription.state() == ConsumerGroupState.STABLE) {
//                    stableGroupIds.add(consumerGroupDescription.groupId());
//                }
//            }
//            stableGroupIds.remove("msh-service");
////            for (Map.Entry<String, Map<String, List<ConsumerDetail>>> entry : consumerDetailMap.entrySet()) {
////
////            }
//            for (String groupId : stableGroupIds) {
//                List<ConsumerDetail> consumerDetails = new ArrayList<>();
//                ListConsumerGroupOffsetsResult offsets = adminClient.listConsumerGroupOffsets(groupId);
//                for (Map.Entry<TopicPartition, OffsetAndMetadata> entry : offsets.partitionsToOffsetAndMetadata().get().entrySet()) {
//                    ConsumerDetail detail = new ConsumerDetail();
//                    detail.setGroupId(groupId);
//                    detail.setTopic(entry.getKey().topic());
//                    detail.setPartition(entry.getKey().partition());
//                    detail.setOffset(entry.getValue().offset());
//                    consumerDetails.add(detail);
//                }
//
//                Map<TopicPartition, Long> endOffsets = f1("", consumerDetails);
//                if (!CollectionUtils.isEmpty(endOffsets)) {
//                    for (ConsumerDetail consumerDetail : consumerDetails) {
//                        TopicPartition tp = new TopicPartition(consumerDetail.getTopic(), consumerDetail.getPartition());
//                        Long logSize = endOffsets.get(tp);
//                        if (logSize != null) {
//                            consumerDetail.setLag(logSize.longValue() - consumerDetail.getOffset());
//                        }
//                    }
//                }
//            }
//
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            adminClient.close();
//        }
//        return 0;
//    }
//
//
//    public Map<TopicPartition, Long> f1(String clusterAlias, List<ConsumerDetail> consumerDetails) {
//        Map<TopicPartition, Long> logSize = new HashMap<>();
//        Properties props = new Properties();
//        props.put(ConsumerConfig.GROUP_ID_CONFIG, "jh.kafka.lag.monitor");
//        props.put(CommonClientConfigs.BOOTSTRAP_SERVERS_CONFIG, "jih-kafka01-test.jihint.com:9092,jih-kafka02-test.jihint.com:9092,jih-kafka03-test.jihint.com:9092");
//        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getCanonicalName());
//        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getCanonicalName());
//        KafkaConsumer<String, String> consumer = new KafkaConsumer<>(props);
//        List<TopicPartition> topicPartitions = consumerDetails.stream().map(p -> new TopicPartition(p.getTopic(), p.getPartition())).collect(Collectors.toList());
//        consumer.assign(topicPartitions);
//
//        try {
//            //histyLogSize = logsize.get(tp).longValue();
//            logSize = consumer.endOffsets(topicPartitions);
//        } catch (Exception e) {
//            System.out.println(JSON.toJSONString(consumerDetails));
//            logger.error("getKafkaLogSizeErr", e);
//        } finally {
//            if (consumer != null) {
//                consumer.close();
//            }
//        }
//        return logSize;
//    }
//
//
//    public long getKafkaLogSize(String clusterAlias, String topic, int partitionid) {
//        long histyLogSize = 0L;
//        Properties props = new Properties();
//        props.put(ConsumerConfig.GROUP_ID_CONFIG, "jh.kafka.lag.monitor");
//        props.put(CommonClientConfigs.BOOTSTRAP_SERVERS_CONFIG, "jih-kafka01-test.jihint.com:9092,jih-kafka02-test.jihint.com:9092,jih-kafka03-test.jihint.com:9092");
//        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getCanonicalName());
//        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getCanonicalName());
////        if (SystemConfigUtils.getBooleanProperty(clusterAlias + ".efak.sasl.enable")) {
////            sasl(props, clusterAlias);
////        }
////        if (SystemConfigUtils.getBooleanProperty(clusterAlias + ".efak.ssl.enable")) {
////            ssl(props, clusterAlias);
////        }
//        KafkaConsumer<String, String> consumer = new KafkaConsumer<>(props);
//        TopicPartition tp = new TopicPartition(topic, partitionid);
//        consumer.assign(Collections.singleton(tp));
//        java.util.Map<TopicPartition, Long> logsize = consumer.endOffsets(Collections.singleton(tp));
//        try {
//            histyLogSize = logsize.get(tp).longValue();
//        } catch (Exception e) {
//            //LOG.error("Get history topic logsize has error, msg is " + e.getMessage());
//            e.printStackTrace();
//            logger.error("getKafkaLogSizeErr", e);
//        } finally {
//            if (consumer != null) {
//                consumer.close();
//            }
//        }
//        return histyLogSize;
//    }
//}
