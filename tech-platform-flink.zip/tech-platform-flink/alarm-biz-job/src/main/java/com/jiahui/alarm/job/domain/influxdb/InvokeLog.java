package com.jiahui.alarm.job.domain.influxdb;

import com.influxdb.annotations.Column;
import com.influxdb.annotations.Measurement;
import lombok.Builder;
import lombok.Data;

import java.io.Serializable;
import java.time.Instant;

@Data
@Builder
@Measurement(name = "invoke_log")
public class InvokeLog implements Serializable {

    @Column(tag = true)
    private String appName;

    @Column(timestamp = true)
    private Instant currentTime;

    @Column
    private Long spendTime;

    @Column(tag = true)
    private String httpStatus;

    @Column(tag = true)
    private String httpMethod;

}