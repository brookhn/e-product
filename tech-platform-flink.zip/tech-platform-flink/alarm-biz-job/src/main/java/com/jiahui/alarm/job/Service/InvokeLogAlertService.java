package com.jiahui.alarm.job.Service;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.ImmutableMap;
import com.jiahui.alarm.job.ESClientProxy;
import com.jiahui.alarm.job.client.proxy.AlarmClient;
import com.jiahui.alarm.job.domain.model.InvokeLogAlertEntity;
import com.jiahui.alarm.job.dto.AlarmRequest;
import com.jiahui.alarm.job.dto.AlarmResponse;
import com.xxl.job.core.handler.annotation.XxlJob;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.RangeQueryBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.TermsAggregationBuilder;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.redisson.api.RBucket;
import org.redisson.api.RedissonClient;
import org.redisson.client.codec.StringCodec;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

@RefreshScope
@Service
public class InvokeLogAlertService {
    private static Logger logger = LoggerFactory.getLogger(InvokeLogAlertService.class);
    private static DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS+08:00");
    @Autowired
    private ESClientProxy clientProxy;
    @Autowired
    private AlarmClient alarmClient;

    @Resource(name = "coreThreadPool")
    private ExecutorService threadPool;

    @Autowired
    private RedissonClient redissonClient;

    @Value("${spring.profiles.active}")
    private String onProfile;

    @Autowired
    private LogCore logCore;

    @Value("#{'${invoke.log.whiteList.codes}'.split(',')}")
    private Set<String> whiteListCodes;

    public final Map<String, Integer> groupMap = new ImmutableMap.Builder<String, Integer>()
            .put("ehr", 2022011701)
            .put("billing", 2022011702)
            .put("tech-platform", 2022011703)
            .put("frontend-server", 2022011704)
            .build();

    @Value("${invoke.log.index.pattern}")
    private String localIndexPatternId;

    @Value("${aliyun.invoke.log.index.pattern}")
    private String aliyunIndexPatternId;

    @XxlJob("invokeLogAlert")
    public void invokeLogAlert() {
        List<CompletableFuture<Boolean>> futures = new ArrayList<>();
        for (Map.Entry<String, Integer> entry : groupMap.entrySet()) {
            CompletableFuture<Boolean> f = CompletableFuture.supplyAsync(() -> invokeLogAlertCore(entry.getKey()), threadPool);
            futures.add(f);
        }
        CompletableFuture.allOf(futures.toArray(new CompletableFuture[futures.size()])).join();
    }

    public boolean invokeLogAlertCore(String group) {
        String invokeLogIndex = logCore.getInvokeLogIndex(group);
        boolean isAliyun = "frontend-server".equals(group) ? true : false;
        boolean exists = clientProxy.exists(invokeLogIndex, isAliyun);
        if (!exists) {
            return false;
        }
        RBucket<String> rBucket = redissonClient.getBucket(String.format("V2:%s:InvokeLogWarning:LastTime", group), new StringCodec());
        ZonedDateTime lastTime;
        ZonedDateTime now = ZonedDateTime.now();
        String lastTimeStr = rBucket.getAndSet(now.format(dateTimeFormatter), 1, TimeUnit.HOURS);
        if (StringUtils.isNotBlank(lastTimeStr)) {
            lastTime = ZonedDateTime.parse(lastTimeStr);
        } else {
            lastTime = now.plusMinutes(-3);
        }
        BoolQueryBuilder queryBuilder = QueryBuilders.boolQuery();
        RangeQueryBuilder rangequerybuilder = QueryBuilders
                .rangeQuery("current_time")
                .from(lastTime).to(now).includeUpper(false);
        queryBuilder.must(rangequerybuilder);
        queryBuilder.must(QueryBuilders.termQuery("ack", "0"));
        queryBuilder.must(QueryBuilders.termQuery("appenv", onProfile));
        SearchSourceBuilder ssb = new SearchSourceBuilder();
        ssb.size(0);
        ssb.query(queryBuilder);
        TermsAggregationBuilder aggregationBuilder
                = AggregationBuilders.terms("app_name").field("appname").subAggregation(AggregationBuilders.terms("code").field("code"))
                .subAggregation(AggregationBuilders.terms("http_status").field("http_status"));
        ssb.aggregation(aggregationBuilder);
        SearchRequest sr = new SearchRequest(invokeLogIndex);
        sr.source(ssb);

        StringBuilder sb = new StringBuilder();
        List<InvokeLogAlertEntity> list = new ArrayList<>();
        try {
            SearchResponse searchResponse = clientProxy.search(sr, isAliyun);
            Terms aggResult = searchResponse.getAggregations().get("app_name");
            if (CollectionUtils.isEmpty(aggResult.getBuckets())) {
                return false;
            }
            for (Terms.Bucket bucket : aggResult.getBuckets()) {
                String appName = bucket.getKey().toString();
                Terms codeTerms = bucket.getAggregations().get("code");
                if (codeTerms == null || CollectionUtils.isEmpty(codeTerms.getBuckets())) {
                    continue;
                }
                Map<String, Long> errorCodeStatMap = codeTerms.getBuckets().stream()
                        .filter(p -> !whiteListCodes.contains(p.getKey().toString()))
                        .sorted(Comparator.comparing((Terms.Bucket p) -> p.getDocCount()).reversed()).limit(10)
                        .collect(Collectors.toMap(p -> p.getKey().toString(), p -> p.getDocCount(), (p1, p2) -> p1, LinkedHashMap<String, Long>::new));
                Terms httpStatusTerms = bucket.getAggregations().get("http_status");
                LinkedHashMap<String, Long> httpStatusMap = null;
                if (httpStatusTerms != null && !CollectionUtils.isEmpty(httpStatusTerms.getBuckets())) {
                    httpStatusMap = httpStatusTerms.getBuckets().stream()
                            .filter(p -> p.getKey().toString().startsWith("4") || p.getKey().toString().startsWith("5"))
                            .sorted(Comparator.comparing((Terms.Bucket p) -> p.getDocCount()).reversed()).limit(10)
                            .collect(Collectors.toMap(p -> p.getKey().toString(), p -> p.getDocCount(), (p1, p2) -> p1, LinkedHashMap<String, Long>::new));
                }
                if (!CollectionUtils.isEmpty(errorCodeStatMap)) {
                    InvokeLogAlertEntity alertEntity = new InvokeLogAlertEntity();
                    alertEntity.setAppName(appName);
                    alertEntity.setErrorCodeStatMap(errorCodeStatMap);
                    alertEntity.setHttpStatusMap(httpStatusMap);
                    list.add(alertEntity);
                }
            }
            if (CollectionUtils.isEmpty(list)) {
                return false;
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return false;
        }

        if (CollectionUtils.isEmpty(list)) {
            return false;
        }
        String indexPatternId = "frontend-server".equals(group) ? aliyunIndexPatternId : localIndexPatternId;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        DateTimeFormatter dtFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        sb.append("  \n  ");
        sb.append("- **发生时间段**：").append(lastTime.format(formatter)).append("至").append(now.format(formatter)).append("（点击应用名查看详情）  \n  ");
        for (InvokeLogAlertEntity entity : list) {
            StringBuilder linkUrl = new StringBuilder();
            linkUrl.append(logCore.getKibanaUrl(group));
            linkUrl.append("?_a=(columns:!(),filters:!(),index:'").append(indexPatternId)
                    .append("',interval:auto,query:(language:kuery,query:'appname%20:%20\"")
                    .append(entity.getAppName())
                    .append("%22%20%20and%20ack%20:%20%220%22%20'),sort:!(!(current_time,desc)))&_g=(filters:!(),refreshInterval:(pause:!t,value:0),time:(from:'")
                    .append(lastTime.withZoneSameInstant(ZoneId.of("UTC")).format(dtFormatter))
                    .append("',to:'").append(now.withZoneSameInstant(ZoneId.of("UTC")).format(dtFormatter)).append("'))");
            sb.append("- [").append(entity.getAppName()).append("]")
                    .append("(").append(linkUrl).append(")").append("  \n  ");
            sb.append(" - **bizCode**：  \n  ");
            for (Map.Entry<String, Long> entry : entity.getErrorCodeStatMap().entrySet()) {
                sb.append(" - ").append(entry.getKey()).append("(").append(entry.getValue()).append(")  \n  ");
            }
            if (!CollectionUtils.isEmpty(entity.getHttpStatusMap())) {
                sb.append(" - **http状态码**：  \n  ");
                for (Map.Entry<String, Long> entry : entity.getHttpStatusMap().entrySet()) {
                    sb.append(" - ").append(entry.getKey()).append("(").append(entry.getValue()).append(")  \n  ");
                }
            }
        }
        String alarmContent = sb.toString();
        logger.info("InvokeLogAlert:{}", alarmContent);
        AlarmRequest alarmRequest = new AlarmRequest();
        alarmRequest.setCode(groupMap.get(group).toString());
        alarmRequest.setContent(alarmContent);
        alarmRequest.setLevel("ERROR");
        try {
            AlarmResponse alarmResponse = alarmClient.alarm(alarmRequest);
            if (alarmResponse != null) {
                logger.info(JSON.toJSONString(alarmResponse));
            }
        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
        }
        return true;
    }
}
