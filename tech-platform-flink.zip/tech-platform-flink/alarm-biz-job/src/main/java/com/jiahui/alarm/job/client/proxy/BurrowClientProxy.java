package com.jiahui.alarm.job.client.proxy;

import com.jiahui.alarm.job.Service.KafkaLagAlertService;
import com.jiahui.alarm.job.dto.kafka.GetConsumerResponse;
import com.jiahui.alarm.job.dto.kafka.GetLagResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class BurrowClientProxy {

    private static Logger logger = LoggerFactory.getLogger(KafkaLagAlertService.class);

    @Autowired
    private BurrowLogClient logClient;

    public GetConsumerResponse getLogClusterConsumers(String cluster) {
        GetConsumerResponse response = null;
        try {
            response = logClient.consumer(cluster);
        } catch (Exception ex) {
            logger.error("getLogClusterConsumersErr", ex);
        }
        return Optional.ofNullable(response).orElse(new GetConsumerResponse());
    }

    public GetLagResponse getConsumerLag(String groupId,String cluster) {
        GetLagResponse response = null;
        try {
            response = logClient.lag(groupId,cluster);
        } catch (Exception ex) {
            logger.error("getLogClusterLagInfoErr", ex);
        }
        return Optional.ofNullable(response).orElse(new GetLagResponse());
    }
}
