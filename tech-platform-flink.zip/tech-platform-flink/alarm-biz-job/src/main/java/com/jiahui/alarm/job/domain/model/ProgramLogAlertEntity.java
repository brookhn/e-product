package com.jiahui.alarm.job.domain.model;

import lombok.*;

import java.util.LinkedHashMap;
import java.util.Map;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode(callSuper = false)
public class ProgramLogAlertEntity {
    private String appName;
    private long errorCount;
    private LinkedHashMap<String, Long> exceptionStatMap;

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public long getErrorCount() {
        return errorCount;
    }

    public void setErrorCount(long errorCount) {
        this.errorCount = errorCount;
    }

    public LinkedHashMap<String, Long> getExceptionStatMap() {
        return exceptionStatMap;
    }

    public void setExceptionStatMap(LinkedHashMap<String, Long> exceptionStatMap) {
        this.exceptionStatMap = exceptionStatMap;
    }
}
