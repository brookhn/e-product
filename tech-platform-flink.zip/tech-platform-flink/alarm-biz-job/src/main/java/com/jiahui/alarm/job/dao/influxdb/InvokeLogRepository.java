package com.jiahui.alarm.job.dao.influxdb;

import com.influxdb.client.WriteApi;
import com.influxdb.client.domain.WritePrecision;
import com.jiahui.alarm.job.domain.influxdb.InvokeLog;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Slf4j
@Repository
public class InvokeLogRepository {

    @Autowired
    private WriteApi writeApi;

    public void batchInsert(List<InvokeLog> invokeLogs) {
        try {
            writeApi.writeMeasurements(WritePrecision.NS, invokeLogs);
        } catch (Exception e) {
            log.error("invokelog batchInsert influxdb error", e);
        }
    }
}
