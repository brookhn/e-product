package com.jiahui.alarm.job.config;

import okhttp3.ConnectionPool;
import okhttp3.OkHttpClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.net.ssl.*;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.concurrent.TimeUnit;

@Configuration
public class OkHttpConfig {
    private static final Logger logger = LoggerFactory.getLogger(OkHttpConfig.class);

    @Value("${okhttp.connect.timeout:5}")
    private int connectTimeout;

    @Value("${okhttp.read.timeout:30}")
    private int readTimeout;

    @Value("${okhttp.write.timeout:30}")
    private int writeTimeout;

    @Value("${okhttp.max.idle.connections:20}")
    private int maxIdleConnections;

    @Bean
    public OkHttpClient okHttpClient(X509TrustManager manager) {
        OkHttpClient httpClient = new OkHttpClient().newBuilder()
                .sslSocketFactory(sslSocketFactory(manager), manager)// 忽略校验
                .hostnameVerifier(hostnameVerifier())
                .retryOnConnectionFailure(false)
                .connectionPool(pool())
                .connectTimeout(connectTimeout, TimeUnit.SECONDS)
                .readTimeout(readTimeout, TimeUnit.SECONDS)
                .writeTimeout(writeTimeout, TimeUnit.SECONDS)
                .build();//忽略校验
        return httpClient;
    }

    @Bean
    public X509TrustManager x509TrustManager() {
        return new X509TrustManager() {
            @Override
            public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {

            }

            @Override
            public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {

            }

            @Override
            public X509Certificate[] getAcceptedIssuers() {
                return new X509Certificate[0];
            }
        };
    }

    @Bean
    public SSLSocketFactory sslSocketFactory(TrustManager manager) {
        SSLSocketFactory socketFactory = null;
        try {
            SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, new TrustManager[]{manager}, new SecureRandom());
            socketFactory = sslContext.getSocketFactory();
        } catch (NoSuchAlgorithmException e) {
            logger.error("sslSocketFactoryErr", e);
        } catch (KeyManagementException e) {
            logger.error("sslSocketFactoryErr", e);
        }
        return socketFactory;
    }

    @Bean
    public HostnameVerifier hostnameVerifier() {
        HostnameVerifier hostnameVerifier = (s, sslSession) -> true;
        return hostnameVerifier;
    }

    @Bean
    public ConnectionPool pool() {
        return new ConnectionPool(maxIdleConnections, 30, TimeUnit.SECONDS);
    }
}
