package com.jiahui.alarm.job.dao.influxdb;

import com.influxdb.client.WriteApi;
import com.influxdb.client.domain.WritePrecision;
import com.jiahui.alarm.job.domain.influxdb.ProgramLogErrors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.List;

@Slf4j
@Repository
public class ProgramLogRepository {

    @Autowired
    private WriteApi writeApi;

    /**
     * 异步插入influxdb
     *
     * @param application
     * @param timestamp
     * @param errors
     */
    public void insert(String application, Long timestamp, Long errors) {
        try {
            ProgramLogErrors programLog = new ProgramLogErrors();
            programLog.setApplication(application);
            programLog.setErrors(errors);
            programLog.setTime(Instant.ofEpochMilli(timestamp));
            writeApi.writeMeasurement(WritePrecision.NS, programLog);

        } catch (Exception e) {
            log.error("programlog insert influxdb error", e);
        }
    }


    public void batchInsert(List<ProgramLogErrors> programLogErrorsList) {
        try {
            writeApi.writeMeasurements(WritePrecision.NS, programLogErrorsList);
        } catch (Exception e) {
            log.error("program batchInsert influxdb error", "e");
        }
    }
}