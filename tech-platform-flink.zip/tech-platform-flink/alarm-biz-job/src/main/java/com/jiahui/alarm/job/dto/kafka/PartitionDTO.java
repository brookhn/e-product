package com.jiahui.alarm.job.dto.kafka;

public class PartitionDTO {
    private String topic;
    private int partition;
    private String status;
    private long current_lag;

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public int getPartition() {
        return partition;
    }

    public void setPartition(int partition) {
        this.partition = partition;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public long getCurrent_lag() {
        return current_lag;
    }

    public void setCurrent_lag(long current_lag) {
        this.current_lag = current_lag;
    }
}
