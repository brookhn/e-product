package com.jiahui.alarm.job.dto.kafka;

import java.util.List;

public class GetConsumerResponse {
    private boolean error;
    private List<String> consumers;

    public boolean isError() {
        return error;
    }

    public void setError(boolean error) {
        this.error = error;
    }

    public List<String> getConsumers() {
        return consumers;
    }

    public void setConsumers(List<String> consumers) {
        this.consumers = consumers;
    }
}
