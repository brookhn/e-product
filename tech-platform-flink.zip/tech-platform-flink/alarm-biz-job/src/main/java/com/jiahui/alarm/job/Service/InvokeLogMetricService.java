package com.jiahui.alarm.job.Service;

import com.google.common.collect.Lists;
import com.jiahui.alarm.job.ESClientProxy;
import com.jiahui.alarm.job.domain.model.ApiTPStatEntity;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.RangeQueryBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.TermsAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.Percentile;
import org.elasticsearch.search.aggregations.metrics.Percentiles;
import org.elasticsearch.search.aggregations.metrics.PercentilesAggregationBuilder;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.text.MessageFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class InvokeLogMetricService {
    private static Logger logger = LoggerFactory.getLogger(ApiTPStatJob.class);

    @Autowired
    private ESClientProxy clientProxy;
    @Value("${spring.profiles.active}")
    private String onProfile;

    public List<ApiTPStatEntity> apiTPStatCore(String groupName) {
        String index = MessageFormat.format("invoking-log-{0}-*", groupName);
        SearchRequest searchRequest = new SearchRequest(index);
        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        searchSourceBuilder.size(0);
        PercentilesAggregationBuilder percentilesAgg = AggregationBuilders.percentiles("spend_time")
                .field("spend_time").percentiles(90, 95);
        TermsAggregationBuilder agg
                = AggregationBuilders.terms("app_name").field("appname").minDocCount(1).size(100)
                .subAggregation(AggregationBuilders.terms("uri").field("uri").minDocCount(1).size(100).subAggregation(percentilesAgg));
        searchSourceBuilder.aggregation(agg);
        LocalDateTime today = LocalDate.now().atTime(0, 0, 0);
        LocalDateTime startDate = today.plusDays(-7);
        BoolQueryBuilder queryBuilder = QueryBuilders.boolQuery();
        RangeQueryBuilder rangequerybuilder = QueryBuilders
                .rangeQuery("current_time")
                .from(ZonedDateTime.of(startDate, ZoneId.of("UTC+8"))).to(ZonedDateTime.of(today, ZoneId.of("UTC+8")));
        queryBuilder.must(rangequerybuilder);
        queryBuilder.must(QueryBuilders.termQuery("appenv", onProfile));
        searchRequest.source(searchSourceBuilder);
        searchSourceBuilder.size(0);
        searchSourceBuilder.query(queryBuilder);
        SearchResponse response;
        List<ApiTPStatEntity> list = Lists.newArrayList();
        boolean isAliyun = "frontend-server".equals(groupName) ? true : false;
        try {
            response = clientProxy.search(searchRequest, isAliyun);
            //获取聚合的结果
            Terms termsAgg = response.getAggregations().get("app_name");
            for (Terms.Bucket bucket : termsAgg.getBuckets()) {
                Terms urlTerms = bucket.getAggregations().get("uri");
                for (Terms.Bucket uriBucket : urlTerms.getBuckets()) {
                    Percentiles aggregations = uriBucket.getAggregations().get("spend_time");
                    ApiTPStatEntity entity = new ApiTPStatEntity();
                    entity.setAppName(bucket.getKey().toString());
                    entity.setUri(uriBucket.getKey().toString());
                    entity.setCount(uriBucket.getDocCount());
                    Map<Integer, Double> map = new LinkedHashMap<>();
                    for (Percentile entry : aggregations) {
                        map.put((int) entry.getPercent(), entry.getValue());
                    }
                    Double tp90 = map.get(90);
                    Double tp95 = map.get(95);
                    if (tp90 != null && tp95 != null && (tp90.doubleValue() >= 500 || tp95.doubleValue() >= 500)) {
                        entity.setTp90(tp90);
                        entity.setTp95(tp95);
                        list.add(entity);
                    }
                }
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return list.stream().sorted(Comparator.comparing(ApiTPStatEntity::getTp95).reversed()).collect(Collectors.toList());
    }

}
