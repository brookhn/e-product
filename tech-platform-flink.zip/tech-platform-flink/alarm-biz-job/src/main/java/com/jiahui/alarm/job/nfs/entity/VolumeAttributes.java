package com.jiahui.alarm.job.nfs.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class VolumeAttributes {

    @JacksonXmlProperty(localName = "volume-id-attributes")
    private VolumeIdAttributes volumeIdAttributes;
    @JacksonXmlProperty(localName = "volume-space-attributes")
    private VolumeSpaceAttributes volumeSpaceAttributes;

    public VolumeIdAttributes getVolumeIdAttributes() {
        return volumeIdAttributes;
    }

    public void setVolumeIdAttributes(VolumeIdAttributes volumeIdAttributes) {
        this.volumeIdAttributes = volumeIdAttributes;
    }

    public VolumeSpaceAttributes getVolumeSpaceAttributes() {
        return volumeSpaceAttributes;
    }

    public void setVolumeSpaceAttributes(VolumeSpaceAttributes volumeSpaceAttributes) {
        this.volumeSpaceAttributes = volumeSpaceAttributes;
    }
}