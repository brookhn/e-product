package com.jiahui.alarm.job.nfs;

import cn.hutool.core.util.NumberUtil;
import com.alibaba.fastjson.JSON;
import com.fasterxml.jackson.dataformat.xml.JacksonXmlModule;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.jiahui.alarm.job.client.proxy.AlarmClient;
import com.jiahui.alarm.job.dto.AlarmRequest;
import com.jiahui.alarm.job.dto.AlarmResponse;
import com.jiahui.alarm.job.dto.NfsWarningDTO;
import com.jiahui.alarm.job.nfs.entity.NFSEntity;
import com.xxl.job.core.handler.annotation.XxlJob;
import okhttp3.*;
import org.apache.commons.lang3.StringUtils;
import org.redisson.api.RBucket;
import org.redisson.api.RedissonClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

@RefreshScope
@Service
public class NFSAlarmService {

    private static final Logger logger = LoggerFactory.getLogger(NFSAlarmService.class);

    @Autowired
    private OkHttpClient okHttpClient;
    @Autowired
    private AlarmClient alarmClient;
    @Autowired
    private RedissonClient redissonClient;

    @Value("${volume.space.percentage.size.used:85}")
    private int percentageSizeUsed;
    @Value("#{'${volume.blacklist}'.split(',')}")
    private Set<String> volumeBlacklist;

    @XxlJob("nfsAlert")
    public void nfsAlert() {
        logger.info("nfs monitor start");
        RBucket<Object> bucket = redissonClient.getBucket("V1:NFS:Warning");
        if (!bucket.trySet(1, 30, TimeUnit.MINUTES)) {
            logger.info("repeat scheduling");
            return;
        }

        NFSEntity data = getNfsData();
        if (data == null || data.getResults() == null || CollectionUtils.isEmpty(data.getResults().getAttributesList())) {
            return;
        }

        List<NfsWarningDTO> list = data.getResults().getAttributesList().stream()
                .filter(p -> p.getVolumeSpaceAttributes() != null
                        && p.getVolumeSpaceAttributes().getPercentageSizeUsed() > percentageSizeUsed
                        && !volumeBlacklist.contains(p.getVolumeIdAttributes().getName()))
                .map(p -> NfsWarningDTO.builder().name(p.getVolumeIdAttributes().getName())
                        .svm(p.getVolumeIdAttributes().getSvm())
                        .sizeAvailable((double) p.getVolumeSpaceAttributes().getSizeAvailable() / 1024 / 1024 / 1024)
                        .sizeTotal((double) p.getVolumeSpaceAttributes().getSizeTotal() / 1024 / 1024 / 1024)
                        .percentageSizeUsed(p.getVolumeSpaceAttributes().getPercentageSizeUsed()).build())
                .collect(Collectors.toList());
        List<NfsWarningDTO> results = new ArrayList<>();
        for (NfsWarningDTO dto : list) {
            //大于等于5T
            if (dto.getSizeTotal() >= 5 * 1024) {
                if (dto.getPercentageSizeUsed() >= 95) {
                    results.add(dto);
                }
            } else {
                results.add(dto);
            }
        }
        if (CollectionUtils.isEmpty(results)) {
            return;
        }
        logger.info("NFSWarningResult:{}", JSON.toJSONString(results));
        StringBuilder sb = new StringBuilder();
        sb.append("  \n  ");
        for (NfsWarningDTO dto : results) {
            sb.append("- **卷名**：").append(dto.getName()).append("  \n  ")
                    .append(" - SVM：").append(dto.getSvm()).append("  \n  ")
                    .append(" - 可用空间：").append(NumberUtil.round(dto.getSizeAvailable(), 2)).append("GB").append("  \n  ")
                    .append(" - 总空间：").append(NumberUtil.round(dto.getSizeTotal(), 2)).append("GB").append("  \n  ")
                    .append(" - 已用：").append(dto.getPercentageSizeUsed()).append("%").append("  \n  ");
        }
        AlarmRequest alarmRequest = new AlarmRequest();
        alarmRequest.setCode("2021123101");
        alarmRequest.setContent(sb.toString());
        alarmRequest.setLevel("WARNING");
        try {
            AlarmResponse response = alarmClient.alarm(alarmRequest);
            logger.info(JSON.toJSONString(response));
        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
        }
    }

    private NFSEntity getNfsData() {
        String xmlStr = "<netapp version=\"1.7\" xmlns=\"http://www.netapp.com/filer/admin\"><volume-get-iter><query><volume-attributes><volume-state-attributes><is-constituent>false</is-constituent></volume-state-attributes></volume-attributes></query><desired-attributes><volume-attributes><encrypt/><volume-id-attributes><name/><instance-uuid/><containing-aggregate-name/><junction-path/><owning-vserver-name/><type/><style/><style-extended/><flexcache-endpoint-type/><owning-vserver-uuid/><application/><application-uuid/><aggr-list><aggr-name/></aggr-list></volume-id-attributes><volume-inode-attributes><files-total/><files-used/><block-type/></volume-inode-attributes><volume-language-attributes><is-convert-ucode-enabled/><is-create-ucode-enabled/><language/><language-code/></volume-language-attributes><volume-state-attributes><is-node-root/><is-vserver-root/><is-moving/><state/><is-protocol-access-fenced/><protocol-access-fenced-by/></volume-state-attributes><volume-space-attributes><size-available/><size-used/><size-total/><percentage-size-used/><percentage-snapshot-reserve/><snapshot-reserve-size/><percentage-snapshot-reserve-used/><size-used-by-snapshots/><physical-used/><space-guarantee/><size/><percentage-fractional-reserve/><over-provisioned/><snapshot-reserve-available/><performance-tier-inactive-user-data/><physical-used-percent/><logical-available/><logical-used/><logical-used-percent/><is-space-reporting-logical/><expected-available/><is-space-enforcement-logical/></volume-space-attributes><volume-mirror-attributes><is-replica-volume/><is-data-protection-mirror/><is-snapmirror-source/></volume-mirror-attributes><volume-export-attributes/><volume-clone-attributes/><volume-security-attributes/><volume-autosize-attributes/><volume-snapshot-attributes/><volume-sis-attributes/><volume-snapshot-autodelete-attributes/><volume-infinitevol-attributes/><volume-performance-attributes><is-atime-update-enabled/></volume-performance-attributes><volume-qos-attributes><policy-group-name/></volume-qos-attributes><volume-hybrid-cache-attributes><caching-policy/><eligibility/><cache-retention-priority/></volume-hybrid-cache-attributes><volume-snaplock-attributes/><volume-comp-aggr-attributes/></volume-attributes></desired-attributes><max-records>1000</max-records></volume-get-iter></netapp>";
        RequestBody body = RequestBody.create(MediaType.parse("text/plain;charset=UTF-8"), xmlStr);
        String url = "https://10.2.5.201/servlets/netapp.servlets.admin.XMLrequest_filer";
        Request requestOk = new Request.Builder()
                .addHeader("Authorization", "Basic amloLW1vbml0b3I6WHVVRjNSdGVpRlBmYnhp")
                .url(url)
                .post(body)
                .build();
        Response response;
        try {
            response = okHttpClient.newCall(requestOk).execute();
            String str = response.body().string();
            if (StringUtils.isBlank(str)) {
                return null;
            }
            JacksonXmlModule module = new JacksonXmlModule();
            XmlMapper mapper = new XmlMapper(module);
            NFSEntity entity = mapper.readValue(str, NFSEntity.class);
            return entity;
        } catch (Exception e) {
            logger.error("getNfsDataErr", e);
            return null;
        }
    }

}
