package com.jiahui.alarm.job.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

@NoArgsConstructor
@Data
public class ProgramLogDTO implements Serializable {

    @JsonProperty("appname")
    private String appName;

    @JsonAlias("@timestamp")    //兼容Logback
    @JsonProperty("current_time")
    private Date currentTime;

    private String level;
}
