package com.jiahui.alarm.job.domain.model;

import com.alibaba.excel.annotation.ExcelProperty;

public class ApiTPStatEntity {
    @ExcelProperty("应用名")
    private String appName;
    @ExcelProperty("Uri")
    private String uri;
    @ExcelProperty("TP90")
    private double tp90;
    @ExcelProperty("TP95")
    private double tp95;

    @ExcelProperty("访问次数")
    private long count;

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    public double getTp90() {
        return tp90;
    }

    public void setTp90(double tp90) {
        this.tp90 = tp90;
    }

    public double getTp95() {
        return tp95;
    }

    public void setTp95(double tp95) {
        this.tp95 = tp95;
    }

    public long getCount() {
        return count;
    }

    public void setCount(long count) {
        this.count = count;
    }
}
