package com.jiahui.alarm.job.dao.influxdb;

import com.influxdb.client.WriteApi;
import com.influxdb.client.domain.WritePrecision;
import com.jiahui.alarm.job.domain.influxdb.InvokeLogMetric;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import java.util.List;

@Slf4j
@Repository
public class InvokeLogMetricRepository {

    @Autowired
    private WriteApi writeApi;

    public void batchInsert(List<InvokeLogMetric> logMetrics) {
        if (CollectionUtils.isEmpty(logMetrics)) {
            return;
        }
        try {
            writeApi.writeMeasurements(WritePrecision.NS, logMetrics);
        } catch (Exception e) {
            log.error("invokeLogMetric batchInsert error", e);
        }
    }


}
