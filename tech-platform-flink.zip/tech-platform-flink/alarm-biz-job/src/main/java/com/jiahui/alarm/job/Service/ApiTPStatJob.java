package com.jiahui.alarm.job.Service;

import com.google.common.collect.Lists;
import com.jiahui.alarm.job.ESClientProxy;
import com.jiahui.alarm.job.dao.influxdb.InvokeLogMetricRepository;
import com.jiahui.alarm.job.domain.influxdb.InvokeLogMetric;
import com.xxl.job.core.handler.annotation.XxlJob;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.RangeQueryBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.TermsAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.Percentile;
import org.elasticsearch.search.aggregations.metrics.Percentiles;
import org.elasticsearch.search.aggregations.metrics.PercentilesAggregationBuilder;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;

@RefreshScope
@Service
public class ApiTPStatJob {
    private static Logger logger = LoggerFactory.getLogger(ApiTPStatJob.class);

    @Autowired
    private ESClientProxy clientProxy;

    @Autowired
    private InvokeLogMetricRepository invokeLogMetricRepository;

    @Value("#{'${index.groups}'.split(',')}")
    private Set<String> indexGroups;

    @Resource(name = "coreThreadPool")
    private ExecutorService threadPool;

    @Value("${spring.profiles.active}")
    private String onProfile;

    @Autowired
    private LogCore invokeLogCore;

    @XxlJob("apiTPStat")
    public void apiTPStat() {
        List<CompletableFuture<Boolean>> futures = new ArrayList<>();
        for (String group : indexGroups) {
            CompletableFuture<Boolean> f = CompletableFuture.supplyAsync(() -> apiTPStatCore(group), threadPool);
            futures.add(f);
        }
        CompletableFuture.allOf(futures.toArray(new CompletableFuture[futures.size()])).join();
    }

    //50,95,99线
    public boolean apiTPStatCore(String groupName) {
        boolean isAliyun = "frontend-server".equals(groupName) ? true : false;
        String index = invokeLogCore.getInvokeLogIndex(groupName);
        boolean exists = clientProxy.exists(index, isAliyun);
        if (!exists) {
            return false;
        }
        SearchRequest searchRequest = new SearchRequest(index);
        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        searchSourceBuilder.size(0);
        PercentilesAggregationBuilder percentilesAgg = AggregationBuilders.percentiles("spend_time")
                .field("spend_time").percentiles(50, 90, 95);
        TermsAggregationBuilder agg
                = AggregationBuilders.terms("app_name").field("appname").minDocCount(1).size(100)
                .subAggregation(AggregationBuilders.terms("uri").field("uri").minDocCount(1).size(100).subAggregation(percentilesAgg));
        searchSourceBuilder.aggregation(agg);
        LocalDateTime today = LocalDate.now().atTime(0, 0, 0);
        LocalDateTime yesterday = today.plusDays(-1);
        BoolQueryBuilder queryBuilder = QueryBuilders.boolQuery();
        RangeQueryBuilder rangequerybuilder = QueryBuilders
                .rangeQuery("current_time")
                .from(ZonedDateTime.of(yesterday, ZoneId.of("UTC+8"))).to(ZonedDateTime.of(today, ZoneId.of("UTC+8")));
        queryBuilder.must(rangequerybuilder);
        searchRequest.source(searchSourceBuilder);
        searchSourceBuilder.size(0);
        searchSourceBuilder.query(queryBuilder);
        logger.info("index:{},{}", index, searchSourceBuilder);
        SearchResponse response;
        List<InvokeLogMetric> logMetrics = Lists.newArrayList();
        try {
            response = clientProxy.search(searchRequest, isAliyun);
            //获取聚合的结果
            Terms termsAgg = response.getAggregations().get("app_name");
            for (Terms.Bucket bucket : termsAgg.getBuckets()) {
                Terms urlTerms = bucket.getAggregations().get("uri");
                for (Terms.Bucket uriBucket : urlTerms.getBuckets()) {
                    if (uriBucket.getKey().toString().indexOf("/actuator/") > -1) {
                        continue;
                    }
                    Percentiles aggregations = uriBucket.getAggregations().get("spend_time");
                    for (Percentile entry : aggregations) {
                        int requestCount = (int) (uriBucket.getDocCount() * entry.getPercent() / 100);
                        InvokeLogMetric logMetric = InvokeLogMetric.builder().date(yesterday.toInstant(ZoneOffset.of("+8")))
                                .appName(bucket.getKey().toString()).percent(entry.getPercent())
                                .uri(uriBucket.getKey().toString())
                                .elapsed_time(entry.getValue()).request_count((long) requestCount).build();
                        logMetrics.add(logMetric);
                    }
                }
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        invokeLogMetricRepository.batchInsert(logMetrics);
        return true;
    }


}
