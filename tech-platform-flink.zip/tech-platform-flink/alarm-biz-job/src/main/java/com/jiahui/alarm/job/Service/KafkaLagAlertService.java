package com.jiahui.alarm.job.Service;

import com.alibaba.fastjson.JSON;
import com.jiahui.alarm.job.client.proxy.AlarmClient;
import com.jiahui.alarm.job.client.proxy.BurrowClientProxy;
import com.jiahui.alarm.job.dto.AlarmRequest;
import com.jiahui.alarm.job.dto.kafka.GetConsumerResponse;
import com.jiahui.alarm.job.dto.kafka.GetLagResponse;
import com.jiahui.alarm.job.dto.kafka.PartitionDTO;
import com.xxl.job.core.context.XxlJobHelper;
import com.xxl.job.core.handler.annotation.XxlJob;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class KafkaLagAlertService {

    private static Logger logger = LoggerFactory.getLogger(KafkaLagAlertService.class);

    @Autowired
    private BurrowClientProxy burrowClientProxy;

    @Autowired
    private AlarmClient alarmClient;

    @XxlJob("kafkaLagAlert")
    public void KafkaLagAlert() {
        String cluster = XxlJobHelper.getJobParam();
        logger.info("接收調度中心参数...[{}]",cluster);
        GetConsumerResponse consumerResponse = burrowClientProxy.getLogClusterConsumers(cluster);
        logger.info(JSON.toJSONString(consumerResponse));
        if (consumerResponse.isError() && CollectionUtils.isEmpty(consumerResponse.getConsumers())) {
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("  \n  ");
        boolean warn = false;
        List<String> consumers = consumerResponse.getConsumers();
        try {
            for (String consumer : consumers) {
                if (consumer.indexOf("burrow") > -1 || consumer.indexOf("efak.system.group") > -1) {
                    continue;
                }
                GetLagResponse getLagResponse = burrowClientProxy.getConsumerLag(consumer,cluster);
                if (!getLagResponse.isError() && getLagResponse.getStatus() != null
                        && !CollectionUtils.isEmpty(getLagResponse.getStatus().getPartitions())) {
                    Map<String, List<PartitionDTO>> map = getLagResponse.getStatus().getPartitions().stream().collect(Collectors.groupingBy(PartitionDTO::getTopic));
                    if (map.size() == 1 && getLagResponse.getStatus().getTotallag() > 5000) {
                        warn = true;
                        sb.append("- ").append("**消费组**：").append(getLagResponse.getStatus().getGroup()).append("  \n  ")
                                .append(" - 状态：").append(getLagResponse.getStatus().getPartitions().get(0).getStatus())
                                .append("  Topic：").append(getLagResponse.getStatus().getPartitions().get(0).getTopic())
                                .append("  Lag：").append(getLagResponse.getStatus().getTotallag()).append("  \n  ");
                    } else {
                        for (Map.Entry<String, List<PartitionDTO>> entry : map.entrySet()) {
                            long totalLag = entry.getValue().stream().mapToLong(p -> p.getCurrent_lag()).sum();
                            if (totalLag > 5000) {
                                warn = true;
                                sb.append("- ").append("**消费组**：").append(getLagResponse.getStatus().getGroup()).append("  \n  ")
                                        .append(" - 状态：").append(entry.getValue().get(0).getStatus())
                                        .append("  Topic：").append(entry.getValue().get(0).getTopic())
                                        .append("  Lag：").append(totalLag).append("  \n  ");
                            }
                        }
                    }
                }
            }
        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
        }
        if (!warn) {
            return;
        }
        String alarmContent = sb.toString();
        AlarmRequest alarmRequest = new AlarmRequest();
        alarmRequest.setCode("2022011301");
        alarmRequest.setContent(alarmContent);
        alarmRequest.setLevel("ERROR");
        try {
            alarmClient.alarm(alarmRequest);
        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
        }
    }
}
