package com.jiahui.alarm.job;

import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.client.indices.GetIndexRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.io.IOException;

@Component
public class ESClientProxy {

    private static final Logger logger = LoggerFactory.getLogger(ESClientProxy.class);

    @Resource(name = "localClient")
    public RestHighLevelClient localClient;

    @Resource(name = "aliyunClient")
    public RestHighLevelClient aliyunClient;

//    protected static final RequestOptions COMMON_OPTIONS;
//
//    static {
//        RequestOptions.Builder builder = RequestOptions.DEFAULT.toBuilder();
//        // 默认缓冲限制为100MB，此处修改为30MB。
//        builder.setHttpAsyncResponseConsumerFactory(new HttpAsyncResponseConsumerFactory.HeapBufferedResponseConsumerFactory(30 * 1024 * 1024));
//        COMMON_OPTIONS = builder.build();
//    }

    private RestHighLevelClient getClient(boolean aliyun) {
        return aliyun ? aliyunClient : localClient;
    }

    public boolean exists(String index, boolean aliyun) {
        GetIndexRequest request = new GetIndexRequest(index);
        RestHighLevelClient client = getClient(aliyun);
        try {
            return client.indices().exists(request, RequestOptions.DEFAULT);
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
            return false;
        }
    }

    public SearchResponse search(SearchRequest searchRequest, boolean aliyun) throws IOException {
        RestHighLevelClient client = getClient(aliyun);
        SearchResponse response = client.search(searchRequest, RequestOptions.DEFAULT);
        return response;
    }
}
