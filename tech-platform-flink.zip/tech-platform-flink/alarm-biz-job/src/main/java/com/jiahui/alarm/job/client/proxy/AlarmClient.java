package com.jiahui.alarm.job.client.proxy;

import com.jiahui.alarm.job.dto.AlarmRequest;
import com.jiahui.alarm.job.dto.AlarmResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@Component
@FeignClient(name = "alarm-server", configuration = AlarmClientConfig.class)
public interface AlarmClient {

    @PostMapping(path = "/v1/alarm", headers = {"Content-Type=application/json;charset=UTF-8"})
    AlarmResponse alarm(@RequestBody AlarmRequest request);

}
