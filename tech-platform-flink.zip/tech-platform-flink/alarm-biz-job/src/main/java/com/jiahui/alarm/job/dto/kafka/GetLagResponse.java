package com.jiahui.alarm.job.dto.kafka;

public class GetLagResponse {
    private boolean error;
    private LagStatusDTO status;

    public boolean isError() {
        return error;
    }

    public void setError(boolean error) {
        this.error = error;
    }

    public LagStatusDTO getStatus() {
        return status;
    }

    public void setStatus(LagStatusDTO status) {
        this.status = status;
    }
}
