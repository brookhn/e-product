package com.jiahui.alarm.job.nfs.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Results {

    @JacksonXmlProperty(localName = "attributes-list")
    private List<VolumeAttributes> attributesList;

    public List<VolumeAttributes> getAttributesList() {
        return attributesList;
    }

    public void setAttributesList(List<VolumeAttributes> attributesList) {
        this.attributesList = attributesList;
    }
}
