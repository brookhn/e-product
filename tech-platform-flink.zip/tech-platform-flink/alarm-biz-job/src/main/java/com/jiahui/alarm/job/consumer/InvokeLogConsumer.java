//package com.jiahui.alarm.job.consumer;
//
//import com.jiahui.alarm.job.constants.TopicConstant;
//import com.jiahui.alarm.job.dao.influxdb.InvokeLogRepository;
//import com.jiahui.alarm.job.domain.influxdb.InvokeLog;
//import com.jiahui.alarm.job.dto.InvokeLogDTO;
//import com.jiahui.alarm.job.util.JacksonUtils;
//import lombok.extern.slf4j.Slf4j;
//import org.apache.commons.compress.utils.Lists;
//import org.apache.kafka.clients.consumer.ConsumerRecord;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.kafka.annotation.KafkaListener;
//import org.springframework.kafka.support.Acknowledgment;
//import org.springframework.stereotype.Component;
//import org.springframework.util.CollectionUtils;
//
//import java.time.Instant;
//import java.util.List;
//import java.util.Objects;
//
///**
// * 消费kafka invoke log写入influxdb（grafana Http看板信息）
// */
//@Slf4j
//@Component
//public class InvokeLogConsumer {
//
//    @Autowired
//    private InvokeLogRepository invokeLogRepository;
//
//    @KafkaListener(topics = TopicConstant.INVOKE_LOG_TOPIC, groupId = "influxdbConsumer", containerFactory = "batchFactory")
//    public void listenProgramLog(List<ConsumerRecord<String, String>> list, Acknowledgment ack) {
//        if (CollectionUtils.isEmpty(list)) {
//            return;
//        }
//        List<InvokeLog> invokeLogs = Lists.newArrayList();
//        for (ConsumerRecord<String, String> record : list) {
//            try {
//                String value = record.value();
//                InvokeLogDTO dto = JacksonUtils.json2pojo(value, InvokeLogDTO.class);
//                if (Objects.nonNull(dto)) {
//                    InvokeLog invokeLog = InvokeLog.builder().appName(dto.getAppName())
//                            .currentTime(Instant.ofEpochMilli(dto.getCurrentTime().getTime()))
//                            .spendTime(dto.getSpendTime())
//                            .httpMethod(dto.getHttpMethod())
//                            .httpStatus(dto.getHttpStatus()).build();
//                    invokeLogs.add(invokeLog);
//                }
//            } catch (Exception e) {
//                log.error("write to influxdb error", e.getMessage());
//            }
//        }
//        if (!CollectionUtils.isEmpty(invokeLogs)) {
//            invokeLogRepository.batchInsert(invokeLogs);
//        }
//        ack.acknowledge();
//    }
//}
