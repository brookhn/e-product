package com.jiahui.alarm.job.nfs.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class VolumeSpaceAttributes {
    @JacksonXmlProperty(localName = "percentage-size-used")
    private int percentageSizeUsed;
    @JacksonXmlProperty(localName = "size-available")
    private long sizeAvailable;
    @JacksonXmlProperty(localName = "size-total")
    private long sizeTotal;

    public int getPercentageSizeUsed() {
        return percentageSizeUsed;
    }

    public void setPercentageSizeUsed(int percentageSizeUsed) {
        this.percentageSizeUsed = percentageSizeUsed;
    }

    public long getSizeAvailable() {
        return sizeAvailable;
    }

    public void setSizeAvailable(long sizeAvailable) {
        this.sizeAvailable = sizeAvailable;
    }

    public long getSizeTotal() {
        return sizeTotal;
    }

    public void setSizeTotal(long sizeTotal) {
        this.sizeTotal = sizeTotal;
    }
}
