//package com.jiahui.alarm.job.consumer;
//
//import com.fasterxml.jackson.core.JsonProcessingException;
//import com.jiahui.alarm.job.constants.TopicConstant;
//import com.jiahui.alarm.job.dao.influxdb.ProgramLogRepository;
//import com.jiahui.alarm.job.domain.influxdb.ProgramLogErrors;
//import com.jiahui.alarm.job.dto.ProgramLogDTO;
//import com.jiahui.alarm.job.util.JacksonUtils;
//import lombok.extern.slf4j.Slf4j;
//import org.apache.commons.compress.utils.Lists;
//import org.apache.commons.lang3.StringUtils;
//import org.apache.kafka.clients.consumer.ConsumerRecord;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.kafka.annotation.KafkaListener;
//import org.springframework.kafka.support.Acknowledgment;
//import org.springframework.stereotype.Component;
//import org.springframework.util.CollectionUtils;
//
//import java.time.Instant;
//import java.util.List;
//import java.util.Map;
//import java.util.Objects;
//
//@Slf4j
//@Component
//public class ProgramLogConsumer {
//
//    @Autowired
//    private ProgramLogRepository programLogRepository;
//
//    @KafkaListener(topics = TopicConstant.PROGRAM_LOG_TOPIC, groupId = "influxdbConsumer", containerFactory = "batchFactory")
//    public void listenProgramLog(List<ConsumerRecord<String, String>> list, Acknowledgment ack) {
//        if (CollectionUtils.isEmpty(list)) {
//            return;
//        }
//        List<ProgramLogErrors> programLogErrors = Lists.newArrayList();
//        for (ConsumerRecord<String, String> record : list) {
//            try {
//                Map<String, Object> jsonMap = JacksonUtils.json2map(record.value());
//                Object message = jsonMap.get("message");
//                if (Objects.isNull(message)) {
//                    continue;
//                }
//                ProgramLogDTO dto = JacksonUtils.json2pojo(message.toString(), ProgramLogDTO.class);
//                if (Objects.nonNull(dto) && StringUtils.isNotBlank(dto.getLevel()) && "error".equalsIgnoreCase(dto.getLevel())) {
//
//                    ProgramLogErrors programLog = new ProgramLogErrors();
//                    programLog.setApplication(dto.getAppName());
//                    programLog.setErrors(1L);
//                    programLog.setTime(Instant.ofEpochMilli(dto.getCurrentTime().getTime()));
//                    programLogErrors.add(programLog);
//                }
//            } catch (JsonProcessingException e) {
//                //log.warn("parseJsonError:{}", e.getMessage());
//                continue;
//            } catch (Exception e) {
//                log.error("write to influxdb error", e);
//                continue;
//            }
//        }
//        if (!CollectionUtils.isEmpty(programLogErrors)) {
//            programLogRepository.batchInsert(programLogErrors);
//        }
//        ack.acknowledge();
//    }
//}
