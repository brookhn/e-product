package com.jiahui.alarm.job.dto;

import lombok.*;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode(callSuper = false)
public class NfsWarningDTO {
    private String name;
    private String svm;
    private int percentageSizeUsed;
    private double sizeAvailable;
    private double sizeTotal;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSvm() {
        return svm;
    }

    public void setSvm(String svm) {
        this.svm = svm;
    }

    public int getPercentageSizeUsed() {
        return percentageSizeUsed;
    }

    public void setPercentageSizeUsed(int percentageSizeUsed) {
        this.percentageSizeUsed = percentageSizeUsed;
    }

    public double getSizeAvailable() {
        return sizeAvailable;
    }

    public void setSizeAvailable(double sizeAvailable) {
        this.sizeAvailable = sizeAvailable;
    }

    public double getSizeTotal() {
        return sizeTotal;
    }

    public void setSizeTotal(double sizeTotal) {
        this.sizeTotal = sizeTotal;
    }
}
