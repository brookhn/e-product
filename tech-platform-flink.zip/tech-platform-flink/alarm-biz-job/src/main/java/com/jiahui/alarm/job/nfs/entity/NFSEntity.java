package com.jiahui.alarm.job.nfs.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

@JacksonXmlRootElement(localName = "netapp")  //root根是book
@JsonIgnoreProperties(ignoreUnknown = true)
public class NFSEntity {
    @JacksonXmlProperty(localName = "results")
    private Results results;

    public Results getResults() {
        return results;
    }

    public void setResults(Results results) {
        this.results = results;
    }
}
