package com.jiahui.alarm.job.dto.kafka;

import java.util.List;

public class LagStatusDTO {
    private String cluster;
    private String group;
    private String status;
    private int complete;
    private List<PartitionDTO> partitions;
    private long totallag;

    public String getCluster() {
        return cluster;
    }

    public void setCluster(String cluster) {
        this.cluster = cluster;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getComplete() {
        return complete;
    }

    public void setComplete(int complete) {
        this.complete = complete;
    }

    public List<PartitionDTO> getPartitions() {
        return partitions;
    }

    public void setPartitions(List<PartitionDTO> partitions) {
        this.partitions = partitions;
    }

    public long getTotallag() {
        return totallag;
    }

    public void setTotallag(long totallag) {
        this.totallag = totallag;
    }
}
