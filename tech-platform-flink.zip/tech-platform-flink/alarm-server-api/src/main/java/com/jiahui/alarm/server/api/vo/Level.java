package com.jiahui.alarm.server.api.vo;

public enum Level {
    DEBUG("debug"), INFO("info"), ERROR("error");

    private String value;

    Level(String value) {
        this.value = value;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return "{" +
                "value='" + value + '\'' +
                '}';
    }
}
