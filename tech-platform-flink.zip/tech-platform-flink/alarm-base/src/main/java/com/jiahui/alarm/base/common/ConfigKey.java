package com.jiahui.alarm.base.common;

/**
 * Created by caijt on 2017/4/6.
 */
public enum ConfigKey {

    MAIL_QUEUE("mail.queue"),
    SMS_QUEUE("sms.queue"),
    DING_TALK_QUEUE("dingTalk.queue"),
    DELIVERY_QUEUE("delivery.queue"),
    ALARM_REPORT_ID_POOL("alarm.report.id.pool"),

    TOTAL_REQUEST_QUANTITY("monitor.request.quantity"),
    MAIL_PUSH_QUANTITY("monitor.mail.push.quantity"),
    SMS_PUSH_QUANTITY("monitor.sms.push.quantity"),
    DING_TALK_PUSH_QUANTITY("monitor.dingTalk.push.quantity"),
    MAIL_PUSH_DAILY("monitor.mail.push.{date}"),
    SMS_PUSH_DAILY("monitor.sms.push.{date}"),
    DING_TALK_PUSH_DAILY("monitor.dingTalk.push.{date}");

    private String value;

    ConfigKey(String value) {
        this.value = value;
    }

    public String value() {
        return value;
    }
}
