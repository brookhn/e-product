package com.jiahui.alarm.base.entity;

public enum Level {
    DEBUG("debug"), INFO("info"), ERROR("error"), WARNING("warning");

    private String value;

    Level(String value) {
        this.value = value;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return "{" +
                "value='" + value + '\'' +
                '}';
    }
}
