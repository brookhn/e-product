package com.jiahui.alarm.base.entity;

/**
 */
public class User {
    private Integer id;
    private String account;
    private String name;
    private String identification;
    private Integer type;
    private String mail;
    private String phone;
    private String dingTalk;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIdentification() {
        return identification;
    }

    public void setIdentification(String identification) {
        this.identification = identification;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getDingTalk() {
        return dingTalk;
    }

    public void setDingTalk(String dingTalk) {
        this.dingTalk = dingTalk;
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", account='" + account + '\'' +
                ", name='" + name + '\'' +
                ", identification='" + identification + '\'' +
                ", type=" + type +
                ", mail='" + mail + '\'' +
                ", phone='" + phone + '\'' +
                ", dingTalk='" + dingTalk + '\'' +
                '}';
    }
}
