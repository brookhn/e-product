package com.jiahui.alarm.base.entity;


import java.util.List;


public class QueueMessage {
    private long logId;
    private String title;
    private String content;
    private Level level;
    /**
     * 接收人
     */
    private List<String> receivers;
    /**
     * 被@用户 --dingTalk
     */
    private List<String> atReceivers;


    public QueueMessage() {
    }

    public QueueMessage(String title, String content, List<String> receivers, long logId, Level level) {
        this.logId = logId;
        this.title = title;
        this.content = content;
        this.level = level;
        this.receivers = receivers;
    }

    public List<String> getAtReceivers() {
        return atReceivers;
    }

    public void setAtReceivers(List<String> atReceivers) {
        this.atReceivers = atReceivers;
    }

    public long getLogId() {
        return logId;
    }

    public void setLogId(long logId) {
        this.logId = logId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Level getLevel() {
        return level;
    }

    public void setLevel(Level level) {
        this.level = level;
    }

    public List<String> getReceivers() {
        return receivers;
    }

    public void setReceivers(List<String> receivers) {
        this.receivers = receivers;
    }

    @Override
    public String toString() {
        return "{" +
                "logId=" + logId +
                ", title='" + title + '\'' +
                ", content='" + content + '\'' +
                ", level=" + level +
                ", receivers=" + receivers +
                '}';
    }
}
