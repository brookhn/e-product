package com.jiahui.flink.job.program.log.schema;

import com.jiahui.flink.job.program.log.model.ProgramLog;
import com.jiahui.alarm.job.util.JacksonUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.serialization.DeserializationSchema;
import org.apache.flink.api.common.serialization.SerializationSchema;
import org.apache.flink.api.common.typeinfo.TypeInformation;

import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.Objects;

@Slf4j
public class ProgramLogSchema implements DeserializationSchema<ProgramLog>, SerializationSchema<ProgramLog> {

    @Override
    public ProgramLog deserialize(byte[] bytes) {
        try {
            Map<String, Object> jsonMap = JacksonUtils.json2map(new String(bytes));
            Object message = jsonMap.get("message");
            if (Objects.nonNull(message)) {
                log.info(message.toString());
                return JacksonUtils.json2pojo(message.toString(), ProgramLog.class);
            }
        } catch (Exception e) {
            log.error("ProgramLogSchema deserialize error", e);
        }

        return null;
    }

    @Override
    public boolean isEndOfStream(ProgramLog programLog) {
        return false;
    }

    @Override
    public byte[] serialize(ProgramLog programLog) {
        try {
            return JacksonUtils.obj2json(programLog).getBytes(StandardCharsets.UTF_8);
        } catch (Exception e) {
            log.error("ProgramLogSchema serialize error", e);
        }
        return null;
    }

    @Override
    public TypeInformation<ProgramLog> getProducedType() {
        return TypeInformation.of(ProgramLog.class);
    }
}
