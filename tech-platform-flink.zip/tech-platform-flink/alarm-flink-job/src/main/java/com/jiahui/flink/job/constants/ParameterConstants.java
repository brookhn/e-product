package com.jiahui.flink.job.constants;


public class ParameterConstants {

    /**
     * program log topic
     */
    public static final String PROGRAM_LOG_TOPIC = "JH-PROGRAM-LOG";

    /**
     * invoke log topic
     */
    public static final String INVOKE_LOG_TOPIC = "JH-INVOKE-LOG";

    /**
     * kafka地址
     */
    public static final String KAFKA_BROKERS = "kafka.brokers";

    /**
     * window 开窗时间
     */
    public static final String LOGGING_WINDOW_TIME = "program.log.window.time";

    /**
     * watermark 允许延迟
     */
    public static final String LOGGING_MAX_OUTOF_ORDERNESS = "program.log.watermark.maxOutOfOrderness";

    /**
     * window 开窗时间
     */
    public static final String INVOKE_LOG_WINDOW_TIME = "invoke.log.window.time";

    /**
     * invoke log watermark 允许延迟
     */
    public static final String INVOKE_LOG_MAX_OUTOF_ORDERNESS = "invoke.log.watermark.maxOutOfOrderness";


    public static final String CONSUMER_FROM_TIME = "consumer.from.time";
    public static final String STREAM_PARALLELISM = "stream.parallelism";
    public static final String STREAM_SINK_PARALLELISM = "stream.sink.parallelism";
    public static final String STREAM_DEFAULT_PARALLELISM = "stream.default.parallelism";
    public static final String STREAM_CHECKPOINT_ENABLE = "stream.checkpoint.enable";
    public static final String STREAM_CHECKPOINT_DIR = "stream.checkpoint.dir";
    public static final String STREAM_CHECKPOINT_TYPE = "stream.checkpoint.type";
    public static final String STREAM_CHECKPOINT_INTERVAL = "stream.checkpoint.interval";
    public static final String PROPERTIES_FILE_NAME = "/application.properties";
    public static final String CHECKPOINT_MEMORY = "memory";
    public static final String CHECKPOINT_FS = "fs";
    public static final String CHECKPOINT_ROCKETSDB = "rocksdb";

}
