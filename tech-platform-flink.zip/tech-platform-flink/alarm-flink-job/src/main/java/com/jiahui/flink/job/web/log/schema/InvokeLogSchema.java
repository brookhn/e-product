package com.jiahui.flink.job.web.log.schema;

import com.jiahui.alarm.job.util.JacksonUtils;
import com.jiahui.flink.job.web.log.model.InvokeLog;
import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.serialization.DeserializationSchema;
import org.apache.flink.api.common.serialization.SerializationSchema;
import org.apache.flink.api.common.typeinfo.TypeInformation;

import java.nio.charset.StandardCharsets;

@Slf4j
public class InvokeLogSchema implements DeserializationSchema<InvokeLog>, SerializationSchema<InvokeLog> {

    @Override
    public InvokeLog deserialize(byte[] bytes) {
        try {
            return JacksonUtils.json2pojo(new String(bytes), InvokeLog.class);
        } catch (Exception e) {
            log.error("ProgramLogSchema deserialize error", e);
        }
        return null;
    }

    @Override
    public boolean isEndOfStream(InvokeLog programLog) {
        return false;
    }

    @Override
    public byte[] serialize(InvokeLog programLog) {
        try {
            return JacksonUtils.obj2json(programLog).getBytes(StandardCharsets.UTF_8);
        } catch (Exception e) {
            log.error("ProgramLogSchema serialize error", e);
        }
        return null;
    }

    @Override
    public TypeInformation<InvokeLog> getProducedType() {
        return TypeInformation.of(InvokeLog.class);
    }
}
