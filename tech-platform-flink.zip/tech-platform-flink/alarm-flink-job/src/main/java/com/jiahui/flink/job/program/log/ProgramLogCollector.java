package com.jiahui.flink.job.program.log;

import com.jiahui.flink.job.constants.ParameterConstants;
import com.jiahui.flink.job.program.log.model.ProgramLog;
import com.jiahui.flink.job.program.log.schema.ProgramLogSchema;
import com.jiahui.flink.job.util.ExecutionEnvUtil;
import com.jiahui.alarm.job.constants.TopicConstant;
import com.jiahui.alarm.job.model.ProgramLogAlarm;
import com.jiahui.alarm.job.util.JacksonUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.connector.kafka.sink.KafkaRecordSerializationSchema;
import org.apache.flink.connector.kafka.sink.KafkaSink;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.windowing.ProcessWindowFunction;
import org.apache.flink.streaming.api.windowing.assigners.TumblingEventTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer;
import org.apache.flink.streaming.connectors.kafka.partitioner.FlinkFixedPartitioner;
import org.apache.flink.util.Collector;

import java.time.Duration;
import java.util.Objects;
import java.util.Properties;


/**
 * 基于program log 收集器
 */
@Slf4j
public class ProgramLogCollector {

    @SuppressWarnings("all")
    public static void main(String[] args) throws Exception {
        ParameterTool parameters = ExecutionEnvUtil.createParameterTool(args);
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        String kafkaBrokers = parameters.get(ParameterConstants.KAFKA_BROKERS);
        long maxOutOfOrderness = parameters.getLong(ParameterConstants.LOGGING_MAX_OUTOF_ORDERNESS);
        long windowTime = parameters.getLong(ParameterConstants.LOGGING_WINDOW_TIME);

        Properties properties = new Properties();
        properties.setProperty("bootstrap.servers", kafkaBrokers);
        properties.setProperty("group.id", "flink-alarm");
        properties.setProperty("auto.offset.reset", "latest");

        FlinkKafkaConsumer<ProgramLog> consumer = new FlinkKafkaConsumer<>(ParameterConstants.PROGRAM_LOG_TOPIC, new ProgramLogSchema(), properties);
        //设置EventTime 允许延长时间2s
        WatermarkStrategy<ProgramLog> watermarkStrategy = WatermarkStrategy.<ProgramLog>forBoundedOutOfOrderness(Duration.ofSeconds(maxOutOfOrderness))
                .withTimestampAssigner(((element, recordTimestamp) ->
                        Objects.nonNull(element.getCurrentTime()) ? element.getCurrentTime().getTime() : System.currentTimeMillis()));
        consumer.assignTimestampsAndWatermarks(watermarkStrategy);

        SingleOutputStreamOperator<ProgramLog> stream = env.addSource(consumer, "kafka program log source")
                .filter(log -> "error".equalsIgnoreCase(log.getLevel()))
                .filter(log -> Objects.nonNull(log.getCurrentTime()));
        if (log.isDebugEnabled()) {
            stream.print();
        }

        stream.keyBy(new KeySelector<ProgramLog, String>() {
            @Override
            public String getKey(ProgramLog event) {
                return event.getAppName();
            }
        }).window(TumblingEventTimeWindows.of(Time.seconds(windowTime)))//滚动窗口为5s
                .process(new ProcessWindowFunction<ProgramLog, String, String, TimeWindow>() {
                    //窗口关闭
                    @Override
                    public void process(String key, Context context, Iterable<ProgramLog> iterable, Collector<String> collector) throws Exception {
                        Long errNum = 0L;
                        for (ProgramLog event : iterable) errNum++;
                        log.info("window process invoked key[{}] windowStart[{}] windowEnd[{}] errorCount[{}]", key, context.window().getStart(), context.window().getEnd(), errNum);
                        collector.collect(JacksonUtils.obj2json(new ProgramLogAlarm(key, errNum, context.window().getStart(), context.window().getEnd())));
                    }
                }).sinkTo(getKafkaSink(kafkaBrokers));

        try {
            env.execute("Program log collector execute.");
        } catch (Exception e) {
            log.error("Program log alarm execute error", e);
        }

    }

    public static KafkaSink getKafkaSink(String bootstrapServers) {
        return KafkaSink.<String>builder()
                .setBootstrapServers(bootstrapServers)
                .setRecordSerializer(KafkaRecordSerializationSchema.builder()
                        .setTopic(TopicConstant.FLINK_LOGGING_ERROR_COUNT)
                        .setValueSerializationSchema(new SimpleStringSchema())
                        .setPartitioner(new FlinkFixedPartitioner())
                        .build()
                ).build();
    }

}
