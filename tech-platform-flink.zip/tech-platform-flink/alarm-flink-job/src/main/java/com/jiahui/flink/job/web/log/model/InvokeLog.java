package com.jiahui.flink.job.web.log.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class InvokeLog {

    @JsonProperty("traceid")
    private String traceid;
    @JsonProperty("appversion")
    private String appversion;
    @JsonProperty("appname")
    private String appname;
    @JsonProperty("appenv")
    private String appenv;
    @JsonProperty("current_time")
    private Long currentTime;
    @JsonProperty("response_time")
    private Long responseTime;
    @JsonProperty("http_status")
    private Integer httpStatus;
    @JsonProperty("uri")
    private String uri;
    @JsonProperty("user_agent")
    private String userAgent;
    @JsonProperty("http_method")
    private String httpMethod;
    @JsonProperty("spend_time")
    private Integer spendTime;
    @JsonProperty("server_ip")
    private String serverIp;
    @JsonProperty("ip")
    private String ip;
    @JsonProperty("src")
    private String src;
    @JsonProperty("userid")
    private String userid;
    @JsonProperty("request_param")
    private String requestParam;
    @JsonProperty("code")
    private String code;
    @JsonProperty("response_body")
    private String responseBody;
}
