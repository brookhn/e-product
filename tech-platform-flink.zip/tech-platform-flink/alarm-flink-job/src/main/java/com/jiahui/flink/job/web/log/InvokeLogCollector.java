//package com.jiahui.flink.job.web.log;
//
//import com.jiahui.alarm.job.constants.TopicConstant;
//import com.jiahui.alarm.job.model.ProgramLogAlarm;
//import com.jiahui.alarm.job.util.JacksonUtils;
//import com.jiahui.flink.job.constants.ParameterConstants;
//import com.jiahui.flink.job.util.ExecutionEnvUtil;
//import com.jiahui.flink.job.web.log.model.InvokeLog;
//import com.jiahui.flink.job.web.log.schema.InvokeLogSchema;
//import lombok.extern.slf4j.Slf4j;
//import org.apache.flink.api.common.eventtime.WatermarkStrategy;
//import org.apache.flink.api.common.serialization.SimpleStringSchema;
//import org.apache.flink.api.java.functions.KeySelector;
//import org.apache.flink.api.java.utils.ParameterTool;
//import org.apache.flink.connector.kafka.sink.KafkaRecordSerializationSchema;
//import org.apache.flink.connector.kafka.sink.KafkaSink;
//import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
//import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
//import org.apache.flink.streaming.api.functions.windowing.ProcessWindowFunction;
//import org.apache.flink.streaming.api.windowing.assigners.TumblingEventTimeWindows;
//import org.apache.flink.streaming.api.windowing.time.Time;
//import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
//import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer;
//import org.apache.flink.streaming.connectors.kafka.partitioner.FlinkFixedPartitioner;
//import org.apache.flink.util.Collector;
//
//import java.time.Duration;
//import java.util.Objects;
//import java.util.Properties;
//
///**
// * 方案废弃(invoke log 告警直接查询es，此代码未测试)
// */
//@Deprecated
//@Slf4j
//public class InvokeLogCollector {
//
//    @SuppressWarnings("all")
//    public static void main(String[] args) throws Exception {
//        ParameterTool parameters = ExecutionEnvUtil.createParameterTool(args);
//        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
//
//        String kafkaBrokers = parameters.get(ParameterConstants.KAFKA_BROKERS);
//        long maxOutOfOrderness = parameters.getLong(ParameterConstants.INVOKE_LOG_MAX_OUTOF_ORDERNESS);
//        long windowTime = parameters.getLong(ParameterConstants.INVOKE_LOG_WINDOW_TIME);
//
//        Properties properties = new Properties();
//        properties.setProperty("bootstrap.servers", kafkaBrokers);
//        properties.setProperty("group.id", "flink-alarm");
//        properties.setProperty("auto.offset.reset", "latest");
//
//        FlinkKafkaConsumer<InvokeLog> consumer = new FlinkKafkaConsumer<>(ParameterConstants.INVOKE_LOG_TOPIC, new InvokeLogSchema(), properties);
//        //设置EventTime及窗口允许延时
//        WatermarkStrategy<InvokeLog> watermarkStrategy = WatermarkStrategy.<InvokeLog>forBoundedOutOfOrderness(Duration.ofSeconds(maxOutOfOrderness))
//                .withTimestampAssigner(((element, recordTimestamp) ->
//                        Objects.nonNull(element.getCurrentTime()) ? element.getCurrentTime() : System.currentTimeMillis()));
//        consumer.assignTimestampsAndWatermarks(watermarkStrategy);
//
//        SingleOutputStreamOperator<InvokeLog> stream = env.addSource(consumer, "kafka invoke log source")
//                .filter(invokeLog -> !"200".equalsIgnoreCase(invokeLog.getCode()) && !"0".equalsIgnoreCase(invokeLog.getCode()));
//        if (log.isDebugEnabled()) {
//            stream.print();
//        }
//
//        stream.keyBy(new KeySelector<InvokeLog, String>() {
//            @Override
//            public String getKey(InvokeLog event) {
//                return event.getAppname();
//            }
//        }).window(TumblingEventTimeWindows.of(Time.minutes(windowTime)))
//                .process(new ProcessWindowFunction<InvokeLog, String, String, TimeWindow>() {
//                    //窗口关闭触发
//                    @Override
//                    public void process(String key, Context context, Iterable<InvokeLog> iterable, Collector<String> collector) throws Exception {
//                        Long errNum = 0L;
//                        for (InvokeLog event : iterable) errNum++;
//                        log.info("window process invoked key[{}] windowStart[{}] windowEnd[{}] errorCount[{}]", key, context.window().getStart(), context.window().getEnd(), errNum);
//                        collector.collect(JacksonUtils.obj2json(new ProgramLogAlarm(key, errNum, context.window().getStart(), context.window().getEnd())));
//                    }
//                }).sinkTo(getKafkaSink(kafkaBrokers));
//        try {
//            env.execute("InvokeLog collector execute.");
//        } catch (Exception e) {
//            log.error("InvokeLog alarm execute error", e);
//        }
//
//    }
//
//    public static KafkaSink getKafkaSink(String bootstrapServers) {
//        return KafkaSink.<String>builder()
//                .setBootstrapServers(bootstrapServers)
//                .setRecordSerializer(KafkaRecordSerializationSchema.builder()
//                        .setTopic(TopicConstant.FLINK_INVOKE_LOG_ERROR_COUNT)
//                        .setValueSerializationSchema(new SimpleStringSchema())
//                        .setPartitioner(new FlinkFixedPartitioner())
//                        .build()
//                ).build();
//    }
//
//}
