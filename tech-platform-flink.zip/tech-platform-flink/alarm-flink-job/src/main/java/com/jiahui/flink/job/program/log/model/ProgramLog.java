package com.jiahui.flink.job.program.log.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
public class ProgramLog implements Serializable {

    @JsonProperty("appname")
    private String appName;

    @JsonProperty("current_time")
    private Date currentTime;

    @JsonProperty("TID")
    private String tid;

    @JsonProperty("thread_name")
    private String threadName;

    private String level;

    @JsonProperty("logger_name")
    private String loggerName;

    private String message;

    @JsonProperty("source_host")
    private String sourceHost;

    @JsonProperty("appversion")
    private String appVersion;

    @JsonProperty("appenv")
    private String appEnv;

}
