package com.jiahui.alarm.server.configuration;

import com.jiahui.framework.datasource.config.JiaHuiDataSourceProperties;
import com.jiahui.framework.datasource.core.DynamicDataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;


@Configuration
public class DataSourceConfiguration {

    @Bean("alarm-server")
    public DataSource getDataSource(JiaHuiDataSourceProperties dbProp) {
        DynamicDataSource dataSource = new DynamicDataSource("alarm-server", dbProp);
        return dataSource;
    }

}
