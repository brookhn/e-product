package com.jiahui.alarm.server.channel;

import com.alibaba.fastjson.JSON;
import com.jiahui.alarm.base.common.ConfigKey;
import com.jiahui.alarm.base.entity.QueueMessage;
import com.jiahui.alarm.server.vo.AlarmMessage;
import org.redisson.api.RedissonClient;
import org.springframework.stereotype.Service;

@Service("smsChannel")
public class SmsChannel extends Channel {

    public SmsChannel(RedissonClient client) {
        super(client);
    }

    @Override
    public void send(AlarmMessage alarmMessage) {
        String content = "告警名称:" + alarmMessage.getAlarmName()
                + ",上报编号:" + alarmMessage.getReportId()
                + ",时间:" + alarmMessage.getCreateTime()
                + ",内容:" + alarmMessage.getContent();

        if (content.length() > 500) {
            content = content.substring(0, 480) + "(完整内容见告警日志)";
        }

        QueueMessage queueMessage = new QueueMessage(null, content, alarmMessage.getPhoneList(),
                alarmMessage.getLogId(), alarmMessage.getLevel());
        this.save(JSON.toJSONString(queueMessage));
    }

    @Override
    protected String getPreSendingQueue() {
        return ConfigKey.SMS_QUEUE.value();
    }
}
