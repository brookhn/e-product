package com.jiahui.alarm.server.dao;

import com.jiahui.alarm.base.entity.Group;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

/**
 * Created by caijt on 2017/3/26.
 */
public interface GroupDao {
    @Select("select * from tb_group where id=#{id}")
    Group getGroupById(@Param("id") int id);
}
