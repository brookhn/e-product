package com.jiahui.alarm.server.configuration;

import com.jiahui.alarm.server.interceptor.MonitorInterceptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * Created by caijt on 2017/4/2.
 */
@Configuration
public class InterceptorsConfiguration implements WebMvcConfigurer {

    @Bean
    MonitorInterceptor monitorInterceptor() {
        return new MonitorInterceptor();
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(monitorInterceptor()).addPathPatterns("/v1/alarm");
    }
}
