package com.jiahui.alarm.server.common;

import org.redisson.api.RedissonClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
public class IdGenerator {

    @Autowired
    private RedissonClient redissonClient;

    private static final Logger logger = LoggerFactory.getLogger(IdGenerator.class);

    public Long generate(String pool) {
        try {
            return redissonClient.getAtomicLong(pool).incrementAndGet();
        } catch (Exception e) {
            logger.error("generate id fail, caused by ", e);
            return 0L;
        }
    }
}
