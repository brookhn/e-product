package com.jiahui.alarm.server.dao;

import com.jiahui.alarm.base.entity.AlarmLog;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Update;


public interface AlarmLogDao {
    @Insert("insert into tb_alarm_log(report_id, code, alarm_name, project_name, module_name, group_name, level, " +
            "receivers, content, ip, status, alarm_time) values(#{reportId}, #{code}, #{alarmName}, " +
            "#{projectName}, #{moduleName}, #{groupName}, #{level}, #{receivers}, #{content}, #{ip}, " +
            "#{status}, #{alarmTime})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    void save(AlarmLog alarmLog);

    @Update("update tb_alarm_log set status=#{status},delivery_status=#{deliveryStatus},update_time=#{updateTime} where id=#{id}")
    int updateStatus(AlarmLog alarmLog);
}
