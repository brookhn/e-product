package com.jiahui.alarm.server.configuration;

import com.jiahui.alarm.server.client.impl.DingTalkClient;
import com.jiahui.alarm.server.client.impl.MailClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;

@Component
public class ApplicationEventListener implements ApplicationListener<ApplicationReadyEvent> {

    private static Logger logger = LoggerFactory.getLogger(ApplicationEventListener.class);

    @Autowired
    private MailClient mailClient;

    @Autowired
    private DingTalkClient dingTalkClient;

    @Resource(name = "coreThreadPool")
    private ExecutorService coreThreadPool;

    @Override
    public void onApplicationEvent(ApplicationReadyEvent readyEvent) {
        try {
            CompletableFuture.runAsync(() -> {
                dingTalkClient.start();
            }, coreThreadPool);

            CompletableFuture.runAsync(() -> {
                mailClient.start();
            }, coreThreadPool);

        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
    }

}
