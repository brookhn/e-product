package com.jiahui.alarm.server.dao;

import com.jiahui.alarm.base.entity.Project;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

/**
 * Created by caijt on 2017/1/28.
 */
public interface ProjectDao {
    @Select("select * from tb_project where id=#{id}")
    Project getProjectById(@Param("id") int id);
}
