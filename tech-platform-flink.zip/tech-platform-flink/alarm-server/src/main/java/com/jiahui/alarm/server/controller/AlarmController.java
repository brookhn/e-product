package com.jiahui.alarm.server.controller;

import com.alibaba.fastjson.JSON;
import com.jiahui.alarm.server.common.ResponseHelper;
import com.jiahui.alarm.server.service.AlarmService;
import com.jiahui.alarm.server.vo.AlarmForm;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConversionException;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

@RestController
@RequestMapping("/v1")
public class AlarmController {

    private static final Logger logger = LoggerFactory.getLogger(AlarmController.class);

    @Autowired
    private AlarmService alarmService;

    @RequestMapping(value = "/alarm", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
    public String report(HttpServletRequest request, @RequestBody @Valid AlarmForm alarmForm) {
        alarmForm.setIp(ResponseHelper.getRemoteIp(request));
        logger.info("POST /v1/alarm, body:{}.", JSON.toJSONString(alarmForm));
        try {
            return alarmService.handle(alarmForm);
        } catch (Exception e) {
            logger.error("bad service", e);
            return ResponseHelper.buildResponse(5000, "reason", "bad service");
        }
    }

    @ExceptionHandler(HttpMessageConversionException.class)
    public String invalidParameterHandler(HttpServletRequest req, Exception e) {
        return ResponseHelper.buildResponse(4000, "reason", "invalid params");
    }

    @ExceptionHandler(Exception.class)
    public String badService(Exception e) {
        return ResponseHelper.buildResponse(5000, "reason", "bad service");
    }
}
