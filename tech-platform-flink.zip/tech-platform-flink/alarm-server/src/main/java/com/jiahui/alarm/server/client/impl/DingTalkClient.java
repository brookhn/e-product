package com.jiahui.alarm.server.client.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.jiahui.alarm.base.common.ConfigKey;
import com.jiahui.alarm.base.entity.AlarmLog;
import com.jiahui.alarm.base.entity.QueueMessage;
import com.jiahui.alarm.server.client.Client;
import com.jiahui.alarm.server.dao.AlarmLogDao;
import com.jiahui.dingtalk.RobotGroupChatController;
import com.jiahui.vo.JsonOutResult;
import com.jiahui.vo.robot.MarkdownMessage;
import org.apache.skywalking.apm.toolkit.trace.Trace;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;


@Component
public class DingTalkClient extends Client {

    @Autowired
    private RobotGroupChatController robotChatClient;

    @Autowired
    private AlarmLogDao alarmLogDao;

    public DingTalkClient(RedissonClient redissonClient) {
        super("dingTalk", ConfigKey.DING_TALK_QUEUE.value(), "dingTalk", redissonClient);
    }


    @Trace
    @Override
    public int send(String message) {
        try {
            logger.debug("start send dingTalk alarm, body:{}", message);
            QueueMessage queueMessage = JSON.parseObject(message, QueueMessage.class);
            if (doSend(queueMessage)) {
                markDeliveryStatus(queueMessage.getLogId(), 1);
                return queueMessage.getReceivers().size();
            }
            markDeliveryStatus(queueMessage.getLogId(), 0);
            return 0;
        } catch (Exception e) {
            logger.error("handle mail message error, caused by", e);
            return 0;
        }
    }

    @Override
    protected String getPushQuantityKey() {
        return ConfigKey.DING_TALK_PUSH_QUANTITY.value();
    }

    @Override
    protected String getPushDailyKey() {
        return ConfigKey.DING_TALK_PUSH_DAILY.value();
    }


    private boolean doSend(QueueMessage message) {
        try {
            MarkdownMessage msgBody = new MarkdownMessage();
            msgBody.setText(message.getContent());
            msgBody.setTitle(message.getTitle());
            msgBody.setAtAll(false);
            msgBody.setAtMobiles(message.getAtReceivers().toArray(new String[0]));
            msgBody.setRobotCode(message.getAtReceivers().get(0));
            logger.info("logId{}发送dingTalk入参{}", message.getLogId(), msgBody);
            JsonOutResult result = robotChatClient.sendMarkdown(msgBody);
            logger.info("logId{}发送dingTalk出参{}", message.getLogId(), JSONObject.toJSON(result));
            return 200 == result.getCode();
        } catch (Exception e) {
            logger.error("send mail to {} fail, caused by", JSON.toJSONString(message.getReceivers()), e);
            return false;
        }
    }

    public void markDeliveryStatus(long logId, int deliverStatus) {
        try {
            AlarmLog alarmLog = new AlarmLog();
            alarmLog.setId(logId);
            alarmLog.setStatus(1);
            alarmLog.setDeliveryStatus(deliverStatus);
            alarmLog.setUpdateTime(new Date());
            int update = alarmLogDao.updateStatus(alarmLog);
            logger.info("update alarmLog status {}", update);
        } catch (Exception e) {
            logger.error("update alarmLog logId{} status error", logId, e);
        }
    }
}
