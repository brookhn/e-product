package com.jiahui.alarm.server.client;

import com.jiahui.alarm.base.util.DateUtil;
import org.redisson.api.RedissonClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Date;
import java.util.concurrent.TimeUnit;

public abstract class Client {

    protected final Logger logger = LoggerFactory.getLogger(getClass());

    private static final int MAX_RETRY_TIMES = 3;

    public String name;
    public String queueName;
    protected String channel;
    private RedissonClient redissonClient;

    protected abstract int send(String message);

    protected abstract String getPushQuantityKey();

    protected abstract String getPushDailyKey();

    public Client(String name, String queueName, String channel, RedissonClient redissonClient) {
        this.name = name;
        this.queueName = queueName;
        this.channel = channel;
        this.redissonClient = redissonClient;
    }

    public void start() {
        logger.info("start {} client success", name);
        while (true) {
            try {
                int sendNumber = send((String) redissonClient.getBlockingQueue(queueName).take());
                if (sendNumber > 0) {
                    recordPushNumber(sendNumber);
                }
            } catch (Exception e) {
                logger.error("consume queue {} error, caused by", queueName, e);
            }
        }
    }

    /**
     * 各个渠道的推送数量统计(每日和总量)
     */
    private void recordPushNumber(int number) {
        try {
            String pushQuantityKey = getPushQuantityKey();
            if (pushQuantityKey != null) {
                redissonClient.getAtomicLong(pushQuantityKey).getAndAdd(number);
            }
            String pushDailyKey = getPushDailyKey();
            if (pushDailyKey != null) {
                String date = DateUtil.formatDate(DateUtil.YYYYMMDD, new Date());
                redissonClient.getAtomicLong(pushDailyKey.replace("{date}", date)).getAndAdd(number);
                redissonClient.getAtomicLong(pushDailyKey.replace("{date}", date)).expire(2, TimeUnit.DAYS);
            }
        } catch (Exception e) {
            logger.error("record push number error, key:{}, caused by", getPushQuantityKey(), e);
        }
    }

    private int sendWithRetry(String message) {
        int sendNumber = 0;
        for (int i = 1; i <= MAX_RETRY_TIMES && sendNumber == 0; i++) {
            logger.info("send alarm fail, retry times:{}, data:{}", i, message);
            sendNumber = send(message);
        }
        if (sendNumber > 0) {
            return sendNumber;
        }
        logger.info("send alarm always fail, content:{}", message);
        return sendNumber;
    }

}
