package com.jiahui.alarm.server.interceptor;

import com.jiahui.alarm.base.common.ConfigKey;
import org.redisson.api.RedissonClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Component
public class MonitorInterceptor implements HandlerInterceptor {

    @Autowired
    private RedissonClient redissonClient;

    private static final Logger logger = LoggerFactory.getLogger(MonitorInterceptor.class);

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        try {
            redissonClient.getAtomicLong(ConfigKey.TOTAL_REQUEST_QUANTITY.value()).incrementAndGet();
        } catch (Exception e) {
            logger.error("do monitor interceptor error, caused by", e);
        }
        return true;
    }
}
