package com.jiahui.alarm.server.configuration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * @author zzc
 */
@Configuration
public class ThreadPoolConfig {

    private static final Logger logger = LoggerFactory.getLogger(ThreadPoolConfig.class);

    @Bean(destroyMethod = "shutdown")
    public ExecutorService coreThreadPool() {
        ExecutorService executor = new ThreadPoolExecutor(10,
                50, 60, TimeUnit.SECONDS,
                new LinkedBlockingQueue<Runnable>(1000), new DefaultThreadFactory("coreThreadPool-"), new CoreThreadPolicy());
        return executor;
    }


    /**
     * 核心线程池拒绝策略,线程池满转到主线程运行
     */
    public class CoreThreadPolicy implements RejectedExecutionHandler {


        private ThreadPoolExecutor.CallerRunsPolicy callerRunsPolicy = new ThreadPoolExecutor.CallerRunsPolicy();

        public CoreThreadPolicy() {
        }

        /**
         * Executes task r in the caller's thread, unless the executor has been shut down, in which case the task is discarded.
         *
         * @param r the runnable task requested to be executed
         * @param e the executor attempting to execute this task
         */
        @Override
        public void rejectedExecution(Runnable r, ThreadPoolExecutor e) {
            logger.warn(String.format("线程池已满:%s,%s", r.toString(), e.toString()));
            callerRunsPolicy.rejectedExecution(r, e);
        }
    }

    static class DefaultThreadFactory implements ThreadFactory {
        private final ThreadGroup group;
        private final AtomicInteger threadNumber = new AtomicInteger(1);
        private final String namePrefix;

        DefaultThreadFactory(String namePrefix) {
            SecurityManager s = System.getSecurityManager();
            group = (s != null) ? s.getThreadGroup() : Thread.currentThread().getThreadGroup();
            this.namePrefix = namePrefix;
        }

        @Override
        public Thread newThread(Runnable r) {
            Thread t = new Thread(group, r, namePrefix + threadNumber.getAndIncrement(), 0);
            if (t.isDaemon()) {
                t.setDaemon(false);
            }
            if (t.getPriority() != Thread.NORM_PRIORITY) {
                t.setPriority(Thread.NORM_PRIORITY);
            }
            return t;
        }
    }
}
