package com.jiahui.alarm.server;

import org.mybatis.spring.annotation.MapperScan;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

@EnableDiscoveryClient
@EnableFeignClients(value = {"com.jiahui"})
@MapperScan("com.jiahui.alarm.server.dao")
@SpringBootApplication
public class Bootstrap {

    private static final Logger logger = LoggerFactory.getLogger(Bootstrap.class);

    public static void main(String[] args) {
        try {
            SpringApplication.run(Bootstrap.class, args);
            logger.info("start alarm server success");
        } catch (Exception e) {
            logger.error("start alarm server error, caused by", e);
        }
    }
}
