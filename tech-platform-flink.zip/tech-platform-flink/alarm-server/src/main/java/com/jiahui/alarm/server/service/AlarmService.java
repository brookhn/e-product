package com.jiahui.alarm.server.service;

import com.alibaba.fastjson.JSON;
import com.google.common.base.Splitter;
import com.google.common.base.Strings;
import com.jiahui.alarm.base.common.ConfigKey;
import com.jiahui.alarm.base.entity.Alarm;
import com.jiahui.alarm.base.entity.AlarmStatusEnum;
import com.jiahui.alarm.base.entity.Group;
import com.jiahui.alarm.base.entity.AlarmLog;
import com.jiahui.alarm.base.entity.Project;
import com.jiahui.alarm.base.entity.Receiver;
import com.jiahui.alarm.base.exception.AlarmNotFoundException;
import com.jiahui.alarm.server.channel.Channel;
import com.jiahui.alarm.server.common.IdGenerator;
import com.jiahui.alarm.server.common.ResponseHelper;
import com.jiahui.alarm.server.dao.*;
import com.jiahui.alarm.server.vo.AlarmForm;
import com.jiahui.alarm.server.vo.AlarmMessage;
import com.jiahui.alarm.server.vo.JsonConfig;
import org.redisson.api.RedissonClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.jiahui.alarm.base.entity.Module;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

/**
 */
@Service
public class AlarmService {

    private static final Logger logger = LoggerFactory.getLogger(AlarmService.class);

    // 限频参数
    private static final int DEFAULT_TIME_INTERVAL_LIMIT = 5;   //分钟
    private static final int DEFAULT_SEND_TIMES_LIMIT = 10;     //次数

    @Autowired
    private AlarmDao alarmDao;
    @Autowired
    private ReceiverDao receiverDao;
    @Autowired
    private AlarmLogDao alarmLogDao;
    @Autowired
    private ProjectDao projectDao;
    @Autowired
    private ModuleDao moduleDao;
    @Autowired
    private GroupDao groupDao;


    @Autowired
    private Channel dingTalkChannel;
    @Autowired
    private Channel smsChannel;
    @Autowired
    private Channel mailChannel;

    @Autowired
    private IdGenerator idGenerator;

    @Autowired
    private RedissonClient redissonClient;

    /**
     * 处理告警上报信息
     *
     * @param alarmForm 告警表单
     * @return 处理结果
     */
    public String handle(AlarmForm alarmForm) {
        try {
            // 已发送的接收人id
            Set<Integer> sent = new HashSet<>();
            // 根据表单配置获取告警列表
            List<Alarm> alarmList = getAlarmList(alarmForm);
            // 一个告警信息共用一个上报id
            long reportId = idGenerator.generate(ConfigKey.ALARM_REPORT_ID_POOL.value());
            for (Alarm alarm : alarmList) {
                // 获取该告警接收人
                List<Receiver> receiverList = receiverDao.getReceiverByGroupId(alarm.getGroupId());
                // 接收人去重,防止一条告警信息多次发送给同一个接收人
                receiverList = removeDuplicatedReceiver(receiverList, sent);
                if (receiverList.size() != 0) {
                    Group group = groupDao.getGroupById(alarm.getGroupId());
                    AlarmMessage alarmMessage = buildAlarmMessage(alarm, alarmForm, receiverList, reportId, group);
                    if (alarmForm.isTest()) {
                        logger.debug("ignore test alarm, message:{}", alarmMessage);
                        saveAlarmLog(alarmMessage, AlarmStatusEnum.TEST);
                    } else if (isFrequencyLimited(alarmMessage)) {
                        logger.debug("alarm frequency limit, message:{}", alarmMessage);
                        saveAlarmLog(alarmMessage, AlarmStatusEnum.LIMIT);
                    } else {
                        saveAlarmLog(alarmMessage, AlarmStatusEnum.CREATE);
                        triggerAlarm(alarmMessage);
                    }
                }
            }
            // 告警信息无接收人, 发送告警信息给管理员
            if (sent.size() == 0) {
                return ResponseHelper.buildResponse(4004, "reason", "receiver is empty");
            }
            return ResponseHelper.buildResponse(200);
        } catch (AlarmNotFoundException e) {
            logger.error("alarm not found by code:{}", alarmForm.getCode());
            return ResponseHelper.buildResponse(4004, "reason", "alarm not found.");
        }
    }

    /**
     * 获取告警列表，根据code和routeKey过滤告警
     *
     * @param alarmForm 告警表单
     * @return 告警列表
     */
    private List<Alarm> getAlarmList(AlarmForm alarmForm) {
        List<Alarm> alarms = alarmDao.getAllByCode(alarmForm.getCode());

        List<Alarm> legalAlarm = new ArrayList<>();
        for (Alarm alarm : alarms) {
            legalAlarm.add(alarm);
        }
        if (legalAlarm.size() == 0) {
            throw new AlarmNotFoundException();
        }
        return legalAlarm;
    }

    /**
     * route key匹配
     *
     * @param userRouteKey  用户发送的route key
     * @param alarmRouteKey 告警配置的route key
     * @return 匹配结果
     */
    private boolean isMatch(String userRouteKey, String alarmRouteKey) {
        if (Strings.isNullOrEmpty(alarmRouteKey)) {
            return false;
        }
        List<String> userPart = Splitter.on(".").splitToList(userRouteKey);
        List<String> alarmPart = Splitter.on(".").splitToList(alarmRouteKey);

        if (userPart.size() != alarmPart.size()) return false;

        for (int i = 0; i < userPart.size(); i++) {
            if (!userPart.get(i).equals(alarmPart.get(i)) && !"*".equals(alarmPart.get(i))) {
                return false;
            }
        }
        return true;
    }

    /**
     * 接收人去重
     *
     * @param receiverList 接收人列表
     * @param sent         已发送的接收人
     * @return 去重后的接收人列表
     */
    private List<Receiver> removeDuplicatedReceiver(List<Receiver> receiverList, Set<Integer> sent) {
        List<Receiver> uniqueReceiverList = new ArrayList<>();
        for (Receiver receiver : receiverList) {
            if (sent.add(receiver.getId())) {
                uniqueReceiverList.add(receiver);
            }
        }
        return uniqueReceiverList;
    }

    /**
     * 根据用户配置，转发告警信息到各个渠道
     *
     * @param alarmMessage 告警相关信息
     */
    private void triggerAlarm(AlarmMessage alarmMessage) {
        JsonConfig config = new JsonConfig(alarmMessage.getConfig());

        if (config.getConfig("sms", false)) {
            smsChannel.send(alarmMessage);
        }
        if (config.getConfig("mail", false)) {
            mailChannel.send(alarmMessage);
        }
        if (config.getConfig("dingTalk", false)) {
            dingTalkChannel.send(alarmMessage);
        }
    }

    /**
     * 告警限频处理
     *
     * @param alarmMessage 告警相关信息
     * @return 是否限频
     */
    private boolean isFrequencyLimited(AlarmMessage alarmMessage) {
        JsonConfig config = new JsonConfig(alarmMessage.getConfig());
        if (!config.getConfig("freq_limit", true)) {
            return false;
        }
        switch (alarmMessage.getLevel()) {
            case DEBUG:
                Integer debugTimes = config.getConfig("debug_times", DEFAULT_SEND_TIMES_LIMIT);
                Integer debugInterval = config.getConfig("debug_interval", DEFAULT_TIME_INTERVAL_LIMIT);
                return checkFrequencyLimited(alarmMessage, debugTimes, debugInterval);
            case INFO:
                Integer infoTimes = config.getConfig("info_times", DEFAULT_SEND_TIMES_LIMIT);
                Integer infoInterval = config.getConfig("info_interval", DEFAULT_TIME_INTERVAL_LIMIT);
                return checkFrequencyLimited(alarmMessage, infoTimes, infoInterval);
            case ERROR:
                Integer errorTimes = config.getConfig("error_times", DEFAULT_SEND_TIMES_LIMIT);
                Integer errorInterval = config.getConfig("error_interval", DEFAULT_TIME_INTERVAL_LIMIT);
                return checkFrequencyLimited(alarmMessage, errorTimes, errorInterval);
            default:
                logger.info("unknow alarm level, throw away, content:{}", JSON.toJSONString(alarmMessage));
                return false;
        }
    }

    /**
     * 判断是否限频
     *
     * @param alarmMessage 告警相关信息
     * @param times        限频次数
     * @param interval     限频间隔
     * @return
     */
    private boolean checkFrequencyLimited(AlarmMessage alarmMessage, int times, int interval) {
        String key = alarmMessage.getCode() + "." + alarmMessage.getRouteKey();
        try {
            long currentTimes = redissonClient.getAtomicLong(key).incrementAndGet();
//            Jedis jedis = JedisFactory.getJedisInstance();
//            long currentTimes = jedis.incr(key);
            if (currentTimes == 1) {
//                jedis.expire(key, interval * 60);
                redissonClient.getAtomicLong(key).expire(interval * 60, TimeUnit.SECONDS);
            }
            return currentTimes > times;
        } catch (Exception e) {
            logger.error("check frequency limited error, caused by", e);
            return false;
        }
    }

    /**
     * 告警日志落地
     *
     * @param alarmMessage    告警相关信息
     * @param alarmStatusEnum 告警处理状态
     */
    private void saveAlarmLog(AlarmMessage alarmMessage, AlarmStatusEnum alarmStatusEnum) {
        AlarmLog alarmLog = new AlarmLog();
        alarmLog.setReportId(alarmMessage.getReportId());
        alarmLog.setCode(alarmMessage.getCode());
        alarmLog.setAlarmName(alarmMessage.getAlarmName());
        alarmLog.setProjectName(alarmMessage.getProjectName());
        alarmLog.setModuleName(alarmMessage.getModuleName());
        alarmLog.setLevel(alarmMessage.getLevel());
        alarmLog.setGroupName(alarmMessage.getGroup());
        alarmLog.setReceivers(getReceiversName(alarmMessage.getReceivers()));
        alarmLog.setContent(alarmMessage.getContent(512));
        alarmLog.setIp(alarmMessage.getIp());
        alarmLog.setStatus(alarmStatusEnum.value());
        alarmLog.setAlarmTime(alarmMessage.getCreateTime());

        alarmLogDao.save(alarmLog);
        alarmMessage.addLogId(alarmLog.getId());
    }

    private AlarmMessage buildAlarmMessage(Alarm alarm, AlarmForm alarmForm, List<Receiver> receiverList, long reportId, Group group) {
        Module module = moduleDao.getModuleById(alarm.getModuleId());
        Project project = projectDao.getProjectById(alarm.getProjectId());

        AlarmMessage alarmMessage = new AlarmMessage();
        alarmMessage.addAlarm(alarm)
                .addAlarmForm(alarmForm)
                .addProject(project)
                .addModule(module)
                .addReceivers(receiverList)
                .addReportId(reportId)
                .addGroup(group);
        alarmMessage.setCreateTime(alarmForm.getOccurTime());
        alarmMessage.setLinkUrl(alarmForm.getLinkUrl());
        return alarmMessage;
    }

    private String getReceiversName(List<Receiver> receivers) {
        if (receivers.size() == 0) {
            return "";
        } else if (receivers.size() == 1) {
            return receivers.get(0).getName();
        } else {
            String receiverNames = receivers.get(0).getName();
            for (int i = 1; i < receivers.size(); i++) {
                receiverNames += "," + receivers.get(i).getName();
            }
            return receiverNames;
        }
    }
}
