package com.jiahui.alarm.server.channel;

import com.jiahui.alarm.server.vo.AlarmMessage;
import org.redisson.api.RedissonClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public abstract class Channel {

    protected Logger logger = LoggerFactory.getLogger(getClass());

    private RedissonClient redissonClient;

    public Channel(RedissonClient redissonClient) {
        this.redissonClient = redissonClient;
    }

    private static final int MAX_RETRY_TIMES = 3;

    public abstract void send(AlarmMessage alarmMessage);

    protected abstract String getPreSendingQueue();

    public void save(String message) {
        boolean success = false;
        for (int i = 0; i < MAX_RETRY_TIMES && !success; i++) {
            success = saveToPreSendQueue(this.getPreSendingQueue(), message, i);
        }
        if (!success) {
            logger.error("告警消息发送redis队列失败{}", message);
        }
    }

    private boolean saveToPreSendQueue(String queue, String message, int times) {
        try {
            logger.debug("write redis queue-{} success, retry times:{}, value:{}", queue, times, message);
            return redissonClient.getBlockingQueue(queue).offer(message);
        } catch (Exception e) {
            logger.error("write redis queue-{} fail, retry times:{}, value:{}", queue, times, message, e);
            return false;
        }
    }

}
