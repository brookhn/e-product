package com.jiahui.alarm.server.channel;

import com.alibaba.fastjson.JSON;
import com.jiahui.alarm.base.common.ConfigKey;
import com.jiahui.alarm.base.entity.QueueMessage;
import com.jiahui.alarm.server.vo.AlarmMessage;
import org.redisson.api.RedissonClient;
import org.springframework.stereotype.Service;

@Service("mailChannel")
public class MailChannel extends Channel {

    public MailChannel(RedissonClient client) {
        super(client);
    }

    private static final String NEW_LINE = "<br/>";


    //When a plane from London arrived at Sydney airport,
    // workers began to unload a number of wooden boxes which contained clothing.
    // No one could account for the fact that one of the boxes was extremely heavy.
    // It suddenly occurred to one of the workers to open up the box. He was astonished at what he found. A man was lying in the box on top of a pile of woolen goods. He was so surprised at being discovered that he did not even try to run away. After he was arrested, the man admitted hiding in the box before the plane left London. He had had a long and uncomfortable trip, for he had been confined to the wooden box for over eighteen hours. The man was ordered to pay $3,500 for the cost of the trip. The normal price of a ticket is $2,000!
    @Override
    public void send(AlarmMessage alarmMessage) {
        String title = "告警:" + alarmMessage.getProjectName() + "-" + alarmMessage.getModuleName()
                + "-" + alarmMessage.getAlarmName();
        String content = "上报编号:" + alarmMessage.getReportId() + NEW_LINE
                + "项目:" + alarmMessage.getProjectName() + NEW_LINE
                + "模块:" + alarmMessage.getModuleName() + NEW_LINE
                + "告警名称:" + alarmMessage.getAlarmName() + NEW_LINE
                + "告警级别:" + alarmMessage.getLevel().name() + NEW_LINE
                + "告警IP:" + alarmMessage.getIp() + NEW_LINE
                + "告警时间:" + alarmMessage.getCreateTime() + NEW_LINE
                + "告警内容:" + alarmMessage.getContent();

        QueueMessage queueMessage = new QueueMessage(title, content, alarmMessage.getMailList(),
                alarmMessage.getLogId(), alarmMessage.getLevel());
        this.save(JSON.toJSONString(queueMessage));
    }

    @Override
    protected String getPreSendingQueue() {
        return ConfigKey.MAIL_QUEUE.value();
    }
}
