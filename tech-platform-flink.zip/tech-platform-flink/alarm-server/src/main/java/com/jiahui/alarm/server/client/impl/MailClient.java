package com.jiahui.alarm.server.client.impl;

import com.alibaba.fastjson.JSON;
import com.jiahui.alarm.base.common.ConfigKey;
import com.jiahui.alarm.base.entity.AlarmLog;
import com.jiahui.alarm.base.entity.QueueMessage;
import com.jiahui.alarm.server.client.Client;
import com.jiahui.alarm.server.dao.AlarmLogDao;
import com.jiahui.mailbox.EMailClient;
import com.jiahui.vo.JsonOutResult;
import com.jiahui.vo.OutlookEmailMsg;
import org.apache.skywalking.apm.toolkit.trace.Trace;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;


@Component
public class MailClient extends Client {

    public MailClient(RedissonClient client) {
        super("mail", ConfigKey.MAIL_QUEUE.value(), "mail", client);
    }

    @Autowired
    private EMailClient eMailClient;

    @Autowired
    private AlarmLogDao alarmLogDao;

    @Override
    @Trace
    public int send(String message) {
        try {
            logger.debug("start send mail alarm, body:{}", message);
            QueueMessage queueMessage = JSON.parseObject(message, QueueMessage.class);
            if (doSend(queueMessage.getTitle(), queueMessage.getContent(), queueMessage.getReceivers())) {
                markDeliveryStatus(queueMessage.getLogId(), 1);
                return queueMessage.getReceivers().size();
            }
            markDeliveryStatus(queueMessage.getLogId(), 0);
            return 0;
        } catch (Exception e) {
            logger.error("handle mail message error, caused by", e);
            return 0;
        }
    }

    @Override
    protected String getPushQuantityKey() {
        return ConfigKey.MAIL_PUSH_QUANTITY.value();
    }

    @Override
    protected String getPushDailyKey() {
        return ConfigKey.MAIL_PUSH_DAILY.value();
    }

    private boolean doSend(String title, String content, List<String> receivers) {
        try {
            OutlookEmailMsg email = new OutlookEmailMsg();
            email.setSubject(title);
            email.setContent(content);
            String[] rece = new String[]{};
            email.setToList(receivers.toArray(rece));
            JsonOutResult result = eMailClient.sendMessage(email);
            return 200 == result.getCode();
        } catch (Exception e) {
            logger.error("send mail to {} fail, caused by", JSON.toJSONString(receivers), e);
            return false;
        }
    }

    public void markDeliveryStatus(long logId, int deliverStatus) {
        try {
            AlarmLog alarmLog = new AlarmLog();
            alarmLog.setId(logId);
            alarmLog.setStatus(1);
            alarmLog.setUpdateTime(new Date());
            alarmLog.setDeliveryStatus(deliverStatus);
            int update = alarmLogDao.updateStatus(alarmLog);
            logger.info("update alarmLog status {}", update);
        } catch (Exception e) {
            logger.error("update alarmLog logId{} status error", logId, e);
        }
    }
}
