package com.jiahui.alarm.server.configuration;

import org.apache.commons.lang3.StringUtils;
import org.redisson.Redisson;
import org.redisson.api.RedissonClient;
import org.redisson.config.Config;
import org.springframework.context.EnvironmentAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

@Configuration
public class RedissonConfig implements EnvironmentAware {

    private static final String PREFIX = "redis://";
    private static final String HOST_KEY = "spring.redis.host";
    private static final String PORT_KEY = "spring.redis.port";
    private static final String CLUSTER_KEY = "spring.redis.cluster.nodes";
    private static final String PASSWORD_KEY = "spring.redis.password";
    private static final String DATABASE = "spring.redis.database";

    private Environment environment;

    @Bean
    public RedissonClient getRedisson() {

        String host = environment.getProperty(HOST_KEY);
        String password = environment.getProperty(PASSWORD_KEY);
        String database = environment.getProperty(DATABASE);
        Config config = new Config();

        if (!StringUtils.isEmpty(host)) {
            String port = environment.getProperty(PORT_KEY);
            if (StringUtils.isEmpty(port)) {
                throw new IllegalArgumentException("[getRedisson] port is null.");
            }
            config.useSingleServer().setAddress(PREFIX + host + ":" + port);
            if (!StringUtils.isEmpty(password)) {
                config.useSingleServer().setPassword(password);
            }
            if (StringUtils.isNotBlank(database)) {
                config.useSingleServer().setDatabase(Integer.parseInt(database));
            }
        } else {
            String cluster = environment.getProperty(CLUSTER_KEY);
            if (StringUtils.isEmpty(cluster)) {
                throw new IllegalArgumentException("[getRedisson] cluster is null.");
            }
            String[] nodes = cluster.split(",");
            for (int i = 0; i < nodes.length; i++) {
                nodes[i] = PREFIX + nodes[i];
            }
            config.useClusterServers().setScanInterval(2000).addNodeAddress(nodes);
            if (!StringUtils.isEmpty(password)) {
                config.useClusterServers().setPassword(password);
            }
        }

        return Redisson.create(config);
    }

    @Override
    public void setEnvironment(Environment environment) {
        this.environment = environment;
    }
}