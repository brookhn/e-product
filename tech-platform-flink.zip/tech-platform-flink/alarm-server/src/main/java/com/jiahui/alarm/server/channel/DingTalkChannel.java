package com.jiahui.alarm.server.channel;

import com.alibaba.fastjson.JSON;
import com.jiahui.alarm.base.common.ConfigKey;
import com.jiahui.alarm.base.entity.QueueMessage;
import com.jiahui.alarm.base.util.DateUtil;
import com.jiahui.alarm.server.vo.AlarmMessage;
import org.apache.commons.lang3.StringUtils;
import org.redisson.api.RedissonClient;
import org.springframework.stereotype.Service;


@Service("dingTalkChannel")
public class DingTalkChannel extends Channel {

    public DingTalkChannel(RedissonClient client) {
        super(client);
    }

    private static final String NEW_LINE = "\n";

    @Override
    public void send(AlarmMessage alarmMessage) {
        String content = alarmMessage.getRouteKey();
        if (StringUtils.isBlank(alarmMessage.getRouteKey())) {
            //默认告警模板
            content = "### **告警：" + alarmMessage.getAlarmName() + "**" + NEW_LINE
                    + "- **[项目]-[模块]**：[" + alarmMessage.getProjectName() + "]" + (StringUtils.isBlank(alarmMessage.getModuleName()) ? "" : "-[" + alarmMessage.getModuleName()) + "]" + NEW_LINE
                    + "- **告警编号**：" + alarmMessage.getReportId() + NEW_LINE
                    + "- **级别**：" + alarmMessage.getLevel().name() + NEW_LINE
                    + "- **IP**：" + alarmMessage.getIp() + NEW_LINE
                    + "- **发生时间**：" + DateUtil.formatDate(DateUtil.YYYY_MM_DD_HH_MM_SS, alarmMessage.getCreateTime()) + NEW_LINE
                    + "- **描述**：" + alarmMessage.getContent();
        } else {
            content = content.replace("${alarm.name}", alarmMessage.getAlarmName())
                    .replace("${alarm.project}", alarmMessage.getProjectName())
                    .replace("${alarm.module}", alarmMessage.getModuleName())
                    .replace("${alarm.level}", alarmMessage.getLevel().name())
                    .replace("${alarm.id}", alarmMessage.getReportId() + "")
                    .replace("${alarm.ip}", alarmMessage.getIp())
                    .replace("${alarm.occurTime}", DateUtil.formatDate(DateUtil.YYYY_MM_DD_HH_MM_SS, alarmMessage.getCreateTime()))
                    .replace("${alarm.content}", alarmMessage.getContent());
            if (StringUtils.isNotBlank(alarmMessage.getLinkUrl())) {
                content = content.replace("${alarm.linkUrl}", alarmMessage.getLinkUrl());
            }
        }

        QueueMessage queueMessage = new QueueMessage("【告警】", content, alarmMessage.getDingTalkList(),
                alarmMessage.getLogId(), alarmMessage.getLevel());
        queueMessage.setAtReceivers(alarmMessage.getDingTalkList());
        this.save(JSON.toJSONString(queueMessage));
    }

    @Override
    protected String getPreSendingQueue() {
        return ConfigKey.DING_TALK_QUEUE.value();
    }
}
