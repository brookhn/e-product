package com.jiahui.alarm.server.vo;

import com.google.common.base.Strings;
import com.jiahui.alarm.base.entity.*;
import com.jiahui.alarm.base.entity.Module;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

/**
 * Created by caijt on 2017/1/28.
 */
public class AlarmMessage {
    private int code;
    private String alarmName;
    private String routeKey;
    private String projectName;
    private String moduleName;
    private Level level;
    private List<Receiver> receivers;
    private String content;
    private String ip;
    private AlarmStatusEnum status;
    private String group;
    private Date createTime;
    private String config;
    private long reportId;
    private long logId;
    private String linkUrl;

    public AlarmMessage() {

    }

    public AlarmMessage addAlarmForm(AlarmForm alarmForm) {
        this.level = alarmForm.getLevel();
        this.content = alarmForm.getContent();
        this.ip = alarmForm.getIp();
        return this;
    }

    public AlarmMessage addAlarm(Alarm alarm) {
        this.code = alarm.getCode();
        this.alarmName = alarm.getName();
        this.config = alarm.getConfig();
        this.routeKey = alarm.getRouteKey();
        return this;
    }

    public AlarmMessage addProject(Project project) {
        this.projectName = project.getName();
        return this;
    }

    public AlarmMessage addModule(Module module) {
        this.moduleName = Objects.nonNull(module) ? module.getName() : "";
        return this;
    }

    public AlarmMessage addReceivers(List<Receiver> receivers) {
        this.receivers = receivers;
        return this;
    }

    public AlarmMessage addReportId(long reportId) {
        this.reportId = reportId;
        return this;
    }

    public AlarmMessage addGroup(Group group) {
        this.group = group.getName();
        return this;
    }

    public int getCode() {
        return code;
    }

    public String getAlarmName() {
        return alarmName;
    }

    public String getRouteKey() {
        return routeKey;
    }

    public String getProjectName() {
        return projectName;
    }

    public String getModuleName() {
        return moduleName;
    }

    public Level getLevel() {
        return level;
    }

    public List<Receiver> getReceivers() {
        return receivers;
    }

    public String getContent() {
        return content;
    }

    // substring content
    public String getContent(int length) {
        if (content.length() <= length) {
            return content;
        } else {
            return content.substring(0, length);
        }
    }

    public String getIp() {
        return ip;
    }

    public AlarmStatusEnum getStatus() {
        return status;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getConfig() {
        return config;
    }

    public long getReportId() {
        return reportId;
    }

    public AlarmMessage addLogId(long logId) {
        this.logId = logId;
        return this;
    }

    public long getLogId() {
        return logId;
    }

    public List<String> getDingTalkList() {
        List<String> dingTalkList = new ArrayList<>();
        for (Receiver receiver : receivers) {
            if (!Strings.isNullOrEmpty(receiver.getDingTalk())) {
                dingTalkList.add(receiver.getDingTalk());
            }
        }
        return dingTalkList;
    }

    public List<String> getMailList() {
        List<String> mailList = new ArrayList<>();
        for (Receiver receiver : receivers) {
            if (!Strings.isNullOrEmpty(receiver.getMail())) {
                mailList.add(receiver.getMail());
            }
        }
        return mailList;
    }

    public List<String> getPhoneList() {
        List<String> phoneList = new ArrayList<>();
        for (Receiver receiver : receivers) {
            if (!Strings.isNullOrEmpty(receiver.getPhone())) {
                phoneList.add(receiver.getPhone());
            }
        }
        return phoneList;
    }

    public String getGroup() {
        return group;
    }

    public String getLinkUrl() {
        return linkUrl;
    }

    public void setLinkUrl(String linkUrl) {
        this.linkUrl = linkUrl;
    }

    @Override
    public String toString() {
        return "AlarmMessage{" +
                "code=" + code +
                ", alarmName='" + alarmName + '\'' +
                ", routeKey='" + routeKey + '\'' +
                ", projectName='" + projectName + '\'' +
                ", moduleName='" + moduleName + '\'' +
                ", level=" + level +
                ", receivers=" + receivers +
                ", content='" + content + '\'' +
                ", ip='" + ip + '\'' +
                ", status=" + status +
                ", group='" + group + '\'' +
                ", createTime=" + createTime +
                ", config='" + config + '\'' +
                ", reportId=" + reportId +
                ", logId=" + logId +
                '}';
    }
}
