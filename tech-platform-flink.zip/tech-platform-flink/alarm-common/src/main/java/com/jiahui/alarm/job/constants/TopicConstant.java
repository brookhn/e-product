package com.jiahui.alarm.job.constants;

public class TopicConstant {

    public static final String FLINK_LOGGING_ERROR_COUNT = "FLINK-LOGGING-ERROR-COUNT";

    public static final String FLINK_INVOKE_LOG_ERROR_COUNT = "FLINK-INVOKE-LOG-ERRORS";
    /**
     * web log topic
     */
    public static final String INVOKE_LOG_TOPIC = "JH-INVOKE-LOG";

    /**
     * program log topic
     */
    public static final String PROGRAM_LOG_TOPIC = "JH-PROGRAM-LOG";
}
