package com.jiahui.alarm.job.model;

import lombok.*;

import java.io.Serializable;

@Data
@Builder
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class InvokeLogAlarm implements Serializable {

    private String appName;

    private Long errNum;

    private Long windowStart;

    private Long windowEnd;

    private Long averageTimeSpan;

}