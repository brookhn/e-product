package com.jiahui.alarm.web;

import org.mybatis.spring.annotation.MapperScan;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@MapperScan("com.jiahui.alarm.web.dao")
@SpringBootApplication
public class Bootstrap {



    private static final Logger logger = LoggerFactory.getLogger(Bootstrap.class);

    public static void main(String[] args) {
        try {
            SpringApplication.run(Bootstrap.class, args);
            logger.info("start alarm web success");
        } catch (Exception e) {
            logger.error("start alarm web error, caused by", e);
        }
    }
}
