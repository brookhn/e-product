package com.jiahui.alarm.web.service;

import com.jiahui.alarm.base.entity.Module;
import com.jiahui.alarm.web.dao.ModuleDao;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 处理项目模块
 */
@Service
public class ModuleService {

    private static final Logger logger = LoggerFactory.getLogger(ModuleService.class);

    @Autowired
    private ModuleDao moduleDao;

    /**
     * 根据项目id获取模块列表
     *
     * @param projectId 项目id
     * @return 模块列表
     */
    public List<Module> getModuleList(int projectId) {
        return moduleDao.getModuleByPprojectId(projectId);
    }

    /**
     * 创建项目模块
     *
     * @param module 模块信息
     */
    public void createModule(Module module) {
        moduleDao.save(module);
    }

    public Module getModuleByName(Module module) {
        return moduleDao.getModuleByName(module);
    }

    /**
     * 根据模块id删除模块
     *
     * @param moduleId 模块id
     */
    public void deleteModule(int moduleId) {
        moduleDao.deleteById(moduleId);
    }
}
