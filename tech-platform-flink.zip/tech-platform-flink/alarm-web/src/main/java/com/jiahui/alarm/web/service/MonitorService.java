package com.jiahui.alarm.web.service;

import com.jiahui.alarm.base.common.ConfigKey;
import com.jiahui.alarm.base.util.DateUtil;
import org.redisson.api.RedissonClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

@Service
public class MonitorService {

    @Autowired
    private RedissonClient redissonClient;


    private static final Logger logger = LoggerFactory.getLogger(MonitorService.class);

    /**
     * 获取发送队列状态
     *
     * @return 各个队列的大小
     */
    public Map<String, Integer> getQueueStatus() {
        try {
            Map<String, Integer> queueStatus = new HashMap<>();

            queueStatus.put("mail", redissonClient.getBlockingQueue(ConfigKey.MAIL_QUEUE.value()).size());
            queueStatus.put("sms", redissonClient.getBlockingQueue(ConfigKey.SMS_QUEUE.value()).size());
            queueStatus.put("dingTalk", redissonClient.getBlockingQueue(ConfigKey.DING_TALK_QUEUE.value()).size());
            return queueStatus;
        } catch (Exception e) {
            logger.error("get queue status error, caused by", e);
            return Collections.emptyMap();
        }
    }

    /**
     * 获取当前系统处理请求的总量
     *
     * @return 请求总量
     */
    public long getTotalRequestQuantity() {
        try {
            return redissonClient.getAtomicLong(ConfigKey.TOTAL_REQUEST_QUANTITY.value()).get();
        } catch (Exception e) {
            logger.error("get system throughput error, caused by", e);
            return 0;
        }
    }

    /**
     * 获取各个发送端的发送量
     */
    public Map<String, String> getPushQuantity() {
        Map<String, String> sendingQuantity = new HashMap<>();
        Calendar calendar = Calendar.getInstance();
        String today = DateUtil.formatDate(DateUtil.YYYYMMDD, calendar.getTime());
        calendar.add(Calendar.DAY_OF_YEAR, -1);
        String yesterday = DateUtil.formatDate(DateUtil.YYYYMMDD, calendar.getTime());

        try {
            sendingQuantity.put("mail_today", redissonClient.getAtomicLong(ConfigKey.MAIL_PUSH_DAILY.value().replace("{date}", today)).get() + "");
            sendingQuantity.put("sms_today", redissonClient.getAtomicLong(ConfigKey.SMS_PUSH_DAILY.value().replace("{date}", today)).get() + "");
            sendingQuantity.put("dingTalk_today", redissonClient.getAtomicLong(ConfigKey.DING_TALK_PUSH_DAILY.value().replace("{date}", today)).get() + "");

            sendingQuantity.put("mail_yesterday", redissonClient.getAtomicLong(ConfigKey.MAIL_PUSH_DAILY.value().replace("{date}", yesterday)).get() + "");
            sendingQuantity.put("sms_yesterday", redissonClient.getAtomicLong(ConfigKey.SMS_PUSH_DAILY.value().replace("{date}", yesterday)).get() + "");
            sendingQuantity.put("dingTalk_yesterday", redissonClient.getAtomicLong(ConfigKey.DING_TALK_PUSH_DAILY.value().replace("{date}", yesterday)).get() + "");

            sendingQuantity.put("mail_total", redissonClient.getAtomicLong(ConfigKey.MAIL_PUSH_QUANTITY.value()).get() + "");
            sendingQuantity.put("sms_total", redissonClient.getAtomicLong(ConfigKey.SMS_PUSH_QUANTITY.value()).get() + "");
            sendingQuantity.put("dingTalk_total", redissonClient.getAtomicLong(ConfigKey.DING_TALK_PUSH_QUANTITY.value()).get() + "");

            return sendingQuantity;
        } catch (Exception e) {
            logger.error("get system throughput error, caused by", e);
            return Collections.emptyMap();
        }
    }
}
