package com.jiahui.alarm.web.vo;

/**
 * Created by caijt on 2017/3/26.
 */
public class AlarmConfig {
    private boolean freq_limit;
    private boolean sms;
    private boolean mail;
    private boolean dingTalk;

    public boolean isFreq_limit() {
        return freq_limit;
    }

    public void setFreq_limit(boolean freq_limit) {
        this.freq_limit = freq_limit;
    }

    public boolean isSms() {
        return sms;
    }

    public void setSms(boolean sms) {
        this.sms = sms;
    }

    public boolean isMail() {
        return mail;
    }

    public void setMail(boolean mail) {
        this.mail = mail;
    }

    public boolean isDingTalk() {
        return dingTalk;
    }

    public void setDingTalk(boolean dingTalk) {
        this.dingTalk = dingTalk;
    }
}
