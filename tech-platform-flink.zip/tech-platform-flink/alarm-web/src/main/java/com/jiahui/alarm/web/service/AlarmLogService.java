package com.jiahui.alarm.web.service;

import com.jiahui.alarm.base.entity.AlarmLog;
import com.jiahui.alarm.web.dao.AlarmLogDao;
import com.jiahui.alarm.web.vo.AlarmLogSearch;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AlarmLogService {

    @Autowired
    private AlarmLogDao alarmLogDao;

    public List<AlarmLog> getLogList(AlarmLogSearch alarmLogSearch) {
        if (alarmLogSearch.getCode() != null) {
            return alarmLogDao.getLogByCode(alarmLogSearch);
        } else if (alarmLogSearch.getAlarmName() != null) {
            return alarmLogDao.getLogByAlarmName(alarmLogSearch);
        } else if (alarmLogSearch.getProjectName() != null) {
            return alarmLogDao.getLogByProjectName(alarmLogSearch);
        } else {
            return alarmLogDao.getLog(alarmLogSearch);
        }
    }

    public int getLogCount(AlarmLogSearch alarmLogSearch) {
        if (alarmLogSearch.getCode() != null) {
            return alarmLogDao.getLogCountByCode(alarmLogSearch);
        } else if (alarmLogSearch.getAlarmName() != null) {
            return alarmLogDao.getLogCountByAlarmName(alarmLogSearch);
        } else if (alarmLogSearch.getProjectName() != null) {
            return alarmLogDao.getLogCountByProjectName(alarmLogSearch);
        }
        return alarmLogDao.getLogCount();
    }
}
