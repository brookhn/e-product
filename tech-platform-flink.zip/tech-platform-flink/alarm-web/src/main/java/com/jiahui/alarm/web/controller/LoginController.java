package com.jiahui.alarm.web.controller;

import com.alibaba.fastjson.JSON;
import com.jiahui.alarm.base.entity.User;
import com.jiahui.alarm.base.entity.UserTypeEnum;
import com.jiahui.alarm.web.common.ResponseHelper;
import com.jiahui.alarm.web.vo.LoginForm;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

/**
 * 登录/注销API
 */
@RestController
public class LoginController extends BaseController {

    @RequestMapping(value = "/login", method = RequestMethod.POST)
    public String login(HttpServletRequest request, @RequestBody LoginForm loginForm) {
        logger.info("POST /login, loginForm:{}", JSON.toJSONString(loginForm));

        User user = userService.getUserByAccount(loginForm.getUsername());

        // 管理员或普通用户才能登陆
        if (user != null && (UserTypeEnum.ADMIN_USER.value().equals(user.getType())
                || UserTypeEnum.NORMAL_USER.value().equals(user.getType()))) {
            // TODO 接入到运维系统，进行密码校验
            userLoginStatusService.addLoginStatus(request, user.getIdentification());
            return ResponseHelper.buildResponse(2000, "status", "success");
        }
        return ResponseHelper.buildResponse(4004, "reason", "invalid username or password");
    }

    @RequestMapping(value = "/logout", method = RequestMethod.POST)
    public String logout(HttpServletRequest request) {
        logger.info("POST /logout");
        userLoginStatusService.removeLoginStatus(request);
        return ResponseHelper.buildResponse(2000);
    }
}
