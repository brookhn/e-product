package com.jiahui.alarm.web.controller;

import com.alibaba.fastjson.JSON;
import com.jiahui.alarm.web.service.MonitorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

@RestController
@RequestMapping("monitor")
public class MonitorController {

    @Autowired
    private MonitorService monitorService;

    @RequestMapping(value = "/queues/status", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public String getQueueStatus(HttpServletRequest request) {
        Map<String, Integer> queueStatus = monitorService.getQueueStatus();
        return JSON.toJSONString(queueStatus);
    }

    @RequestMapping(value = "/request/quantity", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public String getServerThroughput(HttpServletRequest request) {
        long quantity = monitorService.getTotalRequestQuantity();
        return "{\"quantity\":" + quantity + "}";
    }

    @RequestMapping(value = "/sending/quantity", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public String getPushQuantity(HttpServletRequest request) {
        Map<String, String> sendingQuantity = monitorService.getPushQuantity();
        return JSON.toJSONString(sendingQuantity);
    }
}
